"""V1 strategy namespace."""

