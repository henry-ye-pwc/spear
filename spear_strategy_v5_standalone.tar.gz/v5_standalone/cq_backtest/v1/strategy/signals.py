"""V1 signal exports."""

from cq_backtest.strategy.signals import detect_all

__all__ = ["detect_all"]

