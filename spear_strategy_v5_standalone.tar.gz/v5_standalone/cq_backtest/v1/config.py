"""V1-compatible strategy config exports."""

from cq_backtest.config import STRATEGY_CONFIG

__all__ = ["STRATEGY_CONFIG"]

