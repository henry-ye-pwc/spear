"""V1 counterfactual adapters."""

