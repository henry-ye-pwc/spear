"""
settings.toml 加载器

单一入口加载配置文件, 供 config.py / counterfactual / run.py 共用。
优先级: CLI args > settings.toml > 代码内 defaults
"""

from __future__ import annotations

import os
import tomllib
from pathlib import Path
from typing import Any, Dict, Optional


_PROJECT_ROOT = Path(__file__).resolve().parents[1]
_DEFAULT_PATH = _PROJECT_ROOT / 'settings.toml'
_cached: Optional[Dict[str, Any]] = None


def load(path: Optional[str] = None, *, reload: bool = False) -> Dict[str, Any]:
    """Load and cache the TOML config. Returns empty dict on missing file."""
    global _cached
    if _cached is not None and not reload:
        return _cached

    p = Path(path) if path else _DEFAULT_PATH
    if not p.exists():
        _cached = {}
        return _cached

    with open(p, 'rb') as f:
        _cached = tomllib.load(f)
    return _cached


def get_section(section: str, default: Optional[Dict] = None) -> Dict[str, Any]:
    """Dot-path section access: get_section('counterfactual.gate_break')"""
    cfg = load()
    obj = cfg
    for part in section.split('.'):
        if isinstance(obj, dict):
            obj = obj.get(part, {})
        else:
            return default or {}
    return obj if isinstance(obj, dict) else (default or {})


def get(key: str, default: Any = None) -> Any:
    """Dot-path value access: get('run.pool', 300)"""
    cfg = load()
    obj = cfg
    parts = key.split('.')
    for part in parts[:-1]:
        if isinstance(obj, dict):
            obj = obj.get(part, {})
        else:
            return default
    if isinstance(obj, dict):
        return obj.get(parts[-1], default)
    return default


def get_strategy_config() -> Dict[str, Any]:
    """Build STRATEGY_CONFIG dict from [strategy.*] sections (backward-compatible)."""
    cfg = load()
    return cfg.get('strategy', {})


def get_run_config() -> Dict[str, Any]:
    """Get [run] section."""
    cfg = load()
    return cfg.get('run', {})


def get_counterfactual_config() -> Dict[str, Any]:
    """Get [counterfactual] section."""
    cfg = load()
    return cfg.get('counterfactual', {})
