"""
CQ 量价回测 — 策略配置
数据源: mootdx (通达信)
回测引擎: 自建 (无外部依赖)
"""

import os
import time
import json
import pickle
import re
import numpy as np
import pandas as pd
from collections import defaultdict
from datetime import datetime, timedelta
from dataclasses import dataclass, field
from typing import List, Dict, Optional, Tuple
from mootdx.quotes import Quotes
from mootdx.reader import Reader

# ============================================================
# 策略全局配置 (Pluggable Configs)
# 默认值定义在此处; settings.toml 中的同名 key 会覆盖
# ============================================================
_STRATEGY_DEFAULTS = {
    # 主力出货过滤: VR 极端放大时视为出货信号而非洗盘/突破
    "filter_true_bear": {
        "enabled": True,       # 是否开启真熊巨量过滤
        "vr20_threshold": 3.1, # 相对20日均量的量比阈值 (测试显示真熊平均3.18，洗盘平均2.39)
        "body_threshold": 4.5, # 实体长度阈值(%)，真熊波动剧烈平均>5%
        "positions": ["HIGH", "UP", "SIDE"] # 在哪些位置生效 (低位爆量可能是吸筹，中高位爆量是出货)
    },
    "filter_lhb_net_sell": {
        "enabled": True,       # 是否开启龙虎榜净卖出过滤
        "lookback_days": 5     # 检查入场前几天的龙虎榜
    },
    # V3 终极版配置
    "filter_up_low_conf": {
        "enabled": True,
        "conf_threshold": 0.74 # UP位置且信心<=该值直接过滤
    },
    "trailing_stop_mfe_protect": {
        "enabled": True,
        "mfe_threshold": 5.0,  # MFE达到多少(%)时触发保护
        "new_stop_loss_pct": -2.0 # 触发保护后，新的止损线(相对于成本价的%)
    },
    "dynamic_trailing_tp_conditions": {
        "enabled": True,
        "mfe_exempt_threshold": 10.0, # MFE小于该值(%)时，可能豁免阶梯止盈
        "speed_exempt_threshold": 2.0 # 涨速(MFE/持仓天数)小于该值(%/天)时，豁免阶梯止盈(防洗盘)
    },
    "position_sizing_by_pos": {
        "enabled": True,
        "side_multiplier": 1.5, # SIDE位置仓位倍率
        "up_multiplier": 0.7    # UP位置仓位倍率
    },
    "false_breakdown_buyback": {
        "enabled": False,
        "watch_days": 5
    },
    # ── 入场确认改造 (R0/R1/R2) ──
    "entry_confirm_v2": {
        "enabled": False,        # 总开关: True 启用 R0/R1/R2 全部改造
        "r0_breakout_confirm": {
            "enabled": True,
            "types": ["趋势", "进攻"],
            "min_days_above_gate": 2,
            "sizing_multiplier": 0.5,
        },
        "r1_defer_below_gate": {
            "enabled": True,
            "extra_ttl": 5,
            "sizing_multiplier": 0.4,
            "exit_gate_extra_tolerance_pct": 2.0,
        },
        "r2_banhou_intraday_touch": {
            "enabled": True,
            "require_close_recovery": True,
            "recovery_tolerance_pct": 1.5,
            "sizing_multiplier": 0.7,
        },
    },
    # ── Regime filter (行情过滤层) ──
    "regime_filter": {
        "enabled": False,
        "index": "000001",
        "method": "ma",
        "ma_period": 20,
        "risk_off_disable_alt_paths": True,
        "risk_off_sizing_scale": 0.3,
    },
    # ── V3 Final 插拔式规则 (默认关闭，开启后替代对应的原规则) ──
    "quality_scoring": {
        "enabled": True,       # True=V3几何平均质量分, False=走原filter_up_low_conf+position_sizing_by_pos
        "factors": {
            "confidence": {"min": 0.70, "max": 0.82},
            "upper_shadow": {
                "board": {"best": 3.0, "worst": 7.0},
                "trend": {"best": 3.0, "worst": 8.0},
            },
            "vr": {
                "board": {"center": 2.0, "half_width": 2.5},
                "trend": {"center": 1.15, "half_width": 1.5},
            },
            "position": {"SIDE": 1.0, "LOW": 0.6, "DOWN": 0.5, "UP": 0.4},
        },
        "pos_size_base": 0.3,
        "pos_size_scale": 1.2,
    },
    "adaptive_gate_tolerance": {
        "enabled": True,       # True=V3自适应城门容忍度, False=走原按枪型固定容忍度
        "base_tolerance_pct": 2.0,
        "max_extra_tolerance_pct": 3.0,
    },
    "trailing_tp_exemption": {
        "enabled": True,       # True=V3双条件并集豁免, False=走原dynamic_trailing_tp_conditions
        "mfe_ceiling_pct": 10.0,
        "slow_rise_max_speed": 2.5,
        "slow_rise_max_pullback": 2.0,
        "trend_min_consecutive_up": 3,
        "trend_max_pullback_ratio": 0.5,
    },
}


def _deep_merge(base: dict, override: dict) -> dict:
    """Recursively merge override into base (override wins)."""
    out = base.copy()
    for k, v in override.items():
        if k in out and isinstance(out[k], dict) and isinstance(v, dict):
            out[k] = _deep_merge(out[k], v)
        else:
            out[k] = v
    return out


def _load_strategy_config() -> dict:
    """Build STRATEGY_CONFIG: defaults ← settings.toml overrides."""
    try:
        from cq_backtest.settings_loader import get_strategy_config
        toml_overrides = get_strategy_config()
        if toml_overrides:
            return _deep_merge(_STRATEGY_DEFAULTS, toml_overrides)
    except Exception:
        pass
    return _STRATEGY_DEFAULTS.copy()


STRATEGY_CONFIG = _load_strategy_config()


# ============================================================
# 一、数据层 — mootdx 封装
# ============================================================

