from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path

from cq_backtest.shared.utils import ensure_dir, stable_hash


def snapshot_configs(outdir: str | Path, config_files: dict[str, str]) -> dict[str, str]:
    """
    Copy config files into outdir/config_snapshot and return hash map.
    """
    root = ensure_dir(Path(outdir) / "config_snapshot")
    hashes: dict[str, str] = {}
    for key, path in config_files.items():
        src = Path(path)
        if not src.exists():
            continue
        text = src.read_text(encoding="utf-8")
        h = stable_hash(text)
        hashes[key] = h
        dst = root / f"{key}.yaml"
        dst.write_text(text, encoding="utf-8")
    return hashes


def write_manifest(
    outdir: str | Path,
    *,
    args: dict,
    config_hashes: dict[str, str],
    universe_stats: dict,
    event_stats: dict,
    summary: dict,
) -> str:
    payload = {
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "args": args,
        "config_hashes": config_hashes,
        "universe_stats": universe_stats,
        "event_stats": event_stats,
        "summary": summary,
    }
    payload["run_hash"] = stable_hash(payload)
    Path(outdir).mkdir(parents=True, exist_ok=True)
    path = Path(outdir) / "manifest.json"
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    return payload["run_hash"]

