from __future__ import annotations

import pandas as pd


def to_trade_ts(value: str | pd.Timestamp) -> pd.Timestamp:
    return pd.Timestamp(value).normalize()


def next_trade_day(trade_days: pd.DatetimeIndex, day: str | pd.Timestamp) -> pd.Timestamp | None:
    day = to_trade_ts(day)
    later = trade_days[trade_days > day]
    if len(later) == 0:
        return None
    return pd.Timestamp(later[0]).normalize()

