from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Iterable

import numpy as np
import pandas as pd


def rolling_zscore(series: pd.Series, window: int) -> pd.Series:
    mean = series.rolling(window, min_periods=max(5, window // 4)).mean()
    std = series.rolling(window, min_periods=max(5, window // 4)).std().replace(0.0, np.nan)
    return (series - mean) / std


def pct_change_safe(series: pd.Series, periods: int = 1) -> pd.Series:
    base = series.shift(periods).replace(0, np.nan)
    return (series / base) - 1.0


def ensure_dir(path: str | Path) -> Path:
    p = Path(path)
    p.mkdir(parents=True, exist_ok=True)
    return p


def stable_hash(payload: dict | list | tuple | str) -> str:
    if isinstance(payload, str):
        buf = payload.encode("utf-8")
    else:
        buf = json.dumps(payload, sort_keys=True, ensure_ascii=True, default=str).encode("utf-8")
    return hashlib.sha256(buf).hexdigest()[:16]


def quantile_bucket(values: Iterable[float], q1: float, q2: float, q3: float) -> list[str]:
    arr = np.asarray(list(values), dtype=float)
    if arr.size == 0:
        return []
    a = np.nanquantile(arr, q1)
    b = np.nanquantile(arr, q2)
    c = np.nanquantile(arr, q3)
    out: list[str] = []
    for v in arr:
        if np.isnan(v):
            out.append("unknown")
        elif v <= a:
            out.append("q1")
        elif v <= b:
            out.append("q2")
        elif v <= c:
            out.append("q3")
        else:
            out.append("q4")
    return out

