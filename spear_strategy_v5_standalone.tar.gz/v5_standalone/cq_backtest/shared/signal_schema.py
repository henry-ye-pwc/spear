from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass(slots=True)
class SignalEventV2:
    event_type: str
    symbol: str
    ts: str
    confidence: float
    side: str
    tags: list[str] = field(default_factory=list)
    entry_plan: dict[str, Any] = field(default_factory=dict)
    invalidation: dict[str, Any] = field(default_factory=dict)
    exit_plan: dict[str, Any] = field(default_factory=dict)
    context: dict[str, Any] = field(default_factory=dict)

