from __future__ import annotations

from dataclasses import dataclass


def round_to_tick(price: float, tick: float = 0.01) -> float:
    units = round(price / tick)
    return round(units * tick, 2)


def infer_board(symbol: str) -> str:
    if symbol.startswith(("300", "301")):
        return "gem"
    if symbol.startswith(("688", "689")):
        return "star"
    if symbol.startswith(("8", "4")):
        return "bj"
    return "main"


def limit_pct(symbol: str, is_st: bool = False) -> float:
    if is_st:
        return 0.05
    board = infer_board(symbol)
    if board in {"gem", "star"}:
        return 0.20
    if board == "bj":
        return 0.30
    return 0.10


@dataclass(slots=True)
class LimitPrices:
    up: float
    down: float


def calc_limit_prices(prev_close: float, symbol: str, is_st: bool = False, tick: float = 0.01) -> LimitPrices:
    lp = limit_pct(symbol, is_st=is_st)
    up = round_to_tick(prev_close * (1 + lp), tick=tick)
    down = round_to_tick(prev_close * (1 - lp), tick=tick)
    return LimitPrices(up=up, down=down)


def can_buy_strict(px: float, limit_up: float) -> bool:
    return px < limit_up


def can_sell_strict(px: float, limit_down: float) -> bool:
    return px > limit_down

