from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any


@dataclass(slots=True)
class Bar:
    symbol: str
    ts: datetime
    open: float
    high: float
    low: float
    close: float
    volume: float
    amount: float | None = None


@dataclass(slots=True)
class Event:
    event_id: str
    symbol: str
    event_ts: datetime
    event_type: str
    gun_type: str = "unknown"
    features: dict[str, float] = field(default_factory=dict)


@dataclass(slots=True)
class Signal:
    signal_id: str
    symbol: str
    signal_ts: datetime
    event_id: str
    probs: dict[str, float]
    policy_id: str


@dataclass(slots=True)
class Order:
    order_id: str
    symbol: str
    side: str
    qty: float
    submit_ts: datetime
    meta: dict[str, Any] = field(default_factory=dict)


@dataclass(slots=True)
class Fill:
    order_id: str
    symbol: str
    side: str
    qty: float
    fill_price: float | None
    fill_ts: datetime
    fillable: bool
    reason: str = "ok"


@dataclass(slots=True)
class Position:
    symbol: str
    qty: float
    entry_price: float
    entry_ts: datetime
    policy_id: str
    meta: dict[str, Any] = field(default_factory=dict)


@dataclass(slots=True)
class PolicyDecision:
    policy_id: str
    p_wash: float
    p_dist: float
    p_neutral: float
    context: dict[str, float] = field(default_factory=dict)

