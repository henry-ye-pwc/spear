from __future__ import annotations

from typing import Protocol

import pandas as pd


class DataProvider(Protocol):
    """Provider contract for data ingestion."""

    name: str

    def fetch_daily(self, symbol: str, start: str, end: str) -> pd.DataFrame:
        ...

    def fetch_minute(self, symbol: str, start: str, end: str, freq: str = "1m") -> pd.DataFrame:
        ...

    def fetch_universe(self) -> pd.DataFrame:
        ...

