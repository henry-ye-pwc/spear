"""Shared reusable layer for strategy versions."""

from cq_backtest.shared.calendar import next_trade_day, to_trade_ts
from cq_backtest.shared.experiment import snapshot_configs, write_manifest
from cq_backtest.shared.feature_primitives import anchored_vwap, half_sample_mode, rolling_mad, rolling_rank_pct
from cq_backtest.shared.logging import get_logger
from cq_backtest.shared.market_rules import (
    LimitPrices,
    calc_limit_prices,
    can_buy_strict,
    can_sell_strict,
    infer_board,
    limit_pct,
    round_to_tick,
)
from cq_backtest.shared.providers import DataProvider
from cq_backtest.shared.signal_schema import SignalEventV2
from cq_backtest.shared.types import Bar, Event, Fill, Order, PolicyDecision, Position, Signal
from cq_backtest.shared.utils import ensure_dir, pct_change_safe, quantile_bucket, rolling_zscore, stable_hash

__all__ = [
    "rolling_rank_pct",
    "rolling_mad",
    "half_sample_mode",
    "anchored_vwap",
    "rolling_zscore",
    "pct_change_safe",
    "ensure_dir",
    "stable_hash",
    "quantile_bucket",
    "snapshot_configs",
    "write_manifest",
    "to_trade_ts",
    "next_trade_day",
    "get_logger",
    "Bar",
    "Event",
    "Signal",
    "Order",
    "Fill",
    "Position",
    "PolicyDecision",
    "DataProvider",
    "SignalEventV2",
    "round_to_tick",
    "infer_board",
    "limit_pct",
    "LimitPrices",
    "calc_limit_prices",
    "can_buy_strict",
    "can_sell_strict",
]
