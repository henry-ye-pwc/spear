from __future__ import annotations

import numpy as np
import pandas as pd

try:
    from numba import njit
    _HAS_NUMBA = True
except ImportError:
    _HAS_NUMBA = False

# ---------------------------------------------------------------------------
# Numba kernels — verified bit-identical to the pandas rolling().apply() path.
# Numba's np.median does NOT propagate NaN like numpy, so _rolling_mad_nb
# checks explicitly and returns NaN when any NaN is present in the window.
# ---------------------------------------------------------------------------
if _HAS_NUMBA:
    @njit
    def _rolling_rank_pct_nb(arr, window, min_periods):
        n = len(arr)
        out = np.empty(n)
        out[:] = np.nan
        for i in range(n):
            start = max(0, i - window + 1)
            cnt = i - start + 1
            valid = 0
            for j in range(start, i + 1):
                if not np.isnan(arr[j]):
                    valid += 1
            if valid < min_periods:
                continue
            val = arr[i]
            le_count = 0
            for j in range(start, i + 1):
                if arr[j] <= val:
                    le_count += 1
            out[i] = le_count / cnt
        return out

    @njit
    def _rolling_mad_nb(arr, window, min_periods):
        n = len(arr)
        out = np.empty(n)
        out[:] = np.nan
        for i in range(n):
            start = max(0, i - window + 1)
            cnt = i - start + 1
            has_nan = False
            valid = 0
            for j in range(start, i + 1):
                if np.isnan(arr[j]):
                    has_nan = True
                else:
                    valid += 1
            if valid < min_periods:
                continue
            if has_nan:
                continue
            w = arr[start:i + 1].copy()
            med = np.median(w)
            out[i] = np.median(np.abs(w - med))
        return out


def rolling_rank_pct(series: pd.Series, window: int) -> pd.Series:
    min_periods = max(10, window // 3)
    if _HAS_NUMBA:
        result = _rolling_rank_pct_nb(
            series.to_numpy(dtype=float), window, min_periods,
        )
        return pd.Series(result, index=series.index)

    def rank_last(x: np.ndarray) -> float:
        if len(x) == 0:
            return np.nan
        return float((x <= x[-1]).sum() / len(x))

    return series.rolling(window, min_periods=min_periods).apply(rank_last, raw=True)


def rolling_mad(series: pd.Series, window: int) -> pd.Series:
    min_periods = max(10, window // 3)
    if _HAS_NUMBA:
        result = _rolling_mad_nb(
            series.to_numpy(dtype=float), window, min_periods,
        )
        return pd.Series(result, index=series.index)

    def mad_fn(x: np.ndarray) -> float:
        med = np.median(x)
        return float(np.median(np.abs(x - med)))

    return series.rolling(window, min_periods=min_periods).apply(mad_fn, raw=True)


def half_sample_mode(values: pd.Series | np.ndarray) -> float:
    arr = np.asarray(values, dtype=float)
    arr = arr[np.isfinite(arr)]
    if arr.size == 0:
        return 0.0
    arr = np.sort(arr)
    n = arr.size
    if n < 4:
        return float(np.median(arr))

    half_n = n // 2
    min_width = float("inf")
    best_idx = 0
    for i in range(n - half_n + 1):
        width = arr[i + half_n - 1] - arr[i]
        if width < min_width:
            min_width = width
            best_idx = i
    dense_core = arr[best_idx : best_idx + half_n]
    return float(np.median(dense_core))


def anchored_vwap(frame: pd.DataFrame, anchor_idx: int, price_col: str = "vwap_proxy") -> float:
    if anchor_idx < 0 or anchor_idx >= len(frame):
        return float("nan")
    sub = frame.iloc[anchor_idx:]
    amount = pd.to_numeric(sub.get("amount", pd.Series(dtype=float)), errors="coerce").fillna(0.0)
    volume = pd.to_numeric(sub.get("volume", pd.Series(dtype=float)), errors="coerce").replace(0.0, np.nan)
    price = pd.to_numeric(sub[price_col], errors="coerce")
    if float(amount.sum()) > 0:
        return float((price * amount).sum() / amount.sum())
    if volume.notna().any():
        return float((price * volume).sum() / volume.sum())
    return float("nan")
