import os, json, pandas as pd, numpy as np, time
from datetime import datetime
from collections import defaultdict
from cq_backtest.engine.portfolio import Trade, Portfolio, RiskProfile, get_optimal_exits, calc_stop
from cq_backtest.strategy.signals import detect_all
from cq_backtest.data.feed import DataFeed, prepare_kline
from cq_backtest.config import STRATEGY_CONFIG

from typing import Optional, List, Dict, Tuple
class Backtester:
    """
    本地回测引擎
    模拟 JQ 的 lifecycle hooks:
      pre_open → morning_check → midday → eod_trade → post_close
    """

    def __init__(self, data_feed: DataFeed, profile: RiskProfile = None,
                 disabled_types: Optional[set] = None,
                 max_positions: int = 4,
                 pos_pct: float = 0.25,
                 init_cash: float = 100000,
                 sizing_mode: str = 'fixed',
                 detail_mode: str = 'verbose'):
        self.feed = data_feed
        self.max_positions_cfg = max_positions
        self.pos_pct_cfg = pos_pct
        self.init_cash_cfg = init_cash
        self.sizing_mode = sizing_mode  # fixed | dynamic
        self.detail_mode = (detail_mode or 'verbose').strip().lower()
        self.portfolio = Portfolio(
            cash=init_cash,
            max_positions=max_positions,
            pos_pct=pos_pct,
        )
        self.profile = profile or RiskProfile.balanced()
        self.disabled_types = set(disabled_types or [])
        self.cooldown = {}
        self.signals = {}
        self.candidates = []
        self.watchlist = {}
        self.buyback_watch = {}
        self.pool_size = 300
        self._prepared_cache = {}
        self._prepared_req = {}
        self._name_cache = {}
        self.fill_mode = 'close'  # close | optimistic
        self.kline_lookback_bars = 700
        self.stats = self._fresh_stats()
        self.signal_journal = []
        self.run_meta = {}
        self.run_id = ''
        self.last_report_paths = {}
        self.export_trade_windows = self.detail_mode in ('verbose', 'full')

    def _fresh_stats(self):
        return {
            'total_signals': 0,
            'signal_by_type': {},
            'immediate_eligible': 0,
            'immediate_bought': 0,
            'watchlist_added': 0,
            'watchlist_confirmed': 0,
            'watchlist_bought': 0,
            'watch_expired': 0,
            'reject_reasons': {},
            'exit_reasons': {},
            'entry_modes': {},
            'buy_by_type': {},
            'disabled_by_type': {},
            'size_tiers': {},
            'preload_total': 0,
            'preload_mem_hit': 0,
            'preload_disk_hit': 0,
            'preload_rebuilt': 0,
            'regime_days': {'risk_on': 0, 'risk_off': 0},
        }

    def _reset_runtime(self):
        """Reset runtime state so repeated runs don't contaminate each other."""
        self.portfolio = Portfolio(
            cash=self.init_cash_cfg,
            max_positions=self.max_positions_cfg,
            pos_pct=self.pos_pct_cfg,
        )
        self.cooldown = {}
        self.signals = {}
        self.watchlist = {}
        self.buyback_watch = {}
        self.stats = self._fresh_stats()
        self.signal_journal = []
        self.last_report_paths = {}
        self._regime = 'risk_on'
        self.lhb_data = None
        
        lhb_cfg = STRATEGY_CONFIG.get('filter_lhb_net_sell', {})
        if lhb_cfg.get('enabled', False):
            lhb_cache_file = 'output/lhb_cache.csv'
            if os.path.exists(lhb_cache_file):
                try:
                    df = pd.read_csv(lhb_cache_file)
                    df['上榜日'] = pd.to_datetime(df['上榜日'])
                    df['代码'] = df['代码'].astype(str).str.zfill(6)
                    # We only care about net sell. If 龙虎榜净买额 is negative, it's a net sell.
                    # We index it by code and date for fast lookup.
                    df = df[['代码', '上榜日', '龙虎榜净买额']]
                    self.lhb_data = df
                    print(f"  已加载龙虎榜缓存，共 {len(self.lhb_data)} 条记录")
                except Exception as e:
                    print(f"  加载龙虎榜缓存失败: {e}")
            else:
                print("  未找到龙虎榜缓存文件 output/lhb_cache.csv，龙虎榜过滤将失效。")

    def _prepared_cache_file(self, code: str) -> str:
        return os.path.join(self.feed.cache_dir, f'{code}_prepared.pkl')

    def _load_prepared_disk(self, code: str, end_date: str):
        cache_file = self._prepared_cache_file(code)
        if not os.path.exists(cache_file):
            return None
        try:
            payload = pd.read_pickle(cache_file)
        except Exception:
            return None

        df = payload
        raw_mtime_saved = None
        requested_count = 0
        payload_is_dict = isinstance(payload, dict)
        if payload_is_dict:
            df = payload.get('df')
            raw_mtime_saved = payload.get('raw_mtime')
            requested_count = int(payload.get('requested_count', 0) or 0)
        if df is None or df.empty:
            return None

        if not payload_is_dict:
            # Legacy cache format without metadata: only reuse when length
            # already satisfies current lookback request.
            if len(df) < self.kline_lookback_bars:
                return None
            requested_count = len(df)

        # If this prepared cache was built for a smaller lookback window,
        # rebuild to avoid silently truncating historical context.
        if requested_count > 0 and requested_count < self.kline_lookback_bars:
            return None

        raw_file = os.path.join(self.feed.cache_dir, f'{code}_full.pkl')
        if raw_mtime_saved is not None and os.path.exists(raw_file):
            try:
                raw_mtime_now = os.path.getmtime(raw_file)
                if raw_mtime_now - float(raw_mtime_saved) > 1e-6:
                    return None
            except Exception:
                return None

        if end_date and not self.feed._cache_covers_end_date(df, end_date):
            return None
        return df.sort_index(), max(requested_count, self.kline_lookback_bars)

    def _save_prepared_disk(self, code: str, df: pd.DataFrame, requested_count: int):
        if df is None or df.empty:
            return
        cache_file = self._prepared_cache_file(code)
        raw_file = os.path.join(self.feed.cache_dir, f'{code}_full.pkl')
        raw_mtime = None
        if os.path.exists(raw_file):
            try:
                raw_mtime = os.path.getmtime(raw_file)
            except Exception:
                raw_mtime = None
        payload = {
            'df': df,
            'raw_mtime': raw_mtime,
            'requested_count': int(requested_count),
            'saved_at': time.time(),
        }
        try:
            pd.to_pickle(payload, cache_file)
        except Exception:
            pass

    def _slice_to_date(self, df: pd.DataFrame, date_like):
        if df is None or df.empty:
            return None
        ts = date_like if isinstance(date_like, pd.Timestamp) else pd.Timestamp(date_like)
        pos = int(df.index.searchsorted(ts, side='right'))
        if pos <= 0:
            return None
        return df.iloc[:pos]

    def _calc_lookback_bars(self, start_date: str, end_date: str) -> int:
        """
        Estimate how many daily bars are needed to fully cover backtest window.
        Keep a minimum warm-up for indicators and cap upper bound for performance.
        """
        try:
            days = max(1, (pd.Timestamp(end_date) - pd.Timestamp(start_date)).days)
        except Exception:
            return 700
        est_bars = int(days / 365.25 * 260) + 260
        return max(700, min(5000, est_bars))

    def run(self, start_date: str, end_date: str, pool_size: int = 300):
        """运行回测"""
        self._reset_runtime()
        self.pool_size = pool_size
        self.kline_lookback_bars = self._calc_lookback_bars(start_date, end_date)
        ts = datetime.now().strftime('%Y%m%d_%H%M%S')
        self.run_id = f'{self.profile.name}_{start_date}_{end_date}_{ts}'
        self.run_meta = {
            'profile': self.profile.name,
            'start_date': start_date,
            'end_date': end_date,
            'pool_size': pool_size,
            'run_id': self.run_id,
            'fill_mode': self.fill_mode,
            'disabled_types': sorted(list(self.disabled_types)),
            'max_positions': self.portfolio.max_positions,
            'pos_pct': self.portfolio.pos_pct,
            'sizing_mode': self.sizing_mode,
            'detail_mode': self.detail_mode,
            'kline_lookback_bars': self.kline_lookback_bars,
        }
        print('='*70)
        print(f'  CQ 量价回测  [{self.profile.name}]')
        print(f'  {start_date} → {end_date}  (池={pool_size})')
        print(f'  初始资金: {self.portfolio.cash:,.0f}')
        print(f'  仓位配置: max_positions={self.portfolio.max_positions} '
              f'pos_pct={self.portfolio.pos_pct:.2f} mode={self.sizing_mode}')
        if self.disabled_types:
            print(f'  禁用信号: {",".join(sorted(self.disabled_types))}')
        print('='*70)

        idx = self.feed.get_kline('000001', end_date, count=self.kline_lookback_bars)
        if idx.empty:
            print('❌ 无法获取上证指数数据')
            return

        trade_dates = [str(d)[:10] for d in idx.index
                       if start_date <= str(d)[:10] <= end_date]
        total = len(trade_dates)
        print(f'  共 {total} 个交易日')

        if total > 1:
            idx_win = idx[(idx.index >= pd.Timestamp(start_date)) & (idx.index <= pd.Timestamp(end_date))]
            if not idx_win.empty:
                b0 = float(idx_win.iloc[0]['close'])
                b1 = float(idx_win.iloc[-1]['close'])
                if b0 > 0:
                    self.run_meta['benchmark_return_pct'] = (b1 - b0) / b0 * 100
                    self.run_meta['benchmark_symbol'] = '000001'

        print('  预加载股票池...', end='', flush=True)
        self._preload_pool(start_date, end_date, trade_dates)
        print(f' {len(self._prepared_cache)}只股票已缓存\n')

        for i, today in enumerate(trade_dates):
            yesterday = trade_dates[i-1] if i > 0 else today
            print(f'\r  [{i+1}/{total}] {today}', end='', flush=True)
            self._run_day(today, yesterday)

        print()
        self._print_summary()
        self._export_analysis()
        if self.last_report_paths:
            print('\n  分析文件已导出:')
            print(f'    {self.last_report_paths["summary_json"]}')
            if self.last_report_paths.get('trade_windows_index_csv'):
                print(f'    {self.last_report_paths["trade_windows_index_csv"]}')
        return self.portfolio

    def _preload_pool(self, start_date, end_date, trade_dates):
        """Pre-fetch and prepare all candidate stock data once."""
        stock_list = self.feed.get_stock_list()
        if stock_list.empty:
            return

        codes = []
        if 'code' in stock_list.columns:
            codes = stock_list['code'].tolist()
        elif 'symbol' in stock_list.columns:
            codes = stock_list['symbol'].tolist()
        else:
            codes = stock_list.index.tolist()

        codes = [str(c).zfill(6) for c in codes]
        codes = [c for c in codes
                 if not c.startswith('688') and not c.startswith('8') and not c.startswith('4')
                 and (c.startswith('0') or c.startswith('3') or c.startswith('6'))]

        if len(codes) > self.pool_size:
            np.random.seed(42)
            codes = list(np.random.choice(codes, self.pool_size, replace=False))

        all_codes = ['000001'] + codes
        loaded = 0
        total_codes = len(all_codes)
        self.stats['preload_total'] = total_codes
        for i, code in enumerate(all_codes):
            if (i+1) % 20 == 0 or i == total_codes - 1:
                print(f'\r  预加载股票池... {i+1}/{total_codes}', end='', flush=True)
            try:
                cached = self._prepared_cache.get(code)
                cached_req = int(self._prepared_req.get(code, 0) or 0)
                if (cached is not None and not cached.empty and self.feed._cache_covers_end_date(cached, end_date)
                        and cached_req >= self.kline_lookback_bars):
                    loaded += 1
                    self.stats['preload_mem_hit'] += 1
                    continue

                disk_cached = self._load_prepared_disk(code, end_date)
                if disk_cached is not None:
                    df_disk, req_count = disk_cached
                    self._prepared_cache[code] = df_disk
                    self._prepared_req[code] = req_count
                    loaded += 1
                    self.stats['preload_disk_hit'] += 1
                    continue
                df = self.feed.get_kline(code, end_date, count=self.kline_lookback_bars)
                if df.empty or len(df) < 20:
                    continue
                df = prepare_kline(df, code)
                if df.empty:
                    continue
                self._prepared_cache[code] = df
                self._prepared_req[code] = self.kline_lookback_bars
                self._save_prepared_disk(code, df, self.kline_lookback_bars)
                loaded += 1
                self.stats['preload_rebuilt'] += 1
            except Exception as e:
                import traceback
                print(f"Error preloading {code}: {e}")
                traceback.print_exc()
                pass

    def _inc_stat(self, bucket, key, delta=1):
        d = self.stats.get(bucket, {})
        d[key] = d.get(key, 0) + delta
        self.stats[bucket] = d

    def _norm_reason(self, reason):
        if reason.startswith('止损'):
            return '止损'
        if '套利' in reason and '无溢价' in reason:
            return '套利无溢价'
        if reason.startswith('超时'):
            return '超时退出'
        if '止盈' in reason:
            return '硬止盈'
        if '逃命' in reason:
            return '逃命'
        if reason.startswith('套利次日破枪低'):
            return '套利破枪低'
        return reason

    def _clean_sig_type(self, sig_type):
        return str(sig_type).replace('⚠️', '').strip()

    def _is_disabled_type(self, sig_type):
        clean = self._clean_sig_type(sig_type)
        return clean in self.disabled_types

    def _log_signal_event(self, **kwargs):
        self.signal_journal.append(kwargs)

    def _entry_plan(self, sig):
        """按信号性质分配入场策略。"""
        sig_type = sig.get('type', '')
        plan = {'mode': 'watch', 'min_age': 1, 'max_age': 7, 'min_conf': 0.60}
        if '套利' in sig_type:
            # 套利类信号快进快出、确定性优先
            plan.update({'mode': 'immediate', 'min_age': 0, 'max_age': 3, 'min_conf': 0.64})
        elif sig_type in ('板后', '烂板'):
            # 板后长枪: 涨停后次日或未来 7 日内形成长枪
            plan.update({'mode': 'watch', 'min_age': 1, 'max_age': 7, 'min_conf': 0.60})
        elif sig_type in ('进攻', '趋势', '游资'):
            plan.update({'mode': 'watch', 'min_age': 1, 'max_age': 5, 'min_conf': 0.60})

        return plan

    def _hit_rate_gate(self, sig, plan=None, entry_mode=''):
        """
        Keep only model-faithful constraints.
        Do not use data-mined thresholds from specific years.
        """
        sig_type = str(sig.get('type', ''))
        conf = float(sig.get('conf', 0))
        mode = entry_mode or (plan or {}).get('mode', '')
        min_conf = float((plan or {}).get('min_conf', 0) or 0)
        
        # V3 终极版配置：UP位+低信心信号拦截
        qs_cfg = STRATEGY_CONFIG.get('quality_scoring', {})
        if not qs_cfg.get('enabled', False):
            # 原逻辑: 硬过滤 UP+低信心
            up_conf_cfg = STRATEGY_CONFIG.get('filter_up_low_conf', {})
            if up_conf_cfg.get('enabled', False):
                if sig.get('pos', '') == 'UP' and conf <= up_conf_cfg.get('conf_threshold', 0.74):
                    return False, 'up_low_conf'
        # quality_scoring 开启时不硬拒，由 _stake_ratio 中 geo 值控制仓位

        # 板后长枪上影线过长(>7%)统计上多为诱多或抛压过大，过滤
        if '板后' in sig_type and float(sig.get('shadow', 0)) >= 7.0:
            return False, 'banhou_long_shadow'
            
        # 张扬含蓄形态下突破日量能极度萎缩(vr<0.8)缺乏资金共鸣，过滤
        if sig.get('ctx_zhyx_ok', False) and float(sig.get('vr', 1.0)) < 0.8:
            return False, 'zhyx_low_vr'
            
        if conf < min_conf:
            return False, 'low_conf'
        if '套利' in sig_type and mode and mode != 'immediate':
            return False, 'arb_non_immediate'

        return True, 'ok'

    def _dynamic_size_ratio(self, sig, plan, px):
        """Dynamic stake sizing: 20% / 27% / 35% based on signal quality."""
        conf = float(sig.get('conf', 0))
        sig_type = str(sig.get('type', ''))
        cut = float(sig.get('cut', 0) or 0)
        close = float(px.get('close', 0) or 0)
        score = 0

        # Confidence contributes the most.
        if conf >= 0.82:
            score += 3
        elif conf >= 0.75:
            score += 2
        elif conf >= 0.70:
            score += 1

        # Immediate-route entries are generally stronger and timelier.
        if plan and plan.get('mode') == 'immediate':
            score += 1

        # Trend/attack/post-limit tend to have better continuation.
        if sig_type in ('趋势', '进攻'):
            score += 1
        if sig_type == '板后':
            score += 1
        if '套利' in sig_type:
            score += 1

        # Entries close to "城门" are generally lower slippage / better R.
        if cut > 0 and close > 0:
            rel = close / cut
            if 0.995 <= rel <= 1.02:
                score += 1
            elif rel > 1.08:
                score -= 1

        # Candle strength adjusts final confidence.
        o = float(px.get('open', 0) or 0)
        if o > 0 and close < o * 0.995:
            score -= 1
        elif o > 0 and close > o * 1.01:
            score += 1

        # Raise high-tier hit rate while keeping a floor stake.
        if score >= 3:
            return 0.35, 'high'
        if score >= 1:
            return 0.27, 'mid'
        return 0.20, 'low'

    def _compute_geo_quality(self, sig):
        """V3 quality_scoring: 4-factor geometric mean -> [0, 1]."""
        cfg = STRATEGY_CONFIG.get('quality_scoring', {})
        factors = cfg.get('factors', {})
        sig_type = str(sig.get('type', ''))
        is_board = '板后' in sig_type or '进攻' in sig_type

        c_cfg = factors.get('confidence', {})
        conf_q = (float(sig.get('conf', 0)) - c_cfg.get('min', 0.70)) / max(c_cfg.get('max', 0.82) - c_cfg.get('min', 0.70), 1e-9)

        s_cfg = factors.get('upper_shadow', {}).get('board' if is_board else 'trend', {})
        shadow = float(sig.get('shadow', 0))
        shadow_q = (s_cfg.get('worst', 7.0) - shadow) / max(s_cfg.get('worst', 7.0) - s_cfg.get('best', 3.0), 1e-9)

        v_cfg = factors.get('vr', {}).get('board' if is_board else 'trend', {})
        vr = float(sig.get('vr', 1.0))
        vr_q = 1.0 - abs(vr - v_cfg.get('center', 1.15)) / max(v_cfg.get('half_width', 1.5), 1e-9)

        p_map = factors.get('position', {})
        pos_q = p_map.get(sig.get('pos', ''), 0.5)

        vals = [max(0.0, min(1.0, v)) for v in [conf_q, shadow_q, vr_q, pos_q]]
        geo = (vals[0] * vals[1] * vals[2] * vals[3]) ** 0.25
        return geo

    def _get_entry_geo(self, sig):
        """Get geo quality value for entry: uses quality_scoring if enabled, else pos-based fallback."""
        qs_cfg = STRATEGY_CONFIG.get('quality_scoring', {})
        if qs_cfg.get('enabled', False):
            return self._compute_geo_quality(sig)
        _POS_GEO_FALLBACK = {'SIDE': 0.8, 'LOW': 0.5, 'DOWN': 0.4, 'UP': 0.3}
        return _POS_GEO_FALLBACK.get(sig.get('pos', ''), 0.5)

    def _stake_ratio(self, sig, plan, px):
        qs_cfg = STRATEGY_CONFIG.get('quality_scoring', {})
        if qs_cfg.get('enabled', False):
            # V3: 几何平均质量分驱动仓位
            geo = self._compute_geo_quality(sig)
            base_ratio = qs_cfg.get('pos_size_base', 0.3) + geo * qs_cfg.get('pos_size_scale', 1.2)
            tier = f'geo_{geo:.2f}'
        else:
            # 原逻辑: fixed/dynamic + position_sizing_by_pos + 板后vr减仓
            base_ratio = self.portfolio.pos_pct
            tier = 'fixed'
            if self.sizing_mode == 'dynamic':
                base_ratio, tier = self._dynamic_size_ratio(sig, plan, px)

            pos_sizing_cfg = STRATEGY_CONFIG.get('position_sizing_by_pos', {})
            if pos_sizing_cfg.get('enabled', False):
                pos = sig.get('pos', '')
                if pos == 'SIDE':
                    base_ratio *= pos_sizing_cfg.get('side_multiplier', 1.5)
                    tier += '_side_up'
                elif pos == 'UP':
                    base_ratio *= pos_sizing_cfg.get('up_multiplier', 0.7)
                    tier += '_up_down'

            if '板后' in str(sig.get('type', '')) and float(sig.get('vr', 1.0)) > 3.5:
                base_ratio *= 0.5
                tier = tier + '_half_vr'

        return base_ratio, tier

    def _run_day(self, today, yesterday):
        # === 0. Regime ===
        self._compute_regime(yesterday)
        self.stats['regime_days'][self._regime] = self.stats['regime_days'].get(self._regime, 0) + 1

        # === 1. 大盘环境 ===
        mkt_ok = self._check_market(yesterday)

        # === 2. 扫描信号 (用昨天的数据) ===
        self.signals = {}
        today_sigs = {}
        new_watch = 0

        if mkt_ok:
            pool = self._get_pool_fast(yesterday)
            print(f' 池{len(pool)}', end='', flush=True)
            
            # 【新增】假跌破重返监测 (只看过去3天)
            buyback_cfg = STRATEGY_CONFIG.get('false_breakdown_buyback', {})
            watch_days = buyback_cfg.get('watch_days', 5)
            
            for code in list(self.buyback_watch.keys()):
                bw = self.buyback_watch[code]
                if code in self.portfolio.positions or not buyback_cfg.get('enabled', False):
                    del self.buyback_watch[code]
                    continue
                
                df = self._get_kline(code, yesterday)
                if df is not None and len(df) >= 5:
                    y_row = df.iloc[-1]
                    vol_ma5 = df['volume'].iloc[-6:-1].mean()
                    # 回归城门：收盘价站回城门+1%，且是阳线，且量能不低
                    if y_row['close'] > bw['cut'] * 1.01 and y_row['close'] > y_row['open'] and y_row['volume'] > vol_ma5 * 0.8:
                        sig = {
                            'type': bw['type'] + '(重返)',
                            'conf': max(0.85, bw['conf']),
                            'cut': bw['cut'],
                            'pos': 'SIDE',
                            'vr': y_row['volume'] / vol_ma5 if vol_ma5 > 0 else 1.0,
                            'name': self._get_name(code) or code,
                            'note': '洗盘后重返城门，无视回踩',
                        }
                        # 假跌破重返是极其确定的买点，直接 immediate 追入
                        plan = {'mode': 'immediate', 'min_age': 0, 'max_age': 3, 'min_conf': 0.8}
                        today_sigs[code] = {'sig': sig, 'plan': plan}
                        del self.buyback_watch[code]
                        continue
                
                bw['days'] += 1
                if bw['days'] > watch_days:
                    del self.buyback_watch[code]

            for code in pool:
                if code in self.cooldown:
                    cd = self.cooldown[code]
                    if (pd.Timestamp(today) - pd.Timestamp(cd)).days < 5:
                        continue
                if code in self.watchlist or code in self.portfolio.positions:
                    continue
                try:
                    df = self._get_kline(code, yesterday)
                    if df is None or len(df) < 60:
                        continue
                    name = self._get_name(code)
                    if name and ('ST' in name or '退' in name):
                        continue
                    sig = detect_all(df, code)
                    if sig:
                        self.stats['total_signals'] += 1
                        sig_type = sig.get('type', '')
                        if self._is_disabled_type(sig_type):
                            self._inc_stat('disabled_by_type', self._clean_sig_type(sig_type))
                            self._log_signal_event(
                                date=today, code=code, action='disabled_skip',
                                signal_type=sig_type, conf=sig.get('conf', 0),
                                reason='disabled_type'
                            )
                            continue
                        self._inc_stat('signal_by_type', sig_type)
                        if '逃命' in sig.get('type', '') or sig.get('nat') == '出货':
                            self.signals[code] = sig
                            self._log_signal_event(
                                date=today, code=code, action='detected_skip',
                                signal_type=sig_type, conf=sig.get('conf', 0),
                                reason='escape_or_distribution'
                            )
                            continue
                        sig['name'] = name or code
                        plan = self._entry_plan(sig)
                        quality_ok, quality_reason = self._hit_rate_gate(
                            sig, plan=plan, entry_mode=plan.get('mode', '')
                        )
                        if quality_ok and self.lhb_data is not None:
                            lookback = STRATEGY_CONFIG.get('filter_lhb_net_sell', {}).get('lookback_days', 5)
                            ts_today = pd.Timestamp(today)
                            window_start = ts_today - pd.Timedelta(days=lookback)
                            sub_lhb = self.lhb_data[(self.lhb_data['代码'] == code) & 
                                                    (self.lhb_data['上榜日'] >= window_start) & 
                                                    (self.lhb_data['上榜日'] <= ts_today)]
                            if not sub_lhb.empty and sub_lhb['龙虎榜净买额'].sum() < 0:
                                quality_ok = False
                                quality_reason = 'lhb_net_sell'
                                
                        if not quality_ok:
                            self._inc_stat('reject_reasons', quality_reason)
                            self._log_signal_event(
                                date=today, code=code, action='quality_reject',
                                signal_type=sig_type, conf=sig.get('conf', 0),
                                reason=quality_reason, plan=plan.get('mode', '')
                            )
                            continue
                        sig['entry_plan'] = plan['mode']
                        self.signals[code] = sig

                        self._log_signal_event(
                            date=today, code=code, action='detected',
                            signal_type=sig_type, conf=sig.get('conf', 0),
                            plan=plan['mode'], note=sig.get('note', '')
                        )

                        if plan['mode'] == 'immediate' and sig.get('conf', 0) >= plan['min_conf']:
                            today_sigs[code] = {'sig': sig, 'plan': plan}
                            self.stats['immediate_eligible'] += 1
                            self._inc_stat('entry_modes', 'immediate_candidate')
                        else:
                            self.watchlist[code] = {
                                'sig': sig, 'plan': plan, 'added': today, 'age': 0
                            }
                            self.stats['watchlist_added'] += 1
                            self._inc_stat('entry_modes', 'watch_added')
                            new_watch += 1
                except:
                    pass

            if today_sigs:
                print(f' {len(today_sigs)}即买', end='', flush=True)
            if new_watch:
                print(f' +{new_watch}观察', end='', flush=True)

        for code in list(self.watchlist.keys()):
            w = self.watchlist[code]
            if w['added'] != today:
                w['age'] += 1
            if w['age'] > w.get('plan', {}).get('max_age', 5):
                self.stats['watch_expired'] += 1
                self._log_signal_event(
                    date=today, code=code, action='watch_expired',
                    signal_type=w['sig'].get('type', ''),
                    conf=w['sig'].get('conf', 0), age=w['age']
                )
                del self.watchlist[code]

        # === 3. 用今天的数据执行交易 ===
        watchlist_codes = [
            c for c, w in self.watchlist.items()
            if w['age'] >= w.get('plan', {}).get('min_age', 1)
        ]
        all_trade_codes = (list(self.portfolio.positions.keys())
                           + list(today_sigs.keys()) + watchlist_codes)
        prices = {}
        for code in all_trade_codes:
            df_today = self._get_kline(code, today)
            if df_today is not None and len(df_today) > 0:
                row = df_today.iloc[-1]
                prices[code] = {
                    'open': float(row['open']),
                    'high': float(row['high']),
                    'low': float(row['low']),
                    'close': float(row['close']),
                    'volume': float(row['volume'])
                }

        # --- Morning: 止损/逃命 ---
        self._morning_check(today, prices)

        # --- Midday: 超时/止盈 ---
        self._midday_check(today, prices)

        # --- EOD: 买入 ---
        if mkt_ok:
            self._eod_immediate(today, today_sigs, prices)
            self._eod_trade(today, prices)

        # --- 记录净值 ---
        close_prices = {c: p['close'] for c, p in prices.items()}
        tv = self.portfolio.total_value(close_prices)
        self.portfolio.equity_curve.append({
            'date': today,
            'equity': tv,
            'positions': len(self.portfolio.positions),
            'market_ok': mkt_ok
        })

    def _check_market(self, date_str):
        """
        Keep market gate neutral by default.
        Avoid year-dependent threshold patches.
        """
        return True

    def _compute_regime(self, date_str):
        """Compute market regime (risk_on / risk_off) using index MA."""
        rc = STRATEGY_CONFIG.get('regime_filter', {})
        if not rc.get('enabled', False):
            self._regime = 'risk_on'
            return
        idx_code = rc.get('index', '000001')
        period = rc.get('ma_period', 60)
        df = self.feed.get_kline(idx_code, date_str, count=period + 5)
        if df is None or len(df) < period:
            self._regime = 'risk_on'
            return
        df_up_to = df[df.index <= pd.Timestamp(date_str)]
        if len(df_up_to) < period:
            self._regime = 'risk_on'
            return
        ma = df_up_to['close'].iloc[-period:].mean()
        last_close = float(df_up_to['close'].iloc[-1])
        self._regime = 'risk_on' if last_close > ma else 'risk_off'

    def _hard_cap_for_position(self, p):
        sig_type = p.get('type', '')
        # 诊断显示硬止盈容易截断非套利的扩张行情，改为只用于套利。
        if '套利' in sig_type:
            return self.profile.hard_cap if self.profile.hard_cap > 0 else 0.08
        return 0.0

    def _trail_params_for_position(self, p):
        return self.profile.trail_trigger, self.profile.trail_lock

    def _morning_check(self, today, prices):
        pf = self.profile
        for code in list(self.portfolio.positions.keys()):
            p = self.portfolio.positions[code]
            p['days'] += 1

            if code not in prices:
                continue

            px = prices[code]
            if px['low'] < p.get('trough', p.get('cost', px['low'])):
                p['trough'] = px['low']

            # V3 trailing_tp_exemption: track consecutive up days (含十字星)
            if px['close'] >= px['open'] * 0.998:
                p['consecutive_up_days'] = p.get('consecutive_up_days', 0) + 1
            else:
                p['consecutive_up_days'] = 0

            if code in self.signals and '逃命' in self.signals[code].get('type',''):
                self._sell(code, px['open'], today, '逃命清仓')
                continue

            # 套利长枪: 次日/短期跌破枪低直接走人
            if '套利' in p.get('type', '') and p.get('sig_low', 0) > 0 and p['days'] <= 2:
                if px['low'] < p['sig_low']:
                    sell_px = min(px['open'], p['sig_low'])
                    self._sell(code, sell_px, today, '套利次日破枪低')
                    continue

            # 防线1：盘中极端核按钮兜底防线
            if px['low'] < p['stop']:
                sell_px = min(px['open'], p['stop'])
                self._sell(code, sell_px, today, f'止损 low={px["low"]:.2f}<兜底线{p["stop"]:.2f}')
                # 假跌破重返观测:
                buyback_cfg = STRATEGY_CONFIG.get('false_breakdown_buyback', {})
                if buyback_cfg.get('enabled', False):
                    sig_cut = float(p.get('sig_cut', 0) or 0)
                    peak_profit = (p.get('peak', p['cost']) - p['cost']) / p['cost']
                    if sig_cut > 0 and ('趋势' in p.get('type', '') or '进攻' in p.get('type', '')) and peak_profit <= 0.05:
                        self.buyback_watch[code] = {
                            'date': today,
                            'cut': sig_cut,
                            'type': p.get('type', ''),
                            'conf': p.get('sig_conf', 0.8),
                            'days': 0
                        }
                continue

            # Type-specific Take Profit
            exits = get_optimal_exits(p.get('type', ''))
            hard_cap = exits['tp']
            
            # 【新增】针对一般信心的票做盈利 Cap，见好就收 (避免过山车回吐)
            is_capped = False
            # 趋势和板后现在采用动态追踪，这里只对其他枪型(如套利/烂板/进攻)做硬性截断
            if '趋势' not in p.get('type', '') and '板后' not in p.get('type', ''):
                if float(p.get('sig_conf', 1.0)) < 0.75:
                    if hard_cap > 0.05:  # 对于原本期望较高的弱信心票，强行降低预期到 5%落袋为安
                        hard_cap = 0.05
                        is_capped = True
            
            if hard_cap < 1.0: # If there's an actual TP target
                profit_high = (px['high'] - p['cost']) / p['cost']
                if profit_high >= hard_cap:
                    sell_px = p['cost'] * (1 + hard_cap)
                    reason = f'一般信心见好就收 {hard_cap*100:.0f}%' if is_capped else f'最优期望止盈 {hard_cap*100:.0f}%'
                    self._sell(code, sell_px, today, reason)
                    continue

            if px['high'] > p['peak']:
                p['peak'] = px['high']
            
            # Disable generic trailing stops as they destroy expectancy on highly volatile stocks
            pass

    def _midday_check(self, today, prices):
        for code in list(self.portfolio.positions.keys()):
            if code not in prices:
                continue
            p = self.portfolio.positions[code]
            px = prices[code]
            profit = (px['close'] - p['cost']) / p['cost']
            
            df_tdy = self._get_kline(code, today)
            
            peak_profit = (p.get('peak', p['cost']) - p['cost']) / p['cost']
            
            # V3 终极版配置：MFE达到5%后止损上移
            mfe_protect_cfg = STRATEGY_CONFIG.get('trailing_stop_mfe_protect', {})
            if mfe_protect_cfg.get('enabled', False):
                mfe_thresh = mfe_protect_cfg.get('mfe_threshold', 5.0) / 100.0
                new_stop_pct = mfe_protect_cfg.get('new_stop_loss_pct', -2.0) / 100.0
                if peak_profit >= mfe_thresh:
                    new_stop_price = p['cost'] * (1 + new_stop_pct)
                    if p['stop'] < new_stop_price:
                        p['stop'] = new_stop_price # 动态上移兜底线
            
            # --- 逃命长枪/顶部分布特征 过滤 (针对所有多头仓位) ---
            if df_tdy is not None and len(df_tdy) > 60:
                vol_ma60 = df_tdy['volume'].iloc[-61:-1].mean()
                # 相对巨量区：当前量能远超近三个月平均量
                is_explosive = px['volume'] > vol_ma60 * 3.5
                # 炸板或高位放量阴线：高位巨量发生转变，出货迹象
                failed_lu = (px['high'] >= px['open'] * 1.09) and (px['close'] < px['high'] * 0.98)
                is_exhaustion = is_explosive and (failed_lu or px['close'] < px['open'])
                
                # 如果在高位（有利润）出现逃命特征，果断清仓
                if is_exhaustion and profit > 0.05:
                    self._sell(code, px['close'], today, '高位巨量逃命特征(主力出货)')
                    continue
            
            peak_profit = (p.get('peak', p['cost']) - p['cost']) / p['cost']
            
            # --- 防线2：城门防线 (收盘价有效跌破长枪上影线密集区下沿) ---
            sig_cut = float(p.get('sig_cut', 0) or 0)
            if sig_cut > 0:
                agt_cfg = STRATEGY_CONFIG.get('adaptive_gate_tolerance', {})
                if agt_cfg.get('enabled', False):
                    geo = float(p.get('entry_geo', 0.5))
                    base_tol = agt_cfg.get('base_tolerance_pct', 2.0) / 100.0
                    extra_tol = agt_cfg.get('max_extra_tolerance_pct', 3.0) / 100.0
                    tolerance = 1.0 - (base_tol + geo * extra_tol)
                    if peak_profit > 0.05:
                        tolerance = 1.0 - base_tol
                else:
                    if peak_profit > 0.05:
                        tolerance = 1.00
                    elif '趋势' in p.get('type', '') or '进攻' in p.get('type', ''):
                        tolerance = 0.97
                    else:
                        tolerance = 0.98

                # Deferred entries get wider gate tolerance (already showed gate weakness)
                if p.get('was_deferred', False):
                    ecv2 = STRATEGY_CONFIG.get('entry_confirm_v2', {})
                    r1_cfg = ecv2.get('r1_defer_below_gate', {}) if ecv2.get('enabled', False) else {}
                    extra_gate_tol = r1_cfg.get('exit_gate_extra_tolerance_pct', 0) / 100.0
                    tolerance -= extra_gate_tol

                if px['close'] < sig_cut * tolerance:
                    self._sell(code, px['close'], today, f'收盘有效跌破城门 c={px["close"]:.2f}<城门{sig_cut:.2f}')
                    # 假跌破重返观测:
                    buyback_cfg = STRATEGY_CONFIG.get('false_breakdown_buyback', {})
                    if buyback_cfg.get('enabled', False):
                        if ('趋势' in p.get('type', '') or '进攻' in p.get('type', '')) and peak_profit <= 0.05:
                            self.buyback_watch[code] = {
                                'date': today,
                                'cut': sig_cut,
                                'type': p.get('type', ''),
                                'conf': p.get('sig_conf', 0.8),
                                'days': 0
                            }
                    continue
                    
            # --- 阶梯式动态追踪止盈 (替代原先固定的趋势高位破位回撤) ---
            if peak_profit > 0.05:
                tpe_cfg = STRATEGY_CONFIG.get('trailing_tp_exemption', {})
                is_exempt = False
                if tpe_cfg.get('enabled', False):
                    # V3: 双条件并集豁免
                    mfe_ceil = tpe_cfg.get('mfe_ceiling_pct', 10.0) / 100.0
                    if peak_profit < mfe_ceil and p['days'] > 0:
                        speed = peak_profit / p['days']
                        pullback = peak_profit - profit
                        cond_a = (speed < tpe_cfg.get('slow_rise_max_speed', 2.5) / 100.0
                                  and pullback < tpe_cfg.get('slow_rise_max_pullback', 2.0) / 100.0)
                        consec = p.get('consecutive_up_days', 0)
                        cond_b = (consec >= tpe_cfg.get('trend_min_consecutive_up', 3)
                                  and peak_profit > 0
                                  and pullback < peak_profit * tpe_cfg.get('trend_max_pullback_ratio', 0.5))
                        is_exempt = cond_a or cond_b
                else:
                    # 原逻辑: 单一速度阈值豁免
                    tp_exempt_cfg = STRATEGY_CONFIG.get('dynamic_trailing_tp_conditions', {})
                    if tp_exempt_cfg.get('enabled', False):
                        mfe_exempt = tp_exempt_cfg.get('mfe_exempt_threshold', 10.0) / 100.0
                        speed_exempt = tp_exempt_cfg.get('speed_exempt_threshold', 2.0) / 100.0
                        if peak_profit < mfe_exempt and p['days'] > 0:
                            speed = peak_profit / p['days']
                            if speed < speed_exempt:
                                is_exempt = True

                if not is_exempt:
                    if peak_profit <= 0.15:
                        tp_tolerance = max(peak_profit * 0.5, 0.05)
                    elif peak_profit <= 0.30:
                        tp_tolerance = max(peak_profit * 0.4, 0.08)
                    else:
                        tp_tolerance = max(peak_profit * 0.35, 0.12)
                        
                    if profit < peak_profit - tp_tolerance:
                        self._sell(code, px['close'], today, f'阶梯式动态追踪止盈(从{peak_profit*100:.1f}%回撤)')
                        continue

            # --- 板后长枪：情绪断板与退潮防线 ---
            if '板后' in p.get('type', ''):
                if df_tdy is not None and len(df_tdy) > 5:
                    vol_ma5 = df_tdy['volume'].iloc[-6:-1].mean()
                    is_dumped = px['volume'] > vol_ma5 * 1.5 and px['close'] < px['open'] * 0.98
                    
                    if profit > 0.03 and is_dumped:
                        self._sell(code, px['close'], today, '板后情绪退潮(放量收阴)')
                        continue
                        
                    # 极限情绪高度：如果涨幅超 15% 且当天收出长上影线或未封板，随时准备落袋
                    if profit > 0.15 and px['close'] < px['high'] * 0.98:
                        self._sell(code, px['close'], today, '板后高位断板(情绪落袋)')
                        continue
                        
                    # 弱势票的断气防线：信心一般，且连续3天没怎么涨还缩量，说明没人接力了
                    if p['days'] >= 3 and profit < 0.05 and float(p.get('sig_conf', 1.0)) < 0.75 and px['volume'] < vol_ma5 * 0.8:
                        self._sell(code, px['close'], today, '板后缩量断气(无资金接力)')
                        continue

            exits = get_optimal_exits(p.get('type', ''))
            time_days = exits['days']

            if p['days'] >= time_days:
                self._sell(code, px['close'], today,
                           f'到达最优持有期{time_days}天 profit={profit*100:.1f}%')

    def _estimate_entry_price(self, sig, px, entry_mode='watch'):
        """Estimate fill price. Default to conservative close fill."""
        if self.fill_mode == 'close':
            return round(px['close'], 2)

        # optimistic mode is kept for research comparison only.
        cut = sig.get('cut', 0)
        o, h, l, c = px['open'], px['high'], px['low'], px['close']
        if cut > 0 and l <= cut <= h:
            return round(cut * 1.002, 2)
        vwap_est = (o + h + l + c) / 4
        return round(min(vwap_est, c), 2)

    def _intraday_ok(self, sig, px, plan=None):
        """Model-faithful same-day check using daily OHLC."""
        cut = sig.get('cut', 0)
        o, h, l, c = px['open'], px['high'], px['low'], px['close']

        if c > o * 1.095:
            return False

        # 进攻有效性：不做明显转弱的阴线。
        if c < o * 0.995:
            return False

        # "城门"触达且收盘站上，避免日线假突破。
        if cut > 0 and h < cut:
            return False
        if cut > 0 and c < cut * 0.995:
            return False

        return True

    def _eod_immediate(self, today, today_sigs, prices):
        """Same-day entry for signals routed as immediate by entry plan."""
        if self.portfolio.available_slots() <= 0 or not today_sigs:
            return

        eligible = sorted(
            today_sigs.items(),
            key=lambda x: x[1]['sig'].get('conf', 0), reverse=True
        )

        for code, entry in eligible:
            if self.portfolio.available_slots() <= 0:
                break
            if code in self.portfolio.positions:
                continue
            if code not in prices:
                continue

            sig = entry['sig']
            plan = entry.get('plan', {})
            if sig.get('conf', 0) < plan.get('min_conf', 0):
                continue
            q_ok, q_reason = self._hit_rate_gate(sig, plan=plan, entry_mode='immediate')
            if not q_ok:
                self._inc_stat('reject_reasons', q_reason)
                self._log_signal_event(
                    date=today, code=code, action='immediate_reject',
                    signal_type=sig.get('type', ''), conf=sig.get('conf', 0),
                    reason=q_reason
                )
                continue

            px = prices[code]
            if not self._intraday_ok(sig, px, plan):
                self._log_signal_event(
                    date=today, code=code, action='immediate_reject',
                    signal_type=sig.get('type', ''), conf=sig.get('conf', 0),
                    reason='intraday_check_fail'
                )
                continue

            price = self._estimate_entry_price(sig, px, entry_mode='immediate')
            sig_type = sig.get('type', '')
            stop = calc_stop(sig, price, self.profile)
            stake_ratio, tier = self._stake_ratio(sig, plan, px)
            shares = int(self.portfolio.cash * stake_ratio / price / 100) * 100
            if shares <= 0:
                continue

            cost = shares * price * 1.0003
            if cost > self.portfolio.cash:
                continue

            self.portfolio.cash -= cost
            self.portfolio.positions[code] = {
                'shares': shares,
                'cost': price,
                'stop': stop,
                'init_stop': stop,
                'days': 0,
                'peak': price,
                'trough': price,
                'type': sig_type,
                'buy_date': today,
                'nat': sig.get('nat', ''),
                'sig_conf': sig.get('conf', 0),
                'sig_low': sig.get('low', 0),
                'sig_cut': sig.get('cut', 0),
                'sig_note': sig.get('note', ''),
                'sig_pos': sig.get('pos', ''),
                'sig_shadow': sig.get('shadow', 0),
                'sig_vr': sig.get('vr', 0),
                'sig_ctx_tags': sig.get('ctx_tags', ''),
                'sig_pressure': sig.get('ctx_pressure', 0),
                'sig_release': sig.get('ctx_release', 0),
                'sig_two_side_active': sig.get('ctx_two_side_active', False),
                'sig_zhyx_ok': sig.get('ctx_zhyx_ok', False),
                'sig_zhyx_reason': sig.get('ctx_zhyx_reason', ''),
                'sig_zhyx_base': sig.get('ctx_zhyx_base', 0),
                'sig_zhyx_burst_ref': sig.get('ctx_zhyx_burst_ref', 0),
                'entry_mode': 'immediate',
                'stake_ratio': stake_ratio,
                'entry_geo': self._get_entry_geo(sig),
                'consecutive_up_days': 0,
            }
            self.stats['immediate_bought'] += 1
            self._inc_stat('buy_by_type', sig_type)
            self._inc_stat('entry_modes', 'immediate_bought')
            self._inc_stat('size_tiers', tier)
            self._log_signal_event(
                date=today, code=code, action='buy_immediate',
                signal_type=sig_type, conf=sig.get('conf', 0),
                price=price, stop=stop, stake_ratio=stake_ratio, tier=tier
            )

            print(f'\n  {today} 【即买】[{sig_type}] {code} {sig.get("name","")} '
                  f'价:{price:.2f} 止损:{stop:.2f} 仓:{stake_ratio:.2f} conf={sig.get("conf",0):.2f} '
                  f'| {sig.get("note","")}')
            if self.detail_mode in ('verbose', 'full'):
                print(f'      ↳ 入场画像 pos={sig.get("pos","")} shadow={sig.get("shadow",0):.1f}% '
                      f'vr={sig.get("vr",0):.2f} cut={sig.get("cut",0):.2f} '
                      f'ctx={sig.get("ctx_tags","") or "na"}')

    def _confirm_entry(self, code, sig, px, today, plan=None):
        """量价确认规则校验观察名单入场。

        Returns (ok, reason, sizing_modifier)
            sizing_modifier: 1.0 = standard, <1.0 = alternate confirmation path
        """
        cut = sig.get('cut', 0)
        o, h, l, c = px['open'], px['high'], px['low'], px['close']
        sig_type = sig.get('type', '')

        if c > o * 1.095:
            return False, 'limit_up', 1.0

        df = self._get_kline(code, today)
        if df is None or len(df) < 10:
            return False, 'no_data', 1.0

        s = max(len(df) - 30, 0)
        hist = df.iloc[s:-1]
        if hist.empty:
            return False, 'no_data', 1.0

        ecv2 = STRATEGY_CONFIG.get('entry_confirm_v2', {})
        ecv2_on = ecv2.get('enabled', False)

        # ─── 趋势/进攻: 买阴线/缩量回踩 ───
        if '趋势' in sig_type or '进攻' in sig_type:
            if cut > 0 and c < cut * 0.985:
                return False, 'close_below_gate', 1.0

            # R0: no_pullback → breakout confirmation
            if cut > 0 and l > cut * 1.04:
                r0_cfg = ecv2.get('r0_breakout_confirm', {}) if ecv2_on else {}
                if r0_cfg.get('enabled', False) and sig_type in r0_cfg.get('types', []):
                    min_days = r0_cfg.get('min_days_above_gate', 2)
                    recent = df.iloc[-(min_days + 1):-1]
                    if len(recent) >= min_days and all(recent['close'] > cut):
                        mod = r0_cfg.get('sizing_multiplier', 0.5)
                        return True, 'breakout_confirm', mod
                return False, 'no_pullback', 1.0

            vol_ma = float(hist['volume'].mean())
            if vol_ma > 0 and px['volume'] > vol_ma * 1.0:
                return False, 'no_shrink_vol', 1.0
            return True, 'ok', 1.0

        # ─── 游资/板后/套利: 右侧突破确认 ───
        # R2: 板后 intraday gate touch
        if '板后' in sig_type and ecv2_on:
            r2_cfg = ecv2.get('r2_banhou_intraday_touch', {})
            if r2_cfg.get('enabled', False) and cut > 0:
                intraday_touch = (l <= cut <= h) or (l <= cut * 1.005 and h >= cut * 0.995)
                standard_touch = h >= cut
                if not standard_touch and intraday_touch:
                    pass  # fall through to intraday path below
                elif not standard_touch and not intraday_touch:
                    return False, 'no_gate_touch', 1.0

                if standard_touch:
                    # normal path: close must be above gate
                    if c < cut * 0.995:
                        return False, 'close_below_gate', 1.0
                else:
                    # intraday touch path: require close recovery
                    if r2_cfg.get('require_close_recovery', True):
                        tol = r2_cfg.get('recovery_tolerance_pct', 1.5)
                        if c < cut * (1 - tol / 100):
                            return False, 'close_below_gate', 1.0

                if c < o * 0.992:
                    return False, 'negative_candle', 1.0

                vol_ma = float(hist['volume'].mean())
                if vol_ma > 0 and px['volume'] < vol_ma * 1.10:
                    return False, 'no_confirm_volume', 1.0

                bear = hist[hist['close'] < hist['open']]
                if not bear.empty:
                    top2 = bear['volume'].nlargest(2)
                    bear_ref = float(top2.mean()) if len(top2) >= 2 else float(top2.iloc[0])
                    if bear_ref > 0 and px['volume'] > bear_ref * 2.0:
                        return False, 'explosive_vol', 1.0

                if not standard_touch:
                    mod = r2_cfg.get('sizing_multiplier', 0.7)
                    return True, 'intraday_touch_confirm', mod
                return True, 'ok', 1.0

        # Default path (游资/板后无R2/套利)
        if cut > 0 and h < cut:
            return False, 'no_gate_touch', 1.0
        if cut > 0 and c < cut * 0.995:
            return False, 'close_below_gate', 1.0

        if c < o * 0.992:
            return False, 'negative_candle', 1.0

        vol_ma = float(hist['volume'].mean())
        if vol_ma > 0 and px['volume'] < vol_ma * 1.10:
            return False, 'no_confirm_volume', 1.0

        bear = hist[hist['close'] < hist['open']]
        if not bear.empty:
            top2 = bear['volume'].nlargest(2)
            bear_ref = float(top2.mean()) if len(top2) >= 2 else float(top2.iloc[0])
            if bear_ref > 0 and px['volume'] > bear_ref * 2.0:
                return False, 'explosive_vol', 1.0

        return True, 'ok', 1.0

    def _eod_trade(self, today, prices):
        """Watchlist entries: confirm then buy with estimated intraday price."""
        if self.portfolio.available_slots() <= 0:
            return

        regime = getattr(self, '_regime', 'risk_on')
        rc = STRATEGY_CONFIG.get('regime_filter', {})
        regime_active = rc.get('enabled', False) and regime == 'risk_off'

        eligible = sorted(
            [
                (c, w) for c, w in self.watchlist.items()
                if w['age'] >= w.get('plan', {}).get('min_age', 1)
            ],
            key=lambda x: x[1]['sig'].get('conf', 0), reverse=True
        )

        for code, wentry in eligible:
            if self.portfolio.available_slots() <= 0:
                break
            if code in self.portfolio.positions:
                continue
            if code not in prices:
                continue

            sig = wentry['sig']
            plan = wentry.get('plan', {})
            if sig.get('conf', 0) < plan.get('min_conf', 0.65):
                continue
            q_ok, q_reason = self._hit_rate_gate(sig, plan=plan, entry_mode='watch')
            if not q_ok:
                self._inc_stat('reject_reasons', q_reason)
                self._log_signal_event(
                    date=today, code=code, action='watch_reject',
                    signal_type=sig.get('type', ''), conf=sig.get('conf', 0),
                    reason=q_reason, age=wentry.get('age', 0)
                )
                continue

            px = prices[code]
            sig_type = sig.get('type', '')

            # Regime: temporarily suppress R0/R1/R2 in risk_off
            _ecv2_saved = None
            if regime_active and rc.get('risk_off_disable_alt_paths', True):
                ecv2_ref = STRATEGY_CONFIG.get('entry_confirm_v2', {})
                _ecv2_saved = ecv2_ref.get('enabled', False)
                ecv2_ref['enabled'] = False

            ok, reason, sizing_mod = self._confirm_entry(code, sig, px, today, plan=plan)

            if _ecv2_saved is not None:
                STRATEGY_CONFIG['entry_confirm_v2']['enabled'] = _ecv2_saved

            if not ok:
                # R1: close_below_gate → defer instead of hard reject
                ecv2 = STRATEGY_CONFIG.get('entry_confirm_v2', {})
                ecv2_on = ecv2.get('enabled', False)
                if regime_active and rc.get('risk_off_disable_alt_paths', True):
                    ecv2_on = False
                r1_cfg = ecv2.get('r1_defer_below_gate', {}) if ecv2_on else {}
                if reason == 'close_below_gate' and r1_cfg.get('enabled', False):
                    if not wentry.get('_deferred', False):
                        extra = r1_cfg.get('extra_ttl', 5)
                        wentry['plan'] = dict(wentry.get('plan', {}))
                        wentry['plan']['max_age'] = wentry['plan'].get('max_age', 5) + extra
                        wentry['_deferred'] = True
                        wentry['_defer_sizing'] = r1_cfg.get('sizing_multiplier', 0.8)
                        self._log_signal_event(
                            date=today, code=code, action='watch_defer',
                            signal_type=sig_type, conf=sig.get('conf', 0),
                            reason='close_below_gate', age=wentry.get('age', 0)
                        )
                        self._inc_stat('reject_reasons', 'defer_below_gate')
                        continue

                r = self.stats['reject_reasons']
                r[reason] = r.get(reason, 0) + 1
                self._log_signal_event(
                    date=today, code=code, action='watch_reject',
                    signal_type=sig_type, conf=sig.get('conf', 0),
                    reason=reason, age=wentry.get('age', 0)
                )
                continue
            self.stats['watchlist_confirmed'] += 1

            # Apply sizing modifiers from alternate confirmation paths
            if wentry.get('_deferred', False):
                sizing_mod = min(sizing_mod, wentry.get('_defer_sizing', 0.8))

            price = self._estimate_entry_price(sig, px, entry_mode='watch')
            stop = calc_stop(sig, price, self.profile)
            stake_ratio, tier = self._stake_ratio(sig, plan, px)
            stake_ratio *= sizing_mod

            # Regime: scale down sizing in risk_off
            if regime_active:
                regime_scale = rc.get('risk_off_sizing_scale', 0.6)
                stake_ratio *= regime_scale
                tier += f'_regime_off({regime_scale:.1f}x)'
            if sizing_mod < 1.0:
                tier += f'_alt({reason}|{sizing_mod:.1f}x)'
            shares = int(self.portfolio.cash * stake_ratio / price / 100) * 100
            if shares <= 0:
                continue

            cost = shares * price * 1.0003
            if cost > self.portfolio.cash:
                continue

            self.portfolio.cash -= cost
            self.portfolio.positions[code] = {
                'shares': shares,
                'cost': price,
                'stop': stop,
                'init_stop': stop,
                'days': 0,
                'peak': price,
                'trough': price,
                'type': sig_type,
                'buy_date': today,
                'nat': sig.get('nat', ''),
                'sig_conf': sig.get('conf', 0),
                'sig_low': sig.get('low', 0),
                'sig_cut': sig.get('cut', 0),
                'sig_note': sig.get('note', ''),
                'sig_pos': sig.get('pos', ''),
                'sig_shadow': sig.get('shadow', 0),
                'sig_vr': sig.get('vr', 0),
                'sig_ctx_tags': sig.get('ctx_tags', ''),
                'sig_pressure': sig.get('ctx_pressure', 0),
                'sig_release': sig.get('ctx_release', 0),
                'sig_two_side_active': sig.get('ctx_two_side_active', False),
                'sig_zhyx_ok': sig.get('ctx_zhyx_ok', False),
                'sig_zhyx_reason': sig.get('ctx_zhyx_reason', ''),
                'sig_zhyx_base': sig.get('ctx_zhyx_base', 0),
                'sig_zhyx_burst_ref': sig.get('ctx_zhyx_burst_ref', 0),
                'entry_mode': 'watch',
                'entry_path': reason if sizing_mod < 1.0 else 'standard',
                'was_deferred': wentry.get('_deferred', False),
                'entry_regime': regime,
                'stake_ratio': stake_ratio,
                'entry_geo': self._get_entry_geo(sig),
                'consecutive_up_days': 0,
            }
            del self.watchlist[code]
            self.stats['watchlist_bought'] += 1
            self._inc_stat('buy_by_type', sig_type)
            self._inc_stat('entry_modes', 'watch_bought')
            self._inc_stat('size_tiers', tier)
            self._log_signal_event(
                date=today, code=code, action='buy_watch',
                signal_type=sig_type, conf=sig.get('conf', 0),
                price=price, stop=stop, age=wentry.get('age', 0),
                stake_ratio=stake_ratio, tier=tier
            )

            print(f'\n  {today} 【买入】[{sig_type}] {code} {sig.get("name","")} '
                  f'价:{price:.2f} 止损:{stop:.2f} 仓:{stake_ratio:.2f} 观{wentry["age"]}天 | {sig.get("note","")}')
            if self.detail_mode in ('verbose', 'full'):
                print(f'      ↳ 入场画像 pos={sig.get("pos","")} shadow={sig.get("shadow",0):.1f}% '
                      f'vr={sig.get("vr",0):.2f} cut={sig.get("cut",0):.2f} '
                      f'ctx={sig.get("ctx_tags","") or "na"}')

    def _sell(self, code, sell_price, date, reason):
        if code not in self.portfolio.positions:
            return
        p = self.portfolio.positions[code]
        proceeds = p['shares'] * sell_price * 0.999  # 手续费+印花税
        self.portfolio.cash += proceeds

        pnl = (sell_price - p['cost']) / p['cost'] * 100
        peak = float(p.get('peak', p['cost']) or p['cost'])
        trough = float(p.get('trough', p['cost']) or p['cost'])
        mfe_pct = (peak - p['cost']) / p['cost'] * 100
        mae_pct = (trough - p['cost']) / p['cost'] * 100
        init_stop = float(p.get('init_stop', p.get('stop', 0)) or 0)
        risk_pct = ((p['cost'] - init_stop) / p['cost'] * 100) if init_stop > 0 else 0.0
        if risk_pct < 0:
            risk_pct = 0.0
        r_multiple = (pnl / risk_pct) if risk_pct > 1e-9 else 0.0

        exit_open = exit_high = exit_low = exit_close = 0.0
        try:
            ex_df = self._get_kline(code, date)
            if ex_df is not None and len(ex_df) > 0:
                ex_row = ex_df.iloc[-1]
                exit_open = float(ex_row.get('open', 0) or 0)
                exit_high = float(ex_row.get('high', 0) or 0)
                exit_low = float(ex_row.get('low', 0) or 0)
                exit_close = float(ex_row.get('close', 0) or 0)
        except Exception:
            pass

        trade = Trade(
            code=code,
            buy_date=p['buy_date'],
            buy_price=p['cost'],
            sell_date=date,
            sell_price=sell_price,
            stop_line=p['stop'],
            signal_type=p['type'],
            days_held=p['days'],
            pnl_pct=pnl,
            exit_reason=reason,
            signal_nat=p.get('nat', ''),
            signal_conf=p.get('sig_conf', 0),
            entry_mode=p.get('entry_mode', ''),
            stake_ratio=p.get('stake_ratio', 0),
            entry_note=p.get('sig_note', ''),
            entry_tags=p.get('sig_ctx_tags', ''),
            entry_pos=p.get('sig_pos', ''),
            entry_cut=float(p.get('sig_cut', 0) or 0),
            entry_shadow=float(p.get('sig_shadow', 0) or 0),
            entry_vr=float(p.get('sig_vr', 0) or 0),
            pressure=float(p.get('sig_pressure', 0) or 0),
            release=float(p.get('sig_release', 0) or 0),
            two_side_active=bool(p.get('sig_two_side_active', False)),
            zhyx_ok=bool(p.get('sig_zhyx_ok', False)),
            zhyx_reason=str(p.get('sig_zhyx_reason', '')),
            zhyx_base=float(p.get('sig_zhyx_base', 0) or 0),
            zhyx_burst_ref=float(p.get('sig_zhyx_burst_ref', 0) or 0),
            init_stop=init_stop,
            mfe_pct=float(mfe_pct),
            mae_pct=float(mae_pct),
            risk_pct=float(risk_pct),
            r_multiple=float(r_multiple),
            exit_open=exit_open,
            exit_high=exit_high,
            exit_low=exit_low,
            exit_close=exit_close,
            entry_path=str(p.get('entry_path', '')),
            was_deferred=bool(p.get('was_deferred', False)),
            entry_regime=str(p.get('entry_regime', '')),
        )
        self.portfolio.trades.append(trade)
        self._inc_stat('exit_reasons', self._norm_reason(reason))
        del self.portfolio.positions[code]
        self.cooldown[code] = date
        self._log_signal_event(
            date=date, code=code, action='sell',
            signal_type=p.get('type', ''), pnl_pct=pnl, reason=reason
        )

        emoji = '💰' if pnl > 0 else '❌'
        print(f'\n  {date} {emoji}【卖出】{code} 买:{p["cost"]:.2f} 卖:{sell_price:.2f} '
              f'{pnl:+.1f}% 持{p["days"]}天 | {reason}')
        if self.detail_mode in ('verbose', 'full'):
            print(f'      ↳ MFE:{mfe_pct:+.1f}% MAE:{mae_pct:+.1f}% 风险:{risk_pct:.2f}% R:{r_multiple:+.2f}')
            print(f'      ↳ 入场画像 pos={p.get("sig_pos","")} cut={p.get("sig_cut",0):.2f} '
                  f'shadow={p.get("sig_shadow",0):.1f}% vr={p.get("sig_vr",0):.2f} '
                  f'ctx={p.get("sig_ctx_tags","") or "na"}')
            print(f'      ↳ 结构 pressure={p.get("sig_pressure",0):.2f} release={p.get("sig_release",0):.2f} '
                  f'two_side={int(bool(p.get("sig_two_side_active", False)))} '
                  f'zhyx={int(bool(p.get("sig_zhyx_ok", False)))}({p.get("sig_zhyx_reason","")})')

    def _get_pool_fast(self, date_str):
        """Fast pool screening from pre-loaded cache."""
        ts = pd.Timestamp(date_str)
        pool = []
        for code, full_df in self._prepared_cache.items():
            df = self._slice_to_date(full_df, ts)
            if df is None:
                continue
            if len(df) < 10:
                continue
            lc = df.iloc[-1]['close']
            if lc < 3.0 or lc > 100.0:
                continue
            recent = df.iloc[-7:]
            lp = 0.20 if code.startswith('3') else 0.10
            pcts = recent['close'].pct_change() * 100
            has_lu = (pcts >= (lp*100 - 0.5)).any()
            has_amp = (recent['amp'] > 7.0).any() if 'amp' in recent.columns else False
            has_lb = recent['is_lb'].any() if 'is_lb' in recent.columns else False
            if has_lu or has_amp or has_lb:
                pool.append(code)
        return pool

    def _get_kline(self, code, end_date):
        if code in self._prepared_cache:
            req_count = int(self._prepared_req.get(code, 0) or 0)
            if req_count >= self.kline_lookback_bars:
                df = self._prepared_cache[code]
            else:
                df = None
            if df is not None and end_date:
                df = self._slice_to_date(df, end_date)
            if df is not None and not df.empty:
                lc = df.iloc[-1]['close']
                if lc < 3.0 or lc > 100.0:
                    return None
                return df
        disk_cached = self._load_prepared_disk(code, end_date)
        if disk_cached is not None:
            df, req_count = disk_cached
            self._prepared_cache[code] = df
            self._prepared_req[code] = req_count
            sliced = self._slice_to_date(df, end_date) if end_date else df
            if sliced is None or sliced.empty:
                return None
            lc = sliced.iloc[-1]['close']
            if lc < 3.0 or lc > 100.0:
                return None
            return sliced
        df = self.feed.get_kline(code, end_date, count=self.kline_lookback_bars)
        if df.empty:
            return None
        df = prepare_kline(df, code)
        if df.empty:
            return None
        self._prepared_cache[code] = df
        self._prepared_req[code] = self.kline_lookback_bars
        self._save_prepared_disk(code, df, self.kline_lookback_bars)
        lc = df.iloc[-1]['close']
        if lc < 3.0 or lc > 100.0:
            return None
        if end_date:
            df = self._slice_to_date(df, end_date)
            if df is None or df.empty:
                return None
        return df

    def _get_name(self, code):
        """从股票列表获取名称 (cached)"""
        if code in self._name_cache:
            return self._name_cache[code]
        sl = self.feed.get_stock_list()
        if sl.empty:
            self._name_cache[code] = None
            return None
        code_str = str(code).zfill(6)
        for col in ['code', 'symbol']:
            if col in sl.columns:
                match = sl[sl[col].astype(str).str.zfill(6) == code_str]
                if not match.empty:
                    for ncol in ['name', 'short_name']:
                        if ncol in match.columns:
                            name = str(match.iloc[0][ncol])
                            self._name_cache[code] = name
                            return name
        self._name_cache[code] = None
        return None

    def _get_prepared_full(self, code):
        df = self._prepared_cache.get(code)
        if df is not None and not df.empty:
            return df
        disk_cached = self._load_prepared_disk(code, None)
        if disk_cached is not None:
            df_disk, req_count = disk_cached
            self._prepared_cache[code] = df_disk
            self._prepared_req[code] = req_count
            return df_disk
        return None

    def _export_trade_windows(self, out_dir):
        """
        导出每笔交易前后窗口，便于逐笔复盘“为何赚/为何亏”。
        """
        if not self.export_trade_windows:
            return None
        if not self.portfolio.trades:
            return None

        windows_dir = os.path.join(out_dir, 'trade_windows')
        os.makedirs(windows_dir, exist_ok=True)
        idx_rows = []
        for i, t in enumerate(self.portfolio.trades, start=1):
            df = self._get_prepared_full(t.code)
            if df is None or df.empty:
                continue
            try:
                buy_ts = pd.Timestamp(t.buy_date)
                sell_ts = pd.Timestamp(t.sell_date)
            except Exception:
                continue
            bi = int(df.index.searchsorted(buy_ts, side='left'))
            si = int(df.index.searchsorted(sell_ts, side='right')) - 1
            if bi < 0 or bi >= len(df):
                continue
            if si < bi:
                si = bi
            start = max(0, bi - 15)
            end = min(len(df), si + 16)
            if end <= start:
                continue
            cols = [c for c in [
                'open', 'high', 'low', 'close', 'volume',
                'shadow', 'amp', 'vr', 'is_lu', 'is_lb'
            ] if c in df.columns]
            w = df.iloc[start:end][cols].copy()
            if w.empty:
                continue
            w = w.reset_index().rename(columns={w.index.name or 'index': 'date'})
            if 'date' not in w.columns:
                w = w.rename(columns={'index': 'date'})
            w['date'] = pd.to_datetime(w['date']).dt.strftime('%Y-%m-%d')
            w['trade_id'] = i
            w['code'] = t.code
            w['buy_date'] = t.buy_date
            w['sell_date'] = t.sell_date
            w['pnl_pct'] = t.pnl_pct
            w['is_buy'] = (w['date'] == t.buy_date).astype(int)
            w['is_sell'] = (w['date'] == t.sell_date).astype(int)
            fname = f'{i:04d}_{t.code}_{t.buy_date}_{t.sell_date}.csv'
            rel_path = os.path.join('output', 'backtest_reports', self.run_id, 'trade_windows', fname)
            w.to_csv(os.path.join(windows_dir, fname), index=False)
            idx_rows.append({
                'trade_id': i,
                'code': t.code,
                'buy_date': t.buy_date,
                'sell_date': t.sell_date,
                'signal_type': t.signal_type,
                'pnl_pct': t.pnl_pct,
                'entry_note': t.entry_note,
                'entry_tags': t.entry_tags,
                'window_csv': rel_path,
            })

        if not idx_rows:
            return None
        idx_df = pd.DataFrame(idx_rows)
        idx_path = os.path.join(out_dir, 'trade_windows_index.csv')
        idx_df.to_csv(idx_path, index=False)
        return idx_path

    def _print_type_breakdown(self, trades):
        if not trades:
            return
        bucket = defaultdict(list)
        for t in trades:
            bucket[t.signal_type].append(t)
        print('\n  分枪种表现:')
        print(f'  {"类型":<8} {"笔数":>5} {"胜率":>7} {"均盈亏":>9} {"PF":>7} {"均持天":>7}')
        print(f'  {"-"*56}')
        for k, rows in sorted(bucket.items(), key=lambda x: len(x[1]), reverse=True):
            pnls = [r.pnl_pct for r in rows]
            wins = [p for p in pnls if p > 0]
            losses = [p for p in pnls if p <= 0]
            wr = (len(wins) / len(rows) * 100) if rows else 0
            avg = np.mean(pnls) if pnls else 0
            avg_days = np.mean([r.days_held for r in rows]) if rows else 0
            pf = 0
            if wins and losses and abs(sum(losses)) > 1e-9:
                pf = abs(sum(wins) / sum(losses))
            print(f'  {k:<8} {len(rows):>5} {wr:>6.1f}% {avg:>+8.2f}% {pf:>6.2f} {avg_days:>6.1f}')

    def _print_exit_breakdown(self, trades):
        if not trades:
            return
        bucket = defaultdict(list)
        for t in trades:
            bucket[self._norm_reason(t.exit_reason)].append(t.pnl_pct)
        print('\n  分退出原因表现:')
        print(f'  {"退出原因":<24} {"次数":>5} {"均盈亏":>9}')
        print(f'  {"-"*42}')
        for k, pnls in sorted(bucket.items(), key=lambda x: len(x[1]), reverse=True)[:12]:
            print(f'  {k:<24} {len(pnls):>5} {np.mean(pnls):>+8.2f}%')

    def _print_monthly_breakdown(self, trades):
        if not trades:
            return
        bucket = defaultdict(list)
        for t in trades:
            if t.sell_date:
                bucket[t.sell_date[:7]].append(t.pnl_pct)
        if not bucket:
            return
        print('\n  月度交易分布:')
        print(f'  {"月份":<8} {"笔数":>5} {"胜率":>7} {"均盈亏":>9}')
        print(f'  {"-"*34}')
        for m in sorted(bucket.keys()):
            pnls = bucket[m]
            wins = [p for p in pnls if p > 0]
            wr = len(wins) / len(pnls) * 100 if pnls else 0
            print(f'  {m:<8} {len(pnls):>5} {wr:>6.1f}% {np.mean(pnls):>+8.2f}%')

    def _export_analysis(self):
        """Export helper artifacts for post-run analysis."""
        if not self.run_id:
            return
        out_dir = os.path.join('output', 'backtest_reports', self.run_id)
        os.makedirs(out_dir, exist_ok=True)

        trades_df = pd.DataFrame([{
            'code': t.code,
            'buy_date': t.buy_date,
            'sell_date': t.sell_date,
            'signal_type': t.signal_type,
            'signal_nat': t.signal_nat,
            'signal_conf': t.signal_conf,
            'entry_mode': t.entry_mode,
            'buy_price': t.buy_price,
            'sell_price': t.sell_price,
            'days_held': t.days_held,
            'pnl_pct': t.pnl_pct,
            'exit_reason': t.exit_reason,
            'stake_ratio': t.stake_ratio,
            'entry_note': t.entry_note,
            'entry_tags': t.entry_tags,
            'entry_pos': t.entry_pos,
            'entry_cut': t.entry_cut,
            'entry_shadow': t.entry_shadow,
            'entry_vr': t.entry_vr,
            'pressure': t.pressure,
            'release': t.release,
            'two_side_active': t.two_side_active,
            'zhyx_ok': t.zhyx_ok,
            'zhyx_reason': t.zhyx_reason,
            'zhyx_base': t.zhyx_base,
            'zhyx_burst_ref': t.zhyx_burst_ref,
            'init_stop': t.init_stop,
            'mfe_pct': t.mfe_pct,
            'mae_pct': t.mae_pct,
            'risk_pct': t.risk_pct,
            'r_multiple': t.r_multiple,
            'exit_open': t.exit_open,
            'exit_high': t.exit_high,
            'exit_low': t.exit_low,
            'exit_close': t.exit_close,
            'entry_path': t.entry_path,
            'was_deferred': t.was_deferred,
            'entry_regime': t.entry_regime,
        } for t in self.portfolio.trades])
        equity_df = pd.DataFrame(self.portfolio.equity_curve)
        signal_df = pd.DataFrame(self.signal_journal)

        if not trades_df.empty:
            trades_df.to_csv(os.path.join(out_dir, 'trades.csv'), index=False)
        if not equity_df.empty:
            equity_df.to_csv(os.path.join(out_dir, 'equity.csv'), index=False)
        if not signal_df.empty:
            signal_df.to_csv(os.path.join(out_dir, 'signals.csv'), index=False)
        trade_windows_index = self._export_trade_windows(out_dir)

        init = 100000
        final = equity_df.iloc[-1]['equity'] if not equity_df.empty else init
        total_return = (final - init) / init * 100
        wins = trades_df[trades_df['pnl_pct'] > 0] if not trades_df.empty else pd.DataFrame()
        losses = trades_df[trades_df['pnl_pct'] <= 0] if not trades_df.empty else pd.DataFrame()
        profit_factor = 0.0
        if not wins.empty and not losses.empty and abs(losses['pnl_pct'].sum()) > 1e-9:
            profit_factor = abs(wins['pnl_pct'].sum() / losses['pnl_pct'].sum())

        max_dd = 0.0
        if not equity_df.empty:
            peak = equity_df['equity'].cummax()
            dd = (peak - equity_df['equity']) / peak * 100
            max_dd = float(dd.max())

        sharpe = 0.0
        if not equity_df.empty and len(equity_df) > 2:
            ret = equity_df['equity'].pct_change().dropna()
            if ret.std(ddof=0) > 1e-12:
                sharpe = float((ret.mean() / ret.std(ddof=0)) * np.sqrt(252))

        summary = {
            'run_meta': self.run_meta,
            'core_metrics': {
                'initial_capital': init,
                'final_equity': float(final),
                'total_return_pct': float(total_return),
                'trade_count': int(len(trades_df)),
                'win_count': int(len(wins)),
                'loss_count': int(len(losses)),
                'win_rate_pct': float((len(wins) / len(trades_df) * 100) if len(trades_df) else 0),
                'avg_pnl_pct': float(trades_df['pnl_pct'].mean()) if not trades_df.empty else 0.0,
                'avg_hold_days': float(trades_df['days_held'].mean()) if not trades_df.empty else 0.0,
                'avg_stake_ratio': float(trades_df['stake_ratio'].mean()) if not trades_df.empty else 0.0,
                'profit_factor': float(profit_factor),
                'max_drawdown_pct': float(max_dd),
                'daily_sharpe': float(sharpe),
            },
            'stats': self.stats,
            'paths': {
                'trades_csv': os.path.join(out_dir, 'trades.csv'),
                'equity_csv': os.path.join(out_dir, 'equity.csv'),
                'signals_csv': os.path.join(out_dir, 'signals.csv'),
                'trade_windows_index_csv': trade_windows_index or '',
            }
        }
        with open(os.path.join(out_dir, 'summary.json'), 'w', encoding='utf-8') as f:
            json.dump(summary, f, ensure_ascii=False, indent=2)

        self.last_report_paths = {
            'summary_json': os.path.join(out_dir, 'summary.json'),
            'trades_csv': os.path.join(out_dir, 'trades.csv'),
            'equity_csv': os.path.join(out_dir, 'equity.csv'),
            'signals_csv': os.path.join(out_dir, 'signals.csv'),
            'trade_windows_index_csv': trade_windows_index or '',
        }

    def _print_summary(self):
        pf = self.profile
        print('\n' + '='*70)
        print(f'  回测结果汇总  [{pf.name}]')
        print(f'  止损底线={pf.stop_floor*100:.0f}% 追踪触发={pf.trail_trigger*100:.0f}% '
              f'锁利={pf.trail_lock*100:.0f}% 超时={pf.time_exit_days}天'
              + (f' 硬止盈={pf.hard_cap*100:.0f}%' if pf.hard_cap > 0 else ''))
        print('='*70)

        eq = self.portfolio.equity_curve
        if not eq:
            print('  无交易记录')
            return

        init = 100000
        final = eq[-1]['equity']
        total_return = (final - init) / init * 100
        trades = self.portfolio.trades

        wins = [t for t in trades if t.pnl_pct > 0]
        losses = [t for t in trades if t.pnl_pct <= 0]

        print(f'  初始资金:   {init:>12,.0f}')
        print(f'  最终资金:   {final:>12,.0f}')
        print(f'  总收益:     {total_return:>11.1f}%')
        if 'benchmark_return_pct' in self.run_meta:
            bret = self.run_meta['benchmark_return_pct']
            print(f'  基准收益:   {bret:>11.1f}% ({self.run_meta.get("benchmark_symbol","")})')
            print(f'  超额收益:   {total_return - bret:>11.1f}%')
        print(f'')
        print(f'  总交易数:   {len(trades):>12}')
        print(f'  盈利次数:   {len(wins):>12}')
        print(f'  亏损次数:   {len(losses):>12}')
        if trades:
            win_rate = len(wins) / len(trades) * 100
            print(f'  胜率:       {win_rate:>11.1f}%')

        if wins:
            avg_win = np.mean([t.pnl_pct for t in wins])
            max_win = max(t.pnl_pct for t in wins)
            print(f'  平均盈利:   {avg_win:>11.1f}%')
            print(f'  最大单笔盈: {max_win:>11.1f}%')

        if losses:
            avg_loss = np.mean([t.pnl_pct for t in losses])
            max_loss = min(t.pnl_pct for t in losses)
            print(f'  平均亏损:   {avg_loss:>11.1f}%')
            print(f'  最大单笔亏: {max_loss:>11.1f}%')

        if wins and losses:
            profit_factor = abs(sum(t.pnl_pct for t in wins) / sum(t.pnl_pct for t in losses))
            print(f'  盈亏比:     {profit_factor:>11.2f}')

        # 最大回撤
        eq_values = [e['equity'] for e in eq]
        peak_val = eq_values[0]
        max_dd = 0
        for v in eq_values:
            if v > peak_val:
                peak_val = v
            dd = (peak_val - v) / peak_val * 100
            if dd > max_dd:
                max_dd = dd
        print(f'  最大回撤:   {max_dd:>11.1f}%')

        avg_pos = np.mean([e['positions'] for e in eq]) if eq else 0
        max_pos = max([e['positions'] for e in eq]) if eq else 0
        print(f'  平均仓位数: {avg_pos:>11.2f}')
        print(f'  最大仓位数: {max_pos:>11}')

        self._print_type_breakdown(trades)
        self._print_exit_breakdown(trades)
        self._print_monthly_breakdown(trades)

        # 逐笔明细
        print(f'\n  逐笔交易明细:')
        print(f'  {"日期":<12} {"代码":<8} {"类型":<6} {"买":<8} {"卖":<8} '
              f'{"盈亏%":<8} {"天数":<4} {"原因"}')
        print(f'  {"-"*80}')
        for t in trades:
            emoji = '💰' if t.pnl_pct > 0 else '❌'
            print(f'  {t.buy_date:<12} {t.code:<8} {t.signal_type:<6} '
                  f'{t.buy_price:<8.2f} {t.sell_price:<8.2f} '
                  f'{t.pnl_pct:<+7.1f}% {t.days_held:<4} {emoji} {t.exit_reason}')
            if self.detail_mode in ('verbose', 'full'):
                print(f'      ↳ MFE:{t.mfe_pct:+.1f}% MAE:{t.mae_pct:+.1f}% R:{t.r_multiple:+.2f} '
                      f'风险:{t.risk_pct:.2f}% | {t.entry_note} | {t.entry_tags}')

        # 信号漏斗
        s = self.stats
        print(f'\n  信号漏斗:')
        print(f'    总信号:      {s["total_signals"]:>6}')
        print(f'    即买候选:    {s["immediate_eligible"]:>6}  (按枪种路由)')
        print(f'    即买成交:    {s["immediate_bought"]:>6}')
        print(f'    观察池入:    {s["watchlist_added"]:>6}  (按枪种路由)')
        print(f'    确认通过:    {s["watchlist_confirmed"]:>6}')
        print(f'    观察池买:    {s["watchlist_bought"]:>6}')
        print(f'    观察过期:    {s["watch_expired"]:>6}')
        if s.get('preload_total', 0):
            print(f'    预加载缓存:')
            print(f'      总数      {s["preload_total"]:>6}')
            print(f'      内存命中   {s.get("preload_mem_hit", 0):>6}')
            print(f'      磁盘命中   {s.get("preload_disk_hit", 0):>6}')
            print(f'      重建       {s.get("preload_rebuilt", 0):>6}')
        if s.get('size_tiers'):
            print(f'    仓位层级:')
            for k, cnt in sorted(s['size_tiers'].items(), key=lambda x: -x[1]):
                print(f'      {k:<8} {cnt:>6}')
        if s.get('disabled_by_type'):
            print(f'    被禁用过滤:')
            for t, cnt in sorted(s['disabled_by_type'].items(), key=lambda x: -x[1]):
                print(f'      {t:<8} {cnt:>6}')
        if s.get('signal_by_type'):
            print(f'    类型转化:')
            for t, cnt in sorted(s['signal_by_type'].items(), key=lambda x: -x[1]):
                bought = s.get('buy_by_type', {}).get(t, 0)
                cap = bought / cnt * 100 if cnt > 0 else 0
                print(f'      {t:<8} 检出{cnt:>4}  成交{bought:>4}  转化{cap:>5.1f}%')
        if s['reject_reasons']:
            print(f'    拒绝原因:')
            for reason, cnt in sorted(s['reject_reasons'].items(),
                                       key=lambda x: -x[1]):
                print(f'      {reason:<20} {cnt:>5}')

        # 净值曲线 (文字版)
        print(f'\n  净值曲线:')
        step = max(1, len(eq) // 20)
        for i in range(0, len(eq), step):
            e = eq[i]
            bar_len = int((e['equity'] / init - 0.8) * 100)
            bar_len = max(0, min(bar_len, 50))
            mkt = '✅' if e['market_ok'] else '❌'
            print(f'  {e["date"]} {e["equity"]:>10,.0f} {mkt} {"█"*bar_len}')


# ============================================================
# 五、运行入口
# ============================================================

