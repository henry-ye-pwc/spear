from dataclasses import dataclass, field
from typing import Dict, List

@dataclass
class Trade:
    code: str
    buy_date: str
    buy_price: float
    sell_date: str = ''
    sell_price: float = 0
    stop_line: float = 0
    signal_type: str = ''
    days_held: int = 0
    pnl_pct: float = 0
    exit_reason: str = ''
    signal_nat: str = ''
    signal_conf: float = 0
    entry_mode: str = ''
    stake_ratio: float = 0
    entry_note: str = ''
    entry_tags: str = ''
    entry_pos: str = ''
    entry_cut: float = 0
    entry_shadow: float = 0
    entry_vr: float = 0
    pressure: float = 0
    release: float = 0
    two_side_active: bool = False
    zhyx_ok: bool = False
    zhyx_reason: str = ''
    zhyx_base: float = 0
    zhyx_burst_ref: float = 0
    init_stop: float = 0
    mfe_pct: float = 0
    mae_pct: float = 0
    risk_pct: float = 0
    r_multiple: float = 0
    exit_open: float = 0
    exit_high: float = 0
    exit_low: float = 0
    exit_close: float = 0
    entry_path: str = ''
    was_deferred: bool = False
    entry_regime: str = ''


@dataclass
class Portfolio:
    cash: float = 100000
    max_positions: int = 3
    pos_pct: float = 0.30
    positions: Dict = field(default_factory=dict)  # {code: {shares, cost, stop, days, peak}}
    trades: List[Trade] = field(default_factory=list)
    equity_curve: List = field(default_factory=list)

    def total_value(self, prices: dict) -> float:
        val = self.cash
        for code, p in self.positions.items():
            px = prices.get(code, p['cost'])
            val += p['shares'] * px
        return val

    def available_slots(self):
        return self.max_positions - len(self.positions)


@dataclass
class RiskProfile:
    name: str
    stop_mult: float
    trail_trigger: float
    trail_lock: float
    time_exit_days: int
    time_exit_min: float
    arb_exit_days: int
    arb_exit_min: float
    hard_cap: float
    stop_floor: float

    @classmethod
    def conservative(cls):
        return cls(
            name='保守', stop_mult=0.98, trail_trigger=0.04, trail_lock=0.60,
            time_exit_days=5, time_exit_min=0.015, arb_exit_days=2, arb_exit_min=0.005,
            hard_cap=0.08, stop_floor=0.96)

    @classmethod
    def balanced(cls):
        return cls(
            name='均衡', stop_mult=1.0, trail_trigger=0.06, trail_lock=0.50,
            time_exit_days=7, time_exit_min=0.02, arb_exit_days=3, arb_exit_min=0.005,
            hard_cap=0.0, stop_floor=0.95)

    @classmethod
    def aggressive(cls):
        return cls(
            name='激进', stop_mult=1.0, trail_trigger=0.10, trail_lock=0.40,
            time_exit_days=10, time_exit_min=0.03, arb_exit_days=3, arb_exit_min=0.005,
            hard_cap=0.0, stop_floor=0.92)


def get_optimal_exits(sig_type: str):
    """
    根据最大期望倒推的各枪型最优固定止盈止损策略。
    
    【全新改造】: 引入“破枪底即斩”的动态防线。
    这里的 sl 只是一个极端兜底防线（防核按钮）。
    因为有了收盘价跌破城门的动态防线，我们将所有枪型的兜底防线统一放宽到 10% (0.10)，
    给予主力充分的日内震荡/深V洗盘空间。
    """
    opts = {
        '★套利': {'sl': 0.10, 'tp': 0.10, 'days': 15}, 
        '趋势': {'sl': 0.10, 'tp': 1.00, 'days': 15}, # 移除固定止盈，采用动态量价跟踪
        '游资': {'sl': 0.15, 'tp': 0.10, 'days': 3},  
        '进攻': {'sl': 0.10, 'tp': 1.00, 'days': 5},
        '板后': {'sl': 0.10, 'tp': 1.00, 'days': 12}, # 移除固定止盈，采用动态量价跟踪
        '烂板': {'sl': 0.10, 'tp': 0.10, 'days': 5},
    }
    return opts.get(str(sig_type), {'sl': 0.10, 'tp': 0.10, 'days': 5})

def calc_stop(sig, buy_price, profile: RiskProfile):
    sig_type = sig.get('type', '')
    exits = get_optimal_exits(sig_type)
    
    # 基础止损位：基于回测优化的兜底百分比防线（防极端核按钮）
    base_stop = buy_price * (1 - exits['sl'])
    
    # 城门防线：用于计算收盘有效跌破，不作为盘中直接斩仓依据
    # 这个值会通过 init_stop_close 存入仓位字典
    sig_cut = float(sig.get('cut', 0) or 0)
    
    return round(base_stop, 2)


