"""反事实出场回测模块 — P0/P1 验证"""
from .config import CounterfactualConfig, PRESETS
from .engine import simulate_trade, simulate_trades, TradeInput, TradeResult
from .metrics import compute_metrics, evaluate_selloffs, diff_report
