"""
反事实出场回测 — CLI 入口

用法:
    cd spear-strategy
    python -m cq_backtest.counterfactual.runner \
        --trades output/backtest_reports/.../trades.csv \
        --presets baseline,G1,G2,B1,B2 \
        --output-dir output/counterfactual
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import time
from pathlib import Path

import pandas as pd

# 确保 package 可导入
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from cq_backtest.counterfactual.config import CounterfactualConfig, PRESETS
from cq_backtest.counterfactual.engine import TradeInput, simulate_trades
from cq_backtest.counterfactual.metrics import compute_metrics, evaluate_selloffs, diff_report
from cq_backtest.v1.data.feed import DataFeed, prepare_kline


def load_trades(csv_path: str) -> list[TradeInput]:
    df = pd.read_csv(csv_path)
    trades = []
    for _, row in df.iterrows():
        code = str(row['code']).zfill(6)
        trades.append(TradeInput(
            code=code,
            buy_date=str(row['buy_date']),
            buy_price=float(row['buy_price']),
            signal_type=str(row.get('signal_type', '')),
            signal_conf=float(row.get('signal_conf', 0.8)),
            entry_cut=float(row.get('entry_cut', 0) or 0),
            init_stop=float(row.get('init_stop', 0) or 0),
            entry_geo=float(row.get('entry_geo', 0.5) if 'entry_geo' in row.index else 0.5),
            entry_pos=str(row.get('entry_pos', '')),
            stake_ratio=float(row.get('stake_ratio', 0.1) or 0.1),
            risk_pct=float(row.get('risk_pct', 10.0) or 10.0),
            orig_sell_date=str(row.get('sell_date', '')),
            orig_sell_price=float(row.get('sell_price', 0) or 0),
            orig_pnl_pct=float(row.get('pnl_pct', 0) or 0),
            orig_exit_reason=str(row.get('exit_reason', '')),
            orig_mfe_pct=float(row.get('mfe_pct', 0) or 0),
            orig_mae_pct=float(row.get('mae_pct', 0) or 0),
        ))
    return trades


def load_klines(trades: list[TradeInput], feed: DataFeed) -> dict[str, pd.DataFrame]:
    codes = sorted(set(t.code for t in trades))
    print(f'  Loading K-lines for {len(codes)} stocks...')
    klines = {}
    for i, code in enumerate(codes):
        df = feed.get_kline(code, count=3200)
        if df is not None and not df.empty:
            df = prepare_kline(df, code)
            if not df.empty:
                klines[code] = df
        if (i + 1) % 50 == 0:
            print(f'    {i + 1}/{len(codes)}')
    print(f'  ✓ {len(klines)}/{len(codes)} stocks loaded')
    return klines


def run_preset(name: str, trades: list[TradeInput],
               klines: dict[str, pd.DataFrame],
               output_dir: str) -> dict:
    factory = PRESETS.get(name)
    if factory is None:
        print(f'  ⚠ Unknown preset "{name}", skipping')
        return {}

    cfg = factory()
    print(f'\n{"═" * 60}')
    print(f'  {cfg.name}')
    print(f'  {cfg.describe_diff()}')
    print(f'{"═" * 60}')

    t0 = time.time()
    results = simulate_trades(trades, cfg, klines)
    results = evaluate_selloffs(results, klines, cfg)
    metrics = compute_metrics(results)
    elapsed = time.time() - t0

    out = os.path.join(output_dir, name)
    os.makedirs(out, exist_ok=True)

    with open(os.path.join(out, 'metrics.json'), 'w', encoding='utf-8') as f:
        json.dump(metrics, f, indent=2, ensure_ascii=False, default=str)

    results_df = pd.DataFrame([r.__dict__ for r in results])
    results_df.to_csv(os.path.join(out, 'trades_simulated.csv'), index=False)

    cfg.to_json(os.path.join(out, 'config.json'))

    print(f'  Trades:     {metrics["total_trades"]}')
    print(f'  Win rate:   {metrics["win_rate"]:.1%}')
    print(f'  PF:         {metrics["profit_factor"]:.3f}')
    print(f'  Sum PnL:    {metrics["sum_pnl_pct"]:.1f}%')
    print(f'  Compound:   {metrics["compounded_return_pct"]:.1f}%')
    print(f'  MaxDD:      {metrics["max_drawdown_pct"]:.1f}%')
    print(f'  Avg hold:   {metrics["avg_hold_days"]:.1f} days')
    print(f'  Selloff:    {metrics["selloff_rebound_rate_pct"]:.1f}%')
    print(f'  ({elapsed:.1f}s)')

    return metrics


def main():
    parser = argparse.ArgumentParser(description='反事实出场回测')
    parser.add_argument('--trades', required=True, help='Path to trades.csv')
    parser.add_argument('--cache-dir', default='./cache', help='K-line cache dir')
    parser.add_argument('--presets', default='baseline,G1,G2,B1,B2',
                        help='Comma-separated preset names (default: baseline,G1,G2,B1,B2)')
    parser.add_argument('--output-dir', default='./output/counterfactual',
                        help='Output directory')
    args = parser.parse_args()

    print('═══ 反事实出场回测 ═══\n')

    print('1. Loading trades...')
    trades = load_trades(args.trades)
    print(f'   {len(trades)} trades loaded\n')

    print('2. Loading K-line data...')
    feed = DataFeed(cache_dir=args.cache_dir)
    klines = load_klines(trades, feed)

    print('\n3. Running simulations...')
    preset_names = [p.strip() for p in args.presets.split(',')]
    all_metrics = {}

    for name in preset_names:
        m = run_preset(name, trades, klines, args.output_dir)
        if m:
            all_metrics[name] = m

    if 'baseline' in all_metrics and len(all_metrics) > 1:
        print('\n4. Generating diff report...')
        report = diff_report(all_metrics, baseline_name='baseline')
        os.makedirs(args.output_dir, exist_ok=True)
        report_path = os.path.join(args.output_dir, 'diff_report.md')
        with open(report_path, 'w', encoding='utf-8') as f:
            f.write(report)
        print(f'   Saved to {report_path}')
        print('\n' + report)

    print('\n✓ Done!')


if __name__ == '__main__':
    main()
