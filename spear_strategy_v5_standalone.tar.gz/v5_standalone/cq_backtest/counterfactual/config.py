"""
反事实出场回测 — 配置系统

设计原则:
  1. Dataclass 替代嵌套 dict → 类型安全 + IDE 补全 + 不再需要 .get() 链
  2. 每个出场机制通过 mode 字段选择行为变体 (plugin pattern)
  3. 预设配置(presets) 覆盖常用组合, 支持 from_overrides 快速派生
  4. 所有百分比参数统一存储为人类可读的百分比值(5.0 = 5%), 引擎内部 /100
"""

from __future__ import annotations
import copy
import json
from dataclasses import dataclass, field, asdict
from typing import Dict, Literal, Optional


# ═══════════════════════════════════════════════════════════════
# 各出场机制配置
# ═══════════════════════════════════════════════════════════════

@dataclass
class StopLossConfig:
    """兜底止损 (盘中 low < stop → 立即出场)"""
    enabled: bool = True
    sl_pct: float = 10.0
    sl_pct_youzi: float = 15.0


@dataclass
class GateBreakConfig:
    """城门跌破出场"""
    enabled: bool = True
    mode: Literal['immediate', 'next_day_confirm', 'volume_qualified'] = 'immediate'

    tolerance_mode: Literal['fixed', 'adaptive'] = 'adaptive'
    fixed_tolerance_trend_pct: float = 3.0
    fixed_tolerance_other_pct: float = 2.0
    adaptive_base_pct: float = 2.0
    adaptive_extra_pct: float = 3.0

    volume_ratio_threshold: float = 1.5
    volume_ma_period: int = 20


@dataclass
class MfeProtectConfig:
    """MFE 保护机制"""
    enabled: bool = True
    mode: Literal['raise_stop', 'breakeven', 'tight_trail'] = 'raise_stop'

    mfe_threshold_pct: float = 5.0
    raise_new_stop_pct: float = -2.0
    breakeven_buffer_pct: float = 0.0
    trail_pct: float = 3.0


@dataclass
class TrailingTpConfig:
    """阶梯式动态追踪止盈"""
    enabled: bool = True
    trigger_pct: float = 5.0

    exemption_mode: Literal['v3_dual', 'v2_speed', 'none'] = 'v3_dual'
    mfe_ceiling_pct: float = 10.0
    slow_rise_max_speed: float = 2.5
    slow_rise_max_pullback: float = 2.0
    trend_min_consecutive_up: int = 3
    trend_max_pullback_ratio: float = 0.5
    v2_mfe_exempt_pct: float = 10.0
    v2_speed_exempt: float = 2.0


@dataclass
class EscapeConfig:
    """高位巨量逃命特征 (midday)"""
    enabled: bool = True
    vol_ma_period: int = 60
    vol_threshold: float = 3.5
    min_profit_pct: float = 5.0


@dataclass
class BoardPostConfig:
    """板后特殊出场"""
    enabled: bool = True


@dataclass
class TimeExitConfig:
    """超时退出"""
    enabled: bool = True
    max_days: Dict[str, int] = field(default_factory=lambda: {
        '★套利': 15, '套利': 15, '趋势': 15, '游资': 3,
        '进攻': 5, '板后': 12, '烂板': 5,
    })
    default_max_days: int = 5


# ═══════════════════════════════════════════════════════════════
# 主配置
# ═══════════════════════════════════════════════════════════════

@dataclass
class CounterfactualConfig:
    """反事实出场回测 — 一体化配置"""
    name: str = 'baseline'

    stop_loss: StopLossConfig = field(default_factory=StopLossConfig)
    gate_break: GateBreakConfig = field(default_factory=GateBreakConfig)
    mfe_protect: MfeProtectConfig = field(default_factory=MfeProtectConfig)
    trailing_tp: TrailingTpConfig = field(default_factory=TrailingTpConfig)
    escape: EscapeConfig = field(default_factory=EscapeConfig)
    board_post: BoardPostConfig = field(default_factory=BoardPostConfig)
    time_exit: TimeExitConfig = field(default_factory=TimeExitConfig)

    fill_model: Literal['close', 'next_open'] = 'close'
    selloff_horizon_days: int = 20
    selloff_rebound_pct: float = 10.0
    max_extended_days: int = 30

    # ── helpers ──

    def to_dict(self) -> dict:
        return asdict(self)

    def to_json(self, path: str):
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(self.to_dict(), f, indent=2, ensure_ascii=False)

    @classmethod
    def from_toml(cls, name: str = 'baseline') -> CounterfactualConfig:
        """Build config from [counterfactual] section in settings.toml."""
        try:
            from cq_backtest.settings_loader import get_counterfactual_config
            t = get_counterfactual_config()
        except Exception:
            t = {}
        if not t:
            return cls(name=name)

        sub_map = {
            'stop_loss': StopLossConfig,
            'gate_break': GateBreakConfig,
            'mfe_protect': MfeProtectConfig,
            'trailing_tp': TrailingTpConfig,
            'escape': EscapeConfig,
            'board_post': BoardPostConfig,
            'time_exit': TimeExitConfig,
        }
        kwargs: dict = {'name': name}
        for field_name, dc_cls in sub_map.items():
            section = t.get(field_name, {})
            if section:
                kwargs[field_name] = dc_cls(**{
                    k: v for k, v in section.items()
                    if k in {f.name for f in __import__('dataclasses').fields(dc_cls)}
                })
        for scalar in ('fill_model', 'selloff_horizon_days', 'selloff_rebound_pct', 'max_extended_days'):
            if scalar in t:
                kwargs[scalar] = t[scalar]
        return cls(**kwargs)

    @classmethod
    def from_overrides(cls, name: str = 'custom', **kw) -> CounterfactualConfig:
        """Dot-path overrides: ``from_overrides('G2', gate_break__mode='volume_qualified')``"""
        cfg = cls(name=name)
        for key, val in kw.items():
            parts = key.split('__')
            obj = cfg
            for part in parts[:-1]:
                obj = getattr(obj, part)
            setattr(obj, parts[-1], val)
        return cfg

    def describe_diff(self, baseline: Optional[CounterfactualConfig] = None) -> str:
        """Human-readable summary of differences from baseline."""
        if baseline is None:
            baseline = CounterfactualConfig()
        bd, sd = baseline.to_dict(), self.to_dict()
        diffs = _dict_diff(bd, sd)
        if not diffs:
            return f'[{self.name}] identical to baseline'
        lines = [f'[{self.name}] diff from baseline:']
        for path, (old, new) in diffs.items():
            lines.append(f'  {path}: {old} → {new}')
        return '\n'.join(lines)


def _dict_diff(a: dict, b: dict, prefix: str = '') -> dict:
    out = {}
    for k in set(list(a.keys()) + list(b.keys())):
        av, bv = a.get(k), b.get(k)
        path = f'{prefix}.{k}' if prefix else k
        if isinstance(av, dict) and isinstance(bv, dict):
            out.update(_dict_diff(av, bv, path))
        elif av != bv:
            out[path] = (av, bv)
    return out


# ═══════════════════════════════════════════════════════════════
# 预设工厂 (Presets)
# ═══════════════════════════════════════════════════════════════

def _baseline() -> CounterfactualConfig:
    return CounterfactualConfig.from_toml('baseline')


def _G1() -> CounterfactualConfig:
    cfg = _baseline()
    cfg.name = 'G1_gate_next_day'
    cfg.gate_break.mode = 'next_day_confirm'
    return cfg


def _G2() -> CounterfactualConfig:
    cfg = _baseline()
    cfg.name = 'G2_volume_qualified'
    cfg.gate_break.mode = 'volume_qualified'
    return cfg


def _B1() -> CounterfactualConfig:
    cfg = _baseline()
    cfg.name = 'B1_breakeven'
    cfg.mfe_protect.mode = 'breakeven'
    return cfg


def _B2() -> CounterfactualConfig:
    cfg = _baseline()
    cfg.name = 'B2_tight_trail'
    cfg.mfe_protect.mode = 'tight_trail'
    return cfg


def _G1_B1() -> CounterfactualConfig:
    cfg = _G1()
    cfg.name = 'G1+B1'
    cfg.mfe_protect.mode = 'breakeven'
    return cfg


def _G2_B1() -> CounterfactualConfig:
    cfg = _G2()
    cfg.name = 'G2+B1'
    cfg.mfe_protect.mode = 'breakeven'
    return cfg


PRESETS: Dict[str, callable] = {
    'baseline': _baseline,
    'G1': _G1,
    'G2': _G2,
    'B1': _B1,
    'B2': _B2,
    'G1+B1': _G1_B1,
    'G2+B1': _G2_B1,
}
