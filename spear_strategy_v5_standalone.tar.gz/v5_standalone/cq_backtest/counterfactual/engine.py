"""
反事实出场回测 — 模拟引擎

核心约束: 所有出场决策只使用 *当日及之前* 的数据，禁止前视偏差。
MFE/MAE 在逐日前推过程中实时计算，不得使用 full_analysis 中的事后值。
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

from .config import CounterfactualConfig


# ═══════════════════════════════════════════════════════════════
# 数据合约
# ═══════════════════════════════════════════════════════════════

@dataclass
class TradeInput:
    """从 trades.csv 读入的原始交易（入场固定，只改出场）"""
    code: str
    buy_date: str
    buy_price: float
    signal_type: str
    signal_conf: float = 0.80
    entry_cut: float = 0.0        # 城门线 (入场时确定, 持仓期不变)
    init_stop: float = 0.0
    entry_geo: float = 0.5
    entry_pos: str = ''
    stake_ratio: float = 0.10
    risk_pct: float = 10.0
    # 原始出场 (供对比，不参与决策)
    orig_sell_date: str = ''
    orig_sell_price: float = 0.0
    orig_pnl_pct: float = 0.0
    orig_exit_reason: str = ''
    orig_mfe_pct: float = 0.0
    orig_mae_pct: float = 0.0


@dataclass
class TradeResult:
    """模拟输出"""
    code: str
    buy_date: str
    buy_price: float
    sell_date: str
    sell_price: float
    pnl_pct: float
    days_held: int
    exit_reason: str
    mfe_pct: float
    mae_pct: float
    # 对比
    orig_sell_date: str = ''
    orig_pnl_pct: float = 0.0
    orig_exit_reason: str = ''
    pnl_delta: float = 0.0
    # 卖飞诊断
    sold_then_rebound: bool = False


# ═══════════════════════════════════════════════════════════════
# 内部状态
# ═══════════════════════════════════════════════════════════════

@dataclass
class _State:
    cost: float
    stop: float
    sig_cut: float
    sig_type: str
    sig_conf: float
    entry_geo: float
    days_held: int = 0
    peak_price: float = 0.0
    trough_price: float = 0.0
    consecutive_up_days: int = 0
    gate_pending: bool = False
    mfe_reached: bool = False
    trail_stop: float = 0.0


# ═══════════════════════════════════════════════════════════════
# 辅助 — 从现有 backtester 提取的出场参数
# ═══════════════════════════════════════════════════════════════

_TP_MAP = {
    '★套利': 0.10, '套利': 0.10, '趋势': 1.00, '游资': 0.10,
    '进攻': 1.00, '板后': 1.00, '烂板': 0.10,
}

_SL_MAP = {'游资': 0.15}          # 其余统一 0.10
_DEFAULT_SL = 0.10


def _hard_cap(sig_type: str, sig_conf: float) -> float:
    cap = _TP_MAP.get(sig_type, 0.10)
    if '趋势' not in sig_type and '板后' not in sig_type:
        if sig_conf < 0.75 and cap > 0.05:
            cap = 0.05
    return cap


def _init_stop(buy_price: float, sig_type: str, cfg: CounterfactualConfig, override: float) -> float:
    if override > 0:
        return override
    sl = cfg.stop_loss.sl_pct_youzi / 100 if '游资' in sig_type else cfg.stop_loss.sl_pct / 100
    return buy_price * (1 - sl)


# ═══════════════════════════════════════════════════════════════
# 出场检查 — 每个函数对应一个出场机制
# ═══════════════════════════════════════════════════════════════

def _check_stop_loss(s: _State, o: float, l: float, cfg: CounterfactualConfig) -> Optional[Tuple[float, str]]:
    if not cfg.stop_loss.enabled:
        return None
    if l < s.stop:
        px = min(o, s.stop)
        return px, f'止损 low={l:.2f}<兜底线{s.stop:.2f}'
    return None


def _check_hard_tp(s: _State, h: float) -> Optional[Tuple[float, str]]:
    cap = _hard_cap(s.sig_type, s.sig_conf)
    if cap >= 1.0:
        return None
    pf = (h - s.cost) / s.cost
    if pf >= cap:
        px = s.cost * (1 + cap)
        is_capped = '趋势' not in s.sig_type and '板后' not in s.sig_type and s.sig_conf < 0.75
        reason = f'低信心见好就收 {cap*100:.0f}%' if is_capped and cap <= 0.05 else f'止盈 {cap*100:.0f}%'
        return px, reason
    return None


def _apply_mfe_protect(s: _State, peak_pf: float, cfg: CounterfactualConfig):
    mc = cfg.mfe_protect
    if not mc.enabled:
        return
    thresh = mc.mfe_threshold_pct / 100
    if peak_pf < thresh:
        return
    s.mfe_reached = True
    if mc.mode == 'raise_stop':
        ns = s.cost * (1 + mc.raise_new_stop_pct / 100)
        s.stop = max(s.stop, ns)
    elif mc.mode == 'breakeven':
        ns = s.cost * (1 + mc.breakeven_buffer_pct / 100)
        s.stop = max(s.stop, ns)
    elif mc.mode == 'tight_trail':
        ts = s.peak_price * (1 - mc.trail_pct / 100)
        s.trail_stop = max(s.trail_stop, ts)
        s.stop = max(s.stop, s.trail_stop)


def _check_escape(kline_up_to: pd.DataFrame, o: float, h: float, c: float,
                   vol: float, profit: float, ec: 'EscapeConfig') -> Optional[str]:
    if not ec.enabled:
        return None
    n = ec.vol_ma_period
    if len(kline_up_to) <= n:
        return None
    vol_ma = kline_up_to['volume'].iloc[-(n + 1):-1].mean()
    if vol_ma <= 0:
        return None
    if vol <= vol_ma * ec.vol_threshold:
        return None
    failed_lu = (h >= o * 1.09) and (c < h * 0.98)
    if (failed_lu or c < o) and profit > ec.min_profit_pct / 100:
        return '高位巨量逃命特征(主力出货)'
    return None


def _gate_tolerance(s: _State, peak_pf: float, cfg: CounterfactualConfig) -> float:
    gc = cfg.gate_break
    if gc.tolerance_mode == 'adaptive':
        base = gc.adaptive_base_pct / 100
        extra = gc.adaptive_extra_pct / 100
        tol = 1.0 - (base + s.entry_geo * extra)
        if peak_pf > 0.05:
            tol = 1.0 - base
        return tol
    # fixed
    if peak_pf > 0.05:
        return 1.00
    if '趋势' in s.sig_type or '进攻' in s.sig_type:
        return 1.0 - gc.fixed_tolerance_trend_pct / 100
    return 1.0 - gc.fixed_tolerance_other_pct / 100


def _check_gate(s: _State, c: float, vol: float,
                kline_up_to: pd.DataFrame, peak_pf: float,
                cfg: CounterfactualConfig) -> Optional[str]:
    gc = cfg.gate_break
    if not gc.enabled or s.sig_cut <= 0:
        return None
    tol = _gate_tolerance(s, peak_pf, cfg)
    gate_line = s.sig_cut * tol
    broken = c < gate_line

    if not broken:
        s.gate_pending = False
        return None

    if gc.mode == 'immediate':
        return f'收盘有效跌破城门 c={c:.2f}<城门{s.sig_cut:.2f}'

    if gc.mode == 'next_day_confirm':
        if not s.gate_pending:
            s.gate_pending = True
            return None
        s.gate_pending = False
        return f'城门次日确认跌破 c={c:.2f}<城门{s.sig_cut:.2f}(G1)'

    if gc.mode == 'volume_qualified':
        n = gc.volume_ma_period
        if len(kline_up_to) > n:
            vol_ma = kline_up_to['volume'].iloc[-(n + 1):-1].mean()
            vr = vol / vol_ma if vol_ma > 0 else 0
        else:
            vr = 0
        if vr >= gc.volume_ratio_threshold:
            s.gate_pending = False
            return f'放量跌破城门 c={c:.2f}(G2 vr={vr:.1f})'
        if not s.gate_pending:
            s.gate_pending = True
            return None
        s.gate_pending = False
        return f'缩量跌破城门次日确认 c={c:.2f}(G2确认)'

    return None


def _check_trailing_tp(s: _State, profit: float, peak_pf: float,
                       cfg: CounterfactualConfig) -> Optional[str]:
    tc = cfg.trailing_tp
    if not tc.enabled or peak_pf <= tc.trigger_pct / 100:
        return None

    exempt = False
    if tc.exemption_mode == 'v3_dual':
        ceil = tc.mfe_ceiling_pct / 100
        if peak_pf < ceil and s.days_held > 0:
            spd = peak_pf / s.days_held
            pb = peak_pf - profit
            ca = spd < tc.slow_rise_max_speed / 100 and pb < tc.slow_rise_max_pullback / 100
            cb = (s.consecutive_up_days >= tc.trend_min_consecutive_up
                  and peak_pf > 0
                  and pb < peak_pf * tc.trend_max_pullback_ratio)
            exempt = ca or cb
    elif tc.exemption_mode == 'v2_speed':
        ceil = tc.v2_mfe_exempt_pct / 100
        if peak_pf < ceil and s.days_held > 0:
            exempt = peak_pf / s.days_held < tc.v2_speed_exempt / 100

    if exempt:
        return None

    if peak_pf <= 0.15:
        tol = max(peak_pf * 0.5, 0.05)
    elif peak_pf <= 0.30:
        tol = max(peak_pf * 0.4, 0.08)
    else:
        tol = max(peak_pf * 0.35, 0.12)

    if profit < peak_pf - tol:
        return f'阶梯式追踪止盈(从{peak_pf * 100:.1f}%回撤)'
    return None


def _check_board_post(s: _State, kline_up_to: pd.DataFrame,
                      o: float, h: float, c: float, vol: float,
                      profit: float) -> Optional[str]:
    if '板后' not in s.sig_type:
        return None
    if len(kline_up_to) <= 5:
        return None
    vma5 = kline_up_to['volume'].iloc[-6:-1].mean()
    if vma5 <= 0:
        return None
    if profit > 0.03 and vol > vma5 * 1.5 and c < o * 0.98:
        return '板后情绪退潮(放量收阴)'
    if profit > 0.15 and c < h * 0.98:
        return '板后高位断板(情绪落袋)'
    if s.days_held >= 3 and profit < 0.05 and s.sig_conf < 0.75 and vol < vma5 * 0.8:
        return '板后缩量断气(无资金接力)'
    return None


# ═══════════════════════════════════════════════════════════════
# 核心: 逐日前推模拟单笔交易
# ═══════════════════════════════════════════════════════════════

def simulate_trade(trade: TradeInput, cfg: CounterfactualConfig,
                   kline: pd.DataFrame) -> TradeResult:
    """
    从 buy_date+1 逐日前推, 直到出场条件触发或超时。
    kline: 该股票完整日K (DatetimeIndex, 含 open/high/low/close/volume)。
    """
    buy_ts = pd.Timestamp(trade.buy_date)
    s = _State(
        cost=trade.buy_price,
        stop=_init_stop(trade.buy_price, trade.signal_type, cfg, trade.init_stop),
        sig_cut=trade.entry_cut,
        sig_type=trade.signal_type,
        sig_conf=trade.signal_conf,
        entry_geo=trade.entry_geo,
        peak_price=trade.buy_price,
        trough_price=trade.buy_price,
    )

    time_days = cfg.time_exit.max_days.get(trade.signal_type, cfg.time_exit.default_max_days)
    hard_max = time_days + cfg.max_extended_days

    future = kline.index[kline.index > buy_ts]
    if len(future) == 0:
        return _empty_result(trade)

    exit_price: Optional[float] = None
    exit_date = None
    exit_reason = ''

    for date in future:
        if s.days_held >= hard_max:
            break
        s.days_held += 1
        row = kline.loc[date]
        o, h, l, c = float(row['open']), float(row['high']), float(row['low']), float(row['close'])
        vol = float(row.get('volume', 0))

        if l < s.trough_price:
            s.trough_price = l

        # ── morning ──
        sig = _check_stop_loss(s, o, l, cfg)
        if sig:
            exit_price, exit_reason = sig
            exit_date = date
            break

        sig = _check_hard_tp(s, h)
        if sig:
            exit_price, exit_reason = sig
            exit_date = date
            break

        # update peak (after morning stop, before midday)
        if h > s.peak_price:
            s.peak_price = h
        if c >= o * 0.998:
            s.consecutive_up_days += 1
        else:
            s.consecutive_up_days = 0

        peak_pf = (s.peak_price - s.cost) / s.cost
        profit = (c - s.cost) / s.cost

        # ── midday ──
        _apply_mfe_protect(s, peak_pf, cfg)

        kline_up_to = kline.loc[:date]

        reason = _check_escape(kline_up_to, o, h, c, vol, profit, cfg.escape)
        if reason:
            exit_price, exit_reason, exit_date = c, reason, date
            break

        reason = _check_gate(s, c, vol, kline_up_to, peak_pf, cfg)
        if reason:
            exit_price, exit_reason, exit_date = c, reason, date
            break

        reason = _check_trailing_tp(s, profit, peak_pf, cfg)
        if reason:
            exit_price, exit_reason, exit_date = c, reason, date
            break

        reason = _check_board_post(s, kline_up_to, o, h, c, vol, profit)
        if reason:
            exit_price, exit_reason, exit_date = c, reason, date
            break

        if cfg.time_exit.enabled and s.days_held >= time_days:
            exit_price = c
            exit_date = date
            exit_reason = f'到达最优持有期{time_days}天 profit={profit * 100:.1f}%'
            break

    # force exit at hard_max
    if exit_price is None:
        idx = min(len(future) - 1, hard_max - 1)
        last_date = future[idx]
        exit_price = float(kline.loc[last_date, 'close'])
        exit_date = last_date
        exit_reason = f'强制退出(超{hard_max}天)'

    pnl = (exit_price - trade.buy_price) / trade.buy_price * 100
    mfe = (s.peak_price - trade.buy_price) / trade.buy_price * 100
    mae = (s.trough_price - trade.buy_price) / trade.buy_price * 100
    sell_str = str(exit_date.date()) if hasattr(exit_date, 'date') else str(exit_date)

    return TradeResult(
        code=trade.code,
        buy_date=trade.buy_date,
        buy_price=trade.buy_price,
        sell_date=sell_str,
        sell_price=round(exit_price, 4),
        pnl_pct=round(pnl, 4),
        days_held=s.days_held,
        exit_reason=exit_reason,
        mfe_pct=round(mfe, 4),
        mae_pct=round(mae, 4),
        orig_sell_date=trade.orig_sell_date,
        orig_pnl_pct=trade.orig_pnl_pct,
        orig_exit_reason=trade.orig_exit_reason,
        pnl_delta=round(pnl - trade.orig_pnl_pct, 4),
    )


def _empty_result(t: TradeInput) -> TradeResult:
    return TradeResult(
        code=t.code, buy_date=t.buy_date, buy_price=t.buy_price,
        sell_date=t.buy_date, sell_price=t.buy_price,
        pnl_pct=0.0, days_held=0, exit_reason='no_data',
        mfe_pct=0.0, mae_pct=0.0,
        orig_sell_date=t.orig_sell_date, orig_pnl_pct=t.orig_pnl_pct,
        orig_exit_reason=t.orig_exit_reason, pnl_delta=-t.orig_pnl_pct,
    )


# ═══════════════════════════════════════════════════════════════
# 批量模拟
# ═══════════════════════════════════════════════════════════════

def simulate_trades(trades: List[TradeInput], cfg: CounterfactualConfig,
                    klines: Dict[str, pd.DataFrame]) -> List[TradeResult]:
    results = []
    skipped = 0
    for t in trades:
        kl = klines.get(t.code)
        if kl is None or kl.empty:
            skipped += 1
            continue
        results.append(simulate_trade(t, cfg, kl))
    if skipped:
        print(f'  ⚠ {skipped} trades skipped (no K-line data)')
    return results
