"""
反事实出场回测 — 指标计算 & 对比报告

输出指标严格遵循实验规格:
  收益: 资金曲线回报、PF、胜率、均盈亏
  风险: 最大回撤、尾部率(PnL<=-20%)、单笔最大亏损、最大连亏
  结构: 平均持仓天数、平均同时持仓数
  诊断: 卖飞率(抛后20天反弹>10%)
"""

from __future__ import annotations

from typing import Dict, List, Optional
import numpy as np
import pandas as pd

from .engine import TradeInput, TradeResult
from .config import CounterfactualConfig


def compute_metrics(results: List[TradeResult],
                    initial_equity: float = 100_000,
                    ) -> Dict:
    if not results:
        return {'total_trades': 0}

    pnls = np.array([r.pnl_pct for r in results])
    wins = pnls[pnls > 0]
    losses = pnls[pnls <= 0]
    days = np.array([r.days_held for r in results])

    sum_win = float(wins.sum()) if len(wins) else 0.0
    sum_loss = float(np.abs(losses).sum()) if len(losses) else 0.0
    pf = sum_win / sum_loss if sum_loss > 0 else float('inf')

    # max consecutive losses
    max_con_loss = _max_consecutive(pnls <= 0)

    # pseudo-compounded equity curve (trade-sequential, using stake_ratio proxy)
    eq_curve = _pseudo_equity_curve(results, initial_equity)
    comp_return = (eq_curve[-1] / initial_equity - 1) * 100 if eq_curve else 0.0
    max_dd = _max_drawdown(eq_curve) * 100

    # average simultaneous positions
    avg_overlap = _avg_overlap(results)

    # tail rate
    tail_count = int((pnls <= -20).sum())

    # selloff count
    selloff_count = sum(1 for r in results if r.sold_then_rebound)

    return {
        'total_trades': len(results),
        'win_rate': float(len(wins) / len(pnls)),
        'profit_factor': round(pf, 3),
        'sum_pnl_pct': round(float(pnls.sum()), 2),
        'compounded_return_pct': round(comp_return, 2),
        'max_drawdown_pct': round(max_dd, 2),
        'avg_win_pct': round(float(wins.mean()), 2) if len(wins) else 0.0,
        'avg_loss_pct': round(float(losses.mean()), 2) if len(losses) else 0.0,
        'max_loss_pct': round(float(pnls.min()), 2),
        'max_consecutive_losses': max_con_loss,
        'tail_rate_pct': round(tail_count / len(pnls) * 100, 2),
        'tail_count': tail_count,
        'avg_hold_days': round(float(days.mean()), 1),
        'avg_overlap_positions': round(avg_overlap, 2),
        'selloff_rebound_count': selloff_count,
        'selloff_rebound_rate_pct': round(selloff_count / len(pnls) * 100, 2),
    }


def _max_consecutive(mask: np.ndarray) -> int:
    best = cur = 0
    for v in mask:
        cur = cur + 1 if v else 0
        best = max(best, cur)
    return best


def _pseudo_equity_curve(results: List[TradeResult], initial: float) -> List[float]:
    """Trade-sequential compounded curve using a fixed 10% allocation proxy."""
    sorted_r = sorted(results, key=lambda r: r.buy_date)
    eq = initial
    curve = [eq]
    for r in sorted_r:
        alloc = eq * 0.10
        eq += alloc * (r.pnl_pct / 100)
        curve.append(eq)
    return curve


def _max_drawdown(curve: List[float]) -> float:
    if len(curve) < 2:
        return 0.0
    peak = curve[0]
    dd = 0.0
    for v in curve:
        peak = max(peak, v)
        dd = max(dd, (peak - v) / peak)
    return dd


def _avg_overlap(results: List[TradeResult]) -> float:
    if not results:
        return 0.0
    events = []
    for r in results:
        try:
            bd = pd.Timestamp(r.buy_date)
            sd = pd.Timestamp(r.sell_date)
            events.append((bd, 1))
            events.append((sd, -1))
        except Exception:
            pass
    if not events:
        return 0.0
    events.sort()
    total_area = 0.0
    cur = 0
    prev_date = events[0][0]
    for date, delta in events:
        gap = (date - prev_date).days
        total_area += cur * gap
        cur += delta
        prev_date = date
    span = (events[-1][0] - events[0][0]).days
    return total_area / span if span > 0 else 0.0


# ═══════════════════════════════════════════════════════════════
# 卖飞诊断
# ═══════════════════════════════════════════════════════════════

def evaluate_selloffs(results: List[TradeResult],
                      klines: Dict[str, pd.DataFrame],
                      cfg: CounterfactualConfig) -> List[TradeResult]:
    """In-place annotate sold_then_rebound for each result."""
    horizon = cfg.selloff_horizon_days
    thresh = cfg.selloff_rebound_pct / 100
    for r in results:
        kl = klines.get(r.code)
        if kl is None or kl.empty:
            continue
        try:
            sell_ts = pd.Timestamp(r.sell_date)
            future = kl[kl.index > sell_ts].head(horizon)
            if future.empty:
                continue
            max_high = float(future['high'].max())
            rebound = (max_high - r.sell_price) / r.sell_price
            r.sold_then_rebound = rebound >= thresh
        except Exception:
            pass
    return results


# ═══════════════════════════════════════════════════════════════
# 对比报告
# ═══════════════════════════════════════════════════════════════

_METRIC_LABELS = {
    'total_trades': '交易笔数',
    'win_rate': '胜率',
    'profit_factor': 'PF',
    'sum_pnl_pct': '逐笔盈亏求和%',
    'compounded_return_pct': '伪复利回报%',
    'max_drawdown_pct': '最大回撤%',
    'avg_win_pct': '平均盈利%',
    'avg_loss_pct': '平均亏损%',
    'max_loss_pct': '单笔最大亏损%',
    'max_consecutive_losses': '最大连亏笔数',
    'tail_rate_pct': '尾部率(PnL≤-20%)%',
    'tail_count': '尾部笔数',
    'avg_hold_days': '平均持仓天数',
    'avg_overlap_positions': '平均同时持仓数',
    'selloff_rebound_count': '卖飞笔数',
    'selloff_rebound_rate_pct': '卖飞率%',
}


def diff_report(all_metrics: Dict[str, Dict],
                baseline_name: str = 'baseline') -> str:
    """Generate a Markdown comparison report."""
    base = all_metrics.get(baseline_name)
    if base is None:
        return '⚠ No baseline metrics found.'

    variants = [k for k in all_metrics if k != baseline_name]
    if not variants:
        return '⚠ Only baseline found, nothing to compare.'

    lines = ['# 反事实出场回测 — 对比报告\n']
    lines.append(f'Baseline: **{baseline_name}** ({base["total_trades"]} trades)\n')

    # summary table
    header_cols = ['指标', baseline_name] + variants
    lines.append('| ' + ' | '.join(header_cols) + ' |')
    lines.append('|' + '|'.join(['---'] * len(header_cols)) + '|')

    display_keys = [
        'win_rate', 'profit_factor', 'sum_pnl_pct', 'compounded_return_pct',
        'max_drawdown_pct', 'avg_win_pct', 'avg_loss_pct', 'max_loss_pct',
        'max_consecutive_losses', 'tail_rate_pct', 'avg_hold_days',
        'avg_overlap_positions', 'selloff_rebound_rate_pct',
    ]

    for key in display_keys:
        label = _METRIC_LABELS.get(key, key)
        bval = base.get(key, '-')
        row = [label, _fmt(bval)]
        for v in variants:
            vm = all_metrics[v]
            vval = vm.get(key, '-')
            delta = _delta_str(bval, vval, key)
            row.append(f'{_fmt(vval)} {delta}')
        lines.append('| ' + ' | '.join(row) + ' |')

    # acceptance check
    lines.append('\n## 验收判定\n')
    for v in variants:
        vm = all_metrics[v]
        checks = _acceptance_check(base, vm)
        status = '✅ PASS' if all(checks.values()) else '❌ FAIL'
        lines.append(f'### {v}: {status}\n')
        for criterion, passed in checks.items():
            mark = '✅' if passed else '❌'
            lines.append(f'- {mark} {criterion}')
        lines.append('')

    return '\n'.join(lines)


def _fmt(v) -> str:
    if isinstance(v, float):
        if abs(v) >= 100:
            return f'{v:.1f}'
        return f'{v:.2f}'
    return str(v)


def _delta_str(base_val, var_val, key: str) -> str:
    try:
        bf, vf = float(base_val), float(var_val)
    except (TypeError, ValueError):
        return ''
    d = vf - bf
    if abs(d) < 0.005:
        return ''
    sign = '+' if d > 0 else ''
    better_up = key in ('win_rate', 'profit_factor', 'sum_pnl_pct',
                         'compounded_return_pct', 'avg_win_pct')
    is_better = (d > 0) if better_up else (d < 0)
    arrow = '↑' if is_better else '↓'
    return f'({sign}{d:.2f}{arrow})'


def _acceptance_check(base: Dict, variant: Dict) -> Dict[str, bool]:
    """P0/P1 acceptance criteria from experiment spec."""
    checks = {}

    bpf = base.get('profit_factor', 0)
    vpf = variant.get('profit_factor', 0)
    checks['PF 改善 ≥ +0.10'] = vpf >= bpf + 0.10

    bret = base.get('compounded_return_pct', 0)
    vret = variant.get('compounded_return_pct', 0)
    checks['复利回报改善'] = vret > bret

    bdd = base.get('max_drawdown_pct', 0)
    vdd = variant.get('max_drawdown_pct', 0)
    dd_tolerance = abs(bdd) * 0.10
    checks['最大回撤不恶化 >10%'] = vdd <= bdd + dd_tolerance

    bt = base.get('tail_rate_pct', 0)
    vt = variant.get('tail_rate_pct', 0)
    checks['尾部率不增加'] = vt <= bt + 0.01

    bh = base.get('avg_hold_days', 0)
    vh = variant.get('avg_hold_days', 0)
    checks['持仓天数可控'] = vh <= bh * 2

    return checks
