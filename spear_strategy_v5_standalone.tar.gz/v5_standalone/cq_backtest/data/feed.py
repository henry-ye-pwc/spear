import os, pickle, time
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from typing import List, Dict, Optional, Tuple
from mootdx.quotes import Quotes
from mootdx.reader import Reader


_connection_msg_shown = False


def _apply_qfq(raw: pd.DataFrame, xdxr: pd.DataFrame) -> pd.DataFrame:
    """Apply 前复权 using XDXR 除权除息 records from 通达信 server.

    Uses the standard preclose-based cumulative adjustment algorithm
    (same as mootdx's internal _reversion, with pandas 2+ fixes).
    """
    if xdxr is None or xdxr.empty:
        return raw
    cat1 = xdxr.query('category==1').copy()
    if len(cat1) == 0:
        return raw

    cat1['date'] = pd.to_datetime(cat1[['year', 'month', 'day']])
    cat1 = cat1.set_index('date')

    data = raw.copy().assign(if_trade=1)
    data.index = data.index.normalize()
    data = data[~data.index.duplicated(keep='first')]

    sliced = cat1.loc[data.index[0]:data.index[-1]]
    if sliced.empty:
        return raw

    data = pd.concat([data, sliced[['category']]], axis=1, sort=True)
    data['if_trade'] = data['if_trade'].fillna(0)
    data = data.ffill()
    data = pd.concat([data, sliced[['fenhong', 'peigu', 'peigujia', 'songzhuangu']]], axis=1, sort=True)
    data = data.fillna(0)

    data['preclose'] = (
        data['close'].shift(1) * 10 - data['fenhong']
        + data['peigu'] * data['peigujia']
    ) / (10 + data['peigu'] + data['songzhuangu'])
    data['adj'] = (data['preclose'].shift(-1) / data['close']).fillna(1)[::-1].cumprod()

    for col in ['open', 'high', 'low', 'close']:
        if col in data.columns:
            data[col] = data[col].astype(float) * data['adj']

    keep = [c for c in raw.columns if c in data.columns]
    result = data.loc[data['if_trade'] == 1, keep].copy()
    result.index = raw.index
    return result


class DataFeed:
    """
    mootdx 数据源封装
    自动缓存到本地 pickle, 避免重复请求
    """

    def __init__(self, cache_dir='./cache', **_kw):
        self.cache_dir = cache_dir
        os.makedirs(cache_dir, exist_ok=True)
        self.client = None
        self._stock_list = None
        self._kline_mem = {}
        self._kline_mem_ts = {}
        self.cache_ttl_secs = 14400
        self.history_stable_days = 7

    def _connect(self):
        global _connection_msg_shown
        try:
            self.client = Quotes.factory(market='std', timeout=10)
            if not _connection_msg_shown:
                print('✅ 通达信连接成功')
                _connection_msg_shown = True
        except Exception as e:
            print(f'⚠️ 通达信连接失败: {e}')
            print('  将使用本地缓存数据')

    def _ensure_connected(self):
        if self.client is None:
            self._connect()

    def _market_code(self, code: str) -> int:
        """通达信市场编号: 0=深圳 1=上海"""
        if code.startswith('6') or code.startswith('5'):
            return 1
        return 0

    def _normalize_bars(self, df: pd.DataFrame) -> pd.DataFrame:
        if df is None or df.empty:
            return pd.DataFrame()
        if 'datetime' in df.columns and df.index.name == 'datetime':
            df = df.drop(columns=['datetime']).reset_index()
        else:
            df = df.reset_index()
        if 'vol' in df.columns and 'volume' in df.columns:
            df = df.drop(columns=['vol'])
        elif 'vol' in df.columns:
            df = df.rename(columns={'vol': 'volume'})
        if 'datetime' in df.columns:
            df = df.rename(columns={'datetime': 'date'})
        if 'date' in df.columns:
            df['date'] = pd.to_datetime(df['date'])
            df = df.set_index('date')
        return df.sort_index()

    def _fetch_raw_bars(self, code: str, max_bars: int = 3200) -> pd.DataFrame:
        """Fetch unadjusted daily bars from 通达信."""
        if self.client is None:
            return pd.DataFrame()
        market = self._market_code(code)
        step = 800
        parts = []
        for start in range(0, max_bars, step):
            try:
                part = self.client.bars(
                    symbol=code, frequency=9, start=start, offset=step,
                    market=market,
                )
            except Exception:
                part = None
            part = self._normalize_bars(part)
            if part.empty:
                break
            parts.append(part)
            if len(part) < step:
                break
        if not parts:
            return pd.DataFrame()
        full = pd.concat(parts).sort_index()
        full = full[~full.index.duplicated(keep='last')]
        return full

    def _fetch_xdxr(self, code: str) -> pd.DataFrame:
        """Fetch 除权除息 records from 通达信 server."""
        if self.client is None:
            return pd.DataFrame()
        try:
            return self.client.xdxr(symbol=code)
        except Exception:
            return pd.DataFrame()

    def _fetch_full_history(self, code: str, max_bars: int = 3200) -> pd.DataFrame:
        raw = self._fetch_raw_bars(code, max_bars)
        if raw.empty:
            return raw
        xdxr = self._fetch_xdxr(code)
        return _apply_qfq(raw, xdxr)

    def _fetch_latest_bars(self, code: str, n: int = 10) -> pd.DataFrame:
        """Fetch only the most recent *n* daily bars (raw + QFQ) for incremental append."""
        if self.client is None:
            return pd.DataFrame()
        market = self._market_code(code)
        try:
            part = self.client.bars(symbol=code, frequency=9, start=0, offset=n, market=market)
        except Exception:
            return pd.DataFrame()
        raw = self._normalize_bars(part)
        if raw.empty:
            return raw
        xdxr = self._fetch_xdxr(code)
        return _apply_qfq(raw, xdxr)

    def _remember_kline(self, code: str, df: pd.DataFrame):
        if df is None or df.empty:
            return
        self._kline_mem[code] = df
        self._kline_mem_ts[code] = time.time()

    def _cache_covers_end_date(self, df: pd.DataFrame, end_date: str = None) -> bool:
        if df is None or df.empty:
            return False
        if not end_date:
            return True
        try:
            end_ts = pd.Timestamp(end_date)
            last_ts = pd.Timestamp(df.index.max())
            if last_ts >= end_ts:
                return True
            # Allow small natural-day gap for weekends/holidays.
            lag_days = (end_ts.normalize() - last_ts.normalize()).days
            return 0 <= lag_days <= 7
        except Exception:
            return False

    def _cache_exactly_covers_end_date(self, df: pd.DataFrame, end_date: str = None) -> bool:
        if df is None or df.empty or not end_date:
            return False
        try:
            end_ts = pd.Timestamp(end_date).normalize()
            last_ts = pd.Timestamp(df.index.max()).normalize()
            return last_ts >= end_ts
        except Exception:
            return False

    def _historical_request_is_stable(self, end_date: str = None) -> bool:
        if not end_date:
            return False
        try:
            days = (pd.Timestamp.today().normalize() - pd.Timestamp(end_date)).days
            return days >= self.history_stable_days
        except Exception:
            return False

    def get_kline(self, code: str, end_date: str = None, count: int = 250,
                  cache_only: bool = False, force_refresh: bool = False) -> pd.DataFrame:
        """
        获取日K线 (带本地缓存)
        code: 6位纯数字, 如 '002395'
        """
        cache_file = os.path.join(self.cache_dir, f'{code}_full.pkl')

        def _filter(df):
            if end_date and not df.empty and hasattr(df.index, 'dtype'):
                end_ts = pd.Timestamp(end_date).normalize()
                df = df[df.index.normalize() <= end_ts]
            if count and not df.empty and len(df) > count:
                df = df.iloc[-count:]
            return df.sort_index()

        if force_refresh:
            self._ensure_connected()
            if self.client is not None:
                df = self._fetch_full_history(code, max_bars=max(3200, count * 4))
                if not df.empty:
                    df.to_pickle(cache_file)
                    self._remember_kline(code, df)
                    return _filter(df)

        # 1) 尝试内存缓存
        mem_df = self._kline_mem.get(code)
        if mem_df is not None and not mem_df.empty:
            mem_ts = self._kline_mem_ts.get(code, 0)
            if self._cache_covers_end_date(mem_df, end_date):
                if end_date or (time.time() - mem_ts < self.cache_ttl_secs):
                    return _filter(mem_df)

        disk_df = None
        cache_age = None

        # 2) 尝试磁盘缓存
        if os.path.exists(cache_file):
            try:
                disk_df = pd.read_pickle(cache_file)
                mtime = os.path.getmtime(cache_file)
                cache_age = time.time() - mtime
                self._remember_kline(code, disk_df)
                # 只要缓存已经精确覆盖到目标结束日，历史回测直接复用。
                if self._cache_exactly_covers_end_date(disk_df, end_date):
                    return _filter(disk_df)
                # 历史区间如果已覆盖，直接复用，不受TTL影响
                if self._cache_covers_end_date(disk_df, end_date) and self._historical_request_is_stable(end_date):
                    return _filter(disk_df)
                # 近期请求沿用原TTL语义
                if self._cache_covers_end_date(disk_df, end_date) and cache_age is not None and cache_age < self.cache_ttl_secs:
                    return _filter(disk_df)
            except Exception:
                disk_df = None

        if cache_only:
            if disk_df is not None and not disk_df.empty:
                return _filter(disk_df)
            return pd.DataFrame()

        self._ensure_connected()
        if self.client is None:
            if disk_df is not None and not disk_df.empty:
                return _filter(disk_df)
            return pd.DataFrame()

        try:
            # Incremental append: if we have cached data, fetch only the delta
            if disk_df is not None and not disk_df.empty and len(disk_df) >= 120:
                latest = self._fetch_latest_bars(code, n=10)
                if not latest.empty:
                    overlap_idx = disk_df.index.intersection(latest.index)
                    adj_break = False
                    if len(overlap_idx) >= 2:
                        old_close = disk_df.loc[overlap_idx, 'close'].astype(float)
                        new_close = latest.loc[overlap_idx, 'close'].astype(float)
                        deviation = ((new_close - old_close) / old_close.replace(0, float('nan'))).abs()
                        max_dev = float(deviation.max()) if not deviation.empty else 0.0
                        if max_dev > 0.005:
                            adj_break = True
                            print(
                                f'[feed] {code}: 复权因子变化 '
                                f'(max_dev={max_dev:.4f}), 触发全量刷新',
                                flush=True,
                            )
                    if not adj_break:
                        df = pd.concat([disk_df, latest]).sort_index()
                        df = df[~df.index.duplicated(keep='last')]
                        if self._cache_exactly_covers_end_date(df, end_date):
                            df.to_pickle(cache_file)
                            self._remember_kline(code, df)
                            return _filter(df)

            # Fallback: full history fetch when no cache or incremental didn't cover
            df = self._fetch_full_history(code, max_bars=max(3200, count * 4))
            if df.empty:
                if disk_df is not None and not disk_df.empty:
                    return _filter(disk_df)
                return pd.DataFrame()

            df.to_pickle(cache_file)
            self._remember_kline(code, df)
            return _filter(df)

        except Exception as e:
            if disk_df is not None and not disk_df.empty:
                return _filter(disk_df)
            return pd.DataFrame()

    def get_minute_bars(self, code: str, frequency: int = 8, count: int = 250) -> pd.DataFrame:
        """Fetch intraday minute bars (no caching -- data changes every minute).

        Frequency mapping:  7/8 = 1min, 0 = 5min, 1 = 15min, 2 = 30min, 3 = 60min.
        """
        self._ensure_connected()
        if self.client is None:
            return pd.DataFrame()
        market = self._market_code(code)
        parts = []
        step = 800
        for start in range(0, count, step):
            try:
                part = self.client.bars(
                    symbol=code, frequency=frequency, start=start, offset=step,
                    market=market,
                )
            except Exception:
                part = None
            part = self._normalize_bars(part)
            if part.empty:
                break
            parts.append(part)
            if len(part) < step:
                break
        if not parts:
            return pd.DataFrame()
        return pd.concat(parts).sort_index()

    def get_stock_list(self) -> pd.DataFrame:
        """获取全市场股票列表"""
        cache_file = os.path.join(self.cache_dir, 'stock_list.pkl')

        if self._stock_list is not None:
            return self._stock_list

        if os.path.exists(cache_file):
            mtime = os.path.getmtime(cache_file)
            if time.time() - mtime < 86400:
                self._stock_list = pd.read_pickle(cache_file)
                return self._stock_list

        self._ensure_connected()
        if self.client is None:
            if os.path.exists(cache_file):
                self._stock_list = pd.read_pickle(cache_file)
                return self._stock_list
            return pd.DataFrame()

        try:
            # 深圳 + 上海
            stocks_sz = self.client.stocks(market=0)
            stocks_sh = self.client.stocks(market=1)
            df = pd.concat([stocks_sz, stocks_sh], ignore_index=True)
            df.to_pickle(cache_file)
            self._stock_list = df
            return df
        except:
            if os.path.exists(cache_file):
                self._stock_list = pd.read_pickle(cache_file)
                return self._stock_list
            return pd.DataFrame()


# ============================================================
# K线分析 — 核心技术指标
# ============================================================

def add_supertrend(df, period=10, multiplier=3.0):
    if len(df) < period + 1:
        df['supertrend'] = 1
        return df

    hl2 = (df['high'] + df['low']) / 2
    prev_close = df['close'].shift(1)
    tr1 = df['high'] - df['low']
    tr2 = (df['high'] - prev_close).abs()
    tr3 = (df['low'] - prev_close).abs()
    tr = pd.concat([tr1, tr2, tr3], axis=1).max(axis=1)
    atr = tr.rolling(window=period).mean()

    basic_ub = hl2 + multiplier * atr
    basic_lb = hl2 - multiplier * atr

    n = len(df)
    close = df['close'].values
    bub = basic_ub.fillna(0).values
    blb = basic_lb.fillna(0).values

    fub = np.zeros(n)
    flb = np.zeros(n)
    trend = np.ones(n, dtype=int)

    fub[0] = bub[0]
    flb[0] = blb[0]

    for i in range(1, n):
        if bub[i] < fub[i-1] or close[i-1] > fub[i-1]:
            fub[i] = bub[i]
        else:
            fub[i] = fub[i-1]

        if blb[i] > flb[i-1] or close[i-1] < flb[i-1]:
            flb[i] = blb[i]
        else:
            flb[i] = flb[i-1]

        if trend[i-1] == 1 and close[i] < flb[i]:
            trend[i] = -1
        elif trend[i-1] == -1 and close[i] > fub[i]:
            trend[i] = 1
        else:
            trend[i] = trend[i-1]

    df['supertrend'] = trend
    return df

def prepare_kline(df: pd.DataFrame, code: str) -> pd.DataFrame:
    """计算回测所需的所有技术指标"""
    if df.empty or len(df) < 20:
        return pd.DataFrame()

    df = df.copy()
    df = df.loc[:, ~df.columns.duplicated()]
    df['code'] = code
    df['pct'] = df['close'].pct_change() * 100

    # 上影线比率
    df['top'] = df[['open', 'close']].max(axis=1)
    df['bot'] = df[['open', 'close']].min(axis=1)
    st = df['top'].replace(0, np.nan)
    df['shadow'] = ((df['high'] - df['top']) / st * 100).fillna(0)

    # 振幅
    sl = df['low'].replace(0, np.nan)
    df['amp'] = ((df['high'] - df['low']) / sl * 100).fillna(0)

    # 涨停/炸板
    lp = 0.20 if code.startswith('3') else 0.10
    df['pc'] = df['close'].shift(1)
    df['lup'] = df['pc'] * (1 + lp)
    sc = df['close'].replace(0, np.nan)
    df['is_lu'] = (df['pct'] >= (lp*100 - 0.5)) & \
                  ((df['high'] - df['close']).abs() / sc < 0.002).fillna(False)
    df['touch_l'] = df['high'] >= df['lup'] * 0.998
    df['is_lb'] = df['touch_l'] & (~df['is_lu'])

    # 量比
    df['vma'] = df['volume'].rolling(20, min_periods=5).mean()
    svm = df['vma'].replace(0, np.nan)
    df['vr'] = (df['volume'] / svm).fillna(1)
    
    # 附加 SuperTrend 趋势过滤
    df = add_supertrend(df, period=10, multiplier=3.0)

    return df


# ============================================================
# 长枪信号检测
# ============================================================
