import pandas as pd
import numpy as np
from .indicators import *
from .indicators import _norm_value, _conf_from_flags, _ctx_tags, _type_specificity, _select_primary_signal
from cq_backtest.config import STRATEGY_CONFIG

def detect_escape(df, code, cur, has, ctx=None):
    ctx = ctx or build_signal_context(df, code)
    if not has:
        return None
    pos = ctx['pos']
    if pos not in ('HIGH', 'UP'):
        return None
        
    # 逃命特征：成交量从常规区突变至巨量区
    vol_ma60 = float(df.iloc[-61:-1]['volume'].mean()) if len(df) > 60 else 1.0
    vol_rank = _norm_value(ctx, 'vol', 'rank', 0.5)
    
    is_explosive = (cur['volume'] > vol_ma60 * 3.5) or (vol_rank > 0.98)
    
    # 是否有炸板或高位冲高回落行为
    failed_lu = (cur['high'] >= cur['open'] * 1.09) and (cur['close'] < cur['high'] * 0.98)
    
    consec = 0
    for i in range(len(df)-2, max(len(df)-10, -1), -1):
        if i < 0:
            break
        if df.iloc[i]['is_lu']:
            consec += 1
        else:
            break
            
    is_exhaustion = is_explosive and (failed_lu or cur['close'] < cur['open'])
    
    if not (is_exhaustion or (consec >= 2 and is_explosive)):
        return None
        
    conf = _conf_from_flags(0.86, consec >= 3, ctx['struct'].get('near_pressure', False), is_explosive)
    return {'type': '⚠️逃命', 'conf': conf, 'nat': '出货',
            'low': cur['low'], 'cut': 0,
            'note': f'高位巨量区(主力出货) {"炸板" if failed_lu else ""} {_ctx_tags(ctx)}'.strip()}


def detect_arb(df, code, cur, has, ctx=None):
    """套利长枪: 封板失败 → 分时横盘 → 缩量长枪，尾盘套利"""
    ctx = ctx or build_signal_context(df, code)
    if not has:
        return None
    if cur['amp'] <= 6.99:
        return None
    pos = ctx['pos']
    if pos in ['HIGH', 'DOWN']:
        return None
    if ctx['lu7'] == 0:
        return None
    # 核心逻辑: 封板失败 → 横盘 → 缩量长枪
    # 日线代理: 当日触碰涨停价, 或近3日有炸板
    today_touch = bool(cur.get('touch_l', False))
    recent_lb = False
    for i in range(max(len(df)-4, 0), len(df)-1):
        if df.iloc[i].get('is_lb', False) or df.iloc[i].get('touch_l', False):
            recent_lb = True
            break
    if not today_touch and not recent_lb:
        return None
    # 横盘区间量不应超过进攻期量; 但箱体突破型标的历史极度缩量导致
    # 绝对 vr 偏高, 所以同时参考 vol_rank
    vr_cap = max(2.8, _norm_value(ctx, 'vr', 'q90', 3.5))
    vol_rank = _norm_value(ctx, 'vol', 'rank', 0.5)
    if cur['vr'] > vr_cap and vol_rank < 0.95:
        return None
    if vol_rank >= 0.998:
        return None
    cut = ctx['cut']
    st = ctx['struct']
    conf = _conf_from_flags(
        0.68,
        ctx['lu7'] >= 2,
        st.get('near_pressure', False),
        today_touch,
        st.get('two_side_active', False),
    )
    return {'type': '★套利', 'conf': conf, 'nat': '套利',
            'low': cur['low'], 'cut': cut,
            'note': f'{"炸板" if today_touch else "近炸板"} 振幅{cur["amp"]:.1f}% vr={cur["vr"]:.1f} {_ctx_tags(ctx)}'.strip()}


def detect_trend(df, code, cur, has, ctx=None):
    ctx = ctx or build_signal_context(df, code)
    if not has or len(df) < 60:
        return None
    pos = ctx['pos']
    if pos not in ['UP', 'SIDE']:
        return None
    if ctx['lu30'] == 0:
        return None
        
    # SuperTrend 空头排列下胜率极低，直接过滤
    if cur.get('supertrend', 1) == -1:
        return None

    zhyx = ctx['zhyx']
    st = ctx['struct']
    vr_soft_cap = max(2.0, _norm_value(ctx, 'vr', 'q85', 2.2))
    vr_hot_cap = max(2.8, _norm_value(ctx, 'vr', 'q95', 3.0))
    if not zhyx.get('ok', False):
        if not (st.get('near_pressure', False) and cur['vr'] <= vr_soft_cap and ctx['lu30'] >= 2):
            return None
    if cur['vr'] > vr_hot_cap:
        return None
    cut, si = ctx['cut'], ctx['spear_idx']
    if len(si) < 1:
        return None
    if len(si) >= 2:
        vols = [df.iloc[i]['volume'] for i in si]
        spear_ref = max(float(np.median(vols[:-1])), 1e-9)
        med_v = max(_norm_value(ctx, 'vol', 'med', spear_ref), 1e-9)
        q95_v = max(_norm_value(ctx, 'vol', 'q95', med_v), med_v)
        expand_cap = max(1.4, min(2.3, q95_v / med_v))
        if vols[-1] > spear_ref * expand_cap:
            return None
    conf = _conf_from_flags(
        0.70,
        len(si) >= 2,
        st.get('near_pressure', False),
        st.get('two_side_active', False),
        zhyx.get('ok', False),
    )
    return {'type': '趋势', 'conf': conf, 'nat': '进攻',
            'low': cur['low'], 'cut': cut,
            'note': f'{len(si)}枪 城门{cut:.2f} {"量含蓄" if zhyx.get("ok", False) else "量过渡"} {_ctx_tags(ctx)}'.strip()}


def detect_post(df, code, cur, has, ctx=None):
    ctx = ctx or build_signal_context(df, code)
    if not has:
        return None
    pos = ctx['pos']
    if pos in ['HIGH']:
        return None
        
    # 已跌破 SuperTrend 支撑说明涨停动能完全失效，不参与
    if cur.get('supertrend', 1) == -1:
        return None

    ld = None
    lu_gap = 999
    lookback = 8  # 涨停后 1-7 日窗口
    for i in range(len(df)-2, max(len(df)-(lookback+1), -1), -1):
        if i < 0:
            break
        if df.iloc[i]['is_lu']:
            ld = df.index[i]
            lu_gap = int((len(df)-1) - i)
            break
    if ld is None:
        return None
    if lu_gap > 7:
        return None
    zhyx = ctx['zhyx']
    st = ctx['struct']
    # 板后的核心是“板后承压区再平衡”，可由近压区或双区活跃体现，不限定单一形态。
    if (not zhyx.get('ok', False)) and (not st.get('near_pressure', False)) and (not st.get('two_side_active', False)):
        return None
    # 4. 异动确认 + 人为操作痕迹 (震荡期有起量小脉冲)
    vr_rank = _norm_value(ctx, 'vr', 'rank', 0.5)
    amp_rank = _norm_value(ctx, 'amp', 'rank', 0.5)
    is_anomaly = vr_rank >= 0.60 or amp_rank >= 0.70
    
    trace_ok = zhyx.get('trace_ok', False)
    
    # 只要有异动，或者有明确的人为操作痕迹，就可以过关
    if not (is_anomaly or trace_ok):
        return None
        
    vol_rank = _norm_value(ctx, 'vol', 'rank', 0.5)
    # 实证: 短间隔(lu_gap 小)时 vol_rank=1.0 仍有效
    if vol_rank >= 0.995 and lu_gap > 3 and (not zhyx.get('ok', False)):
        return None
    vr_cap = max(3.5, _norm_value(ctx, 'vr', 'q99', 4.5))
    if cur['vr'] > vr_cap:
        return None
    cut, si = ctx['cut'], ctx['spear_idx']
    fit = 0.45
    if len(si) >= 2:
        fit += 0.12
    if st.get('near_pressure', False):
        fit += 0.12
    if st.get('two_side_active', False):
        fit += 0.08
    if zhyx.get('ok', False):
        fit += 0.08
    if zhyx.get('trace_ok', False):
        fit += 0.05
    if lu_gap <= 3:
        fit += 0.10
    fit = float(round(min(fit, 0.95), 3))
    conf = _conf_from_flags(
        0.66,
        len(si) >= 2,
        st.get('near_pressure', False),
        st.get('two_side_active', False),
        lu_gap <= 3,
        zhyx.get('ok', False)
    )
    return {'type': '板后', 'conf': conf, 'nat': '吸筹',
            'low': cur['low'], 'cut': cut,
            'fit': fit,
            'note': f'板({str(ld)[:10]})后{lu_gap}天 确量' +
                    (f' {len(si)}连枪' if len(si) >= 2 else '') +
                    f' {_ctx_tags(ctx)}'}


def detect_attack(df, code, cur, has, ctx=None):
    """进攻长枪: 近期必须有涨停板作为依托 + 多枪(最后枪缩量) + 张扬含蓄"""
    ctx = ctx or build_signal_context(df, code)
    if not has:
        return None
    pos = ctx['pos']
    if pos not in ['UP', 'LOW', 'SIDE']:
        return None
    # 进攻长枪需有涨停板作为依托
    li = [i for i in range(max(len(df)-31, 0), len(df)-1) if df.iloc[i]['is_lu']]
    if not li:
        return None
    # 回调窗口 7-10 天 (实证数据显示 10 天内仍有效)
    lu_gap = (len(df)-1) - li[-1]
    if lu_gap > 10:
        return None
    si = ctx['spear_idx']
    # 连续多枪, 至少当前这一枪
    if len(si) < 1:
        return None
    # 连续 3 枪中末枪相对前两枪缩量 → 买点
    last_spear_shrink = False
    if len(si) >= 2:
        vols = [float(df.iloc[i]['volume']) for i in si]
        prev_avg = float(np.mean(vols[:-1]))
        if prev_avg > 0 and vols[-1] < prev_avg * 0.90:
            last_spear_shrink = True
    vr_cap = max(2.8, _norm_value(ctx, 'vr', 'q95', 3.2))
    if cur['vr'] > vr_cap:
        return None
    zhyx = ctx['zhyx']
    st = ctx['struct']
    # 张扬含蓄: 量能放大但不超前高, 下跌缩量
    if not zhyx.get('ok', False) and not st.get('near_pressure', False):
        return None
    cut = ctx['cut']
    conf = _conf_from_flags(
        0.64,
        len(si) >= 2,
        last_spear_shrink,
        zhyx.get('ok', False),
        st.get('near_pressure', False),
    )
    note_parts = [f'{len(si)}枪']
    if last_spear_shrink:
        note_parts.append('末枪缩量')
    note_parts.append(_ctx_tags(ctx))
    return {'type': '进攻', 'conf': conf, 'nat': '进攻',
            'low': cur['low'], 'cut': cut,
            'note': ' '.join(note_parts).strip()}


def detect_lanban(df, code, cur, has, ctx=None):
    ctx = ctx or build_signal_context(df, code)
    """烂板长枪: 炸板+放量在承上启下位置, 确量不爆量 = 吸筹/洗盘"""
    has_lb = cur.get('is_lb', False)
    if not has_lb and not has:
        return None
    pos = ctx['pos']
    # 承上启下位置: 反转或上涨调整区间均可触发
    if pos in ('HIGH', 'DOWN'):
        return None
    if len(df) < 30:
        return None
    if cnt_lu(df, 10) == 0:
        return None
    vol_rank = _norm_value(ctx, 'vol', 'rank', 0.5)
    if vol_rank < 0.58:
        return None
    s = max(len(df)-30, 0)
    bear_vols = df.iloc[s:-1]
    bear = bear_vols[bear_vols['close'] < bear_vols['open']]
    if len(bear) > 0:
        bear_peak = bear['volume'].max()
        vol_q97 = _norm_value(ctx, 'vol', 'q97', cur['volume'] * 1.2)
        if cur['volume'] > max(bear_peak * 1.9, vol_q97):
            return None
    st = ctx['struct']
    if not st.get('ok', False):
        return None
    if not (st.get('two_side_active', False) or st.get('near_pressure', False)):
        return None
    zhyx = ctx['zhyx']
    if zhyx.get('reason') == 'shape_fail' and not zhyx.get('zhangyang', False):
        return None
    lb_days = []
    sp_days = []
    for i in range(max(len(df)-8, 0), len(df)):
        row = df.iloc[i]
        if row.get('is_lb', False):
            lb_days.append(i)
        if is_spear(row, code):
            sp_days.append(i)
    combo = sorted(set(lb_days + sp_days))
    cut, si = ctx['cut'], ctx['spear_idx']
    if cut > 0:
        if st.get('ok', False):
            band = max(float(st.get('pressure', cut)) - float(st.get('release', cut)), max(cut * 0.02, 1e-6))
            if float(cur['close']) - float(cut) > band * 0.65:
                return None
        elif cur['close'] > cut * 1.10:
            return None
    note_parts = []
    conf = 0.60
    if len(combo) >= 2:
        conf += 0.10
        note_parts.append(f'双枪')
    if st.get('two_side_active', False):
        conf += 0.08
        note_parts.append('双区松动')
    if zhyx.get('ok', False):
        conf += 0.06
        note_parts.append('张扬含蓄')
    conf = round(min(conf, 0.90), 2)
    if has_lb:
        note_parts.append('烂板')
    note_parts.append(f'确量vr={cur["vr"]:.1f}')
    if cut > 0:
        note_parts.append(f'城门{cut:.2f}')
    return {'type': '烂板', 'conf': conf, 'nat': '吸筹',
            'low': cur['low'], 'cut': cut,
            'note': ' '.join(note_parts)}


def detect_youzi(df, code, cur, has, ctx=None):
    """游资长枪: 必须建立在量价+热点之上，且同板块有涨停票。
    无板块数据时用严格的长期运作证据+近期炸板/涨停作为代理。"""
    ctx = ctx or build_signal_context(df, code)
    if not has and not cur.get('is_lb', False):
        return None
    if code.startswith('3'):
        return None
    pos = ctx['pos']
    if pos in ['HIGH', 'DOWN']:
        return None
    if len(df) < 120:
        return None
    # 无板块数据时要求本票自身有更强的长期运作证据
    lu_200 = int(df.iloc[-min(200, len(df)):]['is_lu'].sum())
    lu_7 = cnt_lu(df, 7)
    # 严格: 长期至少 3 次涨停 (多板标的验证)
    if lu_200 < 3:
        return None
    # 近期必须有活跃信号(7日内有板 或 当日炸板)
    if lu_7 == 0 and not cur.get('is_lb', False):
        return None
    n = min(200, len(df))
    hist = df.iloc[-n:]
    # 左侧资金运作痕迹: 近期量应不低于早期量
    q1_vol = hist.iloc[:n//3]['volume'].mean()
    q3_vol = hist.iloc[-n//3:]['volume'].mean()
    if q1_vol == 0:
        return None
    if q3_vol < q1_vol * 0.5:
        return None
    # 涨停板的时间跨度 — 体现"长期运作"
    lu_idx = [i for i in range(len(hist)) if hist.iloc[i]['is_lu']]
    if len(lu_idx) < 3:
        return None
    spread = lu_idx[-1] - lu_idx[0]
    min_spread = max(25, n // 8)
    if spread < min_spread:
        return None
    st = ctx['struct']
    # 位置不高 + 结构证据
    if not (st.get('near_pressure', False) or st.get('two_side_active', False)):
        return None
    # 量能不能太极端, 过大暗示出货
    vol_rank = _norm_value(ctx, 'vol', 'rank', 0.5)
    if vol_rank >= 0.97:
        return None
    zhyx = ctx['zhyx']
    conf = _conf_from_flags(
        0.62,
        spread >= max(40, n // 4),
        lu_200 >= 5,
        lu_7 >= 1,
        zhyx.get('ok', False),
        st.get('two_side_active', False),
    )
    cut = ctx['cut']
    return {'type': '游资', 'conf': conf, 'nat': '进攻',
            'low': cur['low'], 'cut': cut,
            'note': f'长运{spread}天 {lu_200}板 近{lu_7}板 {_ctx_tags(ctx)}'.strip()}


def detect_all(df, code):
    ctx = build_signal_context(df, code)
    cur = ctx['cur']
    has = ctx['has']
    
    # ---------------------------------------------------------
    # 主力出货过滤: 量能从有量区突变至巨量区, 高位实体剧烈波动
    # 回测数据: 后续暴跌 20%+ 的出货案例平均 VR>3.18, 实体>5%
    # 同时回顾近 5 日内长枪日是否出现极端爆量
    # ---------------------------------------------------------
    bear_cfg = STRATEGY_CONFIG.get('filter_true_bear', {})
    is_true_bear = False
    
    if bear_cfg.get('enabled', False) and ctx['pos'] in bear_cfg.get('positions', []):
        # 取过去5天(包含今天)内量最大的一天，看它是否具备出货特征
        recent_5 = df.iloc[-6:-1] if len(df) > 5 else df.iloc[:-1]
        if not recent_5.empty:
            max_vol_idx = recent_5['volume'].idxmax()
            peak_candle = recent_5.loc[max_vol_idx]
            
            # 计算该峰值日的20日均量
            peak_pos = df.index.get_loc(max_vol_idx)
            if peak_pos > 20:
                vol_ma20 = df.iloc[peak_pos-20:peak_pos]['volume'].mean()
            else:
                vol_ma20 = 1.0
                
            vr20 = peak_candle['volume'] / vol_ma20 if vol_ma20 > 0 else 1.0
            body_pct = abs(peak_candle['close'] - peak_candle['open']) / peak_candle['open'] * 100
            
            # 如果量比极大，且实体波动剧烈，判定为“真熊/主力借机出货”
            if vr20 > bear_cfg.get('vr20_threshold', 3.1) and body_pct > bear_cfg.get('body_threshold', 4.5):
                is_true_bear = True

    cands = []
    for det in [detect_escape, detect_arb, detect_lanban, detect_trend,
                detect_post, detect_attack, detect_youzi]:
        sig = det(df, code, cur, has, ctx=ctx)
        if sig:
            # 如果判定为真熊巨量出货，屏蔽除“逃命”以外的所有做多信号
            if is_true_bear and '逃命' not in sig.get('type', ''):
                continue
                
            if 'fit' not in sig:
                # 通用适配度: 由 detector conf 映射，避免路由依赖枪型硬编码。
                c = float(sig.get('conf', 0) or 0)
                sig['fit'] = float(round(max(0.0, min(1.0, (c - 0.55) / 0.35)), 3))
            cands.append(sig)
    if cands:
        sig, ranked = _select_primary_signal(cands, ctx)
        st = ctx.get('struct', {}) or {}
        zh = ctx.get('zhyx', {}) or {}
        sig['code'] = code
        sig['shadow'] = float(cur['shadow'])
        sig['vr'] = float(cur['vr'])
        sig['pos'] = ctx['pos']
        sig['price'] = float(cur['close'])
        sig['date'] = str(df.index[-1])[:10]
        sig['ctx_tags'] = _ctx_tags(ctx)
        sig['ctx_pressure'] = float(st.get('pressure', 0) or 0)
        sig['ctx_release'] = float(st.get('release', 0) or 0)
        sig['ctx_two_side_active'] = bool(st.get('two_side_active', False))
        sig['ctx_span_ratio'] = float(st.get('span_ratio', 0) or 0)
        sig['ctx_zhyx_ok'] = bool(zh.get('ok', False))
        sig['ctx_zhyx_reason'] = str(zh.get('reason', ''))
        sig['ctx_zhyx_base'] = float(zh.get('base', 0) or 0)
        sig['ctx_zhyx_burst_ref'] = float(zh.get('burst_ref', 0) or 0)
        sig['ctx_vol_rank'] = float(_norm_value(ctx, 'vol', 'rank', 0.5))
        sig['ctx_vr_rank'] = float(_norm_value(ctx, 'vr', 'rank', 0.5))
        sig['ctx_amp_rank'] = float(_norm_value(ctx, 'amp', 'rank', 0.5))
        sig['route_score'] = float(sig.get('_route_score', 0))
        sig['fit'] = float(sig.get('fit', 0) or 0)
        sig['alt_types'] = '|'.join([str(x.get('type', '')) for x in ranked])
        sig['alt_route'] = '; '.join(
            [f'{x.get("type", "")}:{float(x.get("_route_score", 0)):.2f}' for x in ranked[:4]]
        )
        sig.pop('_route_score', None)
        return sig
    return None
