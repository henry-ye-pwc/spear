import pandas as pd
import numpy as np

def is_spear(row, code):
    t = 5.0 if code.startswith('3') else 3.0
    return row['shadow'] >= t


def position(df):
    if len(df) < 60:
        return 'UNK'
    c = df.iloc[-1]['close']
    n = min(120, len(df))
    hi = df.iloc[-n:]['high'].max()
    lo = df.iloc[-n:]['low'].min()
    rng = hi - lo
    if rng == 0:
        return 'SIDE'
    r = (c - lo) / rng
    m20 = df.iloc[-20:]['close'].mean()
    m60 = df.iloc[-min(60, len(df)):]['close'].mean()
    if r > 0.85: return 'HIGH'
    elif r < 0.15: return 'LOW'
    elif m20 > m60 and c > m20: return 'UP'
    elif m20 < m60 and c < m20: return 'DOWN'
    else: return 'SIDE'


def _local_extrema_idx(values, left=3, right=3, find_max=True):
    vals = np.asarray(values, dtype=float)
    n = len(vals)
    out = []
    if n < left + right + 1:
        return out
    for i in range(left, n - right):
        c = vals[i]
        if not np.isfinite(c):
            continue
        win = vals[i-left:i+right+1]
        if find_max:
            m = np.nanmax(win)
            if c >= m and np.sum(np.isclose(win, c)) == 1:
                out.append(i)
        else:
            m = np.nanmin(win)
            if c <= m and np.sum(np.isclose(win, c)) == 1:
                out.append(i)
    return out


def structure_profile(df, lookback=160):
    """
    用近期结构刻画“承压区/释放区”：
    - 承压区: 最近有效局部高点
    - 释放区: 该高点后的局部低点（常见筹码交换区）
    """
    if df is None or len(df) < 40:
        return {'ok': False}
    n = min(lookback, len(df))
    seg = df.iloc[-n:].copy()
    highs = seg['high'].to_numpy(dtype=float)
    lows = seg['low'].to_numpy(dtype=float)
    last = seg.iloc[-1]

    peaks = [i for i in _local_extrema_idx(highs, left=5, right=5, find_max=True) if i < n - 4]
    if not peaks:
        if n <= 10:
            return {'ok': False}
        peaks = [int(np.nanargmax(highs[:-4]))]
    p = peaks[-1]
    pressure = float(highs[p])

    lows_idx = [i for i in _local_extrema_idx(lows, left=5, right=5, find_max=False) if i > p]
    if lows_idx:
        q = lows_idx[0]
    else:
        if p + 2 >= n:
            q = max(0, n - 2)
        else:
            q = p + 1 + int(np.nanargmin(lows[p+1:]))
    release = float(lows[q])

    band = max(pressure - release, 1e-6)
    near_pressure = float(last['high']) >= pressure * 0.985
    near_release = float(last['low']) <= release * 1.03
    span_ratio = (float(last['high']) - float(last['low'])) / band
    two_side_active = bool(near_pressure and near_release and span_ratio >= 0.55)

    return {
        'ok': True,
        'pressure': pressure,
        'release': release,
        'near_pressure': near_pressure,
        'near_release': near_release,
        'span_ratio': float(span_ratio),
        'two_side_active': two_side_active,
        'peak_idx': int(p),
        'release_idx': int(q),
    }


def _get_hsm_base(vols_series):
    """
    最短半样本法 (Half-Sample Mode, HSM):
    寻找连续分布中密度最高的核心小区间，完美抵抗右偏分布的极端异常值掩蔽效应。
    """
    arr = np.sort(vols_series.dropna().values)
    n = len(arr)
    if n < 4:
        return float(np.median(arr)) if n > 0 else 0.0
    
    half_n = n // 2
    min_width = float('inf')
    best_idx = 0
    
    for i in range(n - half_n + 1):
        width = arr[i + half_n - 1] - arr[i]
        if width < min_width:
            min_width = width
            best_idx = i
            
    dense_core = arr[best_idx : best_idx + half_n]
    return float(np.median(dense_core))

def zhyx_profile(df, ctx=120, recent=26, peak_idx=None):
    """
    张扬含蓄量能形态:
    1) 取近期结构峰值附近的量作为前高量(peak_vol)。
    2) 张扬 = 当前量 > 基线(1.30倍) 且 < 前高量。
    3) 含蓄 = 结构峰值之后的震荡期内，下跌日均量 < 上涨日均量。
    4) 人为震荡操作痕迹: 震荡期间出现 outlier volume
    """
    if df is None or len(df) < 20:
        return {'ok': False, 'reason': 'short'}

    hist = df.iloc[:-1].copy()
    vols = hist['volume'].astype(float)
    now_v = float(df.iloc[-1]['volume'])
    
    trace_ok = False # 人为操作痕迹

    if peak_idx is not None and 0 < peak_idx < len(hist):
        left = max(0, peak_idx - 3)
        right = min(len(hist), peak_idx + 4)
        peak_vol = float(hist.iloc[left:right]['volume'].max())
        
        recent_window_len = len(hist) - peak_idx - 1
        recent = max(8, min(recent_window_len, 40))
        
        # 寻找震荡期的“人为操作痕迹”(小高量/试盘量)
        if recent_window_len > 3:
            recent_vols = hist.iloc[-recent_window_len:]['volume']
            # 如果震荡期内有某一天的量超过了这期间中位数的 1.8倍，说明有明显的试盘小脉冲
            if float(recent_vols.max()) > float(recent_vols.median()) * 1.8:
                trace_ok = True
    else:
        ctx_hist = hist.iloc[-min(ctx, len(hist)):]
        peak_vol = float(ctx_hist['volume'].quantile(0.95))
        recent = 26
        recent_vols = hist.iloc[-recent:]['volume']
        if float(recent_vols.max()) > float(recent_vols.median()) * 1.8:
            trace_ok = True

    if peak_vol <= 0:
        return {'ok': False, 'reason': 'bad_peak'}

    base = _get_hsm_base(vols)
    if base <= 0:
        return {'ok': False, 'reason': 'bad_base'}

    # 张扬: 当前量比日常死水基线大(1.30倍，因为基线已剔除极值，1.3能越过随机噪音)，但比前高量小(吃货不爆量)
    zhangyang = now_v >= base * 1.30 and now_v <= peak_vol * 0.95

    rec = hist.iloc[-min(recent, len(hist)):]
    rec_pct = rec['pct'].astype(float) if 'pct' in rec.columns else pd.Series(dtype=float)
    up_days = rec[rec_pct > 0.2]
    dn_days = rec[rec_pct < -0.2]
    if len(up_days) >= 2 and len(dn_days) >= 2:
        up_vol_avg = float(up_days['volume'].mean())
        dn_vol_avg = float(dn_days['volume'].mean())
        hansu = dn_vol_avg < up_vol_avg * 0.90
    else:
        hansu = now_v <= peak_vol * 0.85

    not_too_quiet = now_v >= base * 1.05
    burst_ref = peak_vol

    # 如果有人为操作痕迹，可以适当放宽张扬和含蓄的硬性条件（作为综合判断的一部分）
    is_ok = bool(zhangyang and hansu and not_too_quiet)

    return {
        'ok': is_ok,
        'trace_ok': trace_ok,
        'reason': 'ok' if is_ok else 'shape_fail',
        'zhangyang': bool(zhangyang),
        'hansu': bool(hansu),
        'base': float(base),
        'now': float(now_v),
        'burst_old': float(peak_vol),
        'burst_new': float(peak_vol),
        'burst_ref': float(burst_ref),
    }


def zhyx_strict(df, lb=20, peak_idx=None):
    prof = zhyx_profile(df, ctx=max(80, lb * 5), recent=max(18, lb), peak_idx=peak_idx)
    return bool(prof.get('ok', False))


def build_signal_context(df, code):
    cur = df.iloc[-1]
    has = is_spear(cur, code)
    pos = position(df)
    cut, spear_idx = cutting_price(df, code)
    hist = df.iloc[max(len(df)-121, 0):-1].copy()
    if hist.empty:
        hist = df.iloc[:-1].copy()
    vol_prof = _series_profile(hist['volume'] if 'volume' in hist.columns else pd.Series(dtype=float),
                               float(cur.get('volume', 0) or 0))
    vr_prof = _series_profile(hist['vr'] if 'vr' in hist.columns else pd.Series(dtype=float),
                              float(cur.get('vr', 0) or 0))
    amp_prof = _series_profile(hist['amp'] if 'amp' in hist.columns else pd.Series(dtype=float),
                               float(cur.get('amp', 0) or 0))
                               
    struct_info = structure_profile(df, lookback=160)
    
    return {
        'cur': cur,
        'has': has,
        'pos': pos,
        'cut': cut,
        'spear_idx': spear_idx,
        'lu7': cnt_lu(df, 7),
        'lu30': cnt_lu(df, 30),
        'struct': struct_info,
        'zhyx': zhyx_profile(df, ctx=120, recent=26, peak_idx=struct_info.get('peak_idx')),
        'norm': {
            'vol': vol_prof,
            'vr': vr_prof,
            'amp': amp_prof,
        },
    }


def _series_profile(values, now: float) -> dict:
    s = pd.to_numeric(pd.Series(values), errors='coerce')
    s = s.replace([np.inf, -np.inf], np.nan).dropna()
    if len(s) < 8:
        return {
            'ok': False, 'n': int(len(s)), 'med': float(s.median()) if len(s) > 0 else 0.0,
            'q75': 0.0, 'q80': 0.0, 'q85': 0.0, 'q90': 0.0, 'q95': 0.0, 'q97': 0.0, 'q99': 0.0,
            'rank': 0.5,
        }
    med = float(s.median())
    q75 = float(s.quantile(0.75))
    q80 = float(s.quantile(0.80))
    q85 = float(s.quantile(0.85))
    q90 = float(s.quantile(0.90))
    q95 = float(s.quantile(0.95))
    q97 = float(s.quantile(0.97))
    q99 = float(s.quantile(0.99))
    rank = float((s <= float(now)).mean()) if np.isfinite(now) else 0.5
    return {
        'ok': True, 'n': int(len(s)), 'med': med,
        'q75': q75, 'q80': q80, 'q85': q85, 'q90': q90, 'q95': q95, 'q97': q97, 'q99': q99,
        'rank': rank,
    }


def _norm_value(ctx, key: str, field: str, default: float) -> float:
    try:
        v = float((((ctx or {}).get('norm', {}) or {}).get(key, {}) or {}).get(field, default))
        if np.isfinite(v):
            return v
    except Exception:
        pass
    return float(default)


def cutting_price(df, code):
    """
    城门价(Cutting Price)重构:
    抛弃全天均价，锚定长枪日的“密集成交区”(即上影线的基座/实体顶部)。
    上影线区间反映了主力干架投入资金最多的区域。
    """
    idx = [i for i in range(max(len(df)-10, 0), len(df))
           if is_spear(df.iloc[i], code) or df.iloc[i].get('is_lb', False)]
    if not idx:
        return 0, idx
        
    ta = 0.0
    tv = 0.0
    for i in idx:
        row = df.iloc[i]
        # 密集成交区中枢：实体顶部(起攻点) 与 最高价(受阻点) 的均值
        # 相比(H+L+C)/3，这能极大过滤掉无量砸盘留下的长下影线毛刺
        top = max(row['open'], row['close'])
        dense_mid = (row['high'] + top) / 2.0
        
        vol = row['volume']
        ta += dense_mid * vol
        tv += vol
        
    return (ta/tv if tv > 0 else 0), idx


def cnt_lu(df, days=7):
    if len(df) < days + 1:
        return 0
    return int(df.iloc[-(days+1):-1]['is_lu'].sum())


def _conf_from_flags(base=0.60, *flags):
    extra = 0.0
    for f in flags:
        if f:
            extra += 0.04
    return round(max(0.55, min(0.90, base + extra)), 2)


def _ctx_tags(ctx):
    tags = []
    st = (ctx or {}).get('struct', {})
    zh = (ctx or {}).get('zhyx', {})
    if st.get('ok', False):
        if st.get('two_side_active', False):
            tags.append('双区松动')
        elif st.get('near_pressure', False):
            tags.append('压区试探')
    if zh.get('ok', False):
        tags.append('张扬含蓄')
    elif zh.get('reason', '') == 'no_dual_burst':
        tags.append('缺双锚')
    return ' '.join(tags[:2])


def _route_score(sig: dict, ctx: dict) -> float:
    """
    多标签裁决分（通用版）:
    - 以 detector conf 为基线
    - 叠加结构/量能证据，不做枪型定向加减分
    """
    score = float(sig.get('conf', 0) or 0)
    st = (ctx or {}).get('struct', {}) or {}
    zh = (ctx or {}).get('zhyx', {}) or {}
    cur = (ctx or {}).get('cur', None)
    if cur is None:
        cur = {}
    evidence = 0
    if bool(st.get('near_pressure', False)):
        evidence += 1
    if bool(st.get('two_side_active', False)):
        evidence += 1
    if bool(zh.get('ok', False)):
        evidence += 1
    if bool((ctx or {}).get('has', False)):
        evidence += 1
    if bool(cur.get('is_lb', False)):
        evidence += 1
    if int((ctx or {}).get('lu30', 0) or 0) >= 2:
        evidence += 1
    score += min(0.12, 0.02 * evidence)

    spear_strength = min(1.0, len((ctx or {}).get('spear_idx', []) or []) / 3.0)
    score += 0.04 * float(spear_strength)

    vr_rank = _norm_value(ctx, 'vr', 'rank', 0.5)
    vol_rank = _norm_value(ctx, 'vol', 'rank', 0.5)
    if vr_rank >= 0.98:
        score -= 0.04
    elif vr_rank <= 0.35:
        score -= 0.01
    if vol_rank >= 0.98 and not zh.get('ok', False):
        score -= 0.03
    if str(zh.get('reason', '')) == 'no_dual_burst':
        score -= 0.01
    return float(round(score, 4))


def _type_specificity(sig_type: str) -> int:
    """More specialized types get higher specificity.
    板后 is the broadest catch-all (any LU + spear).
    When route_score/conf are close, prefer specialized types."""
    return {
        '★套利': 3, '烂板': 3, '进攻': 2, '趋势': 2,
        '游资': 1, '板后': 0, '⚠️逃命': 4,
    }.get(str(sig_type), 0)


def _select_primary_signal(cands: list, ctx: dict):
    ranked = []
    for s in cands:
        x = dict(s)
        x['_route_score'] = _route_score(x, ctx)
        ranked.append(x)
    ranked.sort(
        key=lambda x: (
            float(x.get('_route_score', 0)),
            float(x.get('conf', 0) or 0),
            _type_specificity(x.get('type', '')),
            float(x.get('fit', 0) or 0),
        ),
        reverse=True
    )
    return ranked[0], ranked


