# Spear Strategy v5 Standalone

A standalone package for the Spear (长枪) quantitative trading strategy — backtest engine, daily signal scanner, and web-based control studio.

## Architecture

```
v5_standalone/
├── v5/            # AKQuant host, data routing, reporting, notify pipeline
├── v4/            # Strategy logic, features, models, execution state machine
├── cq_backtest/   # Shared market rules, signal schema, mootdx data feed
├── studio_backend/ # FastAPI control plane
├── studio_frontend/ # React + Vite dashboard
├── pools/         # User-saved custom symbol pools
├── cache/         # Mootdx data cache (PKL files)
└── outputs/       # Structured output directory
    ├── backtests/
    ├── signals/
    └── state/     # Persistent watch state, cron meta, audit log
```

## Quick Start

### 1. Install Dependencies

```bash
pip install -r requirements.txt
```

Core dependencies: `pandas`, `numpy`, `mootdx`, `akquant`. Optional: `akshare`, `tqdm`.

The backend also requires `fastapi` and `uvicorn`:

```bash
pip install fastapi uvicorn
```

### 2. Run a Backtest

```bash
python v5/run.py \
  --start 2024-01-02 --end 2024-12-31 \
  --pool 300 --pool-sampling random --pool-seed 42 \
  --execution-profile next_open_realistic \
  --output-dir my_backtest
```

### 3. Run a Daily Signal Scan

```bash
python v5/daily_signal_job.py \
  --date 2026-03-09 \
  --pool 300 --pool-sampling random --pool-seed 42 \
  --execution-profile delayed_limit_hunt \
  --dry-run
```

### 4. Launch the Studio

Backend:

```bash
python start_studio_backend.py
```

Frontend (from `studio_frontend/`):

```bash
cd studio_frontend
npm install
npm run dev
```

Open `http://localhost:5173`. The frontend proxies API requests to the backend at `localhost:8000`.

## Execution Profiles

| Profile | Description |
|---------|-------------|
| `day_level_ideal` | 以信号当日收盘价入场。实盘不可实现，仅用于天花板分析 |
| `next_open_realistic` | 以信号次日开盘价入场。最接近实盘的模拟方式 |
| `delayed_limit_hunt` | 信号触发后，在数日窗口内挂限价单等待回踩入场 |

## Studio Features

- **Backtest Launcher** — configure and run backtests with live progress logs
- **Signal Scanner** — daily signal detection with full message preview and Feishu push
- **Results Explorer** — equity curves, trade tables, notable trade markers
- **Named Pools** — save/reuse custom symbol lists across runs
- **Watch State** — persistent multi-day signal lifecycle tracking

## Feishu Integration

Create a `.env` file in the project root:

```
FEISHU_WEBHOOK=https://open.feishu.cn/open-apis/bot/v2/hook/YOUR_HOOK_ID
FEISHU_SECRET=YOUR_SECRET
```

The daily signal job and studio will auto-load these values.

## Data Sources

- **Mootdx** — primary data provider for daily K-line bars (通达信 protocol)
- **AKShare** — optional alternative provider
- Data is cached locally as PKL files in `cache/`. Incremental fetching pulls only new bars.
- Parallel prefetch (`ProcessPoolExecutor`, 4 workers) warms the cache before signal scans.

## Notes

- Market data requires network access unless running in `--cache-only` mode.
- Results depend on data-provider availability and cache coverage.
- All paths are resolved relative to this directory.
