import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function prettyDate(d: string | undefined): string {
  if (!d) return "—";
  return d.slice(0, 10);
}

export function prettyDateTime(d: string | undefined): string {
  if (!d) return "—";
  const dt = new Date(d);
  if (isNaN(dt.getTime())) return d.slice(0, 16).replace("T", " ");
  const mm = String(dt.getMonth() + 1).padStart(2, "0");
  const dd = String(dt.getDate()).padStart(2, "0");
  const hh = String(dt.getHours()).padStart(2, "0");
  const mi = String(dt.getMinutes()).padStart(2, "0");
  return `${mm}-${dd} ${hh}:${mi}`;
}

export function prettyPct(v: number | undefined | null): string {
  if (v === undefined || v === null) return "—";
  return `${(v * 100).toFixed(2)}%`;
}

export function parseSymbols(raw: string): string[] {
  return raw
    .split(/[,\n\s]+/)
    .map((s) => s.trim())
    .filter(Boolean);
}
