import { useEffect, useRef, useState } from "react";
import { api, type TaskRecord } from "../lib/api";

export interface TaskPollState {
  task: TaskRecord | null;
  logLines: string[];
}

export function useTaskPoller(taskId: string | null, intervalMs = 2000): TaskPollState {
  const [task, setTask] = useState<TaskRecord | null>(null);
  const [logLines, setLogLines] = useState<string[]>([]);
  const timer = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    if (!taskId) {
      setTask(null);
      setLogLines([]);
      return;
    }
    const poll = async () => {
      try {
        const t = await api.task(taskId);
        setTask(t);
        if (t.status === "running" || t.status === "pending") {
          try {
            const log = await api.taskLog(taskId);
            setLogLines(log.lines);
          } catch { /* log may not exist yet */ }
        }
        if (t.status === "succeeded" || t.status === "failed") {
          try {
            const log = await api.taskLog(taskId);
            setLogLines(log.lines);
          } catch { /* ignore */ }
          if (timer.current) clearInterval(timer.current);
        }
      } catch { /* task fetch failed */ }
    };
    poll();
    timer.current = setInterval(poll, intervalMs);
    return () => {
      if (timer.current) clearInterval(timer.current);
    };
  }, [taskId, intervalMs]);

  return { task, logLines };
}
