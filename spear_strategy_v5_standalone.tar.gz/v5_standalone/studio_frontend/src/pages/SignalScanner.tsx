import {
  Activity,
  Bell,
  ChevronDown,
  ChevronRight,
  Eye,
  FileText,
  Filter,
  Loader2,
  Play,
  RefreshCw,
  RotateCcw,
  Save,
  Send,
  Settings2,
  Trash2,
  X,
} from "lucide-react";
import React, { useCallback, useEffect, useRef, useState, useMemo } from "react";
import { toast } from "sonner";
import { Pagination } from "../components/Pagination";
import { SavePoolDialog } from "../components/SavePoolDialog";
import { TaskLogPanel } from "../components/TaskLogPanel";
import { WatchStateTable } from "../components/WatchStateTable";
import { useApi } from "../hooks/useApi";
import { useTaskPoller } from "../hooks/useTaskPoller";
import {
  api,
  type PoolPreview,
  type SignalScanSummary,
  type TaskRecord,
  type TradeSummaryItem,
  type PositionSummaryItem,
} from "../lib/api";
import { cn, parseSymbols, prettyPct } from "../lib/utils";

const SAMPLINGS = ["random", "head"] as const;
type PoolMode = "named" | "random" | "custom";
type SignalMode = "auto" | "preview" | "confirm";
const MODE_LABELS: Record<SignalMode, string> = { auto: "自动", preview: "盘中预测", confirm: "盘后确认" };

function isNearLimitUp(price: number, limitUp?: number): boolean {
  return limitUp != null && price >= limitUp * 0.998;
}
function isNearLimitDown(price: number, limitDown?: number): boolean {
  return limitDown != null && price <= limitDown * 1.002;
}

const EVENT_LABELS: Record<string, string> = {
  trend_spear: "趋势突破", post_limit: "涨停回封", failed_board: "炸板修复",
  youzi: "游资跟踪", sector_spear: "板块联动", attack: "放量攻击",
  arb: "套利信号", escape: "风控逃离", tail_close: "尾盘收敛",
  breakout: "突破确认", continuation: "趋势延续",
};
const ENTRY_STYLE_LABELS: Record<string, string> = {
  breakout: "突破入场", tail_close: "尾盘入场",
};
const REASON_LABELS: Record<string, string> = {
  stop_loss: "止损", take_profit: "止盈", time_exit: "到期",
  no_premium: "无溢价", failed_continuation: "趋势失败",
  theme_collapse: "主题退潮", rebreak: "跌破支撑",
  escape_risk_off: "风险逃离", sell_hunt_expired: "挂单到期",
};
function labelEvent(code: string): string {
  if (!code) return "—";
  const clean = code.replace(/^entry:/, "");
  return EVENT_LABELS[clean] ?? clean;
}
function labelEntryStyle(code: string): string {
  if (!code) return "—";
  return ENTRY_STYLE_LABELS[code] ?? code;
}
function labelReason(code: string): string {
  if (!code) return "—";
  const clean = code.replace(/_forced$/, "");
  return REASON_LABELS[clean] ?? code;
}
function formatEnv(s: { sector_hot: boolean; peer_confirmation: number; leader_strength: number }): React.JSX.Element {
  const peerTip = `同板块共振: 同一天同板块内有 ${s.peer_confirmation} 只其他股票也产生了多头信号，数值越高说明板块整体活跃`;
  const leaderTip = `龙头带动: 同一天同板块内有 ${s.leader_strength} 只股票产生了高信心(≥0.7)的强势信号(趋势突破/涨停回封/炸板修复)`;
  const hotTip = "热门板块: 同板块共振≥2 且 龙头带动≥1";
  return (
    <>
      {s.sector_hot
        ? <span className="text-warning font-medium cursor-help" title={hotTip}>🔥 热门</span>
        : <span className="text-muted-foreground">—</span>}
      <span className="ml-1.5 text-muted-foreground cursor-help" title={peerTip}>
        共振{s.peer_confirmation}
      </span>
      <span className="ml-1 text-muted-foreground cursor-help" title={leaderTip}>
        龙头{s.leader_strength}
      </span>
    </>
  );
}

export function SignalScanner() {
  const { data: pools, refetch: refetchPools } = useApi(() => api.pools(), []);
  const { data: watchState, refetch: refetchWatch } = useApi(() => api.watchState(), []);
  const { data: feishuCfg } = useApi(() => api.feishuConfig(), []);

  const today = new Date().toISOString().slice(0, 10);
  const [date, setDate] = useState(today);
  const [latestBar, setLatestBar] = useState<{ date: string | null; loading: boolean; error?: string; hint?: string; dailyReady?: boolean }>({ date: null, loading: true });
  const probeLatestBar = useCallback(() => {
    setLatestBar((prev) => ({ ...prev, loading: true }));
    api.latestBar()
      .then((r) => setLatestBar({ date: r.latest_date, loading: false, error: r.error, hint: r.hint, dailyReady: r.daily_ready }))
      .catch(() => setLatestBar({ date: null, loading: false, error: "请求失败" }));
  }, []);
  useEffect(() => { probeLatestBar(); }, [probeLatestBar]);
  const [poolMode, setPoolMode] = useState<PoolMode>("random");
  const [poolSize, setPoolSize] = useState(300);
  const [poolSampling, setPoolSampling] = useState<string>("random");
  const [poolSeed, setPoolSeed] = useState(42);
  const [poolName, setPoolName] = useState("");
  const [symbolsRaw, setSymbolsRaw] = useState("");
  const [signalMode, setSignalMode] = useState<SignalMode>("auto");
  const [warmupBars, setWarmupBars] = useState(600);

  const [watchWindowDays, setWatchWindowDays] = useState(5);
  const [huntBufferPct, setHuntBufferPct] = useState(0.005);
  const [huntWindowDays, setHuntWindowDays] = useState(3);
  const [disableEnvMapping, setDisableEnvMapping] = useState(false);
  const [ytd, setYtd] = useState(false);
  const [showStrategyConfig, setShowStrategyConfig] = useState(false);

  const [pushTopNew, setPushTopNew] = useState(3);
  const [pushTopWatch, setPushTopWatch] = useState(5);
  const [pushTopDrops, setPushTopDrops] = useState(5);
  const [minConfidence, setMinConfidence] = useState<"all" | "A">("all");
  const [autoPush, setAutoPush] = useState(false);
  const [showNotifyConfig, setShowNotifyConfig] = useState(false);

  type ViewMode = "signals" | "strategy";
  const [viewMode, setViewMode] = useState<ViewMode>("signals");

  const hasFeishuConfig = Boolean(feishuCfg?.webhook);

  const [taskId, setTaskId] = useState<string | null>(null);
  const { task, logLines } = useTaskPoller(taskId);

  const [snapshot, setSnapshot] = useState<Record<string, unknown> | null>(null);
  const [scanSummary, setScanSummary] = useState<SignalScanSummary | null>(null);

  const [preview, setPreview] = useState<PoolPreview | null>(null);
  const [previewLoading, setPreviewLoading] = useState(false);
  const [pushing, setPushing] = useState(false);
  const [pushed, setPushed] = useState(false);

  const [showNewSignals, setShowNewSignals] = useState(true);
  const [showWatchUpdates, setShowWatchUpdates] = useState(false);
  const [showDropped, setShowDropped] = useState(false);
  const [showMessagePreview, setShowMessagePreview] = useState(true);
  const [showSavePool, setShowSavePool] = useState(false);

  const PAGE_SIZE = 20;
  const [newSigPage, setNewSigPage] = useState(0);
  const [watchUpPage, setWatchUpPage] = useState(0);
  const [droppedPage, setDroppedPage] = useState(0);

  const [watchFilter, setWatchFilter] = useState<{ status: string; type: string; rank: string }>({ status: "", type: "", rank: "" });

  const isRunning = task?.status === "running" || task?.status === "pending";

  async function handlePreview() {
    setPreviewLoading(true);
    try {
      setPreview(await api.poolPreview(poolSize, poolSampling, poolSeed, poolMode === "named" ? poolName : undefined));
    } catch (e: unknown) { toast.error(String(e)); }
    finally { setPreviewLoading(false); }
  }

  async function handleSubmit() {
    if (poolMode === "named" && !poolName) { toast.error("请选择一个标的池"); return; }
    if (poolMode === "custom" && !symbolsRaw.trim()) { toast.error("请输入至少一个股票代码"); return; }
    try {
      const payload: Record<string, unknown> = {
        date,
        pool: poolMode === "random" ? poolSize : 9999,
        pool_sampling: poolSampling,
        pool_seed: poolSeed,
        execution_profile: "delayed_limit_hunt",
        output_dir: "",
        mode: signalMode,
        warmup_bars: warmupBars,
        watch_window_days: watchWindowDays,
        hunt_price_buffer_pct: huntBufferPct,
        hunt_window_days: huntWindowDays,
        push_top_new: pushTopNew,
        push_top_watch: pushTopWatch,
        push_top_drops: pushTopDrops,
        min_confidence: minConfidence === "A" ? 0.78 : 0.0,
        auto_push: autoPush,
        disable_env_mapping: disableEnvMapping,
        ytd,
      };
      if (poolMode === "named") payload.pool_name = poolName;
      if (poolMode === "custom") payload.symbols = parseSymbols(symbolsRaw);
      const t = await api.createSignalScan(payload);
      setTaskId(t.id); setSnapshot(null); setScanSummary(null); setPushed(false); resultLoadedRef.current = false;
      setNewSigPage(0); setWatchUpPage(0); setDroppedPage(0);
      toast.success("信号扫描已启动");
    } catch (e: unknown) { toast.error(String(e)); }
  }

  async function handlePush() {
    const effectiveDate = String(snapshot?.effective_date || snapshot?.date || date);
    const outputDir = task?.output_dir;
    setPushing(true);
    try { await api.feishuPush(effectiveDate, outputDir); setPushed(true); toast.success("已推送到飞书"); }
    catch (e: unknown) { toast.error(`推送失败: ${String(e)}`); }
    finally { setPushing(false); }
  }

  const resultLoadedRef = useRef(false);

  useEffect(() => {
    if (task?.status !== "succeeded" || resultLoadedRef.current) return;
    resultLoadedRef.current = true;
    const name = task.output_dir.split("/").pop() ?? "";
    if (!name) return;
    (async () => {
      try {
        const [meta, summary] = await Promise.allSettled([api.resultMeta(name), api.scanSummary(name)]);
        if (meta.status === "fulfilled") setSnapshot(meta.value);
        if (summary.status === "fulfilled") setScanSummary(summary.value);
        refetchWatch();
      } catch { /* meta may not exist */ }
    })();
  }, [task?.status, task?.output_dir]); // eslint-disable-line react-hooks/exhaustive-deps

  const watchItems = watchState
    ? Object.values(watchState)
        .map((v) => v as Record<string, unknown>)
        .sort((a, b) => String(b.signal_date ?? "").localeCompare(String(a.signal_date ?? "")))
    : [];
  const ss = scanSummary?.snapshot;
  const newSignals = ss?.new_signals ?? [];
  const watchUpdates = [...(ss?.watch_updates ?? [])].sort((a, b) => b.signal_date.localeCompare(a.signal_date));
  const droppedItems = [...(ss?.dropped ?? [])].sort((a, b) => b.signal_date.localeCompare(a.signal_date));
  const todayEntries = ss?.today_entries ?? [];
  const todayExits = ss?.today_exits ?? [];
  const activePositions = ss?.active_positions ?? [];
  const closedTrades = ss?.closed_trades ?? [];
  const hasTradeData = todayEntries.length > 0 || todayExits.length > 0 || activePositions.length > 0 || closedTrades.length > 0 || (ss?.portfolio_equity ?? 0) > 0;

  return (
    <div className="p-6 max-w-5xl mx-auto space-y-5">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">信号扫描</h1>
        <p className="text-muted-foreground text-sm mt-1">检测指定日期的交易信号，追踪已有信号的状态变化</p>
      </div>

      {/* ════════ Config ════════ */}
      <div className="rounded-xl border border-border bg-card p-5 space-y-5">
        {/* Date + Mode */}
        <div className="flex items-start gap-6">
          <div>
            <label className="block text-xs font-medium text-muted-foreground mb-1">扫描日期</label>
            <input type="date" value={date} onChange={(e) => setDate(e.target.value)} className="input-field w-48" />
            <div className="flex items-center gap-2 mt-1">
              <p className="text-[10px] text-muted-foreground">扫描该日的收盘数据，检测新信号并更新观察池状态</p>
            </div>
            {!latestBar.loading && (
              <div className="mt-1.5 flex items-center gap-1.5 text-[10px]">
                {latestBar.date ? (
                  latestBar.date >= date ? (
                    latestBar.dailyReady ? (
                      <span className="text-emerald-600 dark:text-emerald-400">● 数据已就绪（{latestBar.date}）</span>
                    ) : (
                      <span className="text-emerald-600 dark:text-emerald-400" title={latestBar.hint || ""}>● 分钟线已就绪（{latestBar.date}），日线更新中 — 盘后确认会自动用分钟线补齐</span>
                    )
                  ) : (
                    <span className="text-amber-600 dark:text-amber-400">● 数据尚未更新至 {date}（当前最新 {latestBar.date}）</span>
                  )
                ) : (
                  <span className="text-red-500">● 无法获取数据状态{latestBar.error ? `：${latestBar.error}` : ""}</span>
                )}
                <button onClick={probeLatestBar} className="text-muted-foreground hover:text-foreground transition-colors" title="刷新检测">
                  <RefreshCw className="h-3 w-3" />
                </button>
              </div>
            )}
          </div>
          <div>
            <label className="block text-xs font-medium text-muted-foreground mb-1">运行模式</label>
            <div className="flex gap-1.5">
              {(["auto", "preview", "confirm"] as SignalMode[]).map((m) => (
                <button
                  key={m} onClick={() => setSignalMode(m)}
                  className={cn(
                    "rounded-full px-3 py-1 text-xs font-medium transition-all",
                    signalMode === m ? (m === "preview" ? "bg-amber-500/20 text-amber-600 shadow-sm" : m === "confirm" ? "bg-success/20 text-success shadow-sm" : "bg-primary text-primary-foreground shadow-sm") : "bg-muted text-muted-foreground hover:bg-accent",
                  )}
                >
                  {MODE_LABELS[m]}
                </button>
              ))}
            </div>
            <p className="text-[10px] text-muted-foreground mt-1">
              {signalMode === "auto" ? "自动判断: 15:00前盘中预测, 之后盘后确认" : signalMode === "preview" ? "盘中预测: 使用分钟数据合成模糊日线信号" : "盘后确认: 使用完整收盘数据"}
            </p>
          </div>
        </div>

        {/* Pool */}
        <div className="border-t border-border pt-4">
          <label className="block text-xs font-medium text-muted-foreground mb-2">标的池</label>
          <div className="flex gap-1.5 mb-3">
            {(["random", "named", "custom"] as PoolMode[]).map((m) => (
              <button
                key={m} onClick={() => { setPoolMode(m); setPreview(null); }}
                className={cn(
                  "rounded-full px-3.5 py-1 text-xs font-medium transition-all",
                  poolMode === m ? "bg-primary text-primary-foreground shadow-sm" : "bg-muted text-muted-foreground hover:bg-accent",
                )}
              >
                {m === "random" ? "随机抽样" : m === "named" ? "命名池" : "自定义代码"}
              </button>
            ))}
          </div>

          {poolMode === "random" && (
            <div className="space-y-3">
              <div className="flex items-center gap-3">
                <div>
                  <label className="block text-[10px] text-muted-foreground mb-0.5">数量</label>
                  <input type="number" min={1} value={poolSize} onChange={(e) => setPoolSize(+e.target.value)} className="input-field w-24 tabular-nums" />
                </div>
                <div>
                  <label className="block text-[10px] text-muted-foreground mb-0.5">方式</label>
                  <select value={poolSampling} onChange={(e) => setPoolSampling(e.target.value)} className="input-field w-32">
                    {SAMPLINGS.map((s) => (<option key={s} value={s}>{s === "random" ? "随机" : "顺序"}</option>))}
                  </select>
                </div>
                <div>
                  <label className="block text-[10px] text-muted-foreground mb-0.5">种子</label>
                  <input type="number" value={poolSeed} onChange={(e) => setPoolSeed(+e.target.value)} className="input-field w-24 tabular-nums" />
                </div>
              </div>
              <button onClick={handlePreview} disabled={previewLoading} className="flex items-center gap-1.5 text-xs font-medium text-primary hover:text-primary/80 transition-colors">
                {previewLoading ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Eye className="h-3.5 w-3.5" />}
                预览标的池
              </button>
              {preview && <PoolPreviewPanel preview={preview} onClose={() => setPreview(null)} />}
            </div>
          )}

          {poolMode === "named" && (
            <div className="space-y-1.5">
              <div className="flex items-center gap-2">
                <select value={poolName} onChange={(e) => setPoolName(e.target.value)} className="input-field max-w-md">
                  <option value="">— 选择标的池 —</option>
                  {(pools ?? []).map((p) => (
                    <option key={p.name} value={p.name}>
                      {p.label} ({p.symbol_count} 只){p.description ? ` — ${p.description}` : ""}{!p.builtin ? " [自定义]" : ""}
                    </option>
                  ))}
                </select>
                {poolName && (
                  <button onClick={handlePreview} disabled={previewLoading}
                    className="flex items-center gap-1 text-xs font-medium text-primary hover:text-primary/80 transition-colors shrink-0">
                    {previewLoading ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Eye className="h-3.5 w-3.5" />}预览
                  </button>
                )}
                {poolName && !(pools ?? []).find((p) => p.name === poolName)?.builtin && (
                  <button
                    onClick={async () => {
                      if (!confirm(`确定删除「${poolName}」?`)) return;
                      try { await api.deletePool(poolName); toast.success("已删除"); setPoolName(""); refetchPools(); }
                      catch (e: unknown) { toast.error(String(e)); }
                    }}
                    className="flex items-center gap-1 text-xs text-destructive hover:text-destructive/80 shrink-0"
                  ><Trash2 className="h-3.5 w-3.5" />删除</button>
                )}
              </div>
              {preview && <PoolPreviewPanel preview={preview} onClose={() => setPreview(null)} />}
            </div>
          )}

          {poolMode === "custom" && (
            <div className="space-y-2">
              <textarea rows={3} value={symbolsRaw} onChange={(e) => setSymbolsRaw(e.target.value)}
                placeholder="000001, 600519, 300750 ..." className="input-field resize-none font-mono text-xs" />
              {symbolsRaw.trim() && (
                <div className="flex items-center gap-3">
                  <span className="text-xs text-muted-foreground">{parseSymbols(symbolsRaw).length} 只标的</span>
                  <button onClick={() => setShowSavePool(true)} className="flex items-center gap-1 text-xs font-medium text-primary hover:text-primary/80">
                    <Save className="h-3 w-3" />保存为命名池
                  </button>
                </div>
              )}
              {showSavePool && symbolsRaw.trim() && (
                <SavePoolDialog symbols={parseSymbols(symbolsRaw)} onSaved={() => refetchPools()} onClose={() => setShowSavePool(false)} />
              )}
            </div>
          )}
        </div>

        {/* Warmup Bars */}
        <div className="border-t border-border pt-4">
          <label className="block text-xs font-medium text-muted-foreground mb-2">特征预热</label>
          <div className="flex items-center gap-3">
            <input type="number" min={120} max={900} step={50} value={warmupBars} onChange={(e) => setWarmupBars(+e.target.value)} className="input-field w-24 tabular-nums" />
            <span className="text-xs text-muted-foreground">bar</span>
            <span className="text-[10px] text-muted-foreground ml-2">默认 600</span>
          </div>
          <p className="text-[10px] text-muted-foreground mt-1 leading-relaxed max-w-xl">
            扫描区间前加载的历史 K 线数，用于 rolling 特征预热。最低 120（结构特征窗口需要 120 bar），推荐 300~600。
          </p>
          <p className="text-[10px] text-muted-foreground mt-0.5 leading-relaxed max-w-xl">
            <strong className="text-foreground/70">影响示例：</strong>amount_rank（60日成交额排名）在 600 bar 下用 ~2.4 年历史排序，300 bar 下用 ~1.2 年；
            结构特征的"历史高点"在更短窗口下可能找不到更久远的高点。<strong className="text-warning">不同预热值的信号结果不可直接对比。</strong>
          </p>
        </div>

        {/* Strategy Config */}
        <div className="border-t border-border pt-4">
          <button onClick={() => setShowStrategyConfig(!showStrategyConfig)} className="flex items-center gap-2 text-xs font-medium text-muted-foreground hover:text-foreground transition-colors">
            <Settings2 className="h-3.5 w-3.5" />
            <span>策略参数</span>
            {showStrategyConfig ? <ChevronDown className="h-3 w-3" /> : <ChevronRight className="h-3 w-3" />}
            <span className="text-[10px] text-muted-foreground ml-1">
              (观察{watchWindowDays}天, 入场{huntWindowDays}天, 缓冲{(huntBufferPct * 100).toFixed(1)}%)
            </span>
          </button>
          {showStrategyConfig && (
            <div className="mt-3 grid grid-cols-3 gap-4">
              <div className="space-y-1.5">
                <label className="block text-[10px] font-medium text-muted-foreground">观察窗口</label>
                <div className="flex items-center gap-2">
                  <input type="number" min={1} max={30} value={watchWindowDays} onChange={(e) => setWatchWindowDays(+e.target.value)} className="input-field w-16 tabular-nums" />
                  <span className="text-[10px] text-muted-foreground">天</span>
                </div>
                <p className="text-[10px] text-muted-foreground leading-relaxed">信号触发后追踪 N 天，超时则移除</p>
              </div>
              <div className="space-y-1.5">
                <label className="block text-[10px] font-medium text-muted-foreground">入场等待</label>
                <div className="flex items-center gap-2">
                  <input type="number" min={1} max={10} value={huntWindowDays} onChange={(e) => setHuntWindowDays(+e.target.value)} className="input-field w-16 tabular-nums" />
                  <span className="text-[10px] text-muted-foreground">天</span>
                </div>
                <p className="text-[10px] text-muted-foreground leading-relaxed">信号后 N 天内等待价格回踩到 gate 附近</p>
              </div>
              <div className="space-y-1.5">
                <label className="block text-[10px] font-medium text-muted-foreground">回踩缓冲</label>
                <div className="flex items-center gap-2">
                  <input type="number" min={0} max={0.05} step={0.001} value={huntBufferPct} onChange={(e) => setHuntBufferPct(+e.target.value)} className="input-field w-20 tabular-nums" />
                  <span className="text-[10px] text-muted-foreground">({(huntBufferPct * 100).toFixed(1)}%)</span>
                </div>
                <p className="text-[10px] text-muted-foreground leading-relaxed">gate ± N% 范围内视为到位，越大越容易触发</p>
              </div>
            </div>
          )}
        </div>

        <div className="border-t border-border pt-4 space-y-2.5">
          <div>
            <label className="flex items-center gap-2 cursor-pointer select-none text-xs">
              <input type="checkbox" checked={ytd} onChange={(e) => setYtd(e.target.checked)} className="rounded border-border accent-primary" />
              全年回测（持仓连续）
            </label>
            <p className="text-[10px] text-muted-foreground mt-1 ml-5 leading-relaxed max-w-lg">
              {ytd
                ? `从 ${date.slice(0, 4)}-01-01 至今完整回测，确保持仓和交易记录连续可追溯。信号本身不受影响（基于K线 lookback 计算），但交易决策（仓位、资金、冷却期）会与全年轨迹一致。耗时约 30-60s。`
                : "默认仅回测最近数天窗口，持仓轨迹可能因窗口起点不同而与前日结果不一致。开启后以当年1月1日为起点回测，保证跨日结果连续。"
              }
            </p>
          </div>
          <label className="flex items-center gap-2 cursor-pointer select-none text-xs">
            <input type="checkbox" checked={disableEnvMapping} onChange={(e) => setDisableEnvMapping(e.target.checked)} className="rounded border-border accent-primary" />
            禁用行业映射 <span className="text-[11px] text-muted-foreground">— 所有标的归为"其他"，排除板块联动影响</span>
          </label>
        </div>

        {/* Notification Config */}
        <div className="border-t border-border pt-4">
          <button onClick={() => setShowNotifyConfig(!showNotifyConfig)} className="flex items-center gap-2 text-xs font-medium text-muted-foreground hover:text-foreground transition-colors">
            <Bell className="h-3.5 w-3.5" />
            <span>推送配置</span>
            {showNotifyConfig ? <ChevronDown className="h-3 w-3" /> : <ChevronRight className="h-3 w-3" />}
            <span className="text-[10px] text-muted-foreground ml-1">
              (Top {pushTopNew}/{pushTopWatch}/{pushTopDrops}, {minConfidence === "A" ? "仅A级" : "全部"}{autoPush ? ", 自动推送" : ""})
            </span>
          </button>
          {showNotifyConfig && (
            <div className="mt-3 space-y-3">
              <div className="flex items-center gap-4">
                <div>
                  <label className="block text-[10px] text-muted-foreground mb-0.5">新信号条数</label>
                  <input type="number" min={0} max={50} value={pushTopNew} onChange={(e) => setPushTopNew(+e.target.value)} className="input-field w-20 tabular-nums" />
                </div>
                <div>
                  <label className="block text-[10px] text-muted-foreground mb-0.5">观察中条数</label>
                  <input type="number" min={0} max={50} value={pushTopWatch} onChange={(e) => setPushTopWatch(+e.target.value)} className="input-field w-20 tabular-nums" />
                </div>
                <div>
                  <label className="block text-[10px] text-muted-foreground mb-0.5">已失效条数</label>
                  <input type="number" min={0} max={50} value={pushTopDrops} onChange={(e) => setPushTopDrops(+e.target.value)} className="input-field w-20 tabular-nums" />
                </div>
              </div>
              <div className="flex items-center gap-4">
                <div>
                  <label className="block text-[10px] text-muted-foreground mb-0.5">最低信心门槛</label>
                  <div className="flex gap-1.5">
                    {(["all", "A"] as const).map((v) => (
                      <button key={v} onClick={() => setMinConfidence(v)}
                        className={cn("rounded-full px-3 py-1 text-xs font-medium transition-all",
                          minConfidence === v ? "bg-primary text-primary-foreground shadow-sm" : "bg-muted text-muted-foreground hover:bg-accent",
                        )}>
                        {v === "all" ? "全部" : "仅A级 (≥0.78)"}
                      </button>
                    ))}
                  </div>
                </div>
                <div>
                  <label className="block text-[10px] text-muted-foreground mb-0.5">自动推送</label>
                  <button onClick={() => setAutoPush(!autoPush)}
                    className={cn("rounded-full px-3 py-1 text-xs font-medium transition-all",
                      autoPush ? "bg-blue-600/20 text-blue-600 shadow-sm" : "bg-muted text-muted-foreground hover:bg-accent",
                    )}>
                    {autoPush ? "扫描后自动推送" : "手动推送"}
                  </button>
                </div>
              </div>
              <p className="text-[10px] text-muted-foreground">这些配置影响飞书推送的消息内容，适用于 cron 定时任务场景。表格中始终显示全量数据。</p>
            </div>
          )}
        </div>

        {/* Actions */}
        <div className="flex items-center gap-3 pt-1">
          <button onClick={handleSubmit} disabled={isRunning}
            className={cn(
              "flex items-center gap-2 rounded-lg px-6 py-2.5 text-sm font-medium transition-all shadow-sm",
              isRunning ? "bg-muted text-muted-foreground cursor-not-allowed shadow-none" : "bg-primary text-primary-foreground hover:bg-primary/90",
            )}>
            {isRunning ? <Loader2 className="h-4 w-4 animate-spin" /> : <Play className="h-4 w-4" />}
            {isRunning ? "扫描中..." : "开始扫描"}
          </button>
          {task && (
            <button onClick={() => { setTaskId(null); setSnapshot(null); setScanSummary(null); setPushed(false); resultLoadedRef.current = false; }}
              className="flex items-center gap-2 rounded-lg px-4 py-2.5 text-sm font-medium border border-border hover:bg-accent transition-colors">
              <RotateCcw className="h-4 w-4" />重置
            </button>
          )}
        </div>
      </div>

      {/* ════════ Task & Results ════════ */}
      {task && (
        <div className="rounded-xl border border-border bg-card p-5 space-y-4">
          <div className="flex items-center gap-3">
            <span className="text-sm font-medium">Task {task.id}</span>
            <span className={cn(
              "rounded-full px-2.5 py-0.5 text-xs font-medium",
              task.status === "succeeded" ? "bg-success/20 text-success"
                : task.status === "failed" ? "bg-destructive/20 text-destructive"
                  : "bg-warning/20 text-warning",
            )}>{task.status}</span>
            {String(snapshot?.mode ?? "") && (
              <span className={cn(
                "rounded-full px-2.5 py-0.5 text-xs font-medium",
                String(snapshot?.mode) === "preview" ? "bg-amber-500/20 text-amber-600" : "bg-success/20 text-success",
              )}>
                {String(snapshot?.mode) === "preview" ? "盘中预测" : "盘后确认"}
              </span>
            )}
            {String(snapshot?.hint ?? "") && (
              <span className="text-xs text-muted-foreground">{String(snapshot?.hint ?? "")}</span>
            )}
          </div>

          {isRunning && <TaskLogPanel logLines={logLines} isRunning />}

          {snapshot && (
            <div className="space-y-4">
              {/* View mode toggle */}
              {hasTradeData && (
                <div className="flex rounded-lg border border-border overflow-hidden">
                  <button onClick={() => setViewMode("signals")}
                    className={cn("flex-1 flex items-center justify-center gap-2 px-4 py-2 text-xs font-semibold transition-all",
                      viewMode === "signals" ? "bg-primary text-primary-foreground" : "bg-card text-muted-foreground hover:bg-muted",
                    )}>
                    <Eye className="h-3.5 w-3.5" />
                    信号总览
                  </button>
                  <button onClick={() => setViewMode("strategy")}
                    className={cn("flex-1 flex items-center justify-center gap-2 px-4 py-2 text-xs font-semibold transition-all border-l border-border",
                      viewMode === "strategy" ? "bg-primary text-primary-foreground" : "bg-card text-muted-foreground hover:bg-muted",
                    )}>
                    <Activity className="h-3.5 w-3.5" />
                    策略拟真
                  </button>
                </div>
              )}

              {/* Stat bar */}
              {viewMode === "strategy" && hasTradeData ? (
                <div className="grid grid-cols-6 gap-3">
                  <StatCard value={String(todayEntries.length)} label="今日入场" color="text-up" />
                  <StatCard value={String(todayExits.length)} label="今日出场" color="text-down" />
                  <StatCard value={String(snapshot.new_signals ?? "0")} label="新信号" color="text-primary" />
                  <StatCard value={String(activePositions.length)} label="持仓数" color="text-blue-500" />
                  <StatCard value={String(closedTrades.length)} label="已平仓" color="text-muted-foreground" />
                  <StatCard value={String(snapshot.active_watch ?? "0")} label="观察中" color="text-success" />
                  <StatCard value={String(snapshot.dropped ?? "0")} label="已失效" color="text-destructive" />
                </div>
              ) : (
                <div className="grid grid-cols-3 gap-3">
                  <StatCard value={String(snapshot.new_signals ?? "0")} label="新信号" color="text-primary" />
                  <StatCard value={String(snapshot.active_watch ?? "0")} label="观察中" color="text-success" />
                  <StatCard value={String(snapshot.dropped ?? "0")} label="已失效" color="text-destructive" />
                </div>
              )}

              {Boolean(snapshot.effective_date) && snapshot.effective_date !== snapshot.requested_date && (
                <p className="text-xs text-warning">
                  数据截至 {String(snapshot.effective_date)}（请求日期 {String(snapshot.requested_date)}）
                </p>
              )}

              {/* Strategy view: Active Positions (first in strategy view) */}
              {viewMode === "strategy" && activePositions.length > 0 && (() => {
                const equity = ss?.portfolio_equity ?? 0;
                return (
                  <CollapsibleSection title={`当前持仓 (${activePositions.length})`} defaultOpen badge="success">
                    <div className="flex gap-4 rounded-lg bg-muted/50 border border-border px-4 py-2 mb-3">
                      <MiniStat label="总权益" value={`${(equity / 10000).toFixed(1)}万`} />
                      <MiniStat label="现金" value={`${((ss?.portfolio_cash ?? 0) / 10000).toFixed(1)}万`} />
                      <MiniStat label="仓位" value={`${ss?.portfolio_exposure_pct?.toFixed(1) ?? 0}%`} color={Number(ss?.portfolio_exposure_pct ?? 0) > 80 ? "text-warning" : undefined} />
                      {ss?.market_context?.conversion_rate !== undefined && (
                        <MiniStat label="转化率" value={`${(ss.market_context.conversion_rate * 100).toFixed(0)}%`} />
                      )}
                    </div>
                    <div className="overflow-x-auto">
                      <table className="w-full text-xs">
                        <thead><tr className="border-b border-border text-left text-muted-foreground">
                          <th className="pb-1.5 pr-3 font-medium">标的</th><th className="pb-1.5 pr-3 font-medium">入场日</th>
                          <th className="pb-1.5 pr-3 font-medium">入场价</th><th className="pb-1.5 pr-3 font-medium">现价</th>
                          <th className="pb-1.5 pr-3 font-medium">浮盈%</th><th className="pb-1.5 pr-3 font-medium">仓位%</th>
                          <th className="pb-1.5 pr-3 font-medium">持有天数</th>
                          <th className="pb-1.5 font-medium">信号类型</th>
                        </tr></thead>
                        <tbody>
                          {activePositions.map((p, i) => {
                            const weight = equity > 0 ? (p.qty * p.current_price) / equity * 100 : 0;
                            return (
                              <tr key={`pos-${i}`} className="border-b border-border/50 last:border-0">
                                <td className="py-1.5 pr-3 font-mono font-medium">{p.symbol}{p.name && <span className="ml-1 font-normal text-muted-foreground">{p.name}</span>}</td>
                                <td className="py-1.5 pr-3">{p.entry_date}</td>
                                <td className={cn("py-1.5 pr-3 font-mono", isNearLimitUp(p.entry_price, p.entry_limit_up) && "text-orange-500")} title={isNearLimitUp(p.entry_price, p.entry_limit_up) ? `⚠ 接近涨停价 ${p.entry_limit_up?.toFixed(2)}` : undefined}>{p.entry_price.toFixed(2)}{isNearLimitUp(p.entry_price, p.entry_limit_up) && <span className="ml-0.5 text-[10px]">涨</span>}</td>
                                <td className="py-1.5 pr-3 font-mono">{p.current_price.toFixed(2)}</td>
                                <td className={cn("py-1.5 pr-3 font-mono font-medium", p.unrealized_pnl_pct >= 0 ? "text-up" : "text-down")}>{p.unrealized_pnl_pct >= 0 ? "+" : ""}{p.unrealized_pnl_pct.toFixed(2)}%</td>
                                <td className="py-1.5 pr-3 font-mono">{weight.toFixed(1)}%</td>
                                <td className="py-1.5 pr-3">D+{p.days_held}</td>
                                <td className="py-1.5 text-muted-foreground">{labelEvent(p.source_event)}</td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  </CollapsibleSection>
                );
              })()}

              {/* Strategy view: Today's Trades */}
              {viewMode === "strategy" && (todayEntries.length > 0 || todayExits.length > 0) && (
                <CollapsibleSection title={`今日交易 (${todayEntries.length + todayExits.length})`} defaultOpen badge="primary">
                  {todayEntries.length > 0 && (
                    <>
                      <div className="text-xs font-medium text-muted-foreground mb-2">入场 ({todayEntries.length})</div>
                      <div className="overflow-x-auto mb-3">
                        <table className="w-full text-xs">
                          <thead><tr className="border-b border-border text-left text-muted-foreground">
                            <th className="pb-1.5 pr-3 font-medium">标的</th><th className="pb-1.5 pr-3 font-medium">价格</th>
                            <th className="pb-1.5 pr-3 font-medium">数量</th><th className="pb-1.5 pr-3 font-medium">信号来源</th>
                            <th className="pb-1.5 font-medium">仓位%</th>
                          </tr></thead>
                          <tbody>
                            {todayEntries.map((t, i) => (
                              <tr key={`entry-${i}`} className="border-b border-border/50 last:border-0">
                                <td className="py-1.5 pr-3 font-mono font-medium">{t.symbol}{t.name && <span className="ml-1 font-normal text-muted-foreground">{t.name}</span>}</td>
                                <td className="py-1.5 pr-3 font-mono">{t.price.toFixed(2)}</td>
                                <td className="py-1.5 pr-3 font-mono">{t.qty.toFixed(0)}</td>
                                <td className="py-1.5 pr-3">{labelEvent(t.signal_type || t.reason)}{t.signal_date && <span className="ml-1 text-muted-foreground">({t.signal_date})</span>}</td>
                                <td className="py-1.5 font-mono">{t.position_pct.toFixed(1)}%</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </>
                  )}
                  {todayExits.length > 0 && (
                    <>
                      <div className="text-xs font-medium text-muted-foreground mb-2">出场 ({todayExits.length})</div>
                      <div className="overflow-x-auto">
                        <table className="w-full text-xs">
                          <thead><tr className="border-b border-border text-left text-muted-foreground">
                            <th className="pb-1.5 pr-3 font-medium">标的</th><th className="pb-1.5 pr-3 font-medium">价格</th>
                            <th className="pb-1.5 font-medium">原因</th>
                          </tr></thead>
                          <tbody>
                            {todayExits.map((t, i) => (
                              <tr key={`exit-${i}`} className="border-b border-border/50 last:border-0">
                                <td className="py-1.5 pr-3 font-mono font-medium">{t.symbol}{t.name && <span className="ml-1 font-normal text-muted-foreground">{t.name}</span>}</td>
                                <td className="py-1.5 pr-3 font-mono">{t.price.toFixed(2)}</td>
                                <td className="py-1.5">{labelReason(t.reason)}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </>
                  )}
                </CollapsibleSection>
              )}

              {viewMode === "strategy" && closedTrades.length > 0 && (
                <CollapsibleSection title={`已平仓记录 (${closedTrades.length})`} defaultOpen badge="default">
                  <div className="overflow-x-auto">
                    <table className="w-full text-xs">
                      <thead><tr className="border-b border-border text-left text-muted-foreground">
                        <th className="pb-1.5 pr-3 font-medium">标的</th>
                        <th className="pb-1.5 pr-3 font-medium">买入日</th>
                        <th className="pb-1.5 pr-3 font-medium">买入价</th>
                        <th className="pb-1.5 pr-3 font-medium">卖出日</th>
                        <th className="pb-1.5 pr-3 font-medium">卖出价</th>
                        <th className="pb-1.5 pr-3 font-medium">数量</th>
                        <th className="pb-1.5 pr-3 font-medium">盈亏%</th>
                        <th className="pb-1.5 pr-3 font-medium">持有天数</th>
                        <th className="pb-1.5 font-medium">原因</th>
                      </tr></thead>
                      <tbody>
                        {closedTrades.map((ct, i) => (
                          <tr key={`ct-${i}`} className="border-b border-border/50 last:border-0">
                            <td className="py-1.5 pr-3 font-mono font-medium">{ct.symbol}{ct.name && <span className="ml-1 font-normal text-muted-foreground">{ct.name}</span>}</td>
                            <td className="py-1.5 pr-3 font-mono">{ct.buy_date}</td>
                            <td className={cn("py-1.5 pr-3 font-mono", isNearLimitUp(ct.buy_price, ct.buy_limit_up) && "text-orange-500")} title={isNearLimitUp(ct.buy_price, ct.buy_limit_up) ? `⚠ 接近涨停价 ${ct.buy_limit_up?.toFixed(2)}` : undefined}>{ct.buy_price.toFixed(2)}{isNearLimitUp(ct.buy_price, ct.buy_limit_up) && <span className="ml-0.5 text-[10px]">涨</span>}</td>
                            <td className="py-1.5 pr-3 font-mono">{ct.sell_date}</td>
                            <td className={cn("py-1.5 pr-3 font-mono", isNearLimitDown(ct.sell_price, ct.sell_limit_down) && "text-orange-500")} title={isNearLimitDown(ct.sell_price, ct.sell_limit_down) ? `⚠ 接近跌停价 ${ct.sell_limit_down?.toFixed(2)}` : undefined}>{ct.sell_price.toFixed(2)}{isNearLimitDown(ct.sell_price, ct.sell_limit_down) && <span className="ml-0.5 text-[10px]">跌</span>}</td>
                            <td className="py-1.5 pr-3 font-mono">{ct.qty.toFixed(0)}</td>
                            <td className={`py-1.5 pr-3 font-mono font-medium ${ct.pnl_pct >= 0 ? "text-up" : "text-down"}`}>{ct.pnl_pct >= 0 ? "+" : ""}{ct.pnl_pct.toFixed(2)}%</td>
                            <td className="py-1.5 pr-3 font-mono">{ct.holding_days}天</td>
                            <td className="py-1.5 text-muted-foreground">
                              {labelReason(ct.reason) || labelEvent(ct.source_event) || "—"}
                              {ct.reason?.replace(/_forced$/, "") === "stop_loss" && ct.pnl_pct > 0 && (
                                <span className="ml-1 text-[10px] text-amber-500" title="止损价高于买入价：信号的失效价(invalidation)被触发，但因买入价低于失效价，平仓仍盈利">⚠ 止损价&gt;买入价</span>
                              )}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </CollapsibleSection>
              )}

              {scanSummary?.markdown && (
                <div className="rounded-lg border border-border bg-background">
                  <button onClick={() => setShowMessagePreview(!showMessagePreview)}
                    className="w-full flex items-center gap-2 px-4 py-2.5 text-xs font-medium hover:bg-muted/50 transition-colors">
                    <FileText className="h-3.5 w-3.5 text-blue-400" />
                    <span>飞书消息预览</span>
                    <span className="text-muted-foreground ml-1">(推送的完整内容)</span>
                    {showMessagePreview ? <ChevronDown className="h-3.5 w-3.5 ml-auto text-muted-foreground" /> : <ChevronRight className="h-3.5 w-3.5 ml-auto text-muted-foreground" />}
                  </button>
                  {showMessagePreview && (
                    <div className="px-4 pb-3 border-t border-border pt-3">
                      <pre className="text-xs leading-relaxed whitespace-pre-wrap font-mono text-foreground/90 max-h-80 overflow-y-auto">{scanSummary.markdown}</pre>
                    </div>
                  )}
                </div>
              )}

              {newSignals.length > 0 && (
                <CollapsibleSection title={`新信号 (${newSignals.length})`} open={showNewSignals} onToggle={() => setShowNewSignals(!showNewSignals)} badge="primary">
                  <div className="overflow-x-auto">
                    <table className="w-full text-xs">
                      <thead><tr className="border-b border-border text-left text-muted-foreground">
                        <th className="pb-1.5 pr-3 font-medium">标的</th><th className="pb-1.5 pr-3 font-medium">类型</th>
                        <th className="pb-1.5 pr-3 font-medium">信心</th><th className="pb-1.5 pr-3 font-medium">入场</th>
                        <th className="pb-1.5 pr-3 font-medium">城门价</th><th className="pb-1.5 pr-3 font-medium">止损价</th>
                        <th className="pb-1.5 pr-3 font-medium">板块</th><th className="pb-1.5 pr-3 font-medium">板块共振</th>
                        {viewMode === "strategy" && <th className="pb-1.5 font-medium">交易</th>}
                      </tr></thead>
                      <tbody>
                        {newSignals.slice(newSigPage * PAGE_SIZE, (newSigPage + 1) * PAGE_SIZE).map((s, i) => (
                          <tr key={`${s.symbol}-${s.event_type}-${i}`} className="border-b border-border/50 last:border-0">
                            <td className="py-1.5 pr-3 font-mono font-medium">{s.symbol}{s.name && <span className="ml-1 font-normal text-muted-foreground">{s.name}</span>}</td>
                            <td className="py-1.5 pr-3">{labelEvent(s.event_type)}</td>
                            <td className="py-1.5 pr-3">
                              <span className={cn("font-medium", s.signal_confidence >= 0.78 ? "text-up" : "text-primary")}>{s.signal_confidence.toFixed(2)}</span>
                              <span className="ml-1 text-muted-foreground">{s.signal_confidence >= 0.78 ? "A" : "B"}</span>
                            </td>
                            <td className="py-1.5 pr-3">{labelEntryStyle(s.entry_style)}</td>
                            <td className="py-1.5 pr-3 font-mono">{s.gate_price?.toFixed(2) ?? "—"}</td>
                            <td className="py-1.5 pr-3 font-mono">{s.invalidation_price?.toFixed(2) ?? "—"}</td>
                            <td className="py-1.5 pr-3">{s.theme_label}</td>
                            <td className="py-1.5 pr-3">{formatEnv(s)}</td>
                            {viewMode === "strategy" && (
                              <td className="py-1.5">
                                {s.traded ? <span className="rounded-full px-1.5 py-0.5 text-[10px] font-medium bg-success/20 text-success">已入场</span>
                                  : s.near_gate ? <span className="rounded-full px-1.5 py-0.5 text-[10px] font-medium bg-amber-500/20 text-amber-600">接近城门</span>
                                  : s.blocked_reason ? <span className="text-[10px] text-muted-foreground" title={s.blocked_reason}>等待</span>
                                  : <span className="text-[10px] text-muted-foreground">—</span>}
                              </td>
                            )}
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                  <Pagination page={newSigPage} totalPages={Math.ceil(newSignals.length / PAGE_SIZE)} totalItems={newSignals.length} pageSize={PAGE_SIZE} onPageChange={setNewSigPage} />
                </CollapsibleSection>
              )}

              {watchUpdates.length > 0 && (
                <CollapsibleSection title={`观察中 (${watchUpdates.length})`} open={showWatchUpdates} onToggle={() => setShowWatchUpdates(!showWatchUpdates)} badge="success">
                  <div className="overflow-x-auto">
                    <table className="w-full text-xs">
                      <thead><tr className="border-b border-border text-left text-muted-foreground">
                        <th className="pb-1.5 pr-3 font-medium">标的</th><th className="pb-1.5 pr-3 font-medium">类型</th>
                        <th className="pb-1.5 pr-3 font-medium">信号日</th><th className="pb-1.5 pr-3 font-medium">天数</th>
                        <th className="pb-1.5 pr-3 font-medium">状态</th><th className="pb-1.5 pr-3 font-medium">收益</th>
                        <th className="pb-1.5 pr-3 font-medium">最大收益</th>                        <th className="pb-1.5 pr-3 font-medium">触价</th>
                        <th className="pb-1.5 pr-3 font-medium">备注</th>
                        {viewMode === "strategy" && <th className="pb-1.5 font-medium">交易</th>}
                      </tr></thead>
                      <tbody>
                        {watchUpdates.slice(watchUpPage * PAGE_SIZE, (watchUpPage + 1) * PAGE_SIZE).map((w, i) => (
                          <tr key={`${w.symbol}-${w.event_type}-${i}`} className="border-b border-border/50 last:border-0">
                            <td className="py-1.5 pr-3 font-mono font-medium">{w.symbol}{w.name && <span className="ml-1 font-normal text-muted-foreground">{w.name}</span>}</td>
                            <td className="py-1.5 pr-3">{labelEvent(w.event_type)}</td>
                            <td className="py-1.5 pr-3">{w.signal_date}</td>
                            <td className="py-1.5 pr-3">D+{w.obs_day}</td>
                            <td className="py-1.5 pr-3">
                              <span className={cn("rounded-full px-1.5 py-0.5 text-[10px] font-medium",
                                w.status_label === "Chase Candidate" ? "bg-warning/20 text-warning" :
                                w.status_label.includes("强") ? "bg-success/20 text-success" :
                                w.status_label.includes("弱") ? "bg-destructive/20 text-destructive" :
                                "bg-muted text-muted-foreground"
                              )}>{w.status_label}</span>
                            </td>
                            <td className={cn("py-1.5 pr-3 font-mono", w.close_ret_since_signal >= 0 ? "text-up" : "text-down")}>{prettyPct(w.close_ret_since_signal)}</td>
                            <td className="py-1.5 pr-3 font-mono text-up">{prettyPct(w.max_ret_since_signal)}</td>
                            <td className="py-1.5 pr-3">{w.hunt_touched ? "✓" : "—"}</td>
                            <td className="py-1.5 pr-3 text-muted-foreground">{w.note}</td>
                            {viewMode === "strategy" && (
                              <td className="py-1.5">
                                {w.traded ? <span className="rounded-full px-1.5 py-0.5 text-[10px] font-medium bg-success/20 text-success">已入场</span>
                                  : w.days_to_expiry !== undefined && w.days_to_expiry > 0 ? <span className="text-[10px] text-muted-foreground">剩{w.days_to_expiry}天</span>
                                  : <span className="text-[10px] text-muted-foreground">—</span>}
                              </td>
                            )}
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                  <Pagination page={watchUpPage} totalPages={Math.ceil(watchUpdates.length / PAGE_SIZE)} totalItems={watchUpdates.length} pageSize={PAGE_SIZE} onPageChange={setWatchUpPage} />
                </CollapsibleSection>
              )}

              {droppedItems.length > 0 && (
                <CollapsibleSection title={`已失效 (${droppedItems.length})`} open={showDropped} onToggle={() => setShowDropped(!showDropped)} badge="destructive">
                  <div className="overflow-x-auto">
                    <table className="w-full text-xs">
                      <thead><tr className="border-b border-border text-left text-muted-foreground">
                        <th className="pb-1.5 pr-3 font-medium">标的</th><th className="pb-1.5 pr-3 font-medium">类型</th>
                        <th className="pb-1.5 pr-3 font-medium">信号日</th><th className="pb-1.5 pr-3 font-medium">最终收益</th>
                        <th className="pb-1.5 font-medium">原因</th>
                      </tr></thead>
                      <tbody>
                        {droppedItems.slice(droppedPage * PAGE_SIZE, (droppedPage + 1) * PAGE_SIZE).map((d, i) => (
                          <tr key={`${d.symbol}-${d.event_type}-${i}`} className="border-b border-border/50 last:border-0">
                            <td className="py-1.5 pr-3 font-mono font-medium">{d.symbol}{d.name && <span className="ml-1 font-normal text-muted-foreground">{d.name}</span>}</td>
                            <td className="py-1.5 pr-3">{labelEvent(d.event_type)}</td>
                            <td className="py-1.5 pr-3">{d.signal_date}</td>
                            <td className={cn("py-1.5 pr-3 font-mono", d.close_ret_since_signal >= 0 ? "text-up" : "text-down")}>{prettyPct(d.close_ret_since_signal)}</td>
                            <td className="py-1.5 text-muted-foreground">{d.note}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                  <Pagination page={droppedPage} totalPages={Math.ceil(droppedItems.length / PAGE_SIZE)} totalItems={droppedItems.length} pageSize={PAGE_SIZE} onPageChange={setDroppedPage} />
                </CollapsibleSection>
              )}

              <div className="flex items-center gap-3 pt-1">
                <button onClick={handlePush} disabled={pushing || pushed || !hasFeishuConfig}
                  className={cn("flex items-center gap-2 rounded-lg px-4 py-2 text-sm font-medium transition-colors",
                    pushed ? "bg-success/20 text-success cursor-default"
                      : !hasFeishuConfig ? "bg-muted text-muted-foreground cursor-not-allowed"
                        : "bg-blue-600 text-white hover:bg-blue-700",
                  )}>
                  {pushing ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
                  {pushed ? "已推送" : pushing ? "推送中..." : "推送到飞书"}
                </button>
                {!hasFeishuConfig && <span className="text-xs text-muted-foreground">未配置飞书 Webhook</span>}
                {pushed && scanSummary?.markdown && <span className="text-xs text-success">消息已发送</span>}
              </div>
            </div>
          )}

          {task.status === "failed" && (
            <>
              <p className="text-sm text-destructive mt-2">任务失败 (code {task.return_code})</p>
              <TaskLogPanel logLines={logLines} isRunning={false} />
            </>
          )}
        </div>
      )}

      {/* ════════ Persistent Watch ════════ */}
      <PersistentWatchSection items={watchItems} filter={watchFilter} onFilterChange={setWatchFilter} />
    </div>
  );
}

function StatCard({ value, label, color }: { value: string; label: string; color: string }) {
  return (
    <div className="rounded-lg bg-background border border-border p-3 text-center">
      <div className={cn("text-2xl font-bold tabular-nums", color)}>{value}</div>
      <div className="text-[10px] text-muted-foreground mt-0.5">{label}</div>
    </div>
  );
}

function PoolPreviewPanel({ preview, onClose }: { preview: PoolPreview; onClose: () => void }) {
  const missingSet = new Set(preview.missing_symbols ?? []);
  const missingCount = missingSet.size;
  return (
    <div className="rounded-lg border border-border bg-background p-3">
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center gap-2">
          <span className="text-xs font-medium">{preview.count} 只标的</span>
          {missingCount > 0 && (
            <span className="text-[10px] text-amber-600 dark:text-amber-400">
              ({missingCount} 缺缓存)
            </span>
          )}
        </div>
        <button onClick={onClose} className="text-muted-foreground hover:text-foreground"><X className="h-3.5 w-3.5" /></button>
      </div>
      <div className="max-h-48 overflow-y-auto">
        <table className="w-full text-xs">
          <thead><tr className="border-b border-border text-left text-muted-foreground">
            <th className="pb-1 pr-3 font-medium w-8">#</th><th className="pb-1 pr-3 font-medium">代码</th><th className="pb-1 font-medium">名称</th>
          </tr></thead>
          <tbody>
            {preview.symbols.map((s, i) => {
              const isMissing = missingSet.has(s.symbol);
              return (
                <tr key={s.symbol} className={cn("border-b border-border/30 last:border-0", isMissing && "text-amber-600 dark:text-amber-400")}>
                  <td className="py-0.5 pr-3 text-muted-foreground">{i + 1}</td>
                  <td className="py-0.5 pr-3 font-mono">{s.symbol}</td>
                  <td className={cn("py-0.5", isMissing ? "text-amber-500/70 dark:text-amber-400/70" : "text-muted-foreground")}>{s.name || (isMissing ? "无缓存" : "")}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function CollapsibleSection({ title, defaultOpen = false, open: controlledOpen, onToggle, badge, children }: {
  title: string; defaultOpen?: boolean; open?: boolean; onToggle?: () => void;
  badge: "primary" | "success" | "destructive" | "default"; children: React.ReactNode;
}) {
  const [internalOpen, setInternalOpen] = useState(defaultOpen);
  const isOpen = controlledOpen !== undefined ? controlledOpen : internalOpen;
  const handleToggle = onToggle ?? (() => setInternalOpen(v => !v));
  const badgeClass = badge === "primary" ? "bg-primary/20 text-primary" : badge === "success" ? "bg-success/20 text-success" : badge === "destructive" ? "bg-destructive/20 text-destructive" : "bg-muted text-muted-foreground";
  return (
    <div className="rounded-lg border border-border bg-background">
      <button onClick={handleToggle} className="w-full flex items-center gap-2 px-4 py-2.5 text-xs font-medium hover:bg-muted/50 transition-colors">
        <span className={cn("rounded-full px-2 py-0.5 text-[10px] font-medium", badgeClass)}>{title}</span>
        {isOpen ? <ChevronDown className="h-3.5 w-3.5 ml-auto text-muted-foreground" /> : <ChevronRight className="h-3.5 w-3.5 ml-auto text-muted-foreground" />}
      </button>
      {isOpen && <div className="px-4 pb-3 border-t border-border pt-3">{children}</div>}
    </div>
  );
}

type WatchFilterState = { status: string; type: string; rank: string };

function PersistentWatchSection({ items, filter, onFilterChange }: {
  items: Record<string, unknown>[];
  filter: WatchFilterState;
  onFilterChange: (f: WatchFilterState) => void;
}) {
  const activeItems = useMemo(() => items.filter((i) => i.active !== false), [items]);

  const uniqueStatuses = useMemo(() => [...new Set(activeItems.map((i) => String(i.status_label ?? "")))].filter(Boolean).sort(), [activeItems]);
  const uniqueTypes = useMemo(() => [...new Set(activeItems.map((i) => String(i.event_type ?? "")))].filter(Boolean).sort(), [activeItems]);
  const uniqueRanks = useMemo(() => [...new Set(activeItems.map((i) => String(i.priority_rank ?? "")))].filter(Boolean).sort(), [activeItems]);

  const filtered = useMemo(() => {
    let result = activeItems;
    if (filter.status) result = result.filter((i) => i.status_label === filter.status);
    if (filter.type) result = result.filter((i) => i.event_type === filter.type);
    if (filter.rank) result = result.filter((i) => i.priority_rank === filter.rank);
    return result;
  }, [activeItems, filter]);

  const stats = useMemo(() => {
    if (!filtered.length) return null;
    const rets = filtered.map((i) => Number(i.close_ret_since_signal ?? 0));
    const maxRets = filtered.map((i) => Number(i.max_ret_since_signal ?? 0));
    const days = filtered.map((i) => Number(i.obs_day ?? 0));
    const winCount = rets.filter((r) => r > 0).length;
    const avg = (arr: number[]) => arr.reduce((a, b) => a + b, 0) / arr.length;
    return {
      total: filtered.length,
      winRate: winCount / filtered.length,
      avgRet: avg(rets),
      avgMaxRet: avg(maxRets),
      avgDays: avg(days),
      huntRate: filtered.filter((i) => i.hunt_touched).length / filtered.length,
    };
  }, [filtered]);

  const hasFilter = filter.status || filter.type || filter.rank;

  return (
    <div className="rounded-xl border border-border bg-card p-5 space-y-3">
      <div className="flex items-center gap-3 mb-1">
        <h2 className="text-sm font-semibold">信号观察池</h2>
        <span className="text-[10px] text-muted-foreground bg-muted rounded-full px-2 py-0.5">
          {activeItems.length} 活跃
        </span>
      </div>
      <p className="text-[10px] text-muted-foreground">所有信号的完整生命周期追踪。飞书推送仅发送每日摘要，此表为跨次运行的持久化全量状态。</p>

      {/* Filter chips */}
      {activeItems.length > 0 && (
        <div className="flex flex-wrap items-center gap-2">
          <Filter className="h-3 w-3 text-muted-foreground" />
          <FilterChipGroup label="状态" options={uniqueStatuses} value={filter.status} onChange={(v) => onFilterChange({ ...filter, status: v })} />
          <FilterChipGroup label="类型" options={uniqueTypes} value={filter.type} onChange={(v) => onFilterChange({ ...filter, type: v })} labelFn={labelEvent} />
          <FilterChipGroup label="等级" options={uniqueRanks} value={filter.rank} onChange={(v) => onFilterChange({ ...filter, rank: v })} />
          {hasFilter && (
            <button onClick={() => onFilterChange({ status: "", type: "", rank: "" })} className="text-[10px] text-muted-foreground hover:text-foreground underline">
              清除筛选
            </button>
          )}
        </div>
      )}

      {/* Stats bar */}
      {stats && (
        <div className="flex gap-4 rounded-lg bg-muted/50 border border-border px-4 py-2">
          <MiniStat label="数量" value={String(stats.total)} />
          <MiniStat label="胜率" value={`${(stats.winRate * 100).toFixed(0)}%`} color={stats.winRate >= 0.5 ? "text-up" : "text-down"} />
          <MiniStat label="平均收益" value={prettyPct(stats.avgRet)} color={stats.avgRet >= 0 ? "text-up" : "text-down"} />
          <MiniStat label="平均最大" value={prettyPct(stats.avgMaxRet)} color="text-up" />
          <MiniStat label="平均天数" value={`D+${stats.avgDays.toFixed(1)}`} />
          <MiniStat label="触价率" value={`${(stats.huntRate * 100).toFixed(0)}%`} />
        </div>
      )}

      <WatchStateTable items={filtered as never[]} />
    </div>
  );
}

function FilterChipGroup({ label, options, value, onChange, labelFn }: {
  label: string; options: string[]; value: string; onChange: (v: string) => void; labelFn?: (v: string) => string;
}) {
  if (options.length <= 1) return null;
  return (
    <div className="flex items-center gap-1">
      <span className="text-[10px] text-muted-foreground mr-0.5">{label}:</span>
      {options.map((opt) => (
        <button
          key={opt}
          onClick={() => onChange(value === opt ? "" : opt)}
          className={cn(
            "rounded-full px-2 py-0.5 text-[10px] font-medium transition-all",
            value === opt ? "bg-primary text-primary-foreground shadow-sm" : "bg-muted text-muted-foreground hover:bg-accent",
          )}
        >
          {labelFn ? labelFn(opt) : opt}
        </button>
      ))}
    </div>
  );
}

function MiniStat({ label, value, color }: { label: string; value: string; color?: string }) {
  return (
    <div className="text-center">
      <div className={cn("text-xs font-semibold tabular-nums", color)}>{value}</div>
      <div className="text-[9px] text-muted-foreground">{label}</div>
    </div>
  );
}
