import { AlertTriangle, ChevronDown, Copy, Eye, Loader2, Play, RefreshCcw, RotateCcw, Save, Settings2, Trash2, X } from "lucide-react";
import { useCallback, useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import { EquityChart } from "../components/EquityChart";
import { SavePoolDialog } from "../components/SavePoolDialog";
import { TaskLogPanel } from "../components/TaskLogPanel";
import { TradesTable } from "../components/TradesTable";
import { useApi } from "../hooks/useApi";
import { useTaskPoller } from "../hooks/useTaskPoller";
import { api, type ConsistencyCheckResult, type EquityPoint, type PoolPreview, type TaskRecord } from "../lib/api";
import { cn, parseSymbols } from "../lib/utils";

/* ═══════════════════ constants ═══════════════════ */

const ENTRY_PROFILES: { value: string; label: string; desc: string }[] = [
  { value: "day_level_ideal", label: "当天精确价", desc: "当日收盘价成交，理论上限" },
  { value: "next_open_realistic", label: "次日开盘", desc: "次日开盘价市价成交" },
  { value: "delayed_limit_hunt", label: "挂单猎手", desc: "次日起限价单等待成交" },
];


const SAMPLINGS = ["random", "head"] as const;
type PoolMode = "named" | "random" | "custom";
type DateMode = "year" | "custom";

const ALL_YEARS = [2019, 2020, 2021, 2022, 2023, 2024, 2025, 2026];

const MATURITY: Record<string, { tag: string; cls: string }> = {
  stable: { tag: "成熟", cls: "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400" },
  usable: { tag: "可用", cls: "bg-blue-500/15 text-blue-600 dark:text-blue-400" },
  draft:  { tag: "初版", cls: "bg-amber-500/15 text-amber-600 dark:text-amber-400" },
};

const SIGNAL_MODELS: { key: string; label: string; desc: string; maturity: string }[] = [
  { key: "escape",       label: "逃命长枪", desc: "高位冲板失败 + 放量收弱，回避信号",         maturity: "usable" },
  { key: "post_limit",   label: "板后长枪", desc: "涨停后出枪，量能张扬又含蓄",               maturity: "stable" },
  { key: "failed_board",label: "烂板长枪", desc: "炸板日出枪，双枪切点做城门",               maturity: "stable" },
  { key: "trend_spear",  label: "趋势长枪", desc: "趋势多枪共振，末枪量能收敛",               maturity: "stable" },
  { key: "attack",       label: "进攻长枪", desc: "涨停后延续，末枪缩量确认",                 maturity: "usable" },
  { key: "arb",          label: "套利长枪", desc: "高振幅 + 板后短线套利",                    maturity: "draft"  },
  { key: "youzi",        label: "游资长枪", desc: "游资活跃标的，主题同行确认",               maturity: "usable" },
  { key: "sector_spear", label: "板块长枪", desc: "板块热度选股，量能确认或触板",             maturity: "usable" },
];

const POS_MULT_FIELDS: { key: string; model: string; default_: number }[] = [
  { key: "trend_spear_pos_mult",  model: "trend_spear",  default_: 1.00 },
  { key: "post_limit_pos_mult",   model: "post_limit",   default_: 0.90 },
  { key: "failed_board_pos_mult", model: "failed_board",  default_: 0.85 },
  { key: "youzi_pos_mult",        model: "youzi",         default_: 0.75 },
  { key: "sector_spear_pos_mult", model: "sector_spear",  default_: 0.70 },
  { key: "attack_pos_mult",       model: "attack",        default_: 0.55 },
  { key: "arb_pos_mult",          model: "arb",           default_: 0.35 },
];

/* ═══════════════════ component ═══════════════════ */

export function BacktestLauncher() {
  const { data: pools, refetch: refetchPools } = useApi(() => api.pools(), []);

  const [dateMode, setDateMode] = useState<DateMode>("year");
  const [startYear, setStartYear] = useState(2024);
  const [endYear, setEndYear] = useState(2024);
  const [customStart, setCustomStart] = useState("2024-01-01");
  const [customEnd, setCustomEnd] = useState("2024-12-31");
  const effectiveStart = dateMode === "year" ? `${startYear}-01-01` : customStart;
  const effectiveEnd   = dateMode === "year" ? `${endYear}-12-31`   : customEnd;

  const [profile, setProfile] = useState("day_level_ideal");
  const [initCash, setInitCash] = useState(1_000_000);

  const [poolMode, setPoolMode] = useState<PoolMode>("random");
  const [pool, setPool] = useState(300);
  const [poolSampling, setPoolSampling] = useState<string>("random");
  const [poolSeed, setPoolSeed] = useState(42);
  const [poolName, setPoolName] = useState("");
  const [symbolsRaw, setSymbolsRaw] = useState("");

  const [maxPositions, setMaxPositions] = useState(4);
  const [basePosPct, setBasePosPct] = useState(0.25);
  const [cooldownDays, setCooldownDays] = useState(3);
  const [takeProfitPct, setTakeProfitPct] = useState(0.18);
  const [huntBuffer, setHuntBuffer] = useState(0.005);
  const [huntDays, setHuntDays] = useState(3);


  const [enabledModels, setEnabledModels] = useState<Set<string>>(new Set(SIGNAL_MODELS.map(m => m.key)));
  const [posMults, setPosMults] = useState<Record<string, number>>(
    Object.fromEntries(POS_MULT_FIELDS.map(f => [f.key, f.default_]))
  );

  const [warmupBars, setWarmupBars] = useState(600);
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [cacheOnly, setCacheOnly] = useState(false);
  const [showProgress, setShowProgress] = useState(false);
  const [disableEnvMapping, setDisableEnvMapping] = useState(false);

  const [taskId, setTaskId] = useState<string | null>(() => sessionStorage.getItem("bt_task_id"));
  const { task, logLines } = useTaskPoller(taskId);
  const [equityCurve, setEquityCurve] = useState<EquityPoint[]>([]);
  const [trades, setTrades] = useState<Record<string, unknown>[]>([]);
  const [tradesCols, setTradesCols] = useState<string[]>([]);
  const [tradesSource, setTradesSource] = useState("");
  const [preview, setPreview] = useState<PoolPreview | null>(null);
  const [previewLoading, setPreviewLoading] = useState(false);
  const [showSavePool, setShowSavePool] = useState(false);

  const [dataStatus, setDataStatus] = useState<{ total_symbols: number; cached: number; missing: number; missing_symbols?: string[]; coverage_pct: number; est_download_seconds: number; needs_migration?: boolean } | null>(null);
  const [dataChecking, setDataChecking] = useState(false);
  const [dataPreparing, setDataPreparing] = useState(false);

  const [cacheCheck, setCacheCheck] = useState<ConsistencyCheckResult | null>(null);
  const [cacheCheckLoading, setCacheCheckLoading] = useState(false);
  const [cacheRefreshing, setCacheRefreshing] = useState(false);

  const handleCacheCheck = useCallback(async () => {
    setCacheCheckLoading(true);
    try {
      const r = await api.consistencyCheck({ sample_size: 20 });
      setCacheCheck(r);
    } catch { /* ignore */ }
    finally { setCacheCheckLoading(false); }
  }, []);

  const handleCacheRefresh = useCallback(async () => {
    setCacheRefreshing(true);
    try {
      await api.fullRefresh({});
      toast.success("全量刷新任务已创建");
    } catch { /* ignore */ }
    finally { setCacheRefreshing(false); }
  }, []);

  const isRunning = task?.status === "running" || task?.status === "pending";
  const autoLoaded = useRef(false);
  const configSynced = useRef(false);

  useEffect(() => {
    if (taskId) sessionStorage.setItem("bt_task_id", taskId);
    else { sessionStorage.removeItem("bt_task_id"); autoLoaded.current = false; configSynced.current = false; }
  }, [taskId]);

  useEffect(() => {
    const pending = sessionStorage.getItem("bt_apply_config");
    if (pending) {
      sessionStorage.removeItem("bt_apply_config");
      try { applyConfig(JSON.parse(pending)); } catch { /* malformed */ }
    }
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    if (!task) return;
    if (!configSynced.current && task.payload) {
      configSynced.current = true;
      applyConfig(task.payload, true);
    }
    if (task.status === "succeeded" && task.output_dir && equityCurve.length === 0 && !autoLoaded.current) {
      autoLoaded.current = true;
      handleLoadResults(task);
    }
    if (task.kind === "data_prepare" && (task.status === "succeeded" || task.status === "failed")) {
      checkDataStatus();
    }
  }, [task?.status, task?.id]); // eslint-disable-line react-hooks/exhaustive-deps

  function handleYearClick(y: number) {
    setDateMode("year");
    if (startYear === endYear) {
      if (y === startYear) return;
      setStartYear(Math.min(startYear, y));
      setEndYear(Math.max(startYear, y));
    } else {
      setStartYear(y);
      setEndYear(y);
    }
  }

  function applyConfig(cfg: Record<string, unknown>, silent = false) {
    const s = String(cfg.start ?? ""), e = String(cfg.end ?? "");
    const sMatch = s.match(/^(\d{4})-01-0[12]$/), eMatch = e.match(/^(\d{4})-12-31$/);
    if (sMatch && eMatch) {
      setDateMode("year"); setStartYear(+sMatch[1]); setEndYear(+eMatch[1]);
    } else {
      setDateMode("custom"); setCustomStart(s); setCustomEnd(e);
    }
    setProfile(String(cfg.execution_profile ?? "day_level_ideal"));
    setInitCash(Number(cfg.init_cash ?? 1_000_000));
    setMaxPositions(Number(cfg.max_positions ?? 4));
    setBasePosPct(Number(cfg.base_pos_pct ?? 0.25));
    setCooldownDays(Number(cfg.cooldown_days ?? 3));
    setTakeProfitPct(Number(cfg.take_profit_pct ?? 0.18));
    setHuntBuffer(Number(cfg.hunt_price_buffer_pct ?? 0.005));
    setHuntDays(Number(cfg.hunt_window_days ?? 3));
    setWarmupBars(Number(cfg.warmup_bars ?? 600));
    setCacheOnly(Boolean(cfg.mootdx_cache_only));
    setShowProgress(Boolean(cfg.show_progress));
    setDisableEnvMapping(Boolean(cfg.disable_env_mapping));
    if (cfg.pool_name) { setPoolMode("named"); setPoolName(String(cfg.pool_name)); }
    else if (Array.isArray(cfg.symbols) && cfg.symbols.length > 0) { setPoolMode("custom"); setSymbolsRaw((cfg.symbols as string[]).join(", ")); }
    else { setPoolMode("random"); setPool(Number(cfg.pool ?? 300)); setPoolSampling(String(cfg.pool_sampling ?? "random")); setPoolSeed(Number(cfg.pool_seed ?? 42)); }
    if (Array.isArray(cfg.enable_events) && cfg.enable_events.length > 0) setEnabledModels(new Set(cfg.enable_events as string[]));
    else setEnabledModels(new Set(SIGNAL_MODELS.map(m => m.key)));
    const nm = Object.fromEntries(POS_MULT_FIELDS.map(f => [f.key, f.default_]));
    for (const f of POS_MULT_FIELDS) { if (f.key in cfg) nm[f.key] = Number(cfg[f.key]); }
    setPosMults(nm);
    if (!silent) toast.success("配置已应用到表单");
  }

  async function handlePreview() {
    setPreviewLoading(true);
    try {
      setPreview(await api.poolPreview(pool, poolSampling, poolSeed, poolMode === "named" ? poolName : undefined));
    } catch (e: unknown) { toast.error(String(e)); }
    finally { setPreviewLoading(false); }
  }

  async function checkDataStatus() {
    setDataChecking(true);
    try {
      const params: Record<string, unknown> = {};
      if (poolMode === "named" && poolName) params.pool_name = poolName;
      else { params.pool_size = pool; params.pool_sampling = poolSampling; params.pool_seed = poolSeed; }
      const status = await api.dataStatus(params as Parameters<typeof api.dataStatus>[0]);
      setDataStatus(status);
    } catch { /* ignore */ }
    finally { setDataChecking(false); }
  }

  async function handleDataPrepare() {
    setDataPreparing(true);
    try {
      const payload: Record<string, unknown> = { end_date: effectiveEnd };
      if (poolMode === "named" && poolName) payload.pool_name = poolName;
      else { payload.pool_size = pool; payload.pool_sampling = poolSampling; payload.pool_seed = poolSeed; }
      const res = await api.dataPrepare(payload);
      toast.success(`数据准备已启动 (${res.total_symbols} 只标的)`);
      setTaskId(res.task_id);
    } catch (e: unknown) { toast.error(String(e)); }
    finally { setDataPreparing(false); }
  }

  useEffect(() => {
    if (poolMode === "custom") { setDataStatus(null); return; }
    const timer = setTimeout(() => { checkDataStatus(); }, 500);
    return () => clearTimeout(timer);
  }, [poolMode, pool, poolSampling, poolSeed, poolName]); // eslint-disable-line react-hooks/exhaustive-deps

  async function handleSubmit() {
    if (poolMode === "named" && !poolName) { toast.error("请选择一个标的池"); return; }
    if (poolMode === "custom" && !symbolsRaw.trim()) { toast.error("请输入至少一个股票代码"); return; }
    try {
      const enabledList = [...enabledModels];
      const payload: Record<string, unknown> = {
        start: effectiveStart, end: effectiveEnd,
        pool: poolMode === "random" ? pool : 9999,
        pool_sampling: poolSampling, pool_seed: poolSeed,
        execution_profile: profile,
        hunt_price_buffer_pct: huntBuffer, hunt_window_days: huntDays,
        exit_mode: "ideal",
        init_cash: initCash, output_dir: "",
        max_positions: maxPositions, base_pos_pct: basePosPct,
        cooldown_days: cooldownDays, take_profit_pct: takeProfitPct,
        warmup_bars: warmupBars,
        mootdx_cache_only: cacheOnly, show_progress: showProgress, disable_env_mapping: disableEnvMapping,
        ...posMults,
      };
      if (enabledList.length < SIGNAL_MODELS.length) payload.enable_events = enabledList;
      if (poolMode === "named") payload.pool_name = poolName;
      if (poolMode === "custom") payload.symbols = parseSymbols(symbolsRaw);
      const t = await api.createBacktest(payload);
      configSynced.current = true; autoLoaded.current = false;
      setTaskId(t.id); setEquityCurve([]); setTrades([]);
      toast.success("回测已启动");
    } catch (e: unknown) { toast.error(String(e)); }
  }

  async function handleLoadResults(t: TaskRecord) {
    try {
      const name = t.output_dir.split("/").pop() ?? "";
      const [eq, tr] = await Promise.all([api.equityCurve(name), api.trades(name)]);
      setEquityCurve(eq); setTrades(tr.rows); setTradesCols(tr.columns ?? []); setTradesSource(tr.source ?? "");
    } catch { toast.error("加载回测结果失败"); }
  }

  if (task?.status === "succeeded" && task.output_dir && equityCurve.length === 0) handleLoadResults(task);

  const profileObj = ENTRY_PROFILES.find(p => p.value === profile);
  const dateLabel = dateMode === "year"
    ? (startYear === endYear ? `${startYear}` : `${startYear}–${endYear}`)
    : `${customStart} — ${customEnd}`;
  const poolLabel = poolMode === "named"
    ? (poolName || "未选择")
    : poolMode === "custom"
      ? `${parseSymbols(symbolsRaw).length} 只自定义`
      : `${pool} ${poolSampling === "random" ? "随机" : "顺序"} seed=${poolSeed}`;

  return (
    <div className="p-6 max-w-[1200px] mx-auto">
      {/* header */}
      <div className="mb-5">
        <h1 className="text-xl font-bold tracking-tight">回测配置</h1>
        <p className="text-muted-foreground text-sm mt-0.5">配置策略参数，运行历史回测验证</p>
      </div>

      {profile === "day_level_ideal" && (
        <div className="rounded-lg border border-warning/40 bg-warning/5 px-3 py-2 flex items-center gap-2 mb-4">
          <AlertTriangle className="h-4 w-4 text-warning shrink-0" />
          <p className="text-xs"><strong>当日收盘模式</strong><span className="text-muted-foreground"> — 理论上限，实盘不可实现</span></p>
        </div>
      )}

      <div className="flex gap-5 items-start">
        {/* ═══════════ LEFT ═══════════ */}
        <div className="flex-1 min-w-0 space-y-4">

          {/* ── Year range bar ── */}
          <div className="rounded-lg border border-border bg-card px-4 py-3">
            <div className="flex items-center justify-between mb-2.5">
              <h2 className="text-xs font-semibold">回测区间</h2>
              <button onClick={() => { setDateMode(dateMode === "custom" ? "year" : "custom"); }}
                className="text-[11px] text-primary hover:underline">
                {dateMode === "year" ? "精确日期 →" : "← 按年选择"}
              </button>
            </div>

            {dateMode === "year" ? (
              <div>
                <div className="inline-flex rounded-lg bg-muted/60 p-[3px]">
                  {ALL_YEARS.map(y => {
                    const inRange = y >= startYear && y <= endYear;
                    const isStart = y === startYear;
                    const isEnd = y === endYear;
                    const isSingle = startYear === endYear;
                    return (
                      <button key={y} onClick={() => handleYearClick(y)}
                        className={cn(
                          "relative px-3.5 py-1 text-xs font-medium transition-all",
                          inRange
                            ? "bg-primary text-primary-foreground shadow-sm"
                            : "text-muted-foreground hover:text-foreground",
                          isSingle && inRange && "rounded-md",
                          !isSingle && isStart && "rounded-l-md",
                          !isSingle && isEnd && "rounded-r-md",
                        )}>
                        {y}
                      </button>
                    );
                  })}
                </div>
                <p className="text-[11px] text-muted-foreground mt-1.5 tabular-nums">
                  {effectiveStart} 至 {effectiveEnd}
                  {startYear !== endYear && ` · ${endYear - startYear + 1}年`}
                  <span className="text-muted-foreground/50 ml-2">点击单年，再点另一年选范围</span>
                </p>
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <input type="date" value={customStart} onChange={(e) => setCustomStart(e.target.value)} className="input-field w-[140px] text-xs" />
                <span className="text-xs text-muted-foreground">至</span>
                <input type="date" value={customEnd} onChange={(e) => setCustomEnd(e.target.value)} className="input-field w-[140px] text-xs" />
              </div>
            )}
          </div>

          {/* ── Execution ── */}
          <div className="rounded-lg border border-border bg-card px-4 py-3">
            <div className="flex items-center justify-between mb-3">
              <h2 className="text-xs font-semibold">执行模式</h2>
              <div className="flex items-center gap-1.5">
                <span className="text-xs text-muted-foreground">初始资金</span>
                <input type="number" value={initCash} onChange={(e) => setInitCash(+e.target.value)} className="input-field w-28 tabular-nums text-xs" />
              </div>
            </div>
            <div className="grid grid-cols-[60px_1fr] gap-y-2.5 items-start">
              {/* ── Entry row ── */}
              <span className="text-[10px] font-medium text-muted-foreground uppercase tracking-wide pt-1">入场</span>
              <div>
                <div className="inline-flex rounded-lg border border-border overflow-hidden">
                  {ENTRY_PROFILES.map((p) => (
                    <button key={p.value} onClick={() => setProfile(p.value)}
                      className={cn(
                        "px-3 py-1 text-[11px] font-medium transition-all border-r border-border last:border-r-0 whitespace-nowrap",
                        profile === p.value ? "bg-primary/10 text-primary" : "text-muted-foreground hover:bg-muted/50",
                      )}>
                      {p.label}
                    </button>
                  ))}
                </div>
                <span className="text-[10px] text-muted-foreground ml-2.5">{profileObj?.desc}</span>
                {profile === "delayed_limit_hunt" && (
                  <div className="flex items-center gap-3 mt-1.5">
                    <div className="flex items-center gap-1.5">
                      <span className="text-[11px] text-muted-foreground">缓冲</span>
                      <UnitInput unit="%" className="w-16">
                        <input type="number" step={0.1} min={0} max={10} value={+(huntBuffer * 100).toFixed(1)} onChange={(e) => setHuntBuffer(+e.target.value / 100)} className="input-field w-full tabular-nums text-right" />
                      </UnitInput>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <span className="text-[11px] text-muted-foreground">窗口</span>
                      <UnitInput unit="天" className="w-14">
                        <input type="number" min={1} max={10} value={huntDays} onChange={(e) => setHuntDays(+e.target.value)} className="input-field w-full tabular-nums text-right" />
                      </UnitInput>
                    </div>
                  </div>
                )}
              </div>
              {/* ── Exit row (hidden — always "ideal") ── */}
            </div>
          </div>

          {/* ── Pool ── */}
          <div className="rounded-lg border border-border bg-card px-4 py-3">
            <h2 className="text-xs font-semibold mb-2.5">标的池</h2>
            <div className="flex gap-1.5 mb-2.5">
              {(["random", "named", "custom"] as PoolMode[]).map((m) => (
                <button key={m} onClick={() => { setPoolMode(m); setPreview(null); }}
                  className={cn("rounded-full px-3 py-0.5 text-xs font-medium transition-all",
                    poolMode === m ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground hover:bg-accent")}>
                  {m === "random" ? "随机抽样" : m === "named" ? "命名池" : "自定义"}
                </button>
              ))}
            </div>

            {poolMode === "random" && (
              <div className="space-y-2">
                <div className="flex items-center gap-4">
                  <div className="flex items-center gap-1.5">
                    <span className="text-xs text-muted-foreground">数量</span>
                    <input type="number" min={1} value={pool} onChange={(e) => setPool(+e.target.value)} className="input-field w-[68px] tabular-nums text-xs" />
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span className="text-xs text-muted-foreground">方式</span>
                    <select value={poolSampling} onChange={(e) => setPoolSampling(e.target.value)} className="input-field w-20 text-xs">
                      {SAMPLINGS.map((s) => (<option key={s} value={s}>{s === "random" ? "随机" : "顺序"}</option>))}
                    </select>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span className="text-xs text-muted-foreground">种子</span>
                    <input type="number" value={poolSeed} onChange={(e) => setPoolSeed(+e.target.value)} className="input-field w-[68px] tabular-nums text-xs" />
                  </div>
                  <button onClick={handlePreview} disabled={previewLoading}
                    className="flex items-center gap-1 text-xs font-medium text-primary hover:text-primary/80 transition-colors ml-auto">
                    {previewLoading ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Eye className="h-3.5 w-3.5" />}预览
                  </button>
                </div>
                {preview && <PoolPreviewPanel preview={preview} onClose={() => setPreview(null)} />}
              </div>
            )}
            {poolMode === "named" && (
              <div className="space-y-1.5">
                <div className="flex items-center gap-2">
                  <select value={poolName} onChange={(e) => setPoolName(e.target.value)} className="input-field max-w-xs text-xs">
                    <option value="">— 选择 —</option>
                    {(pools ?? []).map((p) => (<option key={p.name} value={p.name}>{p.label} ({p.symbol_count}){!p.builtin ? " ★" : ""}</option>))}
                  </select>
                  {poolName && (
                    <button onClick={handlePreview} disabled={previewLoading}
                      className="flex items-center gap-1 text-xs font-medium text-primary hover:text-primary/80 transition-colors">
                      {previewLoading ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Eye className="h-3.5 w-3.5" />}预览
                    </button>
                  )}
                  {poolName && !(pools ?? []).find((p) => p.name === poolName)?.builtin && (
                    <button onClick={async () => { if (!confirm(`删除「${poolName}」?`)) return; try { await api.deletePool(poolName); setPoolName(""); refetchPools(); } catch (e: unknown) { toast.error(String(e)); }}}
                      className="flex items-center gap-0.5 text-xs text-destructive hover:text-destructive/80"><Trash2 className="h-3.5 w-3.5" />删除</button>
                  )}
                </div>
                {preview && <PoolPreviewPanel preview={preview} onClose={() => setPreview(null)} />}
              </div>
            )}
            {poolMode === "custom" && (
              <div className="space-y-1.5">
                <textarea rows={2} value={symbolsRaw} onChange={(e) => setSymbolsRaw(e.target.value)}
                  placeholder="000001, 600519, 300750 ..." className="input-field max-w-md resize-none font-mono text-xs" />
                {symbolsRaw.trim() && (
                  <div className="flex items-center gap-3 text-xs">
                    <span className="text-muted-foreground">{parseSymbols(symbolsRaw).length} 只</span>
                    <button onClick={() => setShowSavePool(true)} className="flex items-center gap-0.5 font-medium text-primary hover:text-primary/80"><Save className="h-3 w-3" />保存为池</button>
                  </div>
                )}
                {showSavePool && symbolsRaw.trim() && <SavePoolDialog symbols={parseSymbols(symbolsRaw)} onSaved={() => refetchPools()} onClose={() => setShowSavePool(false)} />}
              </div>
            )}

            {/* Data cache status */}
            {dataStatus && poolMode !== "custom" && (
              <div className={cn(
                "mt-2.5 flex items-center gap-2 rounded-md px-3 py-1.5 text-xs",
                dataStatus.missing === 0 ? "bg-emerald-500/10 text-emerald-700 dark:text-emerald-400" : "bg-amber-500/10 text-amber-700 dark:text-amber-400",
              )}>
                {dataChecking ? (
                  <Loader2 className="h-3 w-3 animate-spin" />
                ) : dataStatus.missing === 0 ? (
                  <>
                    <div className="h-1.5 w-1.5 rounded-full bg-emerald-500" />
                    <span>缓存就绪 — {dataStatus.cached}/{dataStatus.total_symbols} 只标的已缓存</span>
                    <button onClick={checkDataStatus} disabled={dataChecking} className="shrink-0 p-0.5 rounded text-muted-foreground hover:text-foreground transition-colors disabled:opacity-50" title="刷新缓存状态">
                      <RefreshCcw className="h-3 w-3" />
                    </button>
                    {!cacheCheck && (
                      <button
                        onClick={handleCacheCheck}
                        disabled={cacheCheckLoading}
                        className="ml-auto shrink-0 inline-flex items-center gap-1 rounded px-2 py-0.5 text-[11px] font-medium text-muted-foreground hover:text-foreground transition-colors disabled:opacity-50"
                      >
                        {cacheCheckLoading ? <Loader2 className="h-3 w-3 animate-spin" /> : null}
                        检查复权一致性
                      </button>
                    )}
                  </>
                ) : (
                  <>
                    <AlertTriangle className="h-3.5 w-3.5 shrink-0" />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <span>缺少 {dataStatus.missing}/{dataStatus.total_symbols} 只标的的本地数据，首次下载约 {dataStatus.est_download_seconds > 60 ? `${Math.ceil(dataStatus.est_download_seconds / 60)} 分钟` : `${dataStatus.est_download_seconds} 秒`}</span>
                        <button
                          onClick={handleDataPrepare}
                          disabled={dataPreparing || isRunning}
                          className="ml-auto shrink-0 inline-flex items-center gap-1 rounded px-2 py-0.5 text-[11px] font-medium bg-primary/10 text-primary hover:bg-primary/20 transition-colors disabled:opacity-50"
                        >
                          {dataPreparing ? <Loader2 className="h-3 w-3 animate-spin" /> : <Play className="h-3 w-3" />}
                          准备数据
                        </button>
                      </div>
                      {dataStatus.missing_symbols && dataStatus.missing_symbols.length > 0 && (
                        <details className="mt-1">
                          <summary className="cursor-pointer text-[10px] text-muted-foreground hover:text-foreground">
                            查看缺失标的 ({dataStatus.missing_symbols.length}{dataStatus.missing > dataStatus.missing_symbols.length ? `/${dataStatus.missing}` : ""})
                          </summary>
                          <p className="mt-0.5 text-[10px] text-muted-foreground font-mono leading-relaxed break-all">
                            {dataStatus.missing_symbols.join(", ")}
                          </p>
                        </details>
                      )}
                    </div>
                  </>
                )}
              </div>
            )}

            {/* Cache consistency warning */}
            {cacheCheck && cacheCheck.inconsistent > 0 && (
              <div className="mt-2 rounded-md bg-amber-500/10 border border-amber-500/20 px-3 py-2 text-xs space-y-1.5">
                <div className="flex items-center gap-2 text-amber-700 dark:text-amber-400">
                  <AlertTriangle className="h-3.5 w-3.5 shrink-0" />
                  <span className="font-medium">
                    检测到 {cacheCheck.inconsistent} 只标的复权因子已变化，建议先刷新缓存再跑回测
                  </span>
                  <button
                    onClick={handleCacheRefresh}
                    disabled={cacheRefreshing}
                    className="ml-auto shrink-0 inline-flex items-center gap-1 rounded px-2 py-0.5 text-[11px] font-medium bg-amber-500/10 hover:bg-amber-500/20 transition-colors disabled:opacity-50"
                  >
                    {cacheRefreshing ? <Loader2 className="h-3 w-3 animate-spin" /> : <RefreshCcw className="h-3 w-3" />}
                    全量刷新
                  </button>
                </div>
                <div className="flex flex-wrap gap-1">
                  {cacheCheck.inconsistent_symbols.map((s) => (
                    <span key={s.symbol} className="rounded bg-amber-500/10 px-1.5 py-0.5 text-[10px] font-mono">
                      {s.symbol} <span className="opacity-60">{s.max_deviation_pct.toFixed(1)}%</span>
                    </span>
                  ))}
                </div>
              </div>
            )}
            {cacheCheck && cacheCheck.inconsistent === 0 && (
              <div className="mt-2 flex items-center gap-1.5 rounded-md bg-emerald-500/10 px-3 py-1.5 text-xs text-emerald-700 dark:text-emerald-400">
                <div className="h-1.5 w-1.5 rounded-full bg-emerald-500" />
                复权数据一致 — 抽检 {cacheCheck.checked} 只标的均正常
              </div>
            )}

            {/* Migration warning: cache built before qfq fix */}
            {dataStatus?.needs_migration && !cacheCheck && (
              <div className="mt-2 rounded-md bg-amber-500/10 border border-amber-500/20 px-3 py-2 text-xs">
                <div className="flex items-center gap-2 text-amber-700 dark:text-amber-400">
                  <AlertTriangle className="h-3.5 w-3.5 shrink-0" />
                  <span className="font-medium">
                    缓存可能包含不复权/混合复权数据，建议全量刷新以确保前复权一致性
                  </span>
                  <button
                    onClick={handleCacheRefresh}
                    disabled={cacheRefreshing}
                    className="ml-auto shrink-0 inline-flex items-center gap-1 rounded px-2 py-0.5 text-[11px] font-medium bg-amber-500/10 hover:bg-amber-500/20 transition-colors disabled:opacity-50"
                  >
                    {cacheRefreshing ? <Loader2 className="h-3 w-3 animate-spin" /> : <RefreshCcw className="h-3 w-3" />}
                    全量刷新
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* ── Position + Models: side by side ── */}
          <div className="flex gap-4">
            {/* Left: 仓位 & 风控 */}
            <div className="w-52 shrink-0 rounded-lg border border-border bg-card px-4 py-3">
              <h2 className="text-xs font-semibold mb-3">仓位 & 风控</h2>
              <div className="space-y-2.5">
                <Field label="最大持仓">
                  <input type="number" min={1} max={20} value={maxPositions} onChange={(e) => setMaxPositions(+e.target.value)} className="input-field w-20 tabular-nums text-right" />
                </Field>
                <Field label="基础仓位">
                  <UnitInput unit="%" className="w-20">
                    <input type="number" step={1} min={5} max={100} value={Math.round(basePosPct * 100)} onChange={(e) => setBasePosPct(+e.target.value / 100)} className="input-field w-full tabular-nums text-right" />
                  </UnitInput>
                </Field>
                <Field label="默认止盈">
                  <UnitInput unit="%" className="w-20">
                    <input type="number" step={1} min={0} max={100} value={Math.round(takeProfitPct * 100)} onChange={(e) => setTakeProfitPct(+e.target.value / 100)} className="input-field w-full tabular-nums text-right" />
                  </UnitInput>
                </Field>
                <Field label="冷却天数">
                  <UnitInput unit="天" className="w-20">
                    <input type="number" min={0} max={30} value={cooldownDays} onChange={(e) => setCooldownDays(+e.target.value)} className="input-field w-full tabular-nums text-right" />
                  </UnitInput>
                </Field>
              </div>
            </div>

            {/* Right: 信号模型 */}
            <div className="flex-1 min-w-0 rounded-lg border border-border bg-card px-4 py-3">
              <div className="flex items-center justify-between mb-2.5">
                <h2 className="text-xs font-semibold">信号模型</h2>
                <div className="flex items-center gap-2 text-[11px]">
                  <button onClick={() => setEnabledModels(new Set(SIGNAL_MODELS.map(m => m.key)))} className="text-primary hover:underline">全选</button>
                  <span className="text-border">·</span>
                  <button onClick={() => setEnabledModels(new Set())} className="text-primary hover:underline">清空</button>
                  <span className="text-border">·</span>
                  <button onClick={() => setPosMults(Object.fromEntries(POS_MULT_FIELDS.map(f => [f.key, f.default_])))} className="text-muted-foreground hover:underline">重置权重</button>
                </div>
              </div>

              <div className="rounded-md border border-border overflow-hidden divide-y divide-border">
                {SIGNAL_MODELS.map((m) => {
                  const pmf = POS_MULT_FIELDS.find(f => f.model === m.key);
                  const enabled = enabledModels.has(m.key);
                  const mult = pmf ? posMults[pmf.key] : 1;
                  const effectivePct = basePosPct * mult * 100;
                  const adj = (d: number) => { if (pmf) setPosMults(p => ({ ...p, [pmf.key]: Math.max(0.1, Math.min(1.5, +(p[pmf.key] + d).toFixed(2))) })); };
                  return (
                    <div key={m.key}
                      className={cn("flex items-center gap-2 px-2.5 py-[6px] cursor-pointer select-none transition-colors",
                        enabled ? "hover:bg-muted/30" : "opacity-35 hover:opacity-55")}
                      onClick={() => { const n = new Set(enabledModels); enabled ? n.delete(m.key) : n.add(m.key); setEnabledModels(n); }}>
                      <div className={cn("h-3.5 w-3.5 rounded border-[1.5px] shrink-0 flex items-center justify-center",
                        enabled ? "border-primary bg-primary" : "border-muted-foreground/25")}>
                        {enabled && <svg viewBox="0 0 12 12" className="h-2 w-2 text-primary-foreground" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="M2 6l3 3 5-5" /></svg>}
                      </div>
                      <span className="text-xs font-medium w-[3.6rem] shrink-0">{m.label}</span>
                      <span className={cn("rounded px-1 py-px text-[9px] font-medium leading-none shrink-0", MATURITY[m.maturity]?.cls)}>{MATURITY[m.maturity]?.tag}</span>
                      <span className="text-[11px] text-muted-foreground flex-1 min-w-0 truncate">{m.desc}</span>
                      {pmf && (
                        <div className="flex items-center shrink-0" onClick={(e) => e.stopPropagation()}>
                          {enabled ? (
                            <>
                              <button onClick={() => adj(-0.05)} className="h-5 w-5 rounded-l border border-border bg-muted/30 text-[11px] hover:bg-accent flex items-center justify-center">−</button>
                              <div className="h-5 px-1.5 border-y border-border bg-background flex items-center justify-center">
                                <span className="text-[11px] tabular-nums font-semibold w-8 text-center">×{mult.toFixed(2)}</span>
                              </div>
                              <button onClick={() => adj(0.05)} className="h-5 w-5 rounded-r border border-border bg-muted/30 text-[11px] hover:bg-accent flex items-center justify-center">+</button>
                              <span className="text-[11px] tabular-nums text-muted-foreground ml-1.5 w-10 text-right">{effectivePct.toFixed(1)}%</span>
                            </>
                          ) : (
                            <span className="text-[11px] tabular-nums text-muted-foreground/30">×{mult.toFixed(2)}</span>
                          )}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
              <p className="text-[11px] text-muted-foreground mt-1.5">
                已启用 <strong className="text-foreground">{enabledModels.size}</strong>/{SIGNAL_MODELS.length}
                <span className="ml-3">实际仓位 = {(basePosPct * 100).toFixed(0)}% × 权重</span>
              </p>
            </div>
          </div>

          {/* ── Advanced ── */}
          <div className="rounded-lg border border-border bg-card">
            <button onClick={() => setShowAdvanced(!showAdvanced)}
              className="flex items-center gap-2 w-full px-4 py-2 text-xs font-medium text-muted-foreground hover:text-foreground transition-colors">
              <Settings2 className="h-3.5 w-3.5" />
              <span className="flex-1 text-left">高级选项</span>
              <ChevronDown className={cn("h-3.5 w-3.5 transition-transform", showAdvanced && "rotate-180")} />
            </button>
            {showAdvanced && (
              <div className="px-4 pb-2.5 space-y-2.5 border-t border-border pt-2.5">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-medium">特征预热</span>
                    <UnitInput unit="bar" className="w-24">
                      <input type="number" min={120} max={900} step={50} value={warmupBars} onChange={(e) => setWarmupBars(+e.target.value)} className="input-field w-full tabular-nums text-right" />
                    </UnitInput>
                    <span className="text-[11px] text-muted-foreground">默认 600</span>
                  </div>
                  <p className="text-[10px] text-muted-foreground mt-1 leading-relaxed">
                    回测区间前加载的历史 K 线数，用于 rolling 特征预热。最低 120（结构特征窗口需要 120 bar），推荐 300~600。
                  </p>
                  <p className="text-[10px] text-muted-foreground mt-0.5 leading-relaxed">
                    <strong className="text-foreground/70">影响示例：</strong>amount_rank（60日成交额排名）在 600 bar 下用 ~2.4 年历史排序，300 bar 下用 ~1.2 年；
                    结构特征的"历史高点"在更短窗口下可能找不到更久远的高点。<strong className="text-warning">不同预热值的回测结果不可直接对比。</strong>
                  </p>
                </div>
                <label className="flex items-center gap-2 cursor-pointer select-none text-xs">
                  <input type="checkbox" checked={cacheOnly} onChange={(e) => setCacheOnly(e.target.checked)} className="rounded border-border accent-primary" />
                  离线模式 <span className="text-[11px] text-muted-foreground">— 仅用本地缓存</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer select-none text-xs">
                  <input type="checkbox" checked={disableEnvMapping} onChange={(e) => setDisableEnvMapping(e.target.checked)} className="rounded border-border accent-primary" />
                  禁用行业映射 <span className="text-[11px] text-muted-foreground">— 所有标的归为"其他"，排除板块联动影响</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer select-none text-xs">
                  <input type="checkbox" checked={showProgress} onChange={(e) => setShowProgress(e.target.checked)} className="rounded border-border accent-primary" />
                  引擎进度 <span className="text-[11px] text-muted-foreground">— 逐 bar 输出日志</span>
                </label>
              </div>
            )}
          </div>
        </div>

        {/* ═══════════ RIGHT: Summary ═══════════ */}
        <div className="w-60 shrink-0 sticky top-6 space-y-3">
          <div className="rounded-lg border border-border bg-card overflow-hidden">
            <div className="px-3.5 py-2 bg-muted/40 border-b border-border">
              <h3 className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wider">运行摘要</h3>
            </div>
            <div className="px-3.5 py-3 space-y-2 text-xs">
              <SummaryRow label="区间" value={dateLabel} />
              <SummaryRow label="执行" value={profileObj?.label ?? profile} />
              <SummaryRow label="资金" value={`¥${initCash.toLocaleString()}`} />
              <SummaryRow label="标的" value={poolLabel} />
              <div className="border-t border-border/40 pt-2 space-y-2">
                <SummaryRow label="持仓" value={`≤ ${maxPositions}`} />
                <SummaryRow label="仓位" value={`${(basePosPct * 100).toFixed(0)}%`} />
                <SummaryRow label="止盈" value={`${(takeProfitPct * 100).toFixed(0)}%`} />
                <SummaryRow label="冷却" value={`${cooldownDays}天`} />
              </div>
              <div className="border-t border-border/40 pt-2 space-y-2">
                <SummaryRow label="模型" value={`${enabledModels.size} / ${SIGNAL_MODELS.length}`} />
                <SummaryRow label="预热" value={`${warmupBars} bar`} />
              </div>
            </div>
          </div>

          <button onClick={handleSubmit} disabled={isRunning}
            className={cn(
              "w-full flex items-center justify-center gap-2 rounded-lg py-2.5 text-sm font-semibold transition-all",
              isRunning ? "bg-muted text-muted-foreground cursor-not-allowed" : "bg-primary text-primary-foreground hover:bg-primary/90 shadow-sm active:scale-[0.98]",
            )}>
            {isRunning ? <Loader2 className="h-4 w-4 animate-spin" /> : <Play className="h-4 w-4" />}
            {isRunning ? "运行中..." : "开始回测"}
          </button>

          {task && !isRunning && (
            <button onClick={() => { setTaskId(null); setEquityCurve([]); setTrades([]); sessionStorage.removeItem("bt_task_id"); }}
              className="w-full flex items-center justify-center gap-1.5 rounded-lg py-2 text-xs font-medium border border-border hover:bg-accent transition-colors">
              <RotateCcw className="h-3.5 w-3.5" />重置
            </button>
          )}

          {task && (
            <div className="rounded-lg border border-border bg-card p-3">
              <div className="flex items-center gap-2">
                <span className={cn("h-2 w-2 rounded-full shrink-0",
                  task.status === "succeeded" ? "bg-success" : task.status === "failed" ? "bg-destructive" : "bg-warning animate-pulse",
                )} />
                <span className="text-xs font-medium">
                  {task.status === "succeeded" ? "回测完成" : task.status === "failed" ? "回测失败" : "运行中"}
                </span>
              </div>
              {isRunning && logLines.length > 0 && (
                <pre className="mt-2 rounded bg-muted/50 p-2 max-h-28 overflow-y-auto text-[10px] text-muted-foreground whitespace-pre-wrap leading-relaxed font-mono">{logLines.slice(-6).join("\n")}</pre>
              )}
              <p className="text-[10px] text-muted-foreground mt-1 truncate">Task {task.id}</p>
            </div>
          )}
        </div>
      </div>

      {/* ═══════════ Results ═══════════ */}
      {task && (
        <div className="mt-6 space-y-5">
          {isRunning && <TaskLogPanel logLines={logLines} isRunning />}
          {task.status === "succeeded" && equityCurve.length > 0 && (
            <>
              <ConfigBanner payload={task.payload} onApply={applyConfig} />
              <div><h3 className="text-sm font-semibold mb-3">收益曲线</h3><EquityChart data={equityCurve} /></div>
              <div><h3 className="text-sm font-semibold mb-3">交易记录 ({trades.length})</h3><TradesTable data={trades} columns={tradesCols} source={tradesSource} /></div>
            </>
          )}
          {task.status === "failed" && (
            <>
              <ConfigBanner payload={task.payload} onApply={applyConfig} />
              <p className="text-sm text-destructive">任务失败 (code {task.return_code})</p>
              <TaskLogPanel logLines={logLines} isRunning={false} />
            </>
          )}
        </div>
      )}
    </div>
  );
}

/* ═══════════════════ helpers ═══════════════════ */

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="flex items-center justify-between gap-2">
      <span className="text-xs text-muted-foreground shrink-0">{label}</span>
      {children}
    </div>
  );
}

function UnitInput({ unit, className, children }: { unit: string; className?: string; children: React.ReactNode }) {
  return (
    <div className={cn("unit-input", className)}>
      {children}
      <span className="unit-suffix">{unit}</span>
    </div>
  );
}

function SummaryRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex justify-between gap-2">
      <span className="text-muted-foreground shrink-0">{label}</span>
      <span className="font-medium text-right truncate tabular-nums">{value}</span>
    </div>
  );
}

const CONFIG_LABELS: Record<string, string> = {
  start: "起始日期", end: "结束日期", execution_profile: "执行模式",
  init_cash: "初始资金", pool: "标的池大小", pool_sampling: "抽样方式",
  pool_seed: "随机种子", pool_name: "命名池", symbols: "自定义标的",
  max_positions: "最大持仓", base_pos_pct: "基础仓位", cooldown_days: "冷却天数",
  take_profit_pct: "默认止盈", hunt_price_buffer_pct: "猎手缓冲",
  hunt_window_days: "入场窗口",
  warmup_bars: "特征预热",
  mootdx_cache_only: "离线模式",
  disable_env_mapping: "禁用行业映射",
  show_progress: "显示进度", enable_events: "启用模型",
  trend_spear_pos_mult: "趋势权重", post_limit_pos_mult: "板后权重",
  failed_board_pos_mult: "烂板权重", youzi_pos_mult: "游资权重",
  sector_spear_pos_mult: "板块权重", attack_pos_mult: "进攻权重",
  arb_pos_mult: "套利权重",
};

function formatConfigValue(key: string, val: unknown): string {
  if (val === null || val === undefined || val === "") return "—";
  if (key === "execution_profile") {
    const p = ENTRY_PROFILES.find(p => p.value === val);
    return p ? p.label : String(val);
  }
  if (key === "init_cash") return `¥${Number(val).toLocaleString()}`;
  if (key === "warmup_bars") return `${val} bar`;
  if (key === "base_pos_pct" || key === "take_profit_pct") return `${(Number(val) * 100).toFixed(0)}%`;
  if (key === "hunt_price_buffer_pct") return `${(Number(val) * 100).toFixed(1)}%`;
  if (key.endsWith("_pos_mult")) return `×${Number(val).toFixed(2)}`;
  if (typeof val === "boolean") return val ? "是" : "否";
  if (Array.isArray(val)) return val.join(", ");
  return String(val);
}

function ConfigBanner({ payload, onApply }: { payload: Record<string, unknown>; onApply: (cfg: Record<string, unknown>) => void }) {
  const [expanded, setExpanded] = useState(false);
  const skip = new Set(["output_dir"]);
  const entries = Object.entries(payload).filter(([k]) => !skip.has(k) && CONFIG_LABELS[k]);
  return (
    <div className="rounded-lg border border-border bg-card">
      <div className="flex items-center justify-between px-4 py-2">
        <button onClick={() => setExpanded(!expanded)} className="flex items-center gap-2 text-xs font-semibold text-muted-foreground hover:text-foreground">
          <ChevronDown className={cn("h-3.5 w-3.5 transition-transform", expanded && "rotate-180")} />
          回测配置参数
        </button>
        <button onClick={() => onApply(payload)} className="flex items-center gap-1.5 text-xs font-medium text-primary hover:text-primary/80 transition-colors">
          <Copy className="h-3.5 w-3.5" />应用此配置
        </button>
      </div>
      {expanded && (
        <div className="px-4 pb-3 border-t border-border pt-2.5">
          <div className="grid grid-cols-3 gap-x-6 gap-y-1.5 text-xs">
            {entries.map(([k, v]) => (
              <div key={k} className="flex justify-between gap-2">
                <span className="text-muted-foreground shrink-0">{CONFIG_LABELS[k]}</span>
                <span className="font-medium tabular-nums text-right truncate">{formatConfigValue(k, v)}</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function PoolPreviewPanel({ preview, onClose }: { preview: PoolPreview; onClose: () => void }) {
  const missingSet = new Set(preview.missing_symbols ?? []);
  const missingCount = missingSet.size;
  return (
    <div className="rounded border border-border bg-background p-2.5 mt-1.5">
      <div className="flex items-center justify-between mb-1.5">
        <div className="flex items-center gap-2">
          <span className="text-xs font-medium">{preview.count} 只标的</span>
          {missingCount > 0 && (
            <span className="text-[10px] text-amber-600 dark:text-amber-400">
              ({missingCount} 缺缓存)
            </span>
          )}
        </div>
        <button onClick={onClose} className="text-muted-foreground hover:text-foreground"><X className="h-3.5 w-3.5" /></button>
      </div>
      <div className="max-h-36 overflow-y-auto text-[11px]">
        <div className="grid grid-cols-4 gap-x-3 gap-y-0.5">
          {preview.symbols.map((s) => {
            const isMissing = missingSet.has(s.symbol);
            return (
              <div key={s.symbol} className={cn("flex gap-1", isMissing && "text-amber-600 dark:text-amber-400")}>
                <span className="font-mono">{s.symbol}</span>
                <span className={cn("truncate", isMissing ? "text-amber-500/70 dark:text-amber-400/70" : "text-muted-foreground")}>{s.name || (isMissing ? "无缓存" : "")}</span>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
