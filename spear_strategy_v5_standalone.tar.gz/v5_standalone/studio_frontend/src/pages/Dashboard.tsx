import {
  Activity,
  AlertTriangle,
  ArrowDown,
  ArrowUp,
  BarChart3,
  CheckCircle2,
  Crosshair,
  Database,
  Loader2,
  RefreshCcw,
  Search,
  TrendingUp,
} from "lucide-react";
import { useCallback, useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { useApi } from "../hooks/useApi";
import { api, type BacktestStat, type BacktestStatEntry, type ConsistencyCheckResult, type TaskRecord } from "../lib/api";
import { cn, prettyDate } from "../lib/utils";

const PROFILE_SHORT: Record<string, string> = {
  day_level_ideal: "DLI",
  next_open_realistic: "NOR",
  delayed_limit_hunt: "DLH",
};

function hasStats(s: BacktestStat["stats"]): s is BacktestStatEntry {
  return "total_closed" in s && (s as BacktestStatEntry).total_closed > 0;
}

function pct(v: number | undefined, digits = 2): string {
  if (v === undefined || v === null) return "—";
  return `${v >= 0 ? "+" : ""}${v.toFixed(digits)}%`;
}

function money(v: number | undefined): string {
  if (v === undefined || v === null) return "—";
  const abs = Math.abs(v);
  if (abs >= 1e6) return `¥${(v / 1e6).toFixed(2)}M`;
  if (abs >= 1e3) return `¥${(v / 1e3).toFixed(1)}K`;
  return `¥${v.toLocaleString()}`;
}

function retColor(v: number | undefined | null): string {
  if (v === undefined || v === null || v === 0) return "text-muted-foreground";
  return v > 0 ? "text-up" : "text-down";
}

function parsePeriod(cfg: Record<string, unknown>): string {
  const s = String(cfg.start ?? "").slice(0, 4);
  const e = String(cfg.end ?? "").slice(0, 4);
  if (!s) return "—";
  return s === e ? s : `${s}-${e}`;
}


interface AggStats {
  count: number;
  avgWinRate: number;
  avgReturn: number;
  avgPnl: number;
  bestReturn: number;
  worstDrawdown: number;
  totalTrades: number;
}

function aggregate(items: BacktestStat[]): AggStats {
  const withStats = items.filter((i) => hasStats(i.stats));
  if (withStats.length === 0) {
    return { count: items.length, avgWinRate: 0, avgReturn: 0, avgPnl: 0, bestReturn: 0, worstDrawdown: 0, totalTrades: 0 };
  }
  const stats = withStats.map((i) => i.stats as BacktestStatEntry);
  return {
    count: items.length,
    avgWinRate: stats.reduce((s, x) => s + x.win_rate, 0) / stats.length,
    avgReturn: stats.reduce((s, x) => s + (x.total_return_pct ?? 0), 0) / stats.length,
    avgPnl: stats.reduce((s, x) => s + x.total_pnl, 0) / stats.length,
    bestReturn: Math.max(...stats.map((x) => x.total_return_pct ?? 0)),
    worstDrawdown: Math.min(...stats.map((x) => x.max_drawdown_pct ?? 0)),
    totalTrades: stats.reduce((s, x) => s + x.total_closed, 0),
  };
}

function KPI({
  label,
  value,
  sub,
  icon: Icon,
  color,
}: {
  label: string;
  value: string;
  sub?: string;
  icon: React.ElementType;
  color: string;
}) {
  return (
    <div className="rounded-xl border border-border bg-card p-4 flex items-start gap-3">
      <div className={cn("rounded-lg p-2", color)}>
        <Icon className="h-4 w-4" />
      </div>
      <div className="min-w-0">
        <p className="text-xs text-muted-foreground">{label}</p>
        <p className="text-xl font-bold tracking-tight mt-0.5 tabular-nums">{value}</p>
        {sub && <p className="text-[11px] text-muted-foreground mt-0.5 truncate">{sub}</p>}
      </div>
    </div>
  );
}

function ActiveTaskCard({ task: t, onCleanup }: { task: TaskRecord; onCleanup: () => void }) {
  const p = t.payload;
  const period = p.start && p.end ? `${String(p.start).slice(0, 10)} → ${String(p.end).slice(0, 10)}` : "";
  const profile = PROFILE_SHORT[String(p.execution_profile ?? "")] ?? String(p.execution_profile ?? "");
  const syms = Array.isArray(p.symbols) ? p.symbols as string[] : [];
  const pool = p.pool_name ? String(p.pool_name) : syms.length > 0 ? `${syms.length} symbols` : p.pool ? `Pool ${p.pool}` : "";
  const elapsed = Math.round((Date.now() - new Date(t.created_at).getTime()) / 1000);
  const mins = Math.floor(elapsed / 60);
  const secs = elapsed % 60;
  const isStale = elapsed > 3600;
  const linkTo = t.kind === "signal_scan" ? "/signals" : "/backtest";

  async function handleCancel(e: React.MouseEvent) {
    e.preventDefault();
    e.stopPropagation();
    await api.cancelTask(t.id);
    onCleanup();
  }

  async function handleDelete(e: React.MouseEvent) {
    e.preventDefault();
    e.stopPropagation();
    await api.deleteTask(t.id);
    onCleanup();
  }

  return (
    <div className={cn(
      "flex items-center gap-3 rounded-lg border px-4 py-3",
      isStale ? "border-destructive/30 bg-destructive/5" : "border-warning/30 bg-warning/5",
    )}>
      <div className="relative flex-shrink-0">
        {isStale
          ? <Activity className="h-5 w-5 text-destructive" />
          : <Loader2 className="h-5 w-5 animate-spin text-warning" />}
      </div>
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 text-sm">
          <span className="font-medium">{t.kind === "backtest" ? "回测" : "信号扫描"}</span>
          {period && <span className="text-muted-foreground">{period}</span>}
          {profile && <span className="rounded bg-muted px-1.5 py-0.5 text-[10px] font-medium">{profile}</span>}
          {isStale && <span className="rounded bg-destructive/10 text-destructive px-1.5 py-0.5 text-[10px] font-medium">疑似卡死</span>}
        </div>
        <div className="flex items-center gap-2 text-xs text-muted-foreground mt-0.5">
          <span>{pool}</span>
          <span>·</span>
          <span>{t.status === "running" ? "运行中" : "等待中"}</span>
          <span>·</span>
          <span>{mins > 0 ? `${mins}m ${secs}s` : `${secs}s`}</span>
        </div>
      </div>
      <div className="flex items-center gap-1.5 flex-shrink-0">
        {isStale && (
          <button onClick={handleDelete} className="text-[11px] text-destructive hover:text-destructive/80 font-medium px-2 py-1 rounded hover:bg-destructive/10 transition-colors">
            删除
          </button>
        )}
        <button onClick={handleCancel} className="text-[11px] text-muted-foreground hover:text-foreground font-medium px-2 py-1 rounded hover:bg-muted transition-colors">
          取消
        </button>
        <Link to={linkTo} className="text-[11px] text-primary font-medium px-2 py-1 rounded hover:bg-primary/10 transition-colors">
          查看 →
        </Link>
      </div>
    </div>
  );
}

function DataHealthCard() {
  const [checkResult, setCheckResult] = useState<ConsistencyCheckResult | null>(null);
  const [checking, setChecking] = useState(false);
  const [refreshTaskId, setRefreshTaskId] = useState<string | null>(null);
  const [refreshTask, setRefreshTask] = useState<TaskRecord | null>(null);

  const handleCheck = useCallback(async () => {
    setChecking(true);
    try {
      const result = await api.consistencyCheck({ sample_size: 30 });
      setCheckResult(result);
    } catch {
      /* ignore */
    } finally {
      setChecking(false);
    }
  }, []);

  const handleFullRefresh = useCallback(async () => {
    try {
      const res = await api.fullRefresh({});
      setRefreshTaskId(res.task_id);
      setRefreshTask({ id: res.task_id, kind: "backtest", status: "pending", created_at: new Date().toISOString(), updated_at: new Date().toISOString(), payload: {} } as TaskRecord);
    } catch {
      /* ignore */
    }
  }, []);

  // Poll refresh task status
  useEffect(() => {
    if (!refreshTaskId) return;
    const interval = setInterval(async () => {
      try {
        const t = await api.task(refreshTaskId);
        setRefreshTask(t as TaskRecord);
        if (t.status === "succeeded" || t.status === "failed") {
          clearInterval(interval);
        }
      } catch {
        clearInterval(interval);
      }
    }, 3000);
    return () => clearInterval(interval);
  }, [refreshTaskId]);

  const r = checkResult;
  const hasIssue = r && r.inconsistent > 0;
  const notMigrated = r && r.qfq_migrated === false;
  const isRefreshing = refreshTask && (refreshTask.status === "pending" || refreshTask.status === "running");
  const refreshDone = refreshTask && refreshTask.status === "succeeded";

  return (
    <div className={cn(
      "rounded-xl border bg-card p-5 space-y-3",
      hasIssue || notMigrated ? "border-warning/50" : "border-border",
    )}>
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Database className="h-4 w-4 text-muted-foreground" />
          <h3 className="font-semibold text-sm">数据健康</h3>
          {r && !hasIssue && !notMigrated && (
            <span className="inline-flex items-center gap-1 text-[11px] text-up font-medium">
              <CheckCircle2 className="h-3 w-3" />前复权一致
            </span>
          )}
          {hasIssue && (
            <span className="inline-flex items-center gap-1 text-[11px] text-warning font-medium">
              <AlertTriangle className="h-3 w-3" />{r.inconsistent}/{r.checked} 只标的历史价格偏差
            </span>
          )}
          {!hasIssue && notMigrated && (
            <span className="inline-flex items-center gap-1 text-[11px] text-warning font-medium">
              <AlertTriangle className="h-3 w-3" />未迁移至前复权
            </span>
          )}
        </div>
        <div className="flex items-center gap-1.5">
          <button
            onClick={handleCheck}
            disabled={checking || !!isRefreshing}
            className="inline-flex items-center gap-1 text-[11px] font-medium px-2.5 py-1 rounded-md border border-border hover:bg-muted transition-colors disabled:opacity-50"
          >
            {checking ? <Loader2 className="h-3 w-3 animate-spin" /> : <Search className="h-3 w-3" />}
            检查一致性
          </button>
          <button
            onClick={handleFullRefresh}
            disabled={!!isRefreshing}
            className="inline-flex items-center gap-1 text-[11px] font-medium px-2.5 py-1 rounded-md border border-border hover:bg-muted transition-colors disabled:opacity-50"
          >
            {isRefreshing ? <Loader2 className="h-3 w-3 animate-spin" /> : <RefreshCcw className="h-3 w-3" />}
            全量刷新
          </button>
        </div>
      </div>

      {/* Explanation when no check has been run */}
      {!r && !checking && !isRefreshing && (
        <div className="text-[11px] text-muted-foreground space-y-1">
          <p>
            缓存的 K 线数据必须使用一致的<b>前复权</b>（qfq）才能保证回测和信号扫描结果可复现。
          </p>
          <p>
            「检查一致性」会抽检缓存中的<b>历史价格</b>（非近期），与 mootdx 最新前复权数据对比。
            若偏差 &gt;0.5% 则判定为复权因子已变化或缓存包含不复权数据，需要全量刷新。
          </p>
        </div>
      )}

      {/* Check results */}
      {r && (
        <div className="space-y-2">
          <div className="flex flex-wrap gap-x-5 gap-y-1 text-[11px] text-muted-foreground">
            <span>缓存: {r.total_cached} 只标的</span>
            <span>抽检: {r.checked} 只（对比历史价格）</span>
            <span>一致: {r.consistent}</span>
            <span>偏差: {r.inconsistent}</span>
            {(r.errors ?? 0) > 0 && <span className="text-destructive">错误: {r.errors}</span>}
            {r.newest_update && <span>最新更新: {prettyDate(r.newest_update)}</span>}
          </div>

          {/* Migration warning */}
          {notMigrated && !hasIssue && (
            <div className="rounded-lg bg-amber-500/5 border border-amber-500/20 p-3 text-[11px] text-amber-700 dark:text-amber-400 space-y-1">
              <p className="font-medium flex items-center gap-1.5">
                <AlertTriangle className="h-3.5 w-3.5 shrink-0" />
                缓存尚未标记为前复权迁移完成
              </p>
              <p className="text-amber-600/80 dark:text-amber-400/70">
                即使抽检一致，建议执行一次「全量刷新」以确保所有标的的完整历史均为前复权数据，
                并写入迁移标记。刷新后新的增量更新会自动检测复权因子变化。
              </p>
            </div>
          )}

          {/* Inconsistent symbols */}
          {hasIssue && (
            <div className="rounded-lg bg-warning/5 border border-warning/20 p-3 space-y-1.5">
              <p className="text-[11px] text-warning font-medium">
                以下标的的缓存历史价格与最新前复权数据存在偏差 (&gt;0.5%)，表明缓存可能包含不复权或混合复权数据：
              </p>
              <div className="flex flex-wrap gap-1.5">
                {r.inconsistent_symbols.map((s) => (
                  <span
                    key={s.symbol}
                    className="inline-flex items-center gap-1 rounded bg-warning/10 px-2 py-0.5 text-[10px] font-mono text-warning"
                    title={`偏差 ${s.max_deviation_pct.toFixed(1)}%, 更新于 ${prettyDate(s.last_pkl_update)}`}
                  >
                    {s.symbol}
                    <span className="text-warning/70">{s.max_deviation_pct.toFixed(1)}%</span>
                  </span>
                ))}
              </div>
              <p className="text-[10px] text-warning/70 mt-1">
                建议点击「全量刷新」重新拉取所有标的的前复权数据，刷新后回测结果将可复现。
              </p>
            </div>
          )}

          {/* All consistent */}
          {!hasIssue && !notMigrated && (
            <p className="text-[11px] text-up/80">
              抽检 {r.checked} 只标的的历史价格均与最新前复权数据一致，缓存状态健康。
            </p>
          )}
        </div>
      )}

      {/* Refresh progress */}
      {isRefreshing && (
        <div className="flex items-center gap-2 rounded-md bg-primary/5 border border-primary/20 px-3 py-2 text-[11px]">
          <Loader2 className="h-3.5 w-3.5 animate-spin text-primary shrink-0" />
          <span className="text-primary font-medium">
            全量刷新进行中...
          </span>
          <span className="text-muted-foreground">
            任务 {refreshTaskId?.slice(0, 8)} · {refreshTask?.status === "running" ? "正在拉取数据" : "等待启动"}
          </span>
        </div>
      )}
      {refreshDone && (
        <div className="flex items-center gap-2 rounded-md bg-emerald-500/10 px-3 py-1.5 text-[11px] text-emerald-700 dark:text-emerald-400">
          <CheckCircle2 className="h-3.5 w-3.5 shrink-0" />
          全量刷新完成，缓存已更新为前复权数据。建议重新「检查一致性」确认。
        </div>
      )}
      {refreshTask?.status === "failed" && (
        <div className="flex items-center gap-2 rounded-md bg-destructive/10 px-3 py-1.5 text-[11px] text-destructive">
          <AlertTriangle className="h-3.5 w-3.5 shrink-0" />
          全量刷新失败，请检查日志 (任务 {refreshTaskId?.slice(0, 8)})
        </div>
      )}
    </div>
  );
}


type SortKey = "name" | "win_rate" | "total_return_pct" | "peak_equity" | "max_drawdown_pct" | "total_closed" | "updated_at";

export function Dashboard() {
  const { data: batchStats, loading: bsLoading } = useApi(() => api.batchStats(), []);
  const { data: tasks, loading: tLoading, refetch: refetchTasks } = useApi(() => api.tasks(), []);
  const [sortKey, setSortKey] = useState<SortKey>("updated_at");
  const [sortDir, setSortDir] = useState<"asc" | "desc">("desc");

  const activeTasks = useMemo(
    () => (tasks ?? []).filter((t) => t.status === "running" || t.status === "pending"),
    [tasks],
  );

  const agg = useMemo(() => aggregate(batchStats ?? []), [batchStats]);

  const sorted = useMemo(() => {
    if (!batchStats) return [];
    const arr = batchStats.filter((item) => {
      const s = hasStats(item.stats) ? (item.stats as BacktestStatEntry) : null;
      return s?.total_return_pct != null;
    });
    arr.sort((a, b) => {
      const sa = hasStats(a.stats) ? (a.stats as BacktestStatEntry) : null;
      const sb = hasStats(b.stats) ? (b.stats as BacktestStatEntry) : null;
      let av: number, bv: number;
      switch (sortKey) {
        case "name": return sortDir === "asc" ? a.name.localeCompare(b.name) : b.name.localeCompare(a.name);
        case "win_rate": av = sa?.win_rate ?? -1; bv = sb?.win_rate ?? -1; break;
        case "total_return_pct": av = sa?.total_return_pct ?? -999; bv = sb?.total_return_pct ?? -999; break;
        case "peak_equity": av = sa?.peak_equity ?? -1e12; bv = sb?.peak_equity ?? -1e12; break;
        case "max_drawdown_pct": av = sa?.max_drawdown_pct ?? -999; bv = sb?.max_drawdown_pct ?? -999; break;
        case "total_closed": av = sa?.total_closed ?? 0; bv = sb?.total_closed ?? 0; break;
        case "updated_at": return sortDir === "asc" ? a.updated_at.localeCompare(b.updated_at) : b.updated_at.localeCompare(a.updated_at);
        default: return 0;
      }
      return sortDir === "asc" ? av - bv : bv - av;
    });
    return arr;
  }, [batchStats, sortKey, sortDir]);

  function handleSort(key: SortKey) {
    if (sortKey === key) {
      setSortDir((d) => (d === "asc" ? "desc" : "asc"));
    } else {
      setSortKey(key);
      setSortDir(key === "name" || key === "updated_at" ? "desc" : "desc");
    }
  }

  function SortHeader({ label, col, className }: { label: string; col: SortKey; className?: string }) {
    const active = sortKey === col;
    return (
      <th
        className={cn("py-2 font-medium cursor-pointer select-none hover:text-foreground transition-colors", active && "text-foreground", className)}
        onClick={() => handleSort(col)}
      >
        <span className="inline-flex items-center gap-0.5">
          {label}
          {active && (sortDir === "asc" ? <ArrowUp className="h-3 w-3" /> : <ArrowDown className="h-3 w-3" />)}
        </span>
      </th>
    );
  }

  if (bsLoading || tLoading) {
    return (
      <div className="flex items-center justify-center h-full">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  const isEmpty = !batchStats || batchStats.length === 0;

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">回测绩效总览</h1>
          <p className="text-muted-foreground text-sm mt-1">
            {isEmpty ? "暂无回测数据" : `${agg.count} 次回测 · ${agg.totalTrades} 笔交易`}
          </p>
        </div>
        <Link
          to="/backtest"
          className="flex items-center gap-1.5 rounded-lg px-4 py-2 text-sm font-medium bg-primary text-primary-foreground hover:bg-primary/90 transition-colors"
        >
          <BarChart3 className="h-4 w-4" />
          新建回测
        </Link>
      </div>

      {/* Active Tasks */}
      {activeTasks.length > 0 && (
        <div className="space-y-2">
          {activeTasks.map((t) => (
            <ActiveTaskCard key={t.id} task={t} onCleanup={refetchTasks} />
          ))}
        </div>
      )}

      {/* Data Health */}
      <DataHealthCard />

      {isEmpty ? (
        <div className="rounded-xl border border-dashed border-border bg-card p-12 text-center space-y-3">
          <BarChart3 className="h-10 w-10 text-muted-foreground mx-auto" />
          <p className="text-muted-foreground">还没有回测结果，开始你的第一次回测吧</p>
          <Link
            to="/backtest"
            className="inline-flex items-center gap-1.5 rounded-lg px-4 py-2 text-sm font-medium bg-primary text-primary-foreground hover:bg-primary/90 transition-colors"
          >
            启动回测
          </Link>
        </div>
      ) : (
        <>
          {/* KPI Row */}
          <div className="grid grid-cols-2 lg:grid-cols-5 gap-3">
            <KPI
              icon={BarChart3}
              label="回测次数"
              value={String(agg.count)}
              sub={`${agg.totalTrades} 笔交易`}
              color="bg-primary/10 text-primary"
            />
            <KPI
              icon={Crosshair}
              label="平均胜率"
              value={`${(agg.avgWinRate * 100).toFixed(1)}%`}
              sub={agg.avgWinRate >= 0.5 ? "胜率 > 50%" : "胜率 < 50%"}
              color={agg.avgWinRate >= 0.5 ? "bg-up/10 text-up" : "bg-down/10 text-down"}
            />
            <KPI
              icon={TrendingUp}
              label="平均总收益"
              value={pct(agg.avgReturn)}
              sub={`平均PnL ${money(agg.avgPnl)}`}
              color={agg.avgReturn >= 0 ? "bg-up/10 text-up" : "bg-down/10 text-down"}
            />
            <KPI
              icon={ArrowUp}
              label="最佳收益"
              value={pct(agg.bestReturn)}
              color="bg-up/10 text-up"
            />
            <KPI
              icon={ArrowDown}
              label="最大回撤"
              value={pct(agg.worstDrawdown)}
              color="bg-down/10 text-down"
            />
          </div>

          {/* Performance Leaderboard */}
          <div className="rounded-xl border border-border bg-card overflow-hidden">
            <div className="flex items-center justify-between border-b border-border px-5 py-3">
              <h2 className="font-semibold text-sm">回测排行榜</h2>
              <Link to="/results" className="text-xs text-primary hover:underline">
                查看详细结果 →
              </Link>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-xs">
                <thead>
                  <tr className="text-muted-foreground text-left border-b border-border bg-muted/30">
                    <SortHeader label="名称" col="name" className="pl-5" />
                    <th className="py-2 font-medium">区间</th>
                    <th className="py-2 font-medium">模式</th>
                    <SortHeader label="交易数" col="total_closed" className="text-right" />
                    <SortHeader label="胜率" col="win_rate" className="text-right" />
                    <SortHeader label="总收益率" col="total_return_pct" className="text-right" />
                    <SortHeader label="最大净值" col="peak_equity" className="text-right" />
                    <SortHeader label="最大回撤" col="max_drawdown_pct" className="text-right" />
                    <SortHeader label="日期" col="updated_at" className="text-right pr-5" />
                  </tr>
                </thead>
                <tbody>
                  {sorted.map((item, idx) => {
                    const s = hasStats(item.stats) ? (item.stats as BacktestStatEntry) : null;
                    const profile = PROFILE_SHORT[String(item.config.execution_profile ?? "")] ?? "";
                    return (
                      <tr key={item.name} className={cn("border-b border-border/50 last:border-0 hover:bg-muted/20", idx < 3 && s && (s.total_return_pct ?? 0) > 0 && "bg-up/[0.03]")}>
                        <td className="py-2 pl-5 font-mono truncate max-w-[14rem]" title={item.name}>
                          <Link to="/results" className="text-primary hover:underline">{item.name}</Link>
                        </td>
                        <td className="py-2 tabular-nums">{parsePeriod(item.config)}</td>
                        <td className="py-2">
                          {profile && (
                            <span className="rounded-full px-1.5 py-0.5 text-[10px] font-medium bg-muted text-muted-foreground">
                              {profile}
                            </span>
                          )}
                        </td>
                        <td className="py-2 text-right tabular-nums">{s?.total_closed ?? "—"}</td>
                        <td className={cn("py-2 text-right tabular-nums", s && retColor(s.win_rate >= 0.5 ? 1 : -1))}>
                          {s ? `${(s.win_rate * 100).toFixed(1)}%` : "—"}
                        </td>
                        <td className={cn("py-2 text-right tabular-nums font-medium", retColor(s?.total_return_pct))}>
                          {s?.total_return_pct != null ? pct(s.total_return_pct) : "—"}
                        </td>
                        <td className="py-2 text-right tabular-nums">
                          {s?.peak_equity != null ? money(s.peak_equity) : "—"}
                        </td>
                        <td className="py-2 text-right tabular-nums text-down">
                          {s?.max_drawdown_pct != null ? pct(s.max_drawdown_pct) : "—"}
                        </td>
                        <td className="py-2 text-right text-muted-foreground pr-5">{prettyDate(item.updated_at)}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>

          {/* Quick Actions */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Link
              to="/backtest"
              className="rounded-xl border border-border bg-card p-5 hover:border-primary hover:shadow-md transition-all group"
            >
              <BarChart3 className="h-5 w-5 text-primary mb-2" />
              <p className="font-semibold group-hover:text-primary transition-colors text-sm">启动回测</p>
              <p className="text-xs text-muted-foreground mt-1">使用自定义参数运行新的回测</p>
            </Link>
            <Link
              to="/signals"
              className="rounded-xl border border-border bg-card p-5 hover:border-primary hover:shadow-md transition-all group"
            >
              <Crosshair className="h-5 w-5 text-success mb-2" />
              <p className="font-semibold group-hover:text-success transition-colors text-sm">信号扫描</p>
              <p className="text-xs text-muted-foreground mt-1">扫描今日交易信号</p>
            </Link>
          </div>
        </>
      )}
    </div>
  );
}
