import { BrowserRouter, Route, Routes } from "react-router-dom";
import { Layout } from "./components/Layout";
import { BacktestLauncher } from "./pages/BacktestLauncher";
import { Dashboard } from "./pages/Dashboard";
import { ResultsExplorer } from "./pages/ResultsExplorer";
import { SignalScanner } from "./pages/SignalScanner";

export function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route element={<Layout />}>
          <Route index element={<Dashboard />} />
          <Route path="backtest" element={<BacktestLauncher />} />
          <Route path="signals" element={<SignalScanner />} />
          <Route path="results" element={<ResultsExplorer />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}
