import { useEffect, useRef } from "react";
import { Loader2, Terminal } from "lucide-react";
import { cn } from "../lib/utils";

interface Props {
  logLines: string[];
  isRunning: boolean;
}

export function TaskLogPanel({ logLines, isRunning }: Props) {
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [logLines]);

  if (!logLines.length && !isRunning) return null;

  return (
    <div className="mt-3">
      <div className="flex items-center gap-2 mb-2">
        {isRunning ? (
          <Loader2 className="h-3.5 w-3.5 animate-spin text-warning" />
        ) : (
          <Terminal className="h-3.5 w-3.5 text-muted-foreground" />
        )}
        <span className="text-xs font-medium text-muted-foreground">
          {isRunning ? "Live output" : "Output"}
        </span>
      </div>
      <div
        ref={scrollRef}
        className={cn(
          "rounded-lg border border-border bg-background p-3 font-mono text-xs leading-5",
          "max-h-48 overflow-y-auto whitespace-pre-wrap break-all"
        )}
      >
        {logLines.length === 0 && isRunning && (
          <span className="text-muted-foreground">Waiting for output...</span>
        )}
        {logLines.map((line, i) => {
          const isProgress = line.startsWith("[prepare]") || line.startsWith("[catch-up]");
          return (
            <div
              key={i}
              className={cn(
                isProgress ? "text-primary" : "text-foreground"
              )}
            >
              {line || "\u00A0"}
            </div>
          );
        })}
      </div>
    </div>
  );
}
