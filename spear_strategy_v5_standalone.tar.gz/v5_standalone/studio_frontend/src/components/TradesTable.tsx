import { useMemo, useRef, useCallback, useEffect, useState } from "react";
import { ChevronDown, ChevronRight } from "lucide-react";
import { cn } from "../lib/utils";
import type { NotableTrade } from "../lib/api";

type Trade = Record<string, unknown>;

interface EntryLeg {
  date: string;
  price: number;
  qty: number;
}

interface Props {
  data: Trade[];
  columns?: string[];
  source?: string;
  notableTrades?: NotableTrade[];
  highlightIndex?: number | null;
  sortCol?: string | null;
  sortDir?: "asc" | "desc";
  onSort?: (col: string, dir: "asc" | "desc") => void;
}

const FROZEN_COUNT = 2;
const COL_MIN_W = 90;
const COL_MAX_W = 180;

function formatCell(value: unknown, colName: string): string {
  if (value === "" || value === null || value === undefined) return "—";
  if (colName.includes("股票代码") || colName === "symbol") {
    return String(value).padStart(6, "0");
  }
  if (typeof value === "number") {
    if (colName.includes("(%)") || colName.includes("pct") || colName.includes("盈亏") || colName.includes("MFE") || colName.includes("MAE")) {
      return `${value.toFixed(2)}%`;
    }
    if (colName.includes("价") || colName.includes("price")) {
      return value.toFixed(3);
    }
    if (Number.isInteger(value)) return String(value);
    return value.toFixed(3);
  }
  return String(value);
}

function cellColor(value: unknown, colName: string): string | undefined {
  if (typeof value !== "number") return undefined;
  if (colName.includes("盈亏") || colName.includes("MFE") || colName.includes("pnl")) {
    return value > 0 ? "text-up" : value < 0 ? "text-down" : undefined;
  }
  return undefined;
}

function parseEntryLegs(row: Trade): EntryLeg[] | null {
  const raw = row["entry_legs"] ?? row["进场明细"];
  if (!raw || raw === "[]" || raw === "") return null;
  try {
    const legs: EntryLeg[] = typeof raw === "string" ? JSON.parse(raw) : raw as EntryLeg[];
    return legs.length > 1 ? legs : null;
  } catch {
    return null;
  }
}

function getEntryCount(row: Trade): number {
  const c = row["entry_count"] ?? row["进场次数"];
  if (typeof c === "number") return c;
  if (typeof c === "string") return parseInt(c, 10) || 1;
  return 1;
}

const HIDDEN_COLS = new Set(["entry_legs", "进场明细"]);

export function TradesTable({
  data, columns: externalCols, source, notableTrades,
  highlightIndex, sortCol, sortDir, onSort,
}: Props) {
  const scrollRef = useRef<HTMLDivElement>(null);
  const highlightRef = useRef<HTMLTableRowElement>(null);
  const [expandedRows, setExpandedRows] = useState<Set<number>>(new Set());

  const toggleExpand = useCallback((idx: number) => {
    setExpandedRows((prev) => {
      const next = new Set(prev);
      if (next.has(idx)) next.delete(idx);
      else next.add(idx);
      return next;
    });
  }, []);

  useEffect(() => {
    if (highlightIndex != null && highlightRef.current) {
      highlightRef.current.scrollIntoView({ behavior: "smooth", block: "center" });
    }
  }, [highlightIndex, data]);

  const notableKeys = useMemo(() => {
    if (!notableTrades?.length) return new Set<string>();
    return new Set(notableTrades.map((t) => `${t.symbol}|${t.sell_date}`));
  }, [notableTrades]);

  const isNotable = useCallback(
    (row: Trade): "best" | "worst" | null => {
      if (!notableKeys.size) return null;
      const sym = String(row["股票代码"] ?? row["symbol"] ?? "").padStart(6, "0");
      const sellDate = String(row["卖出日期"] ?? row["exit_date"] ?? "");
      const key = `${sym}|${sellDate}`;
      if (!notableKeys.has(key)) return null;
      const match = notableTrades?.find((t) => `${t.symbol}|${t.sell_date}` === key);
      return match && match.pnl_pct >= 0 ? "best" : "worst";
    },
    [notableKeys, notableTrades],
  );

  const cols = useMemo(() => {
    const raw = (externalCols && externalCols.length > 0) ? externalCols : (data.length ? Object.keys(data[0]) : []);
    return raw.filter((c) => !HIDDEN_COLS.has(c));
  }, [data, externalCols]);

  function handleSort(col: string) {
    if (!onSort) return;
    const newDir = sortCol === col && sortDir === "desc" ? "asc" : "desc";
    onSort(col, newDir);
  }

  if (!data.length) {
    return <p className="text-muted-foreground text-sm py-8 text-center">No trades</p>;
  }

  const isMaster = source === "master" || cols.includes("股票代码");
  const frozenCols = cols.slice(0, FROZEN_COUNT);
  const scrollCols = cols.slice(FROZEN_COUNT);
  const frozenWidths = frozenCols.map((c) => {
    if (c === "股票代码" || c === "symbol") return 90;
    if (c === "股票名称") return 100;
    return COL_MIN_W;
  });
  const frozenTotalW = frozenWidths.reduce((a, b) => a + b, 0);

  return (
    <div className="relative rounded-lg border border-border">
      <div
        ref={scrollRef}
        className="overflow-auto"
        style={{ maxHeight: "70vh" }}
      >
        <table className="text-xs border-collapse" style={{ minWidth: frozenTotalW + scrollCols.length * COL_MIN_W }}>
          <thead className="sticky top-0 z-30 bg-muted">
            <tr>
              {frozenCols.map((col, i) => {
                const left = frozenWidths.slice(0, i).reduce((a, b) => a + b, 0);
                return (
                  <th
                    key={col}
                    className={cn(
                      "sticky z-40 bg-muted px-2 py-1.5 text-left font-medium text-muted-foreground border-b border-r border-border whitespace-nowrap",
                      onSort && "cursor-pointer select-none",
                    )}
                    style={{ left, minWidth: frozenWidths[i], maxWidth: frozenWidths[i] }}
                    onClick={() => handleSort(col)}
                  >
                    {col}
                    {sortCol === col ? (sortDir === "asc" ? " ↑" : " ↓") : ""}
                  </th>
                );
              })}
              {scrollCols.map((col) => (
                <th
                  key={col}
                  className={cn(
                    "px-2 py-1.5 text-left font-medium text-muted-foreground border-b border-r border-border whitespace-nowrap",
                    onSort && "cursor-pointer select-none",
                  )}
                  style={{ minWidth: COL_MIN_W, maxWidth: COL_MAX_W }}
                  onClick={() => handleSort(col)}
                >
                  {col}
                  {sortCol === col ? (sortDir === "asc" ? " ↑" : " ↓") : ""}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {data.map((row, ri) => {
              const ntKind = isNotable(row);
              const isHighlighted = highlightIndex === ri;
              const entryCount = getEntryCount(row);
              const hasMultiLegs = entryCount > 1;
              const isExpanded = expandedRows.has(ri);
              const legs = isExpanded ? parseEntryLegs(row) : null;
              const rowBg = isHighlighted
                ? "bg-primary/15 hover:bg-primary/20 animate-pulse-once"
                : ntKind === "best"
                  ? "bg-up/8 hover:bg-up/15"
                  : ntKind === "worst"
                    ? "bg-down/8 hover:bg-down/15"
                    : "hover:bg-muted/30";
              const frozenBg = isHighlighted
                ? "[background:color-mix(in_srgb,var(--color-card)_85%,var(--color-primary))]"
                : ntKind === "best"
                  ? "[background:color-mix(in_srgb,var(--color-card)_92%,var(--color-up))]"
                  : ntKind === "worst"
                    ? "[background:color-mix(in_srgb,var(--color-card)_92%,var(--color-down))]"
                    : "bg-card";
              return [
                <tr
                  key={ri}
                  ref={isHighlighted ? highlightRef : undefined}
                  className={cn("transition-colors", rowBg, hasMultiLegs && "cursor-pointer")}
                  onClick={hasMultiLegs ? () => toggleExpand(ri) : undefined}
                >
                  {frozenCols.map((col, ci) => {
                    const left = frozenWidths.slice(0, ci).reduce((a, b) => a + b, 0);
                    const cc = cellColor(row[col], col);
                    return (
                      <td
                        key={col}
                        className={cn(
                          "sticky z-20 px-2 py-1 border-b border-r border-border whitespace-nowrap",
                          frozenBg,
                          cc,
                        )}
                        style={{ left, minWidth: frozenWidths[ci], maxWidth: frozenWidths[ci] }}
                      >
                        <span className="inline-flex items-center gap-1">
                          {ci === 0 && hasMultiLegs && (
                            isExpanded
                              ? <ChevronDown className="h-3 w-3 text-muted-foreground shrink-0" />
                              : <ChevronRight className="h-3 w-3 text-muted-foreground shrink-0" />
                          )}
                          {formatCell(row[col], col)}
                          {ci === 0 && ntKind && (
                            <span className={cn(
                              "inline-block w-1.5 h-1.5 rounded-full",
                              ntKind === "best" ? "bg-up" : "bg-down",
                            )} />
                          )}
                          {ci === 0 && hasMultiLegs && (
                            <span className="rounded bg-amber-500/15 text-amber-700 dark:text-amber-400 px-1 py-px text-[9px] font-medium leading-none">
                              {entryCount}次进场
                            </span>
                          )}
                        </span>
                      </td>
                    );
                  })}
                  {scrollCols.map((col) => {
                    const cc = cellColor(row[col], col);
                    return (
                      <td
                        key={col}
                        className={cn("px-2 py-1 border-b border-r border-border whitespace-nowrap", cc)}
                        style={{ minWidth: COL_MIN_W, maxWidth: COL_MAX_W }}
                      >
                        {formatCell(row[col], col)}
                      </td>
                    );
                  })}
                </tr>,
                ...(isExpanded && legs ? legs.map((leg, li) => (
                  <tr key={`${ri}-leg-${li}`} className="bg-muted/20">
                    {frozenCols.map((col, ci) => {
                      const left = frozenWidths.slice(0, ci).reduce((a, b) => a + b, 0);
                      return (
                        <td
                          key={col}
                          className="sticky z-20 px-2 py-0.5 border-b border-r border-border/50 whitespace-nowrap bg-muted/20 text-muted-foreground"
                          style={{ left, minWidth: frozenWidths[ci], maxWidth: frozenWidths[ci] }}
                        >
                          {ci === 0 && <span className="pl-4 text-[10px]">└ 第{li + 1}笔</span>}
                        </td>
                      );
                    })}
                    {scrollCols.map((col) => {
                      let content = "";
                      if (col === "买入日期" || col === "entry_date") content = leg.date;
                      else if (col === "买入价" || col === "entry_price") content = leg.price.toFixed(4);
                      else if (col.includes("qty") || col === "数量") content = String(leg.qty);
                      return (
                        <td
                          key={col}
                          className="px-2 py-0.5 border-b border-r border-border/50 whitespace-nowrap text-[10px] text-muted-foreground"
                          style={{ minWidth: COL_MIN_W, maxWidth: COL_MAX_W }}
                        >
                          {content}
                        </td>
                      );
                    })}
                  </tr>
                )) : []),
              ];
            })}
          </tbody>
        </table>
      </div>
      {isMaster && (
        <div className="px-3 py-1.5 text-[10px] text-muted-foreground border-t border-border bg-muted/30">
          左侧2列已固定 · 水平滚动查看更多
        </div>
      )}
    </div>
  );
}
