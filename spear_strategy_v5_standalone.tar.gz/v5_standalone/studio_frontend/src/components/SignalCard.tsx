import { cn } from "../lib/utils";

interface Signal {
  symbol: string;
  name?: string;
  event_type: string;
  signal_date: string;
  signal_confidence: number;
  entry_style?: string;
  gate_price?: number | null;
  signal_close: number;
  theme_label?: string;
  peer_confirmation?: number;
  leader_strength?: number;
  sector_hot?: boolean;
}

interface Props {
  signal: Signal;
}

export function SignalCard({ signal: s }: Props) {
  const confColor =
    s.signal_confidence >= 0.78
      ? "text-success"
      : s.signal_confidence >= 0.68
        ? "text-primary"
        : "text-muted-foreground";

  return (
    <div className="rounded-lg border border-border bg-card p-4 hover:shadow-md transition-shadow">
      <div className="flex items-start justify-between mb-2">
        <div>
          <span className="font-mono text-base font-semibold">{s.symbol}</span>
          {s.name && <span className="ml-2 text-sm text-muted-foreground">{s.name}</span>}
        </div>
        <span className={cn("text-sm font-bold", confColor)}>
          {(s.signal_confidence * 100).toFixed(0)}%
        </span>
      </div>
      <div className="flex flex-wrap gap-2 text-xs">
        <span className="rounded bg-accent px-2 py-0.5 font-medium">{s.event_type}</span>
        {s.entry_style && (
          <span className="rounded bg-accent px-2 py-0.5">{s.entry_style}</span>
        )}
        {s.theme_label && s.theme_label !== "其他" && (
          <span className="rounded bg-primary/10 text-primary px-2 py-0.5">{s.theme_label}</span>
        )}
        {s.sector_hot && (
          <span className="rounded bg-warning/20 text-warning px-2 py-0.5 font-medium">🔥 Hot</span>
        )}
      </div>
      <div className="mt-2 grid grid-cols-3 gap-2 text-xs text-muted-foreground">
        <div>
          <span className="block text-foreground font-medium">¥{s.signal_close.toFixed(2)}</span>
          Close
        </div>
        {s.gate_price != null && (
          <div>
            <span className="block text-foreground font-medium">¥{s.gate_price.toFixed(2)}</span>
            Gate
          </div>
        )}
        <div>
          <span className="block text-foreground font-medium">{s.peer_confirmation ?? 0}</span>
          Peers
        </div>
      </div>
    </div>
  );
}
