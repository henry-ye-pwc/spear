import { useMemo } from "react";
import {
  Area,
  AreaChart,
  CartesianGrid,
  Line,
  ReferenceDot,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import type { EquityPoint, NotableTrade } from "../lib/api";
import { cn } from "../lib/utils";

interface Props {
  data: EquityPoint[];
  notableTrades?: NotableTrade[];
  oracleCurve?: EquityPoint[];
}

interface EnrichedPoint {
  date: string;
  equity: number;
  returnPct: number;
  oracleReturnPct?: number;
  trades?: NotableTrade[];
}

function CustomTooltip({
  active,
  payload,
  label,
}: {
  active?: boolean;
  payload?: { payload: EnrichedPoint }[];
  label?: string;
}) {
  if (!active || !payload?.length) return null;
  const point = payload[0].payload;
  return (
    <div className="rounded-lg border border-border bg-card p-2.5 shadow-lg text-xs min-w-[180px]">
      <p className="font-medium mb-1">{label}</p>
      <p>
        Return: <span className={cn("font-semibold", point.returnPct >= 0 ? "text-up" : "text-down")}>
          {point.returnPct >= 0 ? "+" : ""}{point.returnPct.toFixed(2)}%
        </span>
      </p>
      <p className="text-muted-foreground">Equity: ¥{point.equity.toLocaleString(undefined, { maximumFractionDigits: 0 })}</p>
      {point.oracleReturnPct !== undefined && (
        <p className="text-amber-600 dark:text-amber-400 mt-0.5">
          Oracle: {point.oracleReturnPct >= 0 ? "+" : ""}{point.oracleReturnPct.toFixed(2)}%
          <span className="text-muted-foreground ml-1">
            (Δ {(point.oracleReturnPct - point.returnPct) >= 0 ? "+" : ""}
            {(point.oracleReturnPct - point.returnPct).toFixed(2)}%)
          </span>
        </p>
      )}
      {point.trades && point.trades.length > 0 && (
        <div className="mt-1.5 pt-1.5 border-t border-border space-y-1.5">
          {point.trades.map((t) => (
            <div key={`${t.symbol}-${t.sell_date}`}>
              <div className="flex items-center gap-1.5">
                <span className="font-mono font-semibold">{t.symbol}</span>
                {t.name && <span className="text-muted-foreground">{t.name}</span>}
                <span className={cn("font-bold ml-auto", t.pnl_pct >= 0 ? "text-up" : "text-down")}>
                  {t.pnl_pct >= 0 ? "+" : ""}{t.pnl_pct.toFixed(2)}%
                </span>
              </div>
              <div className="text-muted-foreground">
                {t.buy_date} ¥{t.buy_price} → ¥{t.sell_price} · {t.reason}
              </div>
              <div className="text-muted-foreground flex gap-1.5 flex-wrap mt-0.5">
                {t.mfe_pct != null && (
                  <span className="text-amber-600 dark:text-amber-400">MFE +{t.mfe_pct.toFixed(1)}%</span>
                )}
                {t.signal_type && <span className="bg-muted rounded px-1">{t.signal_type}</span>}
                {t.post_trend && <span>{t.post_trend}</span>}
                {t.diagnosis && <span className={t.diagnosis === "标的完全选错" ? "text-red-500" : ""}>{t.diagnosis}</span>}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export function EquityChart({ data, notableTrades = [], oracleCurve }: Props) {
  if (!data.length) {
    return <p className="text-muted-foreground text-sm py-8 text-center">No equity data</p>;
  }

  const initEquity = data[0].equity;

  const tradesByDate = useMemo(() => {
    const m = new Map<string, NotableTrade[]>();
    for (const t of notableTrades) {
      const arr = m.get(t.sell_date) ?? [];
      arr.push(t);
      m.set(t.sell_date, arr);
    }
    return m;
  }, [notableTrades]);

  const oracleByDate = useMemo(() => {
    if (!oracleCurve?.length) return null;
    const m = new Map<string, number>();
    const oracleInit = oracleCurve[0].equity;
    for (const p of oracleCurve) {
      m.set(p.date, (p.equity / oracleInit - 1) * 100);
    }
    return m;
  }, [oracleCurve]);

  const enriched: EnrichedPoint[] = useMemo(() => {
    return data.map((d) => {
      const pt: EnrichedPoint = {
        ...d,
        returnPct: (d.equity / initEquity - 1) * 100,
        trades: tradesByDate.get(d.date),
      };
      if (oracleByDate) {
        const oVal = oracleByDate.get(d.date);
        if (oVal !== undefined) {
          pt.oracleReturnPct = oVal;
        }
      }
      return pt;
    });
  }, [data, initEquity, tradesByDate, oracleByDate]);

  // Fill forward oracle values for dates between oracle data points
  const filled: EnrichedPoint[] = useMemo(() => {
    if (!oracleByDate) return enriched;
    let lastOracle: number | undefined;
    return enriched.map((pt) => {
      if (pt.oracleReturnPct !== undefined) {
        lastOracle = pt.oracleReturnPct;
      }
      return lastOracle !== undefined && pt.oracleReturnPct === undefined
        ? { ...pt, oracleReturnPct: lastOracle }
        : pt;
    });
  }, [enriched, oracleByDate]);

  const markerPoints = useMemo(() => {
    return notableTrades
      .map((t) => {
        const pt = filled.find((d) => d.date === t.sell_date);
        if (!pt) return null;
        return { trade: t, returnPct: pt.returnPct };
      })
      .filter(Boolean) as { trade: NotableTrade; returnPct: number }[];
  }, [notableTrades, filled]);

  const showOracle = oracleByDate !== null;

  return (
    <ResponsiveContainer width="100%" height={360}>
      <AreaChart data={filled} margin={{ top: 10, right: 20, left: 10, bottom: 0 }}>
        <defs>
          <linearGradient id="eqFill" x1="0" y1="0" x2="0" y2="1">
            <stop offset="5%" stopColor="var(--color-primary)" stopOpacity={0.3} />
            <stop offset="95%" stopColor="var(--color-primary)" stopOpacity={0} />
          </linearGradient>
          <linearGradient id="oracleFill" x1="0" y1="0" x2="0" y2="1">
            <stop offset="5%" stopColor="#f59e0b" stopOpacity={0.12} />
            <stop offset="95%" stopColor="#f59e0b" stopOpacity={0} />
          </linearGradient>
        </defs>
        <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
        <XAxis dataKey="date" tick={{ fontSize: 11 }} tickFormatter={(v: string) => v.slice(5)} />
        <YAxis
          dataKey={showOracle ? undefined : "returnPct"}
          tick={{ fontSize: 11 }}
          tickFormatter={(v: number) => `${v.toFixed(1)}%`}
          domain={["auto", "auto"]}
        />
        <Tooltip content={<CustomTooltip />} />
        {showOracle && (
          <Area
            type="monotone"
            dataKey="oracleReturnPct"
            stroke="#f59e0b"
            fill="url(#oracleFill)"
            strokeWidth={2}
            strokeDasharray="6 3"
            name="Oracle"
            dot={false}
            connectNulls
            isAnimationActive={false}
          />
        )}
        <Area
          type="monotone"
          dataKey="returnPct"
          stroke="var(--color-primary)"
          fill="url(#eqFill)"
          strokeWidth={2}
          name="Actual"
        />
        {showOracle && (
          <Line
            type="monotone"
            dataKey="oracleReturnPct"
            stroke="#f59e0b"
            strokeWidth={0}
            dot={false}
            activeDot={false}
            connectNulls
            legendType="none"
          />
        )}
        {markerPoints.map((m) => (
          <ReferenceDot
            key={`${m.trade.symbol}-${m.trade.sell_date}`}
            x={m.trade.sell_date}
            y={m.returnPct}
            r={5}
            fill={m.trade.pnl_pct >= 0 ? "var(--color-up)" : "var(--color-down)"}
            stroke="#fff"
            strokeWidth={2}
          />
        ))}
      </AreaChart>
    </ResponsiveContainer>
  );
}

export function TradeMarkerLegend({
  trades,
  onTradeClick,
}: {
  trades: NotableTrade[];
  onTradeClick?: (t: NotableTrade) => void;
}) {
  if (!trades.length) return null;
  const best = trades.filter((t) => t.pnl_pct >= 0).sort((a, b) => b.pnl_pct - a.pnl_pct);
  const worst = trades.filter((t) => t.pnl_pct < 0).sort((a, b) => a.pnl_pct - b.pnl_pct);
  const clickable = !!onTradeClick;

  const tableBlock = (items: NotableTrade[], color: string, sign: string, title: string) => (
    <div>
      <p className={cn("font-medium mb-1.5", color)}>
        {title}
        {clickable && <span className="text-muted-foreground font-normal ml-1">(click to locate)</span>}
      </p>
      <table className="w-full border-collapse">
        <thead>
          <tr className="text-[10px] text-muted-foreground">
            <th className="text-left font-normal pr-2 pb-0.5">代码</th>
            <th className="text-left font-normal pr-2 pb-0.5">名称</th>
            <th className="text-left font-normal pr-2 pb-0.5">日期</th>
            <th className="text-right font-normal pr-2 pb-0.5">盈亏</th>
            <th className="text-right font-normal pr-2 pb-0.5">MFE</th>
            <th className="text-left font-normal pr-2 pb-0.5">类型</th>
            <th className="text-left font-normal pr-2 pb-0.5">后续走向</th>
            <th className="text-left font-normal pb-0.5">诊断</th>
          </tr>
        </thead>
        <tbody>
          {items.map((t) => (
            <tr
              key={`${t.symbol}-${t.sell_date}`}
              className={cn(
                "border-t border-border/30",
                clickable && "cursor-pointer hover:bg-muted/50 transition-colors",
              )}
              onClick={() => onTradeClick?.(t)}
              role={clickable ? "button" : undefined}
            >
              <td className="font-mono pr-2 py-0.5">{t.symbol}</td>
              <td className="text-muted-foreground pr-2 py-0.5 max-w-16 truncate">{t.name}</td>
              <td className="text-muted-foreground pr-2 py-0.5 whitespace-nowrap">{t.sell_date.slice(5)}</td>
              <td className={cn("text-right pr-2 py-0.5 font-medium tabular-nums whitespace-nowrap", color)}>
                {sign}{t.pnl_pct.toFixed(1)}%
              </td>
              <td className="text-right pr-2 py-0.5 tabular-nums text-amber-600 dark:text-amber-400 whitespace-nowrap">
                {t.mfe_pct != null ? `+${t.mfe_pct.toFixed(1)}%` : "—"}
              </td>
              <td className="pr-2 py-0.5">
                {t.signal_type && (
                  <span className="text-muted-foreground bg-muted rounded px-1 py-0.5 text-[10px]">{t.signal_type}</span>
                )}
              </td>
              <td className="pr-2 py-0.5 text-muted-foreground max-w-20 truncate text-[10px]">{t.post_trend || ""}</td>
              <td className="py-0.5">
                {t.diagnosis && (
                  <span className={cn(
                    "rounded px-1 py-0.5 text-[10px]",
                    t.diagnosis === "标的完全选错" ? "bg-red-500/15 text-red-500" : "bg-muted text-muted-foreground",
                  )}>{t.diagnosis}</span>
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 mt-3 text-xs">
      {best.length > 0 && tableBlock(best, "text-up", "+", "Best Trades")}
      {worst.length > 0 && tableBlock(worst, "text-down", "", "Worst Trades")}
    </div>
  );
}
