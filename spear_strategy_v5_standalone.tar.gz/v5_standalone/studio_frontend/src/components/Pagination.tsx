import { ChevronLeft, ChevronRight, ChevronsLeft, ChevronsRight } from "lucide-react";
import { cn } from "../lib/utils";

interface Props {
  page: number;
  totalPages: number;
  totalItems: number;
  pageSize: number;
  onPageChange: (page: number) => void;
}

export function Pagination({ page, totalPages, totalItems, pageSize, onPageChange }: Props) {
  if (totalPages <= 1) return null;
  const start = page * pageSize + 1;
  const end = Math.min((page + 1) * pageSize, totalItems);
  return (
    <div className="flex items-center justify-between pt-2">
      <span className="text-[10px] text-muted-foreground tabular-nums">
        {start}–{end} / {totalItems}
      </span>
      <div className="flex items-center gap-0.5">
        <PgBtn disabled={page === 0} onClick={() => onPageChange(0)} title="首页">
          <ChevronsLeft className="h-3 w-3" />
        </PgBtn>
        <PgBtn disabled={page === 0} onClick={() => onPageChange(page - 1)} title="上一页">
          <ChevronLeft className="h-3 w-3" />
        </PgBtn>
        <span className="px-2 text-[10px] tabular-nums text-muted-foreground">
          {page + 1} / {totalPages}
        </span>
        <PgBtn disabled={page >= totalPages - 1} onClick={() => onPageChange(page + 1)} title="下一页">
          <ChevronRight className="h-3 w-3" />
        </PgBtn>
        <PgBtn disabled={page >= totalPages - 1} onClick={() => onPageChange(totalPages - 1)} title="末页">
          <ChevronsRight className="h-3 w-3" />
        </PgBtn>
      </div>
    </div>
  );
}

function PgBtn({ disabled, onClick, title, children }: {
  disabled: boolean; onClick: () => void; title: string; children: React.ReactNode;
}) {
  return (
    <button
      disabled={disabled}
      onClick={onClick}
      title={title}
      className={cn(
        "rounded p-1 transition-colors",
        disabled ? "text-muted-foreground/30 cursor-not-allowed" : "text-muted-foreground hover:bg-accent hover:text-foreground",
      )}
    >
      {children}
    </button>
  );
}
