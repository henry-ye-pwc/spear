import { useState } from "react";
import { cn } from "../lib/utils";
import type { CeilingData, OverviewStats, ResultOverview } from "../lib/api";

interface Props {
  overview: ResultOverview;
  showCeiling: boolean;
  onCeilingToggle: (v: boolean) => void;
}

function Stat({ label, value, sub, color }: { label: string; value: string; sub?: string; color?: string }) {
  return (
    <div className="flex flex-col">
      <span className="text-[10px] text-muted-foreground uppercase tracking-wide">{label}</span>
      <span className={cn("text-lg font-semibold tabular-nums", color)}>{value}</span>
      {sub && <span className="text-[10px] text-muted-foreground">{sub}</span>}
    </div>
  );
}

function pct(v: number | undefined, digits = 2): string {
  if (v === undefined || v === null) return "—";
  return `${v >= 0 ? "+" : ""}${v.toFixed(digits)}%`;
}

function money(v: number | undefined): string {
  if (v === undefined || v === null) return "—";
  return `¥${v.toLocaleString()}`;
}

function retColor(v: number | undefined): string | undefined {
  if (v === undefined || v === null) return undefined;
  return v > 0 ? "text-up" : v < 0 ? "text-down" : undefined;
}

const DIAG_HINTS: Record<string, { color: string; tip: string }> = {
  "盈利且接近MFE高点": {
    color: "bg-up/80",
    tip: "盈利出场，且卖在接近持仓期最高点附近，出场时机理想",
  },
  "盈利且兑现合理": {
    color: "bg-up/60",
    tip: "盈利出场，虽未卖在最高点但兑现合理，MFE与实际收益差距不大",
  },
  "盈利但明显卖早": {
    color: "bg-amber-400/70",
    tip: "盈利出场，但持仓期最高浮盈远超实际收益 (MFE ≥ ret+10%)，卖早了不少",
  },
  "卖飞/止损过早": {
    color: "bg-orange-400/70",
    tip: "亏损出场，但退出后20天股价大幅反弹 (≥10%)，说明方向对了但拿不住",
  },
  "进出场时机错误": {
    color: "bg-orange-500/70",
    tip: "亏损出场，持仓期间曾有 ≥8% 浮盈却没兑现，时机把握失误",
  },
  "进场偏早/拿不住": {
    color: "bg-yellow-500/60",
    tip: "亏损出场，持仓期浮盈有限 (<5%)，但退出后20天相对入场价涨 ≥10%，进场偏早",
  },
  "标的完全选错": {
    color: "bg-down/80",
    tip: "亏损出场 · 持仓期最高浮盈不足3% · 退出后20天涨幅不足5% · 退出后也未反弹，标的本身无行情",
  },
  "一般性失败": {
    color: "bg-slate-400/60",
    tip: "亏损出场，不符合以上任何特定失败模式的兜底分类",
  },
};

function Tip({ text }: { text: string }) {
  const [show, setShow] = useState(false);
  return (
    <span
      className="relative inline-flex items-center ml-0.5 cursor-help"
      onMouseEnter={() => setShow(true)}
      onMouseLeave={() => setShow(false)}
    >
      <svg className="w-3 h-3 text-muted-foreground/60 hover:text-foreground transition-colors" viewBox="0 0 16 16" fill="currentColor">
        <path d="M8 1a7 7 0 100 14A7 7 0 008 1zm0 2.5a1 1 0 110 2 1 1 0 010-2zM6.5 7h2v4.5h-2V7z" />
      </svg>
      {show && (
        <span className="pointer-events-none absolute bottom-full right-0 mb-1.5 px-2.5 py-1.5 rounded-md bg-foreground text-background text-[10px] leading-snug whitespace-normal w-52 text-left z-50 shadow-lg">
          {text}
        </span>
      )}
    </span>
  );
}

function DiagBreakdown({ diag }: { diag: Record<string, number> }) {
  const entries = Object.entries(diag).sort((a, b) => b[1] - a[1]);
  if (entries.length === 0) return null;
  const total = entries.reduce((s, [, c]) => s + c, 0);
  return (
    <div className="space-y-1.5">
      <p className="text-[10px] font-medium text-muted-foreground uppercase tracking-wide mb-1.5">交易诊断分布</p>
      {entries.map(([label, count]) => {
        const hint = DIAG_HINTS[label];
        return (
          <div key={label} className="flex items-center gap-2 text-xs">
            <div className="flex-1 h-2 rounded-full bg-muted overflow-hidden">
              <div
                className={cn("h-full rounded-full", hint?.color ?? "bg-primary/60")}
                style={{ width: `${(count / total) * 100}%` }}
              />
            </div>
            <span className="w-28 truncate text-right text-muted-foreground">{label}</span>
            {hint && <Tip text={hint.tip} />}
            <span className="tabular-nums w-8 text-right font-medium">{count}</span>
          </div>
        );
      })}
    </div>
  );
}

function CeilingComparison({ ceiling }: { ceiling: CeilingData }) {
  return (
    <div className="rounded-lg border border-amber-500/30 bg-amber-50/30 dark:bg-amber-950/10 p-4 space-y-3">
      <div className="flex items-center gap-2">
        <span className="text-sm font-semibold text-amber-700 dark:text-amber-400">理论天花板 (Oracle MFE Exit)</span>
      </div>
      <p className="text-xs text-muted-foreground">
        信号入场不变 · "标的完全选错" 保持现有出场 ({ceiling.wrong_count} 笔) · 其余交易按 MFE+20d 最高点出场
      </p>
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="space-y-0.5">
          <p className="text-[10px] text-muted-foreground">实际收益</p>
          <p className={cn("text-base font-semibold tabular-nums", retColor(ceiling.actual_return_pct))}>
            {pct(ceiling.actual_return_pct)}
          </p>
          <p className="text-[10px] text-muted-foreground">{money(ceiling.actual_equity)}</p>
        </div>
        <div className="space-y-0.5">
          <p className="text-[10px] text-muted-foreground">天花板收益</p>
          <p className={cn("text-base font-semibold tabular-nums", retColor(ceiling.ceiling_return_pct))}>
            {pct(ceiling.ceiling_return_pct)}
          </p>
          <p className="text-[10px] text-muted-foreground">{money(ceiling.ceiling_equity)}</p>
        </div>
        <div className="space-y-0.5">
          <p className="text-[10px] text-muted-foreground">提升空间</p>
          <p className="text-base font-semibold tabular-nums text-amber-600 dark:text-amber-400">
            +{ceiling.ceiling_uplift_pct.toFixed(2)}%
          </p>
        </div>
        <div className="space-y-0.5">
          <p className="text-[10px] text-muted-foreground">天花板胜率</p>
          <p className="text-base font-semibold tabular-nums">
            {(ceiling.ceiling_win_rate * 100).toFixed(1)}%
          </p>
        </div>
      </div>
    </div>
  );
}

export function OverviewPanel({ overview, showCeiling, onCeilingToggle }: Props) {
  const { summary, stats, ceiling } = overview;
  const hasStats = stats && "total_closed" in stats;
  const s = hasStats ? (stats as OverviewStats) : null;

  return (
    <div className="space-y-4">
      <div className="rounded-lg border border-border bg-muted/30 p-4">
        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-6 gap-4">
          <Stat
            label="总收益"
            value={pct(Number(summary.equity_return_pct))}
            sub={`${money(Number(summary.init_cash))} → ${money(Number(summary.equity_final))}`}
            color={retColor(Number(summary.equity_return_pct))}
          />
          <Stat
            label="最终净值"
            value={money(Number(summary.equity_final))}
            sub={`净利润 ${money(Number(summary.equity_final) - Number(summary.init_cash))}`}
            color={retColor(Number(summary.equity_final) - Number(summary.init_cash))}
          />
          {s?.peak_equity !== undefined && (
            <Stat
              label="最高净值"
              value={money(s.peak_equity)}
              sub={`距峰值 ${pct(((Number(summary.equity_final) / s.peak_equity) - 1) * 100)}`}
            />
          )}
          {s?.max_drawdown_pct !== undefined && (
            <Stat
              label="最大回撤"
              value={pct(s.max_drawdown_pct)}
              sub={s.max_drawdown_amount !== undefined ? money(s.max_drawdown_amount) : undefined}
              color="text-down"
            />
          )}
          <Stat
            label="买入 / 卖出"
            value={`${summary.buy_count ?? 0} / ${summary.sell_count ?? 0}`}
            sub={Number(summary.open_count) > 0
              ? `${summary.open_count} 持仓中 · 市值 ${money(Number(summary.open_market_value))}`
              : undefined}
          />
          <Stat
            label="信号总数"
            value={String(summary.event_count ?? 0)}
          />
        </div>
      </div>

      {s && (
        <div className="rounded-lg border border-border bg-muted/30 p-4 space-y-4">
          <h4 className="text-sm font-semibold">已平仓交易统计 ({s.total_closed} 笔)</h4>
          <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-6 gap-4">
            <Stat
              label="胜率"
              value={`${(s.win_rate * 100).toFixed(1)}%`}
              sub={`${s.win_count}W / ${s.loss_count}L`}
              color={s.win_rate >= 0.5 ? "text-up" : "text-down"}
            />
            <Stat
              label="平均收益"
              value={pct(s.avg_ret_pct)}
              color={retColor(s.avg_ret_pct)}
            />
            {s.avg_win_ret_pct !== undefined && (
              <Stat label="平均盈利" value={pct(s.avg_win_ret_pct)} color="text-up" />
            )}
            {s.avg_loss_ret_pct !== undefined && (
              <Stat label="平均亏损" value={pct(s.avg_loss_ret_pct)} color="text-down" />
            )}
            <Stat label="平均持仓" value={`${s.avg_hold_days.toFixed(1)} 天`} />
            <Stat
              label="MFE / MAE"
              value={`${pct(s.avg_mfe_pct)} / ${pct(s.avg_mae_pct)}`}
              sub={`捕获率 ${(s.avg_mfe_capture * 100).toFixed(1)}%`}
            />
          </div>

          {Object.keys(s.diagnosis).length > 0 && (
            <DiagBreakdown diag={s.diagnosis} />
          )}
        </div>
      )}

      {ceiling && (
        <div className="space-y-2">
          <label className="flex items-center gap-2 cursor-pointer select-none">
            <input
              type="checkbox"
              checked={showCeiling}
              onChange={(e) => onCeilingToggle(e.target.checked)}
              className="rounded border-border"
            />
            <span className="text-sm font-medium">显示理论天花板 (Oracle MFE Exit)</span>
          </label>
          {showCeiling && <CeilingComparison ceiling={ceiling} />}
        </div>
      )}
    </div>
  );
}
