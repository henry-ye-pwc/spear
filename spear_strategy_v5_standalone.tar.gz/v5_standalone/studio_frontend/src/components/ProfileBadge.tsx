import { AlertTriangle } from "lucide-react";
import { cn } from "../lib/utils";

const PROFILES: Record<string, { label: string; color: string; tooltip: string }> = {
  day_level_ideal: {
    label: "Day Level Ideal",
    color: "bg-warning/20 text-warning",
    tooltip: "以信号当日收盘价入场。实盘不可实现（信号在收盘后才确认），仅用于策略天花板分析。",
  },
  next_open_realistic: {
    label: "Next Open",
    color: "bg-success/20 text-success",
    tooltip: "以信号次日开盘价入场。最接近实盘的模拟方式，考虑了隔夜价差。",
  },
  delayed_limit_hunt: {
    label: "Limit Hunt",
    color: "bg-primary/20 text-primary",
    tooltip: "信号触发后，在数日窗口内挂限价单等待回踩入场。更保守，追求更好的入场价格。",
  },
};

interface Props {
  profile: string;
  showWarning?: boolean;
}

export function ProfileBadge({ profile, showWarning = true }: Props) {
  const info = PROFILES[profile] ?? { label: profile, color: "bg-muted text-muted-foreground", tooltip: "" };
  return (
    <span className="inline-flex items-center gap-1.5">
      <span
        className={cn("inline-block rounded-full px-2.5 py-0.5 text-xs font-medium cursor-help", info.color)}
        title={info.tooltip}
      >
        {info.label}
      </span>
      {info.tooltip && (
        <span className="text-[11px] text-muted-foreground max-w-xs leading-tight">
          {info.tooltip}
        </span>
      )}
      {profile === "day_level_ideal" && showWarning && (
        <AlertTriangle className="h-3.5 w-3.5 text-warning flex-shrink-0" />
      )}
    </span>
  );
}
