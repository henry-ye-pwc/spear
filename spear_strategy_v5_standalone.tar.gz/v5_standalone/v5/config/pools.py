from __future__ import annotations

import json
import re
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True, slots=True)
class NamedPool:
    name: str
    label: str
    source_path: Path
    description: str = ""
    builtin: bool = True


ROOT = Path(__file__).resolve().parents[2]
CUSTOM_POOLS_DIR = ROOT / "pools"

POOL_REGISTRY: dict[str, NamedPool] = {
    "code_txt_pool": NamedPool(
        name="code_txt_pool",
        label="Code TXT Pool",
        source_path=ROOT / "code.txt",
        description="Named pool parsed from code.txt in the standalone project root.",
    )
}


def _extract_symbols(text: str) -> list[str]:
    xml_hits = re.findall(r'code="(\d{6})"', text)
    if xml_hits:
        return sorted(dict.fromkeys(xml_hits))
    token_hits = re.findall(r"\b\d{6}\b", text)
    return sorted(dict.fromkeys(token_hits))


def _discover_custom_pools() -> dict[str, NamedPool]:
    """Scan CUSTOM_POOLS_DIR for user-created pool .json files."""
    if not CUSTOM_POOLS_DIR.exists():
        return {}
    pools: dict[str, NamedPool] = {}
    for meta_path in sorted(CUSTOM_POOLS_DIR.glob("*.json")):
        try:
            meta = json.loads(meta_path.read_text(encoding="utf-8"))
            name = meta["name"]
            symbols_path = CUSTOM_POOLS_DIR / f"{name}.txt"
            if not symbols_path.exists():
                continue
            pools[name] = NamedPool(
                name=name,
                label=meta.get("label", name),
                source_path=symbols_path,
                description=meta.get("description", ""),
                builtin=False,
            )
        except Exception:
            continue
    return pools


def _all_pools() -> dict[str, NamedPool]:
    merged = dict(POOL_REGISTRY)
    merged.update(_discover_custom_pools())
    return merged


def list_named_pools() -> list[dict]:
    out: list[dict] = []
    for pool in _all_pools().values():
        try:
            symbols = resolve_named_pool(pool.name)
            count = len(symbols)
        except Exception:
            count = 0
        out.append(
            {
                "name": pool.name,
                "label": pool.label,
                "source_path": str(pool.source_path),
                "description": pool.description,
                "symbol_count": count,
                "builtin": pool.builtin,
            }
        )
    out.sort(key=lambda x: x["name"])
    return out


def resolve_named_pool(name: str) -> list[str]:
    key = str(name or "").strip()
    all_pools = _all_pools()
    if key not in all_pools:
        raise KeyError(f"Unknown named pool: {name}")
    pool = all_pools[key]
    if not pool.source_path.exists():
        raise FileNotFoundError(f"Named pool source not found: {pool.source_path}")
    return _extract_symbols(pool.source_path.read_text(encoding="utf-8", errors="ignore"))


def save_custom_pool(name: str, label: str, symbols: list[str], description: str = "") -> dict:
    """Save a new custom pool (or overwrite an existing one)."""
    CUSTOM_POOLS_DIR.mkdir(parents=True, exist_ok=True)
    clean_name = re.sub(r"[^a-zA-Z0-9_-]", "_", name.strip())
    if not clean_name:
        raise ValueError("Pool name cannot be empty")
    if clean_name in POOL_REGISTRY:
        raise ValueError(f"Cannot overwrite built-in pool: {clean_name}")

    clean_symbols = sorted(dict.fromkeys(s.strip().zfill(6) for s in symbols if s.strip()))
    if not clean_symbols:
        raise ValueError("Pool must contain at least one symbol")

    symbols_path = CUSTOM_POOLS_DIR / f"{clean_name}.txt"
    meta_path = CUSTOM_POOLS_DIR / f"{clean_name}.json"

    symbols_path.write_text("\n".join(clean_symbols) + "\n", encoding="utf-8")
    meta = {"name": clean_name, "label": label or clean_name, "description": description}
    meta_path.write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")

    return {
        "name": clean_name,
        "label": meta["label"],
        "source_path": str(symbols_path),
        "description": description,
        "symbol_count": len(clean_symbols),
        "builtin": False,
    }


def delete_custom_pool(name: str) -> bool:
    """Delete a custom pool. Returns True if deleted, False if not found."""
    if name in POOL_REGISTRY:
        raise ValueError(f"Cannot delete built-in pool: {name}")
    symbols_path = CUSTOM_POOLS_DIR / f"{name}.txt"
    meta_path = CUSTOM_POOLS_DIR / f"{name}.json"
    deleted = False
    if symbols_path.exists():
        symbols_path.unlink()
        deleted = True
    if meta_path.exists():
        meta_path.unlink()
        deleted = True
    return deleted
