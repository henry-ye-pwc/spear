from __future__ import annotations

import json
import time
from dataclasses import dataclass
from typing import Any

import pandas as pd

try:  # pragma: no cover
    from akquant import ExecutionMode, run_backtest as ak_run_backtest
except Exception as exc:  # pragma: no cover
    ExecutionMode = None  # type: ignore[assignment]
    ak_run_backtest = None  # type: ignore[assignment]
    AKQUANT_IMPORT_ERROR = exc
else:  # pragma: no cover
    AKQUANT_IMPORT_ERROR = None

from v4.backtest.engine import BacktestResult
from v5.backtest.prepare import PreparedBundle, prepare_bundle
from v5.backtest.strategy_host import AKQuantSpearStrategy, SubmittedOrderMeta
from v5.config.defaults import V5Config


@dataclass(slots=True)
class V5RunArtifacts:
    result: BacktestResult
    bundle: PreparedBundle
    ak_result: Any
    strategy: AKQuantSpearStrategy


def _execution_mode(name: str) -> Any:
    if ExecutionMode is None:  # pragma: no cover
        raise RuntimeError("akquant is required for v5 runner") from AKQUANT_IMPORT_ERROR
    return getattr(ExecutionMode, name)


def _build_open_positions(
    strategy: AKQuantSpearStrategy,
    bundle: PreparedBundle,
    ak_result: Any,
    trades: list[dict],
) -> list[dict]:
    """Build open positions using actual filled quantities from trades.

    The state machine tracks *intended* qty (based on budget calculation),
    but akquant may partially fill or reject orders when cash is insufficient.
    We derive net positions from the filled orders list and enrich with
    metadata from the state machine (source_event, etc.).
    """
    net: dict[str, dict] = {}
    for t in trades:
        sym = str(t["symbol"]).zfill(6)
        qty = float(t["qty"])
        price = float(t["price"])
        if t["action"] == "buy":
            if sym not in net:
                meta = json.loads(t["meta"]) if isinstance(t["meta"], str) else (t.get("meta") or {})
                net[sym] = {
                    "qty": 0.0,
                    "cost": 0.0,
                    "entry_date": t["date"],
                    "source_event": t.get("reason", "").replace("entry:", ""),
                    "style": meta.get("style", "") if isinstance(meta, dict) else "",
                }
            net[sym]["qty"] += qty
            net[sym]["cost"] += qty * price
        elif t["action"] == "sell":
            if sym in net:
                net[sym]["qty"] -= qty
                if net[sym]["qty"] <= 0:
                    del net[sym]

    rows: list[dict] = []
    for sym, info in net.items():
        bars = bundle.feature_data.get(sym)
        if bars is None or bars.empty:
            continue
        last_close = float(bars.iloc[-1]["close"])
        qty = info["qty"]
        entry_price = info["cost"] / qty if qty > 0 else 0.0
        market_value = qty * last_close
        unrealized = market_value - qty * entry_price

        state_pos = strategy.state_machine.positions.get(sym)
        source_event = state_pos.source_event if state_pos else info["source_event"]

        entry_limit_up = None
        idx_map = bundle.idx_by_symbol_date.get(sym)
        if idx_map:
            entry_idx = idx_map.get(info["entry_date"])
            if entry_idx is not None:
                entry_row = bars.iloc[entry_idx]
                lu = entry_row.get("limit_up")
                if pd.notna(lu):
                    entry_limit_up = round(float(lu), 4)

        row_dict: dict = {
            "symbol": sym,
            "entry_date": info["entry_date"],
            "entry_price": round(entry_price, 4),
            "qty": qty,
            "source_event": source_event,
            "last_close": round(last_close, 4),
            "market_value": round(market_value, 4),
            "unrealized_pnl": round(unrealized, 4),
        }
        if entry_limit_up is not None:
            row_dict["entry_limit_up"] = entry_limit_up
        rows.append(row_dict)
    return rows


def _enrich_limit_prices(trades: list[dict], bundle: PreparedBundle) -> None:
    """Attach limit_up / limit_down to each trade for frontend display."""
    for t in trades:
        sym = str(t["symbol"]).zfill(6)
        frame = bundle.feature_data.get(sym)
        if frame is None:
            continue
        idx_map = bundle.idx_by_symbol_date.get(sym)
        if idx_map is None:
            continue
        idx = idx_map.get(t["date"])
        if idx is None:
            continue
        row = frame.iloc[idx]
        lp = float(row.get("limit_pct", 0.10))
        lu = row.get("limit_up")
        if pd.notna(lu):
            lu_f = float(lu)
            t["limit_up"] = round(lu_f, 4)
            prev_close = lu_f / (1 + lp)
            t["limit_down"] = round(prev_close * (1 - lp), 4)


def _filled_orders_to_trades(orders_df: pd.DataFrame, submitted_orders: dict[str, SubmittedOrderMeta], initial_cash: float) -> list[dict]:
    if orders_df is None or orders_df.empty:
        return []
    filled = orders_df.copy()
    filled["status"] = filled["status"].astype(str).str.lower()
    filled = filled[filled["status"] == "filled"].copy()
    if filled.empty:
        return []
    filled["updated_at"] = pd.to_datetime(filled["updated_at"])
    filled = filled.sort_values(["updated_at", "id"]).reset_index(drop=True)
    cash = float(initial_cash)
    trades: list[dict] = []
    for _, row in filled.iterrows():
        order_id = str(row["id"])
        meta = submitted_orders.get(order_id)
        if meta is None:
            continue
        price = float(row["avg_price"])
        qty = float(row["filled_quantity"])
        gross = price * qty
        fee_total = float(row.get("commission", 0.0) or 0.0)
        net_cash_delta = -(gross + fee_total) if meta.action == "buy" else gross - fee_total
        cash += net_cash_delta
        trades.append(
            {
                "date": str(pd.Timestamp(row["updated_at"]).date()),
                "symbol": meta.symbol,
                "action": meta.action,
                "price": round(price, 4),
                "qty": qty,
                "reason": meta.reason,
                "meta": {
                    "style": meta.meta.get("style", ""),
                    "exit_style": meta.meta.get("exit_style", ""),
                    "position_mult": meta.meta.get("position_mult"),
                    "gross_notional": round(gross, 4),
                    "fee_total": round(fee_total, 4),
                    "commission": round(fee_total, 4),
                    "net_cash_delta": round(net_cash_delta, 4),
                },
                "cash_after": round(cash, 2),
            }
        )
    for row in trades:
        row["meta"] = json.dumps(row["meta"], ensure_ascii=False, sort_keys=True)
    return trades


def run_backtest(
    cfg: V5Config,
    start: str,
    end: str,
    pool_size: int,
    initial_cash: float,
    symbols: list[str] | None = None,
    active_event_types: set[str] | None = None,
    bundle: PreparedBundle | None = None,
) -> V5RunArtifacts:
    if ak_run_backtest is None:  # pragma: no cover
        raise RuntimeError("akquant is required for v5 runner") from AKQUANT_IMPORT_ERROR

    if bundle is None:
        bundle = prepare_bundle(
            cfg,
            start=start,
            end=end,
            pool_size=pool_size,
            symbols=symbols,
            active_event_types=active_event_types,
        )
    t0 = time.monotonic()
    end_ts = pd.Timestamp(end)
    data = {}
    for symbol, df in bundle.raw_data.items():
        if df.index[-1] <= end_ts:
            data[symbol] = df
        else:
            data[symbol] = df.loc[:end_ts]
    strategy = AKQuantSpearStrategy(bundle=bundle, cfg=cfg, start=start)
    print(f"[backtest] data prep: {len(data)} symbols in {time.monotonic() - t0:.1f}s", flush=True)
    ak_result = ak_run_backtest(
        data=data,
        strategy=strategy,
        symbol=list(data.keys()),
        initial_cash=initial_cash,
        commission_rate=cfg.execution.commission_bps / 10000.0,
        stamp_tax_rate=cfg.execution.stamp_duty_bps / 10000.0,
        min_commission=cfg.execution.min_commission,
        slippage=(cfg.execution.buy_slippage_bps + cfg.execution.sell_slippage_bps) / 20000.0,
        execution_mode=_execution_mode(cfg.execution.execution_mode),
        timezone="Asia/Shanghai",
        t_plus_one=cfg.execution.t_plus_one,
        show_progress=cfg.backtest.show_progress,
    )

    trades = _filled_orders_to_trades(ak_result.orders_df, strategy.submitted_orders, initial_cash)
    _enrich_limit_prices(trades, bundle)
    open_positions = _build_open_positions(strategy, bundle, ak_result, trades)
    equity_curve = ak_result.equity_curve
    final_equity = float(equity_curve.iloc[-1]) if len(equity_curve) else initial_cash
    cash_curve = getattr(ak_result, "cash_curve", None)
    final_cash = float(cash_curve.iloc[-1]) if cash_curve is not None and len(cash_curve) else float(strategy.get_cash())
    open_market_value = max(0.0, final_equity - final_cash)
    open_unrealized = sum(float(x["unrealized_pnl"]) for x in open_positions)
    summary = {
        "init_cash": float(initial_cash),
        "final_cash": round(final_cash, 2),
        "cash_return_pct": round((final_cash / initial_cash - 1.0) * 100.0, 2),
        "open_count": len(open_positions),
        "open_market_value": round(open_market_value, 2),
        "open_unrealized_pnl": round(open_unrealized, 2),
        "equity_final": round(final_equity, 2),
        "equity_return_pct": round((final_equity / initial_cash - 1.0) * 100.0, 2),
        "trade_count": len(trades),
        "buy_count": sum(1 for x in trades if x["action"] == "buy"),
        "sell_count": sum(1 for x in trades if x["action"] == "sell"),
        "event_count": len(bundle.flat_events),
        "total_fees": round(float(ak_result.metrics_df.loc["total_commission", "value"]) if "total_commission" in ak_result.metrics_df.index else 0.0, 2),
    }
    result = BacktestResult(
        trades=trades,
        events=bundle.flat_events,
        open_positions=open_positions,
        summary=summary,
    )
    return V5RunArtifacts(result=result, bundle=bundle, ak_result=ak_result, strategy=strategy)
