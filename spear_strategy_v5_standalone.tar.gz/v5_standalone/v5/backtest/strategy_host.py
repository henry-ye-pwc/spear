from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any

import pandas as pd

try:  # pragma: no cover
    from akquant import Strategy
except Exception as exc:  # pragma: no cover
    Strategy = object  # type: ignore[assignment]
    AKQUANT_IMPORT_ERROR = exc
else:  # pragma: no cover
    AKQUANT_IMPORT_ERROR = None

from v4.execution.state_machine import Decision, V4ExecutionStateMachine
from v5.backtest.prepare import PreparedBundle
from v5.config.defaults import V5Config


@dataclass(slots=True)
class SubmittedOrderMeta:
    action: str
    symbol: str
    reason: str
    requested_price: float | None
    qty: float
    meta: dict[str, Any]


def _event_dt_from_bar_ns(ts_ns: int) -> str:
    return str(pd.Timestamp(ts_ns, tz="UTC").tz_convert("Asia/Shanghai").date())


class AKQuantSpearStrategy(Strategy):  # type: ignore[misc]
    timezone = "Asia/Shanghai"

    def __init__(self, bundle: PreparedBundle, cfg: V5Config, start: str) -> None:
        if AKQUANT_IMPORT_ERROR is not None:  # pragma: no cover
            raise RuntimeError("akquant is required for v5 strategy host") from AKQUANT_IMPORT_ERROR
        super().__init__()
        self.bundle = bundle
        self.cfg = cfg
        self.start = start
        self.state_machine = V4ExecutionStateMachine(
            max_positions=cfg.execution.max_positions,
            base_pos_pct=cfg.execution.base_pos_pct,
            position_multipliers={
                "trend_spear": cfg.execution.trend_spear_pos_mult,
                "post_limit": cfg.execution.post_limit_pos_mult,
                "failed_board": cfg.execution.failed_board_pos_mult,
                "youzi": cfg.execution.youzi_pos_mult,
                "sector_spear": cfg.execution.sector_spear_pos_mult,
                "attack": cfg.execution.attack_pos_mult,
                "arb": cfg.execution.arb_pos_mult,
            },
            cooldown_days=cfg.execution.cooldown_days,
            default_take_profit_pct=cfg.execution.default_take_profit_pct,
            execution_profile=cfg.execution.execution_profile,
            hunt_price_buffer_pct=cfg.execution.hunt_price_buffer_pct,
            hunt_window_days=cfg.execution.hunt_window_days,
            exit_hunt_buffer_pct=cfg.execution.exit_hunt_buffer_pct,
            exit_hunt_window_days=cfg.execution.exit_hunt_window_days,
            exit_mode=cfg.execution.exit_mode,
        )
        self.submitted_orders: dict[str, SubmittedOrderMeta] = {}
        self.trade_log: list[dict[str, Any]] = []
        self.recorded_fills: set[str] = set()

    def on_start(self) -> None:
        for symbol in self.bundle.raw_data:
            self.subscribe(symbol)

    def on_bar(self, bar: Any) -> None:
        date = _event_dt_from_bar_ns(int(bar.timestamp))
        if date < self.start:
            return
        symbol = str(bar.symbol)
        idx_map = self.bundle.idx_by_symbol_date.get(symbol)
        if not idx_map or date not in idx_map:
            return
        frame = self.bundle.feature_data[symbol]
        idx = idx_map[date]
        cur = frame.iloc[idx]
        events = list(self.bundle.events_by_symbol_date.get((symbol, date), []))
        env_ctx = dict(self.bundle.env_by_symbol_date.get((symbol, date), {}))
        cash = float(self.get_cash())
        decisions = self.state_machine.on_day(
            date=date,
            d_idx=idx,
            symbol=symbol,
            open_price=float(cur["open"]),
            close=float(cur["close"]),
            high=float(cur["high"]),
            low=float(cur["low"]),
            limit_up=float(cur["limit_up"]) if pd.notna(cur.get("limit_up")) else None,
            limit_down=float(cur["close"]) * (1 - float(cur.get("limit_pct", 0.1))) if pd.notna(cur.get("limit_pct")) else None,
            events=events,
            cash=cash,
            day_context=env_ctx,
        )
        for dec in decisions:
            self._submit_decision(dec)

    def _submit_decision(self, dec: Decision) -> None:
        tag = dec.reason
        if dec.action == "buy":
            if dec.price is None:
                order_id = self.buy(symbol=dec.symbol, quantity=dec.qty, tag=tag)
            else:
                order_id = self.buy(symbol=dec.symbol, quantity=dec.qty, price=dec.price, tag=tag)
        elif dec.action == "sell":
            if dec.price is None:
                order_id = self.sell(symbol=dec.symbol, quantity=dec.qty, tag=tag)
            else:
                order_id = self.sell(symbol=dec.symbol, quantity=dec.qty, price=dec.price, tag=tag)
        else:
            return
        if order_id:
            self.submitted_orders[order_id] = SubmittedOrderMeta(
                action=dec.action,
                symbol=dec.symbol,
                reason=dec.reason,
                requested_price=(float(dec.price) if dec.price is not None else None),
                qty=float(dec.qty),
                meta=dict(dec.meta),
            )

    def _record_fill(
        self,
        *,
        order_id: str,
        timestamp_ns: int,
        price: float,
        quantity: float,
        commission: float,
    ) -> None:
        if order_id in self.recorded_fills:
            return
        order_meta = self.submitted_orders.get(order_id)
        if order_meta is None:
            return
        self.recorded_fills.add(order_id)
        gross = float(price) * float(quantity)
        fee_total = float(commission or 0.0)
        net_cash_delta = -(gross + fee_total) if order_meta.action == "buy" else gross - fee_total
        self.trade_log.append(
            {
                "date": str(pd.Timestamp(int(timestamp_ns), tz="UTC").tz_convert("Asia/Shanghai").date()),
                "symbol": order_meta.symbol,
                "action": order_meta.action,
                "price": float(price),
                "qty": float(quantity),
                "reason": order_meta.reason,
                "meta": json.dumps(
                    {
                        **order_meta.meta,
                        "style": order_meta.meta.get("style", ""),
                        "gross_notional": round(gross, 4),
                        "fee_total": round(fee_total, 4),
                        "commission": round(fee_total, 4),
                        "net_cash_delta": round(net_cash_delta, 4),
                    },
                    ensure_ascii=False,
                    sort_keys=True,
                ),
                "cash_after": round(float(self.get_cash()), 2),
            }
        )

    def on_trade(self, trade: Any) -> None:
        self._record_fill(
            order_id=str(trade.order_id),
            timestamp_ns=int(trade.timestamp),
            price=float(trade.price),
            quantity=float(trade.quantity),
            commission=float(getattr(trade, "commission", 0.0) or 0.0),
        )

    def on_order(self, order: Any) -> None:
        status = str(getattr(order, "status", "")).lower()
        if status != "filled":
            return
        self._record_fill(
            order_id=str(order.id),
            timestamp_ns=int(pd.Timestamp(getattr(order, "updated_at")).value),
            price=float(getattr(order, "avg_price", 0.0) or 0.0),
            quantity=float(getattr(order, "filled_quantity", 0.0) or 0.0),
            commission=float(getattr(order, "commission", 0.0) or 0.0),
        )
