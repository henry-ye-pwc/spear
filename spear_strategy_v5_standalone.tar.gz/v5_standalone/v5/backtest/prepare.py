from __future__ import annotations

import json
import os
import time
from concurrent.futures import ProcessPoolExecutor
from dataclasses import dataclass, field

import pandas as pd

from v4.data.adapter import preprocess_daily
from v4.features import add_robust_volume_features, add_sequence_features, add_structure_features
from v4.models.registry import count_signals, detect_signals
from v5.config.defaults import V5Config
from v5.data.router import V5DataRouter
from v5.environment.provider import V5EnvironmentProvider


def _log(msg: str) -> None:
    print(msg, flush=True)


@dataclass(slots=True)
class PreparedBundle:
    universe: pd.DataFrame
    raw_data: dict[str, pd.DataFrame] = field(default_factory=dict)
    feature_data: dict[str, pd.DataFrame] = field(default_factory=dict)
    dates_by_symbol: dict[str, list[str]] = field(default_factory=dict)
    idx_by_symbol_date: dict[str, dict[str, int]] = field(default_factory=dict)
    events_by_symbol_date: dict[tuple[str, str], list] = field(default_factory=dict)
    env_by_symbol_date: dict[tuple[str, str], dict] = field(default_factory=dict)
    flat_events: list[dict] = field(default_factory=list)
    env: V5EnvironmentProvider | None = None


def _prepare_frame(raw: pd.DataFrame, symbol: str, cfg: V5Config) -> pd.DataFrame:
    out = preprocess_daily(raw, symbol)
    out = add_robust_volume_features(out, window=cfg.features.vol_window)
    out = add_sequence_features(out, window=cfg.features.sequence_window)
    out = add_structure_features(
        out,
        peak_window=cfg.features.peak_window,
        drawdown_min=cfg.features.drawdown_min,
        peak_touch_eps=cfg.features.peak_touch_eps,
        consolidation_window=cfg.features.consolidation_window,
    )
    return out


def _theme_label(meta: dict, cfg: V5Config) -> str:
    if cfg.data.disable_env_mapping:
        return "其他"
    return str(meta.get("industry") or meta.get("name_theme") or "其他")


# ---------------------------------------------------------------------------
# Phase A+B worker — runs in a subprocess via ProcessPoolExecutor.
# Must be a top-level function (not a closure/lambda) for pickling.
# Reuses a module-level adapter per worker process to avoid repeated mootdx
# TCP connections (reduces ~67 connections to ~10).
# Also performs Phase B signal counting in-parallel to eliminate the
# sequential Phase B pass entirely.
# ---------------------------------------------------------------------------

_worker_adapter: V5DataRouter | None = None


def _phase_a_worker(args: tuple) -> tuple | None:
    global _worker_adapter
    (symbol, start, end, cfg, intraday_bar,
     theme_label, detect_cfg, target_set, active_event_types) = args

    if _worker_adapter is None:
        _worker_adapter = V5DataRouter(cfg)
    adapter = _worker_adapter

    raw = adapter.load_symbol(symbol, start=start, end=end)
    if raw is None or raw.empty or len(raw) < 120:
        return None

    if intraday_bar is not None and not intraday_bar.empty:
        syn = intraday_bar.copy()
        syn["symbol"] = symbol
        keep = [c for c in raw.columns if c in syn.columns]
        raw.index = raw.index.normalize()
        syn.index = syn.index.normalize()
        raw = pd.concat([raw, syn[keep]]).sort_index()
        raw = raw[~raw.index.duplicated(keep="last")]

    raw = raw.sort_index()
    frame = _prepare_frame(raw, symbol, cfg)
    dates = [str(x)[:10] for x in frame.index]
    idx_map = {d: i for i, d in enumerate(dates)}

    # Phase B: lightweight signal counting (runs in parallel with data loading)
    if target_set is not None:
        indices = [(d, idx_map[d]) for d in target_set if d in idx_map and idx_map[d] >= 120]
    else:
        indices = [(dates[i], i) for i in range(120, len(dates)) if dates[i] >= start]

    env_b = {"theme_label": theme_label, "lhb_net_sell": False}
    signal_results: list[tuple] = []
    for date, i in indices:
        if date < start:
            continue
        counts = count_signals(
            frame, symbol, max_idx=i, env=env_b, **detect_cfg,
        )
        if active_event_types is not None:
            counts = [c for c in counts if c.event_type in active_event_types]
        long_counts = [c for c in counts if c.side == "long"]
        has_long = len(long_counts) > 0
        leader_hit = (
            1 if any(
                c.event_type in {"post_limit", "trend_spear", "failed_board"}
                and c.confidence >= 0.7
                for c in long_counts
            ) else 0
        ) if has_long else 0
        signal_results.append((date, counts, has_long, leader_hit))

    return (symbol, raw, frame, dates, idx_map, theme_label, signal_results)


def prepare_bundle(
    cfg: V5Config,
    start: str,
    end: str,
    pool_size: int,
    symbols: list[str] | None = None,
    active_event_types: set[str] | None = None,
    target_dates: list[str] | None = None,
    intraday_bars: dict[str, pd.DataFrame] | None = None,
) -> PreparedBundle:
    adapter = V5DataRouter(cfg)
    if symbols:
        requested = [str(x).zfill(6) for x in symbols]
        catalog = adapter.load_universe(1000000)
        if not catalog.empty:
            catalog = catalog.copy()
            catalog["symbol"] = catalog["symbol"].astype(str).str.zfill(6)
            catalog = catalog.drop_duplicates(subset=["symbol"], keep="first")
            meta = catalog.set_index("symbol")["name"].to_dict()
        else:
            meta = {}
        universe = pd.DataFrame(
            {
                "symbol": requested,
                "name": [str(meta.get(sym, "") or "") for sym in requested],
            }
        )
    else:
        universe = adapter.load_universe(pool_size)
    env = V5EnvironmentProvider(
        universe=universe,
        sector_cache_path=cfg.data.sector_cache_path,
        lhb_cache_path=cfg.data.lhb_cache_path,
    )
    env.load()
    bundle = PreparedBundle(universe=universe, env=env)

    target_set = set(target_dates) if target_dates is not None else None
    symbols_list = universe["symbol"].tolist()
    _log(f"[prepare] {len(symbols_list)} symbols, range={start}~{end}, target_dates={target_dates}")

    t0 = time.monotonic()

    # Pre-compute per-symbol theme labels (cheap dict lookups)
    theme_labels: dict[str, str] = {}
    for sym in symbols_list:
        sym_meta = env.get_symbol_meta(sym)
        theme_labels[sym] = _theme_label(sym_meta, cfg)

    detect_cfg = {
        "post_limit_lookback": cfg.models.post_limit_lookback,
        "trend_multi_days": cfg.models.trend_multi_spear_days,
        "attack_limit_lookback": cfg.models.attack_limit_lookback,
        "arb_limit_lookback": cfg.models.arb_limit_lookback,
    }

    # ── Phase A+B: parallel data loading + features + signal counting ──
    n_workers = min(max(1, os.cpu_count() or 4), 10)
    work_items = [
        (sym, start, end, cfg,
         intraday_bars.get(sym) if intraday_bars else None,
         theme_labels.get(sym, "其他"),
         detect_cfg, target_set, active_event_types)
        for sym in symbols_list
    ]

    loaded = 0
    skipped = 0
    skipped_syms: list[str] = []
    raw_events: dict[tuple[str, str], list] = {}
    day_theme_counts: dict[tuple[str, str], int] = {}
    day_theme_leaders: dict[tuple[str, str], int] = {}
    all_dates: set[str] = set()

    with ProcessPoolExecutor(max_workers=n_workers) as pool:
        for sym, result in zip(symbols_list, pool.map(_phase_a_worker, work_items, chunksize=4)):
            if result is None:
                skipped += 1
                skipped_syms.append(sym)
                continue
            symbol, raw, frame, dates, idx_map, theme_label, signal_results = result
            bundle.raw_data[symbol] = raw
            bundle.feature_data[symbol] = frame
            bundle.dates_by_symbol[symbol] = dates
            bundle.idx_by_symbol_date[symbol] = idx_map
            loaded += 1

            for date, counts, has_long, leader_hit in signal_results:
                all_dates.add(date)
                raw_events[(symbol, date)] = counts
                if has_long:
                    key = (date, theme_label)
                    day_theme_counts[key] = day_theme_counts.get(key, 0) + 1
                    day_theme_leaders[key] = day_theme_leaders.get(key, 0) + leader_hit

            if loaded % 50 == 0:
                _log(f"[prepare] Phase A+B: {loaded}/{len(symbols_list)} [{time.monotonic() - t0:.1f}s]")

    _log(f"[prepare] Phase A+B done: {loaded} loaded, {skipped} skipped in {time.monotonic() - t0:.1f}s ({n_workers} workers)")
    if skipped_syms:
        _log(f"[prepare] Skipped symbols ({len(skipped_syms)}): {', '.join(skipped_syms[:30])}{'...' if len(skipped_syms) > 30 else ''}")
    _log(f"[prepare] Signal count: {len(all_dates)} date(s), {len(raw_events)} (sym,date) pairs")

    # ── Phase C: second pass with enriched environment context ──
    # Iterate by symbol (outer) for data locality + O(1) dict membership test.
    #
    # SKIP OPTIMIZATION: most (symbol, date) pairs have zero Phase B signals
    # AND zero enriched-env activity.  For those, Phase C is guaranteed to
    # produce zero signals too (themed_env_ok gate kills non-escape models;
    # youzi/sector_spear need peer/leader/sector_hot which are all 0).
    # We pre-compute which (date, theme) combos have any env activity and
    # only run detect_signals for pairs that (a) had Phase B signals or
    # (b) belong to an active (date, theme).
    t2 = time.monotonic()
    sorted_dates = sorted(all_dates)
    feature_symbols = list(bundle.feature_data.keys())

    # Pre-compute active (date, theme) combos — those with peer ≥ 1 or leader ≥ 1
    active_date_themes: set[tuple[str, str]] = set()
    for (dt, th), cnt in day_theme_counts.items():
        if cnt >= 1:
            active_date_themes.add((dt, th))
    for (dt, th), ldr in day_theme_leaders.items():
        if ldr >= 1:
            active_date_themes.add((dt, th))

    # Collect (symbol, date) pairs that had Phase B signals
    pairs_with_signals: set[tuple[str, str]] = {k for k, v in raw_events.items() if v}

    total_pairs = 0
    processed_pairs = 0
    skipped_pairs = 0

    _log(f"[prepare] Phase C: second-pass for {len(sorted_dates)} date(s), {len(feature_symbols)} symbols ...")
    _log(f"[prepare] Phase C skip filter: {len(pairs_with_signals)} pairs w/ signals, {len(active_date_themes)} active (date,theme) combos")

    for si, symbol in enumerate(feature_symbols):
        sym_meta = env.get_symbol_meta(symbol)
        theme_label = _theme_label(sym_meta, cfg)
        idx_map = bundle.idx_by_symbol_date[symbol]
        sym_frame = bundle.feature_data[symbol]

        for date in sorted_dates:
            if date not in idx_map:
                continue
            total_pairs += 1

            raw_today = raw_events.get((symbol, date), [])
            has_phase_b_signals = bool(raw_today)
            theme_is_active = (date, theme_label) in active_date_themes

            # Skip: no Phase B signals AND theme inactive on this date →
            # detect_signals would return nothing (themed_env_ok=False for
            # most models; youzi/sector_spear need peer/leader/sector_hot).
            if not has_phase_b_signals and not theme_is_active:
                skipped_pairs += 1
                continue

            peer_confirmation = day_theme_counts.get((date, theme_label), 0) - (1 if has_phase_b_signals else 0)
            leader_strength = max(
                0,
                day_theme_leaders.get((date, theme_label), 0)
                - (
                    1
                    if any(e.event_type in {"post_limit", "trend_spear", "failed_board"} and e.confidence >= 0.7 for e in raw_today)
                    else 0
                ),
            )
            env_ctx = {
                "theme_label": theme_label,
                "peer_confirmation": peer_confirmation,
                "leader_strength": leader_strength,
                "lhb_net_sell": env.recent_lhb_net_sell(symbol, date),
                "sector_hot": bool(peer_confirmation >= 2 and leader_strength >= 1),
                "_enforce_env": True,
            }
            idx = idx_map[date]
            events = detect_signals(
                sym_frame,
                symbol,
                max_idx=idx,
                **detect_cfg,
                env=env_ctx,
            )
            if active_event_types is not None:
                events = [e for e in events if e.event_type in active_event_types]
            enriched = []
            for ev in events:
                ctx = dict(ev.context)
                ctx.update({k: v for k, v in env_ctx.items() if not str(k).startswith("_")})
                ev.context = ctx
                if ev.side == "long" and ctx["lhb_net_sell"]:
                    continue
                enriched.append(ev)
                bundle.flat_events.append(
                    {
                        "date": ev.ts,
                        "symbol": ev.symbol,
                        "event_type": ev.event_type,
                        "confidence": ev.confidence,
                        "side": ev.side,
                        "entry_plan": json.dumps(ev.entry_plan, ensure_ascii=False, sort_keys=True),
                        "invalidation": json.dumps(ev.invalidation, ensure_ascii=False, sort_keys=True),
                        "exit_plan": json.dumps(ev.exit_plan, ensure_ascii=False, sort_keys=True),
                        "context": json.dumps(ev.context, ensure_ascii=False, sort_keys=True),
                    }
                )
            bundle.events_by_symbol_date[(symbol, date)] = enriched
            bundle.env_by_symbol_date[(symbol, date)] = {k: v for k, v in env_ctx.items() if not str(k).startswith("_")}
            processed_pairs += 1

        if (si + 1) % 100 == 0:
            _log(f"[prepare] Phase C: {si + 1}/{len(feature_symbols)} [{time.monotonic() - t2:.1f}s]")

    # Restore chronological order (Phase C iterates by symbol, not by date)
    bundle.flat_events.sort(key=lambda e: (str(e.get("date", "")), str(e.get("symbol", ""))))

    total = time.monotonic() - t0
    _log(f"[prepare] Phase C done in {time.monotonic() - t2:.1f}s — {processed_pairs}/{total_pairs} processed, {skipped_pairs} skipped | total prepare_bundle: {total:.1f}s")
    return bundle
