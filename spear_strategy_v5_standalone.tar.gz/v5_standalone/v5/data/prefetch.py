"""Parallel data prefetch using ProcessPoolExecutor.

The mootdx/tdxpy data-fetching stack does heavy Python-level byte parsing
that holds the GIL, making ThreadPoolExecutor *slower* than serial for
network I/O.  ProcessPoolExecutor bypasses the GIL entirely, giving 4-5x
speedup in practice (verified via POC).

Usage:
    prefetch_symbols(symbols, cache_dir, end_date, workers=4)

Each worker process creates its own mootdx connection and updates the
shared PKL cache on disk.  After prefetch completes, any subsequent
DataFeed.get_kline() call for the same symbols will hit warm cache.
"""
from __future__ import annotations

import os
import time
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path


def _worker_fetch_batch(
    symbols: list[str],
    cache_dir: str,
    end_date: str | None,
    count: int,
    cache_only: bool,
    force_refresh: bool = False,
    worker_id: int = 0,
    total_symbols: int = 0,
) -> dict:
    """Run inside a worker process.  Creates its own DataFeed + connection."""
    from cq_backtest.data.feed import DataFeed

    feed = DataFeed(cache_dir=cache_dir)
    fetched = 0
    cached = 0
    errors = 0
    error_syms: list[str] = []
    for i, sym in enumerate(symbols):
        try:
            feed.get_kline(sym, end_date=end_date, count=count,
                           cache_only=cache_only, force_refresh=force_refresh)
            pkl = os.path.join(cache_dir, f"{sym}_full.pkl")
            if os.path.exists(pkl):
                fetched += 1
            else:
                error_syms.append(sym)
                cached += 1
        except Exception as exc:
            errors += 1
            error_syms.append(sym)
            print(f"[prefetch] W{worker_id} ERROR {sym}: {exc}", flush=True)
        if (i + 1) % 20 == 0:
            print(f"[prefetch] W{worker_id}: {i+1}/{len(symbols)} (本批{len(symbols)}只, 共{total_symbols}只)", flush=True)
    try:
        if feed.client is not None:
            feed.client.close()
    except Exception:
        pass
    return {"fetched": fetched, "cached": cached, "errors": errors, "error_syms": error_syms}


def prefetch_symbols(
    symbols: list[str],
    cache_dir: str,
    end_date: str | None = None,
    count: int = 900,
    workers: int = 4,
    cache_only: bool = False,
    force_refresh: bool = False,
) -> dict:
    """Warm the PKL cache for *symbols* using parallel processes.

    Parameters
    ----------
    symbols : list[str]
        Stock codes (6-digit strings).
    cache_dir : str
        Path to the mootdx PKL cache directory.
    end_date : str | None
        Target end date (YYYY-MM-DD).  Passed to DataFeed.get_kline().
    count : int
        Number of bars to request per symbol.
    workers : int
        Number of parallel worker processes.
    cache_only : bool
        If True, skip network fetches and only use local cache.
    force_refresh : bool
        If True, bypass cache and do a full history re-fetch for every symbol.

    Returns
    -------
    dict with keys: total, elapsed_s, fetched, errors, workers_used.
    """
    if not symbols:
        return {"total": 0, "elapsed_s": 0, "fetched": 0, "errors": 0, "workers_used": 0}

    if cache_only or workers <= 1:
        t0 = time.monotonic()
        result = _worker_fetch_batch(symbols, cache_dir, end_date, count, cache_only, force_refresh)
        elapsed = time.monotonic() - t0
        return {
            "total": len(symbols),
            "elapsed_s": round(elapsed, 1),
            "fetched": result["fetched"],
            "errors": result["errors"],
            "workers_used": 1,
        }

    Path(cache_dir).mkdir(parents=True, exist_ok=True)
    n = min(workers, len(symbols))

    batches: list[list[str]] = [[] for _ in range(n)]
    for i, sym in enumerate(symbols):
        batches[i % n].append(sym)

    mode = "全量刷新" if force_refresh else "增量更新"
    print(f"[prefetch] Starting {n} workers for {len(symbols)} symbols ({mode}) ...", flush=True)
    t0 = time.monotonic()

    totals = {"fetched": 0, "cached": 0, "errors": 0}
    all_error_syms: list[str] = []
    with ProcessPoolExecutor(max_workers=n) as pool:
        futures = {
            pool.submit(
                _worker_fetch_batch, batch, cache_dir, end_date, count,
                cache_only, force_refresh, worker_id=i, total_symbols=len(symbols),
            ): i
            for i, batch in enumerate(batches)
        }
        for future in as_completed(futures):
            idx = futures[future]
            try:
                result = future.result(timeout=600)
                totals["fetched"] += result["fetched"]
                totals["cached"] += result["cached"]
                totals["errors"] += result["errors"]
                all_error_syms.extend(result.get("error_syms", []))
            except Exception as exc:
                print(f"[prefetch] Worker {idx} failed: {exc}", flush=True)
                totals["errors"] += len(batches[idx])
                all_error_syms.extend(batches[idx])

    elapsed = time.monotonic() - t0
    print(
        f"[prefetch] Done: {totals['fetched']} updated, {totals['errors']} errors "
        f"in {elapsed:.1f}s ({elapsed/len(symbols)*1000:.0f}ms/sym, {n} workers)",
        flush=True,
    )
    if all_error_syms:
        print(f"[prefetch] Failed symbols ({len(all_error_syms)}): {', '.join(sorted(all_error_syms))}", flush=True)
    return {
        "total": len(symbols),
        "elapsed_s": round(elapsed, 1),
        "fetched": totals["fetched"],
        "errors": totals["errors"],
        "workers_used": n,
        "error_syms": sorted(all_error_syms),
    }
