"""Build synthetic daily bars from intraday minute data.

Used by preview mode to generate a "fuzzy" daily bar before market close
(e.g. at 14:30) so signal detection can run on partial-day data.
"""
from __future__ import annotations

import time
from concurrent.futures import ProcessPoolExecutor, as_completed

import pandas as pd


def _aggregate_minutes_to_daily(minutes: pd.DataFrame, target_date: str) -> pd.DataFrame | None:
    """Collapse minute bars into a single synthetic daily bar."""
    if minutes is None or minutes.empty:
        return None
    row = {
        "open": float(minutes.iloc[0]["open"]),
        "high": float(minutes["high"].max()),
        "low": float(minutes["low"].min()),
        "close": float(minutes.iloc[-1]["close"]),
        "volume": float(minutes["volume"].sum()),
    }
    if "amount" in minutes.columns:
        row["amount"] = float(minutes["amount"].sum())
    else:
        row["amount"] = row["close"] * row["volume"]
    return pd.DataFrame([row], index=pd.DatetimeIndex([pd.Timestamp(target_date)]))


def _worker_fetch_minute_batch(
    symbols: list[str],
    cache_dir: str,
    target_date: str,
    frequency: int,
    count: int,
) -> dict[str, dict]:
    """Worker process: fetch minute bars and aggregate per symbol."""
    from cq_backtest.data.feed import DataFeed

    feed = DataFeed(cache_dir=cache_dir)
    results: dict[str, dict] = {}
    for sym in symbols:
        try:
            minutes = feed.get_minute_bars(sym, frequency=frequency, count=count)
            if minutes is None or minutes.empty:
                continue
            date_str = target_date.replace("-", "")
            today_minutes = minutes[minutes.index.strftime("%Y%m%d") == date_str]
            if today_minutes.empty:
                continue
            bar = _aggregate_minutes_to_daily(today_minutes, target_date)
            if bar is not None:
                results[sym] = bar.iloc[0].to_dict()
        except Exception:
            continue
    try:
        if feed.client is not None:
            feed.client.close()
    except Exception:
        pass
    return results


def fetch_synthetic_bars(
    symbols: list[str],
    cache_dir: str,
    target_date: str,
    frequency: int = 8,
    count: int = 250,
    workers: int = 4,
) -> dict[str, pd.DataFrame]:
    """Fetch minute bars for *symbols* and aggregate into synthetic daily bars.

    Returns ``{symbol: single-row DataFrame}`` suitable for appending to
    historical daily data before feature computation.
    """
    if not symbols:
        return {}

    print(f"[intraday] Fetching minute bars for {len(symbols)} symbols ...", flush=True)
    t0 = time.monotonic()

    n = min(workers, len(symbols))
    batches: list[list[str]] = [[] for _ in range(n)]
    for i, sym in enumerate(symbols):
        batches[i % n].append(sym)

    merged: dict[str, pd.DataFrame] = {}
    with ProcessPoolExecutor(max_workers=n) as pool:
        futures = {
            pool.submit(_worker_fetch_minute_batch, batch, cache_dir, target_date, frequency, count): i
            for i, batch in enumerate(batches)
        }
        for future in as_completed(futures):
            try:
                result = future.result(timeout=300)
                for sym, row_dict in result.items():
                    merged[sym] = pd.DataFrame(
                        [row_dict],
                        index=pd.DatetimeIndex([pd.Timestamp(target_date)]),
                    )
            except Exception as exc:
                print(f"[intraday] Worker failed: {exc}", flush=True)

    elapsed = time.monotonic() - t0
    print(
        f"[intraday] Done: {len(merged)} synthetic bars in {elapsed:.1f}s",
        flush=True,
    )
    return merged
