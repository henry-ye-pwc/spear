from __future__ import annotations

from .router import V5DataRouter

__all__ = ["V5DataRouter"]
