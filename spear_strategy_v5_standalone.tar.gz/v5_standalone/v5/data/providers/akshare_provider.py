from __future__ import annotations

from dataclasses import dataclass
import os
from pathlib import Path

import pandas as pd


def _install_proxy_patch_if_configured() -> bool:
    auth_ip = os.environ.get("AKSHARE_PROXY_PATCH_IP", "").strip()
    auth_token = os.environ.get("AKSHARE_PROXY_PATCH_TOKEN", "").strip()
    if not auth_ip or not auth_token:
        return False
    try:
        import akshare_proxy_patch  # type: ignore
    except Exception:
        return False
    akshare_proxy_patch.install_patch(auth_ip, auth_token)
    return True


def _akshare() -> object:
    try:
        import akshare as ak  # type: ignore
    except Exception as exc:  # pragma: no cover
        raise RuntimeError("akshare is required for v5 data ingestion") from exc
    _install_proxy_patch_if_configured()
    return ak


def _filter_universe(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    out["symbol"] = out["code"].astype(str).str.zfill(6)
    prefixes = ("000", "001", "002", "003", "300", "301", "600", "601", "603", "605", "688", "689")
    out = out[out["symbol"].str.startswith(prefixes)]
    clean_name = out["name"].astype(str).str.replace("\x00", "", regex=False).str.replace(" ", "", regex=False).str.upper()
    out = out[~clean_name.str.contains("ST", regex=False)]
    return out[["symbol", "name"]].drop_duplicates().reset_index(drop=True)


@dataclass(slots=True)
class AKShareProvider:
    cache_dir: str = "./v5/cache/akshare"
    adjust: str = "qfq"
    pool_sampling: str = "head"
    pool_seed: int | None = 42
    warmup_bars: int = 600
    root: Path = Path(".")
    name: str = "akshare"

    def __post_init__(self) -> None:
        self.root = Path(self.cache_dir)
        self.root.mkdir(parents=True, exist_ok=True)

    def _cache_path(self, symbol: str) -> Path:
        return self.root / f"{symbol}.parquet"

    def load_universe(self, pool_size: int) -> pd.DataFrame:
        cache_path = self.root / "universe.parquet"
        if cache_path.exists():
            df = pd.read_parquet(cache_path)
        else:
            ak = _akshare()
            raw = ak.stock_info_a_code_name()
            raw = raw.rename(columns={"code": "code", "name": "name"})
            df = _filter_universe(raw)
            df.to_parquet(cache_path, index=False)
        if self.pool_sampling == "random":
            return df.sample(n=min(pool_size, len(df)), random_state=self.pool_seed, replace=False).reset_index(drop=True)
        return df.head(pool_size).reset_index(drop=True)

    def _fetch_symbol(self, symbol: str, start: str, end: str) -> pd.DataFrame:
        ak = _akshare()
        raw = ak.stock_zh_a_hist(
            symbol=symbol,
            period="daily",
            start_date=pd.Timestamp(start).strftime("%Y%m%d"),
            end_date=pd.Timestamp(end).strftime("%Y%m%d"),
            adjust=self.adjust,
        )
        if raw is None or raw.empty:
            return pd.DataFrame()
        out = raw.rename(
            columns={
                "日期": "date",
                "开盘": "open",
                "收盘": "close",
                "最高": "high",
                "最低": "low",
                "成交量": "volume",
                "成交额": "amount",
            }
        )
        keep = [c for c in ["date", "open", "high", "low", "close", "volume", "amount"] if c in out.columns]
        out = out[keep].copy()
        out["date"] = pd.to_datetime(out["date"])
        out = out.set_index("date").sort_index()
        out["symbol"] = symbol
        return out

    def load_symbol(self, symbol: str, start: str, end: str) -> pd.DataFrame:
        cache_path = self._cache_path(symbol)
        warmup_start = (pd.Timestamp(start) - pd.offsets.BDay(self.warmup_bars)).strftime("%Y-%m-%d")
        if cache_path.exists():
            df = pd.read_parquet(cache_path)
            df.index = pd.to_datetime(df.index)
            if not df.empty and pd.Timestamp(df.index.max()).normalize() >= pd.Timestamp(end).normalize():
                end_ts = pd.Timestamp(end).normalize()
                return df[(df.index >= pd.Timestamp(warmup_start)) & (df.index.normalize() <= end_ts)].copy()
        df = self._fetch_symbol(symbol, warmup_start, end)
        if not df.empty:
            df.to_parquet(cache_path)
        return df.copy()
