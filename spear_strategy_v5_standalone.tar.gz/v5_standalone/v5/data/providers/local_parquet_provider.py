from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import pandas as pd


@dataclass(slots=True)
class LocalParquetProvider:
    root: str = "./data/processed/freq=d1"
    warmup_bars: int = 600
    name: str = "local_parquet"

    def _symbol_path(self, symbol: str) -> Path:
        return Path(self.root) / f"symbol={symbol}" / "bars.parquet"

    def load_universe(self, pool_size: int) -> pd.DataFrame:
        base = Path(self.root)
        rows: list[dict[str, str]] = []
        if not base.exists():
            return pd.DataFrame(columns=["symbol", "name"])
        for p in sorted(base.glob("symbol=*/bars.parquet"))[:pool_size]:
            symbol = p.parent.name.split("=", 1)[-1]
            rows.append({"symbol": symbol, "name": ""})
        return pd.DataFrame(rows)

    def load_symbol(self, symbol: str, start: str, end: str) -> pd.DataFrame:
        path = self._symbol_path(symbol)
        if not path.exists():
            return pd.DataFrame()
        raw = pd.read_parquet(path)
        raw.index = pd.to_datetime(raw.index)
        warmup_start = pd.Timestamp(start) - pd.offsets.BDay(self.warmup_bars)
        raw = raw[(raw.index >= warmup_start) & (raw.index <= pd.Timestamp(end))].copy()
        if "amount" not in raw.columns and "close" in raw.columns and "volume" in raw.columns:
            raw["amount"] = raw["close"].astype(float) * raw["volume"].astype(float)
        raw["symbol"] = symbol
        keep = [c for c in ["open", "high", "low", "close", "volume", "amount", "symbol"] if c in raw.columns]
        return raw[keep].sort_index()

