from __future__ import annotations

from dataclasses import dataclass, field

import pandas as pd

from cq_backtest.data.feed import DataFeed


def _filter_universe(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    code_col = "code" if "code" in out.columns else out.columns[1]
    name_col = "name" if "name" in out.columns else None
    out["symbol"] = out[code_col].astype(str).str.zfill(6)
    prefixes = ("000", "001", "002", "003", "300", "301", "600", "601", "603", "605", "688", "689")
    out = out[out["symbol"].str.startswith(prefixes)]
    if name_col:
        clean_name = out[name_col].astype(str).str.replace("\x00", "", regex=False).str.replace(" ", "", regex=False).str.upper()
        out = out[~clean_name.str.contains("ST", regex=False)]
        out["name"] = out[name_col].astype(str)
    else:
        out["name"] = ""
    return out[["symbol", "name"]].drop_duplicates().reset_index(drop=True)


@dataclass(slots=True)
class MootdxProvider:
    cache_dir: str = "./cache"
    pool_sampling: str = "head"
    pool_seed: int | None = 42
    warmup_bars: int = 600
    cache_only: bool = False
    name: str = "mootdx"
    feed: DataFeed = field(init=False)

    def __post_init__(self) -> None:
        self.feed = DataFeed(cache_dir=self.cache_dir)

    def load_universe(self, pool_size: int) -> pd.DataFrame:
        df = self.feed.get_stock_list()
        if df is None or df.empty:
            return pd.DataFrame(columns=["symbol", "name"])
        out = _filter_universe(df)
        if self.pool_sampling == "random":
            return out.sample(n=min(pool_size, len(out)), random_state=self.pool_seed, replace=False).reset_index(drop=True)
        return out.head(pool_size).reset_index(drop=True)

    def load_symbol(self, symbol: str, start: str, end: str) -> pd.DataFrame:
        count = max(self.warmup_bars + 260, 900)
        raw = self.feed.get_kline(symbol, end_date=end, count=count, cache_only=self.cache_only)
        if raw is None or raw.empty:
            return pd.DataFrame()
        raw = raw.copy()
        raw.index = pd.to_datetime(raw.index)
        warmup_start = pd.Timestamp(start) - pd.offsets.BDay(self.warmup_bars)
        end_ts = pd.Timestamp(end).normalize()
        raw = raw[(raw.index >= warmup_start) & (raw.index.normalize() <= end_ts)]
        if "amount" not in raw.columns and "close" in raw.columns and "volume" in raw.columns:
            raw["amount"] = raw["close"].astype(float) * raw["volume"].astype(float)
        raw["symbol"] = symbol
        keep = [c for c in ["open", "high", "low", "close", "volume", "amount", "symbol"] if c in raw.columns]
        return raw[keep].sort_index()
