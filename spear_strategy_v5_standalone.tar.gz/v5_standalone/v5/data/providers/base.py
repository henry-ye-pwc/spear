from __future__ import annotations

from typing import Protocol

import pandas as pd


class DailyDataProvider(Protocol):
    name: str

    def load_universe(self, pool_size: int) -> pd.DataFrame: ...

    def load_symbol(self, symbol: str, start: str, end: str) -> pd.DataFrame: ...

