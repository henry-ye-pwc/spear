from __future__ import annotations

from dataclasses import dataclass, field

import pandas as pd

from v5.config.defaults import V5Config
from v5.data.providers import AKShareProvider, LocalParquetProvider, MootdxProvider


def _provider_name(raw: str | None, default: str) -> str:
    return str(raw or default).strip().lower()


@dataclass(slots=True)
class V5DataRouter:
    cfg: V5Config
    _providers: dict[str, object] = field(default_factory=dict)

    def __post_init__(self) -> None:
        self._providers = {}

    def _get(self, name: str):
        key = _provider_name(name, "akshare")
        if key not in self._providers:
            if key == "akshare":
                self._providers[key] = AKShareProvider(
                    cache_dir=self.cfg.data.cache_dir,
                    adjust=self.cfg.data.adjust,
                    pool_sampling=self.cfg.data.pool_sampling,
                    pool_seed=self.cfg.data.pool_seed,
                    warmup_bars=self.cfg.data.warmup_bars,
                )
            elif key == "mootdx":
                self._providers[key] = MootdxProvider(
                    cache_dir=self.cfg.data.mootdx_cache_dir,
                    pool_sampling=self.cfg.data.pool_sampling,
                    pool_seed=self.cfg.data.pool_seed,
                    warmup_bars=self.cfg.data.warmup_bars,
                    cache_only=self.cfg.data.mootdx_cache_only,
                )
            elif key in {"local", "local_parquet", "parquet"}:
                self._providers[key] = LocalParquetProvider(
                    root=self.cfg.data.local_parquet_root,
                    warmup_bars=self.cfg.data.warmup_bars,
                )
            else:
                raise ValueError(f"Unsupported data provider: {name}")
        return self._providers[key]

    def load_universe(self, pool_size: int) -> pd.DataFrame:
        provider = self._get(self.cfg.data.universe_provider)
        return provider.load_universe(pool_size)

    def load_symbol(self, symbol: str, start: str, end: str) -> pd.DataFrame:
        primary = self._get(self.cfg.data.bar_provider)
        try:
            df = primary.load_symbol(symbol, start=start, end=end)
        except Exception:
            df = pd.DataFrame()
        if df is not None and not df.empty:
            return df
        fallback_name = _provider_name(self.cfg.data.fallback_bar_provider, "")
        primary_name = _provider_name(self.cfg.data.bar_provider, "")
        if not fallback_name or fallback_name == primary_name:
            return pd.DataFrame()
        fallback = self._get(fallback_name)
        return fallback.load_symbol(symbol, start=start, end=end)
