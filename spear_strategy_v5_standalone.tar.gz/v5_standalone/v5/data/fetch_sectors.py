"""Fetch industry classification for all A-share stocks via akshare (East Money).

Usage:
    python -m v5.data.fetch_sectors [--output ./output/stock_sectors_cache.csv]

Produces a CSV with columns: code, industry
"""
from __future__ import annotations

import argparse
import sys
import time
from pathlib import Path

import pandas as pd


def _akshare():
    try:
        import akshare as ak  # type: ignore
    except ImportError:
        print("ERROR: akshare is required.  pip install akshare", file=sys.stderr)
        sys.exit(1)
    return ak


def fetch_sector_map(*, delay: float = 1.5) -> pd.DataFrame:
    ak = _akshare()
    boards = ak.stock_board_industry_name_em()
    board_names: list[str] = boards["板块名称"].tolist()
    print(f"[sectors] Found {len(board_names)} industry boards")

    rows: list[dict] = []
    for i, name in enumerate(board_names):
        try:
            cons = ak.stock_board_industry_cons_em(symbol=name)
            for _, r in cons.iterrows():
                code = str(r.get("代码", "")).zfill(6)
                rows.append({"code": code, "industry": name})
            print(f"  [{i + 1}/{len(board_names)}] {name}: {len(cons)} stocks")
        except Exception as exc:
            print(f"  [{i + 1}/{len(board_names)}] {name}: ERROR {exc}")
        if i < len(board_names) - 1:
            time.sleep(delay)

    df = pd.DataFrame(rows).drop_duplicates(subset=["code"], keep="first")
    print(f"[sectors] Total: {len(df)} unique stocks with industry labels")
    return df


def main() -> None:
    parser = argparse.ArgumentParser(description="Fetch A-share industry classification")
    parser.add_argument("--output", default="./v5/data/static/stock_sectors_cache.csv", help="Output CSV path")
    parser.add_argument("--delay", type=float, default=1.5, help="Delay between API calls (seconds)")
    args = parser.parse_args()

    out_path = Path(args.output)
    out_path.parent.mkdir(parents=True, exist_ok=True)

    df = fetch_sector_map(delay=args.delay)
    df.to_csv(out_path, index=False)
    print(f"[sectors] Saved to {out_path}")


if __name__ == "__main__":
    main()
