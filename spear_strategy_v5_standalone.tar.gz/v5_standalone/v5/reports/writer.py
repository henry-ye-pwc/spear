from __future__ import annotations

import json
import platform
import sys
import tempfile
from datetime import datetime, UTC
from pathlib import Path

import pandas as pd

from cq_backtest.shared.utils import ensure_dir
from v4.reports.analytics import (
    build_closed_trades,
    build_trade_master_table,
    enrich_closed_trades_with_path_stats,
    summarize_diagnosis,
    summarize_events,
    summarize_exits,
)
from v4.reports.overview import write_overview
from v5.backtest.prepare import PreparedBundle
from v4.backtest.engine import BacktestResult
from v5.config.defaults import V5Config


def _atomic_write_json(path: Path, data: dict) -> None:
    content = json.dumps(data, ensure_ascii=False, indent=2)
    tmp = Path(tempfile.mktemp(dir=path.parent, suffix=".tmp"))
    tmp.write_text(content, encoding="utf-8")
    tmp.rename(path)


def write_reports(outdir: str, result: BacktestResult, bundle: PreparedBundle, cfg: V5Config, start: str, end: str, equity_curve: pd.Series | None = None, pool_name: str = "", active_event_types: set[str] | None = None) -> None:
    root = ensure_dir(outdir)
    trades = pd.DataFrame(result.trades)
    events = pd.DataFrame(result.events)
    open_positions = pd.DataFrame(result.open_positions)
    closed = build_closed_trades(trades)
    closed = enrich_closed_trades_with_path_stats(closed, cfg=cfg, start=start, end=end, bars_cache=bundle.feature_data)
    event_summary = summarize_events(events, trades)
    exit_summary = summarize_exits(closed)
    diagnosis_summary = summarize_diagnosis(closed)
    master_table = build_trade_master_table(
        closed,
        events,
        cfg=cfg,
        start=start,
        end=end,
        bars_cache=bundle.feature_data,
        env=bundle.env,
    )

    trades.to_csv(Path(root) / "trades.csv", index=False, encoding="utf-8")
    events.to_csv(Path(root) / "events.csv", index=False, encoding="utf-8")
    open_positions.to_csv(Path(root) / "open_positions.csv", index=False, encoding="utf-8")
    closed.to_csv(Path(root) / "closed_trades.csv", index=False, encoding="utf-8")
    master_table.to_csv(Path(root) / "all_trades_master_table.csv", index=False, encoding="utf-8-sig")
    event_summary.to_csv(Path(root) / "event_summary.csv", index=False, encoding="utf-8")
    exit_summary.to_csv(Path(root) / "exit_summary.csv", index=False, encoding="utf-8")
    diagnosis_summary.to_csv(Path(root) / "diagnosis_summary.csv", index=False, encoding="utf-8")
    with (Path(root) / "summary.json").open("w", encoding="utf-8") as fh:
        json.dump(result.summary, fh, ensure_ascii=False, indent=2)
    write_overview(str(root), result.summary, closed, event_summary, exit_summary, diagnosis_summary)

    if equity_curve is not None and len(equity_curve) > 0:
        eq_df = pd.DataFrame({
            "date": [str(x)[:10] for x in equity_curve.index],
            "equity": equity_curve.values,
        })
        eq_daily = eq_df.groupby("date", sort=True)["equity"].last().reset_index()
        eq_daily = eq_daily[(eq_daily["date"] >= start) & (eq_daily["date"] <= end)]
        eq_daily.to_csv(Path(root) / "equity_curve.csv", index=False, encoding="utf-8")

    run_config: dict = {
        "start": start,
        "end": end,
        "pool_size": len(bundle.feature_data),
        "pool_sampling": cfg.data.pool_sampling,
        "pool_seed": cfg.data.pool_seed,
        "execution_profile": cfg.execution.execution_profile,
        "warmup_bars": cfg.data.warmup_bars,
        "hunt_price_buffer_pct": cfg.execution.hunt_price_buffer_pct,
        "hunt_window_days": cfg.execution.hunt_window_days,
        "exit_mode": cfg.execution.exit_mode,
        "exit_hunt_buffer_pct": cfg.execution.exit_hunt_buffer_pct,
        "exit_hunt_window_days": cfg.execution.exit_hunt_window_days,
        "init_cash": cfg.backtest.initial_cash,
        "max_positions": cfg.execution.max_positions,
        "base_pos_pct": cfg.execution.base_pos_pct,
        "cooldown_days": cfg.execution.cooldown_days,
        "take_profit_pct": cfg.execution.default_take_profit_pct,
        "position_multipliers": {
            "trend_spear": cfg.execution.trend_spear_pos_mult,
            "post_limit": cfg.execution.post_limit_pos_mult,
            "failed_board": cfg.execution.failed_board_pos_mult,
            "youzi": cfg.execution.youzi_pos_mult,
            "sector_spear": cfg.execution.sector_spear_pos_mult,
            "attack": cfg.execution.attack_pos_mult,
            "arb": cfg.execution.arb_pos_mult,
        },
        "disable_env_mapping": cfg.data.disable_env_mapping,
    }
    if pool_name:
        run_config["pool_name"] = pool_name
    if active_event_types is not None:
        run_config["enable_events"] = sorted(active_event_types)
    meta = {
        "kind": "backtest",
        "created_at": datetime.now(UTC).isoformat(),
        "config": run_config,
        "runtime": {
            "python_version": sys.version,
            "platform": platform.platform(),
        },
        "symbols_count": len(bundle.feature_data),
        "events_count": len(result.events),
        "trades_count": len(result.trades),
    }
    _atomic_write_json(Path(root) / "meta.json", meta)

