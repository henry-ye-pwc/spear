from __future__ import annotations

from .writer import write_reports

__all__ = ["write_reports"]

