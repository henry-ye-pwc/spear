from __future__ import annotations

from v5.config.pools import list_named_pools, resolve_named_pool


def test_code_txt_pool_is_registered():
    pools = {item["name"]: item for item in list_named_pools()}
    assert "code_txt_pool" in pools
    assert pools["code_txt_pool"]["symbol_count"] > 0


def test_code_txt_pool_resolves_symbols():
    symbols = resolve_named_pool("code_txt_pool")
    assert "000010" in symbols
    assert "688759" in symbols
    assert all(len(x) == 6 and x.isdigit() for x in symbols)
