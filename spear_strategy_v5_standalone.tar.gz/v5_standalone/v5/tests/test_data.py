from __future__ import annotations

import pandas as pd

from v5.config.defaults import load_default_config
from v5.data.providers.akshare_provider import AKShareProvider
from v5.data.providers.mootdx_provider import MootdxProvider
from v5.data.router import V5DataRouter
from v5.backtest.prepare import prepare_bundle


def test_load_universe_uses_cache(tmp_path):
    cache_dir = tmp_path / "akshare"
    cache_dir.mkdir(parents=True, exist_ok=True)
    cached = pd.DataFrame(
        {
            "symbol": ["000001", "000002", "600000"],
            "name": ["平安银行", "万科A", "浦发银行"],
        }
    )
    cached.to_parquet(cache_dir / "universe.parquet", index=False)
    adapter = AKShareProvider(cache_dir=str(cache_dir), pool_sampling="head")
    out = adapter.load_universe(2)
    assert out["symbol"].tolist() == ["000001", "000002"]


def test_router_falls_back_to_secondary_bar_provider(tmp_path, monkeypatch):
    cfg = load_default_config()
    cfg.data.bar_provider = "akshare"
    cfg.data.fallback_bar_provider = "local_parquet"
    cfg.data.local_parquet_root = str(tmp_path)

    idx = pd.date_range("2024-01-01", periods=3, freq="B")
    raw = pd.DataFrame(
        {
            "open": [10.0, 10.2, 10.3],
            "high": [10.3, 10.4, 10.6],
            "low": [9.9, 10.1, 10.2],
            "close": [10.2, 10.3, 10.5],
            "volume": [1000.0, 1200.0, 1300.0],
        },
        index=idx,
    )
    symbol_dir = tmp_path / "symbol=000001"
    symbol_dir.mkdir(parents=True, exist_ok=True)
    raw.to_parquet(symbol_dir / "bars.parquet")

    def _empty(*args, **kwargs):
        return pd.DataFrame()

    monkeypatch.setattr(AKShareProvider, "load_symbol", _empty)
    router = V5DataRouter(cfg)
    out = router.load_symbol("000001", "2024-01-01", "2024-01-05")
    assert not out.empty
    assert out["symbol"].iloc[-1] == "000001"


def test_mootdx_provider_keeps_same_day_bar_at_close(tmp_path):
    provider = MootdxProvider(cache_dir=str(tmp_path), cache_only=True)
    idx = pd.to_datetime(
        [
            "2026-02-27 15:00:00",
            "2026-03-02 15:00:00",
        ]
    )
    raw = pd.DataFrame(
        {
            "open": [10.0, 10.5],
            "high": [10.2, 10.8],
            "low": [9.8, 10.4],
            "close": [10.1, 10.7],
            "volume": [1000.0, 1200.0],
        },
        index=idx,
    )
    provider.feed.get_kline = lambda *args, **kwargs: raw.copy()  # type: ignore[method-assign]
    out = provider.load_symbol("000001", "2026-01-02", "2026-03-02")
    assert not out.empty
    assert out.index.max() == pd.Timestamp("2026-03-02 15:00:00")


def test_akshare_provider_cache_keeps_same_day_bar_at_close(tmp_path):
    cache_dir = tmp_path / "akshare"
    cache_dir.mkdir(parents=True, exist_ok=True)
    idx = pd.to_datetime(
        [
            "2026-02-27 15:00:00",
            "2026-03-02 15:00:00",
        ]
    )
    cached = pd.DataFrame(
        {
            "open": [10.0, 10.5],
            "high": [10.2, 10.8],
            "low": [9.8, 10.4],
            "close": [10.1, 10.7],
            "volume": [1000.0, 1200.0],
            "amount": [10100.0, 12840.0],
            "symbol": ["000001", "000001"],
        },
        index=idx,
    )
    cached.to_parquet(cache_dir / "000001.parquet")
    provider = AKShareProvider(cache_dir=str(cache_dir))
    out = provider.load_symbol("000001", "2026-01-02", "2026-03-02")
    assert not out.empty
    assert out.index.max() == pd.Timestamp("2026-03-02 15:00:00")


def test_prepare_bundle_backfills_names_for_symbol_lists(monkeypatch):
    cfg = load_default_config()

    universe = pd.DataFrame(
        {
            "symbol": ["000001", "600036"],
            "name": ["平安银行", "招商银行"],
        }
    )
    raw_idx = pd.date_range("2024-01-01", periods=140, freq="B")
    raw = pd.DataFrame(
        {
            "open": [10.0] * len(raw_idx),
            "high": [10.2] * len(raw_idx),
            "low": [9.8] * len(raw_idx),
            "close": [10.1] * len(raw_idx),
            "volume": [1000.0] * len(raw_idx),
            "amount": [10100.0] * len(raw_idx),
            "symbol": ["000001"] * len(raw_idx),
        },
        index=raw_idx,
    )

    monkeypatch.setattr(V5DataRouter, "load_universe", lambda self, pool_size: universe.copy())
    monkeypatch.setattr(V5DataRouter, "load_symbol", lambda self, symbol, start, end: raw.assign(symbol=symbol).copy())

    bundle = prepare_bundle(cfg, start="2024-01-02", end="2024-06-30", pool_size=2, symbols=["000001", "600036"])
    assert bundle.universe["name"].tolist() == ["平安银行", "招商银行"]
