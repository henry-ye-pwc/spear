from __future__ import annotations

from v5.notify.models import SignalSnapshot, WatchItem
from v5.notify.scanner import NotificationSnapshot
from v5.notify.templates import build_feishu_post_payload, render_markdown_summary


def test_render_markdown_summary_contains_expected_sections():
    snap = NotificationSnapshot(
        as_of_date="2026-03-08",
        new_signals=[
            SignalSnapshot(
                symbol="600418",
                name="江淮汽车",
                event_type="trend_spear",
                signal_date="2026-03-08",
                signal_confidence=0.80,
                entry_style="breakout",
                gate_price=12.45,
                invalidation_price=11.86,
                signal_close=12.30,
                signal_high=12.60,
                signal_low=11.95,
                theme_label="汽车",
                peer_confirmation=2,
                leader_strength=1,
                sector_hot=True,
            )
        ],
        watch_updates=[
            WatchItem(
                symbol="600418",
                name="江淮汽车",
                event_type="trend_spear",
                signal_date="2026-03-06",
                signal_confidence=0.80,
                entry_style="breakout",
                gate_price=12.45,
                invalidation_price=11.86,
                signal_close=12.30,
                signal_high=12.60,
                signal_low=11.95,
                theme_label="汽车",
                peer_confirmation=2,
                leader_strength=1,
                sector_hot=True,
                obs_day=2,
                latest_date="2026-03-08",
                latest_close=13.10,
                latest_high=13.50,
                latest_low=12.80,
                close_ret_since_signal=0.065,
                max_ret_since_signal=0.098,
                hunt_touched=False,
                still_valid=True,
                new_same_side_signal=True,
                status_label="Chase Candidate",
                priority_rank="A级",
                note="未回踩但持续强于信号价，且同向信号刷新",
                active=True,
            )
        ],
        dropped=[],
    )
    text = render_markdown_summary(snapshot=snap, watch_window_days=5, execution_profile="delayed_limit_hunt")
    assert "市场概览" in text
    assert "今日新信号" in text
    assert "重点跟踪" in text
    assert "今日最值得看" in text
    assert "Chase Candidate" in text


def test_build_feishu_post_payload_wraps_lines():
    payload = build_feishu_post_payload("title", "line1\nline2")
    assert payload["msg_type"] == "post"
    content = payload["content"]["post"]["zh_cn"]["content"]
    assert content[0][0]["text"] == "line1"
    assert content[1][0]["text"] == "line2"

