from __future__ import annotations

import pandas as pd

from v5.backtest.runner import _filled_orders_to_trades
from v5.backtest.strategy_host import SubmittedOrderMeta


def test_filled_orders_to_trades_maps_cash_and_meta():
    orders = pd.DataFrame(
        [
            {
                "id": "o1",
                "symbol": "000001",
                "status": "filled",
                "avg_price": 10.0,
                "filled_quantity": 100.0,
                "commission": 5.0,
                "updated_at": "2024-01-02 00:00:00+08:00",
            },
            {
                "id": "o2",
                "symbol": "000001",
                "status": "filled",
                "avg_price": 11.0,
                "filled_quantity": 100.0,
                "commission": 6.0,
                "updated_at": "2024-01-03 00:00:00+08:00",
            },
        ]
    )
    submitted = {
        "o1": SubmittedOrderMeta(
            action="buy",
            symbol="000001",
            reason="entry:trend_spear",
            requested_price=10.0,
            qty=100.0,
            meta={"style": "breakout", "exit_style": "trend_hold", "position_mult": 1.0},
        ),
        "o2": SubmittedOrderMeta(
            action="sell",
            symbol="000001",
            reason="time_exit",
            requested_price=11.0,
            qty=100.0,
            meta={"style": "", "exit_style": "trend_hold", "position_mult": 1.0},
        ),
    }
    trades = _filled_orders_to_trades(orders, submitted, initial_cash=1_000_000.0)
    assert len(trades) == 2
    assert trades[0]["cash_after"] == 998995.0
    assert trades[1]["cash_after"] == 1000089.0
    assert trades[0]["reason"] == "entry:trend_spear"
    assert trades[1]["reason"] == "time_exit"
