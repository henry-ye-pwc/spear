from __future__ import annotations

from cq_backtest.shared.signal_schema import SignalEventV2
from v4.execution.state_machine import PositionState, V4ExecutionStateMachine
from v5.config.defaults import apply_execution_profile, load_default_config


def test_apply_execution_profile_sets_next_open_mode():
    cfg = load_default_config()
    apply_execution_profile(cfg, "next_open_realistic")
    assert cfg.execution.execution_profile == "next_open_realistic"
    assert cfg.execution.execution_mode == "NextOpen"


def test_apply_execution_profile_sets_delayed_hunt_mode():
    cfg = load_default_config()
    apply_execution_profile(cfg, "delayed_limit_hunt")
    assert cfg.execution.execution_profile == "delayed_limit_hunt"
    assert cfg.execution.execution_mode == "CurrentClose"


def test_realistic_profile_delays_position_until_next_open():
    sm = V4ExecutionStateMachine(
        max_positions=1,
        base_pos_pct=0.5,
        cooldown_days=1,
        execution_profile="next_open_realistic",
    )
    event = SignalEventV2(
        event_type="attack",
        symbol="000001",
        ts="2024-01-02",
        confidence=0.7,
        side="long",
        entry_plan={"style": "tail_close"},
        invalidation={"price": 9.4},
        exit_plan={"style": "continuation", "hold_days": 5, "take_profit_pct": 0.18},
    )

    decisions = sm.on_day(
        date="2024-01-02",
        d_idx=0,
        symbol="000001",
        open_price=10.0,
        close=10.0,
        high=10.5,
        low=9.8,
        limit_up=None,
        limit_down=None,
        events=[event],
        cash=100000.0,
        day_context={},
    )
    assert len(decisions) == 1
    assert decisions[0].action == "buy"
    assert decisions[0].price is None
    assert "000001" not in sm.positions
    assert sm.pending_fills["000001"].action == "buy"
    assert sm.pending_fills["000001"].execute_idx == 1

    decisions = sm.on_day(
        date="2024-01-03",
        d_idx=1,
        symbol="000001",
        open_price=11.0,
        close=11.2,
        high=11.5,
        low=10.9,
        limit_up=None,
        limit_down=None,
        events=[],
        cash=100000.0,
        day_context={},
    )
    assert decisions == []
    assert sm.positions["000001"].entry_price == 11.0
    assert sm.positions["000001"].entry_date == "2024-01-03"


def test_realistic_profile_delays_exit_until_next_open():
    sm = V4ExecutionStateMachine(
        max_positions=1,
        base_pos_pct=0.5,
        cooldown_days=1,
        execution_profile="next_open_realistic",
    )
    sm.positions["000001"] = PositionState(
        symbol="000001",
        entry_date="2024-01-02",
        entry_idx=0,
        entry_price=10.0,
        qty=100.0,
        source_event="trend_spear",
        stop_price=9.4,
        take_price=11.8,
        max_hold_days=5,
        exit_style="trend_hold",
    )

    decisions = sm.on_day(
        date="2024-01-03",
        d_idx=1,
        symbol="000001",
        open_price=10.0,
        close=9.6,
        high=10.1,
        low=9.3,
        limit_up=None,
        limit_down=None,
        events=[],
        cash=100000.0,
        day_context={},
    )
    assert len(decisions) == 1
    assert decisions[0].action == "sell"
    assert decisions[0].price is None
    assert "000001" in sm.positions
    assert sm.pending_fills["000001"].action == "sell"
    assert sm.pending_fills["000001"].execute_idx == 2

    decisions = sm.on_day(
        date="2024-01-04",
        d_idx=2,
        symbol="000001",
        open_price=9.2,
        close=9.3,
        high=9.5,
        low=9.0,
        limit_up=None,
        limit_down=None,
        events=[],
        cash=100000.0,
        day_context={},
    )
    assert decisions == []
    assert "000001" not in sm.positions


def test_hunt_profile_fills_when_future_bar_retests_target_band():
    sm = V4ExecutionStateMachine(
        max_positions=1,
        base_pos_pct=0.5,
        cooldown_days=1,
        execution_profile="delayed_limit_hunt",
        hunt_price_buffer_pct=0.01,
        hunt_window_days=3,
    )
    event = SignalEventV2(
        event_type="attack",
        symbol="000001",
        ts="2024-01-02",
        confidence=0.7,
        side="long",
        entry_plan={"style": "tail_close"},
        invalidation={"price": 9.4},
        exit_plan={"style": "continuation", "hold_days": 5, "take_profit_pct": 0.18},
    )

    decisions = sm.on_day(
        date="2024-01-02",
        d_idx=0,
        symbol="000001",
        open_price=10.0,
        close=10.0,
        high=10.5,
        low=9.8,
        limit_up=None,
        limit_down=None,
        events=[event],
        cash=100000.0,
        day_context={},
    )
    assert decisions == []
    assert sm.pending_hunts["000001"].target_price == 10.0
    assert "000001" not in sm.positions

    decisions = sm.on_day(
        date="2024-01-03",
        d_idx=1,
        symbol="000001",
        open_price=10.6,
        close=10.7,
        high=10.8,
        low=10.4,
        limit_up=None,
        limit_down=None,
        events=[],
        cash=100000.0,
        day_context={},
    )
    assert decisions == []
    assert "000001" in sm.pending_hunts

    decisions = sm.on_day(
        date="2024-01-04",
        d_idx=2,
        symbol="000001",
        open_price=10.2,
        close=10.3,
        high=10.15,
        low=9.95,
        limit_up=None,
        limit_down=None,
        events=[],
        cash=100000.0,
        day_context={},
    )
    assert len(decisions) == 1
    assert decisions[0].action == "buy"
    assert decisions[0].price == 10.0
    assert sm.positions["000001"].entry_price == 10.0
