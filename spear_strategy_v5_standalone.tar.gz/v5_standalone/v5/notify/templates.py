from __future__ import annotations

from typing import Any

from v5.notify.models import PositionSummary, SignalSnapshot, TradeSummary, WatchItem
from v5.notify.scanner import NotificationSnapshot


def _fmt_pct(value: float) -> str:
    return f"{value * 100:.1f}%"


def _fmt_price(value: float | None) -> str:
    return "-" if value is None else f"{value:.2f}"


def _trade_entry_line(idx: int, item: TradeSummary) -> str:
    parts = [f"{idx}. {item.symbol} {item.name or ''} | 买入 {_fmt_price(item.price)} × {item.qty:.0f}"]
    if item.signal_type:
        parts.append(f"   - 来源: {item.signal_type}")
    if item.signal_date:
        parts.append(f"   - 信号日: {item.signal_date}")
    parts.append(f"   - 仓位占比: {item.position_pct:.1f}%")
    return "\n".join(parts)


def _trade_exit_line(idx: int, item: TradeSummary) -> str:
    parts = [f"{idx}. {item.symbol} {item.name or ''} | 卖出 {_fmt_price(item.price)}"]
    parts.append(f"   - 原因: {item.reason}")
    return "\n".join(parts)


def _position_line(idx: int, item: PositionSummary) -> str:
    pnl_sign = "+" if item.unrealized_pnl_pct >= 0 else ""
    return (
        f"{idx}. {item.symbol} {item.name or ''} | "
        f"入{_fmt_price(item.entry_price)} → 现{_fmt_price(item.current_price)} | "
        f"{pnl_sign}{item.unrealized_pnl_pct:.1f}% | D+{item.days_held}"
    )


def _signal_block(idx: int, item: SignalSnapshot) -> str:
    env = f"板块{'强' if item.sector_hot else '一般'}共振, leader={item.leader_strength}"
    note = "3日内观察回踩/突破质量"
    if item.event_type in {"trend_spear", "post_limit"}:
        note = "若数日不回踩且继续强, 进入 chase 候选"
    badge = ""
    if item.traded:
        badge = " [已入场]"
    elif item.near_gate:
        badge = " [接近城门]"
    return "\n".join(
        [
            f"{idx}. {item.symbol} {item.name or ''} | {item.event_type} | {('A级' if item.signal_confidence >= 0.78 else 'B级')}{badge}".strip(),
            f"   - 信号强度: {item.signal_confidence:.2f}",
            f"   - 触发方式: {item.entry_style or '-'}",
            f"   - gate: {_fmt_price(item.gate_price)}",
            f"   - invalidation: {_fmt_price(item.invalidation_price)}",
            f"   - 环境: {env}",
            f"   - 备注: {note}",
        ]
    )


def _watch_block(idx: int, item: WatchItem) -> str:
    badge = " [已入场]" if item.traded else ""
    expiry = f" (剩余{item.days_to_expiry}天)" if item.days_to_expiry > 0 else ""
    return "\n".join(
        [
            f"{idx}. {item.symbol} {item.name or ''} | D+{item.obs_day}{expiry}{badge}",
            f"   - 状态: {item.status_label}",
            f"   - 相对信号日: {_fmt_pct(item.close_ret_since_signal)}",
            f"   - 最高涨幅: {_fmt_pct(item.max_ret_since_signal)}",
            f"   - 是否回踩hunt带: {'是' if item.hunt_touched else '否'}",
            f"   - 今日是否新增同向信号: {'是' if item.new_same_side_signal else '否'}",
            f"   - 结论: {item.note}",
        ]
    )


def _drop_line(item: WatchItem) -> str:
    badge = " [曾入场]" if item.traded else ""
    return f"- {item.symbol} {item.name or ''} | {item.event_type} | 原因: {item.note}{badge}"


def render_markdown_summary(
    *,
    snapshot: NotificationSnapshot,
    watch_window_days: int,
    execution_profile: str,
    push_top_new: int = 3,
    push_top_watch: int = 5,
    push_top_drops: int = 5,
    min_confidence: float = 0.0,
) -> str:
    all_new = [s for s in snapshot.new_signals if s.signal_confidence >= min_confidence] if min_confidence > 0 else snapshot.new_signals
    new_count = len(all_new)
    watch_count = len(snapshot.watch_updates)
    chase_count = sum(1 for x in snapshot.watch_updates if x.status_label == "Chase Candidate")
    drop_count = len(snapshot.dropped)

    top_new = all_new[:push_top_new]
    top_watch = snapshot.watch_updates[:push_top_watch]
    top_drops = snapshot.dropped[:push_top_drops]
    top_candidate = next((x for x in snapshot.watch_updates if x.status_label == "Chase Candidate"), None)
    if top_candidate is None and snapshot.watch_updates:
        top_candidate = snapshot.watch_updates[0]

    lines: list[str] = []
    if snapshot.mode == "preview" and snapshot.hint:
        lines.append(f"[{snapshot.hint}]")
        lines.append("")

    lines.extend([snapshot.as_of_date, ""])

    # Section 1: Today's Trades (if available)
    has_trades = snapshot.today_entries or snapshot.today_exits
    if has_trades:
        entry_count = len(snapshot.today_entries)
        exit_count = len(snapshot.today_exits)
        lines.extend(["今日交易", f"- 入场: {entry_count}", f"- 出场: {exit_count}", ""])
        if snapshot.today_entries:
            lines.append("入场明细")
            for i, item in enumerate(snapshot.today_entries, 1):
                lines.extend([_trade_entry_line(i, item), ""])
        if snapshot.today_exits:
            lines.append("出场明细")
            for i, item in enumerate(snapshot.today_exits, 1):
                lines.extend([_trade_exit_line(i, item), ""])

    # Section 2: Market overview + new signals
    lines.extend([
        "市场概览",
        f"- 今日新信号: {new_count}",
        f"- 观察中: {watch_count}",
        f"- 升级为强势延续: {chase_count}",
        f"- 失效/移除: {drop_count}",
    ])
    if snapshot.market_context and snapshot.market_context.conversion_rate > 0:
        lines.append(f"- 信号转化率: {_fmt_pct(snapshot.market_context.conversion_rate)}")
    lines.append("")

    lines.append(f"今日新信号 ({new_count})")
    if top_new:
        for i, item in enumerate(top_new, 1):
            lines.extend([_signal_block(i, item), ""])
    else:
        lines.append("- 无")
        lines.append("")

    # Section 3: Active Positions (if available)
    if snapshot.active_positions:
        lines.append(f"当前持仓 ({len(snapshot.active_positions)})")
        lines.append(f"- 总权益: {snapshot.portfolio_equity:,.0f}")
        lines.append(f"- 现金: {snapshot.portfolio_cash:,.0f}")
        lines.append(f"- 仓位: {snapshot.portfolio_exposure_pct:.1f}%")
        for i, pos in enumerate(snapshot.active_positions, 1):
            lines.append(_position_line(i, pos))
        lines.append("")

    # Section 4: Watch list
    lines.append(f"重点跟踪 ({watch_count})")
    if top_watch:
        for i, item in enumerate(top_watch, 1):
            lines.extend([_watch_block(i, item), ""])
    else:
        lines.append("- 无")
        lines.append("")

    # Section 5: Dropped
    lines.append(f"失效/移除 ({drop_count})")
    if top_drops:
        lines.extend(_drop_line(item) for item in top_drops)
    else:
        lines.append("- 无")
    lines.append("")

    lines.append("今日最值得看")
    if top_candidate is not None:
        lines.append(f"- {top_candidate.symbol} {top_candidate.name or ''}")
        lines.append(f"  原因: {top_candidate.note}")
    else:
        lines.append("- 暂无")
    lines.append("")
    lines.append("备注")
    lines.append(f"- 观察窗口: {watch_window_days}天")
    lines.append(f"- 当前执行模式: {execution_profile}")
    return "\n".join(lines).strip()


def build_feishu_post_payload(title: str, markdown_text: str) -> dict[str, Any]:
    lines = markdown_text.splitlines()
    content: list[list[dict[str, str]]] = []
    for line in lines:
        content.append([{"tag": "text", "text": line}])
    return {
        "msg_type": "post",
        "content": {
            "post": {
                "zh_cn": {
                    "title": title,
                    "content": content,
                }
            }
        },
    }
