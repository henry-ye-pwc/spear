from __future__ import annotations

import json
import tempfile
from datetime import datetime, UTC
from pathlib import Path

from v5.notify.models import WatchItem


def load_watch_state(path: str | Path) -> dict[str, WatchItem]:
    p = Path(path)
    if not p.exists():
        return {}
    data = json.loads(p.read_text(encoding="utf-8"))
    out: dict[str, WatchItem] = {}
    for key, value in data.items():
        out[key] = WatchItem(**value)
    return out


def save_watch_state(path: str | Path, state: dict[str, WatchItem]) -> None:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    payload = {key: item.to_dict() for key, item in state.items()}
    content = json.dumps(payload, ensure_ascii=False, indent=2)
    tmp = Path(tempfile.mktemp(dir=p.parent, suffix=".tmp"))
    tmp.write_text(content, encoding="utf-8")
    tmp.rename(p)


def make_watch_key(symbol: str, event_type: str, signal_date: str) -> str:
    return f"{symbol}:{event_type}:{signal_date}"


# ── cron_meta.json ──────────────────────────────────────────────────────


def load_cron_meta(state_dir: str | Path) -> dict:
    path = Path(state_dir) / "cron_meta.json"
    default: dict = {"last_run_date": None, "run_history": []}
    if not path.exists():
        return default
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(data, dict):
            return default
        data.setdefault("last_run_date", None)
        data.setdefault("run_history", [])
        return data
    except Exception:
        return default


def save_cron_meta(state_dir: str | Path, as_of_date: str) -> None:
    state_dir = Path(state_dir)
    state_dir.mkdir(parents=True, exist_ok=True)
    path = state_dir / "cron_meta.json"
    meta = load_cron_meta(state_dir)
    meta["last_run_date"] = as_of_date
    meta["run_history"].append({
        "date": as_of_date,
        "ts": datetime.now(UTC).isoformat(),
    })
    meta["run_history"] = meta["run_history"][-90:]
    content = json.dumps(meta, ensure_ascii=False, indent=2)
    tmp = Path(tempfile.mktemp(dir=state_dir, suffix=".tmp"))
    tmp.write_text(content, encoding="utf-8")
    tmp.rename(path)

