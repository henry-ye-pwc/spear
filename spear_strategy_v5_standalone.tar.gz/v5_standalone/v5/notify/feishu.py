from __future__ import annotations

import base64
import hashlib
import hmac
import json
import time
import urllib.request
from typing import Any


def _sign(timestamp: str, secret: str) -> str:
    string_to_sign = f"{timestamp}\n{secret}".encode("utf-8")
    digest = hmac.new(string_to_sign, b"", digestmod=hashlib.sha256).digest()
    return base64.b64encode(digest).decode("utf-8")


def send_feishu_webhook(
    *,
    webhook_url: str,
    payload: dict[str, Any],
    secret: str | None = None,
    timeout: float = 10.0,
) -> dict[str, Any]:
    body = dict(payload)
    if secret:
        timestamp = str(int(time.time()))
        body["timestamp"] = timestamp
        body["sign"] = _sign(timestamp, secret)
    req = urllib.request.Request(
        webhook_url,
        data=json.dumps(body, ensure_ascii=False).encode("utf-8"),
        headers={"Content-Type": "application/json; charset=utf-8"},
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        raw = resp.read().decode("utf-8")
    return json.loads(raw) if raw else {}

