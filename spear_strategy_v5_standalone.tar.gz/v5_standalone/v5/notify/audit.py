from __future__ import annotations

import json
from pathlib import Path


def append_audit(state_dir: str | Path, records: list[dict]) -> None:
    if not records:
        return
    path = Path(state_dir) / "audit.jsonl"
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as f:
        for record in records:
            f.write(json.dumps(record, ensure_ascii=False) + "\n")
