#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from cq_backtest.data.feed import DataFeed
from v5.config.pools import list_named_pools, resolve_named_pool


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="Prefetch and verify mootdx daily snapshot for a named pool")
    p.add_argument("--pool-name", default="code_txt_pool")
    p.add_argument("--cache-dir", default="./cache")
    p.add_argument("--end", default="2026-03-06")
    p.add_argument("--min-start", default="2020-01-02")
    p.add_argument("--max-bars", type=int, default=3200)
    p.add_argument("--output-dir", default="./v5/results/snapshot_prefetch")
    p.add_argument("--list-pools", action="store_true")
    return p


def verify_symbol(df: pd.DataFrame, end: str, min_start: str) -> dict:
    if df is None or df.empty:
        return {
            "status": "empty",
            "rows": 0,
            "first_date": "",
            "last_date": "",
            "covers_end": False,
            "covers_min_start": False,
        }
    first = pd.Timestamp(df.index.min()).normalize()
    last = pd.Timestamp(df.index.max()).normalize()
    end_ts = pd.Timestamp(end).normalize()
    min_start_ts = pd.Timestamp(min_start).normalize()
    return {
        "status": "ok",
        "rows": int(len(df)),
        "first_date": str(first.date()),
        "last_date": str(last.date()),
        "covers_end": bool(last >= end_ts),
        "covers_min_start": bool(first <= min_start_ts),
    }


def main() -> None:
    args = build_parser().parse_args()
    if args.list_pools:
        print(json.dumps(list_named_pools(), ensure_ascii=False, indent=2))
        return

    symbols = resolve_named_pool(args.pool_name)
    cache_dir = Path(args.cache_dir)
    out_dir = Path(args.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    feed = DataFeed(cache_dir=str(cache_dir))
    rows: list[dict] = []
    failures: list[str] = []

    for idx, sym in enumerate(symbols, start=1):
        code = str(sym).zfill(6)
        df = feed.get_kline(code, end_date=args.end, count=args.max_bars, cache_only=False)
        info = verify_symbol(df, end=args.end, min_start=args.min_start)
        row = {"symbol": code, **info}
        rows.append(row)
        if info["status"] != "ok" or not info["covers_end"]:
            failures.append(code)
        if idx % 50 == 0 or idx == len(symbols):
            print(f"[{idx}/{len(symbols)}] ok={sum(r['status']=='ok' for r in rows)} failures={len(failures)}")

    report = pd.DataFrame(rows).sort_values(["status", "symbol"]).reset_index(drop=True)
    report_path = out_dir / f"{args.pool_name}_snapshot_report.csv"
    report.to_csv(report_path, index=False)

    summary = {
        "pool_name": args.pool_name,
        "pool_size": len(symbols),
        "cache_dir": str(cache_dir.resolve()),
        "end": args.end,
        "min_start": args.min_start,
        "max_bars": args.max_bars,
        "ok_count": int((report["status"] == "ok").sum()),
        "covers_end_count": int(report["covers_end"].sum()) if not report.empty else 0,
        "covers_min_start_count": int(report["covers_min_start"].sum()) if not report.empty else 0,
        "failure_count": len(failures),
        "report_csv": str(report_path.resolve()),
        "failures": failures,
    }
    summary_path = out_dir / f"{args.pool_name}_snapshot_summary.json"
    summary_path.write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
