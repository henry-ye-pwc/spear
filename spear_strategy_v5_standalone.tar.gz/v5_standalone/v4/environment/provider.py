from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

import pandas as pd


def infer_name_theme(name: str) -> str:
    keywords = {
        "银行": ["银行"],
        "证券": ["证券", "券商"],
        "保险": ["保险"],
        "地产": ["地产", "置业", "置地", "房产"],
        "医药": ["医药", "药业", "生物", "制药", "医疗"],
        "科技": ["科技", "信息", "软件", "电子", "半导体", "芯片", "光电", "算力", "通信"],
        "新能源": ["新能源", "锂", "电池", "光伏", "风电", "储能"],
        "消费": ["食品", "饮料", "白酒", "乳业", "家电", "服装"],
        "制造": ["装备", "机械", "钢铁", "有色", "化工", "材料", "工业"],
        "传媒": ["传媒", "文化", "影视", "游戏"],
        "汽车": ["汽车", "车业"],
        "建筑": ["建筑", "建设", "建工"],
        "农业": ["农业", "农牧", "种业", "畜牧"],
        "军工": ["军工", "航天", "航空", "兵器", "船舶"],
        "国资": ["国投", "国资", "城投", "公用", "发展"],
    }
    for sector, kws in keywords.items():
        for kw in kws:
            if kw in name:
                return sector
    return "其他"


@dataclass(slots=True)
class EnvironmentProvider:
    cache_dir: str = "./cache"
    sector_cache_path: str = "./v5/data/static/stock_sectors_cache.csv"
    lhb_cache_path: str = "./output/lhb_cache.csv"
    stock_meta: dict[str, dict] = field(default_factory=dict)
    lhb: pd.DataFrame = field(default_factory=pd.DataFrame)

    def load(self) -> None:
        self.stock_meta = {}
        stock_list_path = Path(self.cache_dir) / "stock_list.pkl"
        if stock_list_path.exists():
            sl = pd.read_pickle(stock_list_path)
            sl["code"] = sl["code"].astype(str).str.zfill(6)
            name_col = "name" if "name" in sl.columns else None
            for _, row in sl.iterrows():
                code = str(row["code"]).zfill(6)
                name = str(row[name_col]) if name_col else ""
                self.stock_meta[code] = {
                    "name": name,
                    "name_theme": infer_name_theme(name),
                    "industry": "",
                }

        sector_path = Path(self.sector_cache_path)
        if sector_path.exists():
            sectors = pd.read_csv(sector_path)
            sectors["code"] = sectors["code"].astype(str).str.zfill(6)
            for _, row in sectors.iterrows():
                code = row["code"]
                meta = self.stock_meta.setdefault(code, {"name": "", "name_theme": "其他", "industry": ""})
                meta["industry"] = str(row.get("industry", "") or "")

        lhb_path = Path(self.lhb_cache_path)
        if lhb_path.exists():
            df = pd.read_csv(lhb_path)
            if "代码" in df.columns and "上榜日" in df.columns and "龙虎榜净买额" in df.columns:
                df["代码"] = df["代码"].astype(str).str.zfill(6)
                df["上榜日"] = pd.to_datetime(df["上榜日"])
                self.lhb = df[["代码", "上榜日", "龙虎榜净买额"]].copy()
            else:
                self.lhb = pd.DataFrame()
        else:
            self.lhb = pd.DataFrame()

    def get_symbol_meta(self, symbol: str) -> dict:
        return dict(self.stock_meta.get(symbol, {"name": "", "name_theme": "其他", "industry": ""}))

    def recent_lhb_net_sell(self, symbol: str, date: str, lookback_days: int = 5) -> bool:
        if self.lhb.empty:
            return False
        ts = pd.Timestamp(date)
        window_start = ts - pd.Timedelta(days=lookback_days)
        sub = self.lhb[(self.lhb["代码"] == symbol) & (self.lhb["上榜日"] >= window_start) & (self.lhb["上榜日"] <= ts)]
        if sub.empty:
            return False
        return float(sub["龙虎榜净买额"].sum()) < 0
