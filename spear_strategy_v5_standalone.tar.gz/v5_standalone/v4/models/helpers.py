from __future__ import annotations

import numpy as np
import pandas as pd


def is_spear(row: pd.Series) -> bool:
    return float(row["upper_shadow_pct"]) >= float(row["board_upper_shadow_min"])


def dense_mid(row: pd.Series) -> float:
    top = max(float(row["open"]), float(row["close"]))
    return (float(row["high"]) + top) / 2.0


def themed_env_ok(env: dict | None, *, allow_neutral: bool = False) -> bool:
    env = env or {}
    if "peer_confirmation" not in env and "leader_strength" not in env and not bool(env.get("_enforce_env", False)):
        return True
    peer = int(env.get("peer_confirmation", 0) or 0)
    leader = int(env.get("leader_strength", 0) or 0)
    theme = str(env.get("theme_label", "其他") or "其他")
    sector_hot = bool(env.get("sector_hot", False))
    if leader >= 1 or peer >= 1:
        return True
    if sector_hot and theme != "其他":
        return True
    if allow_neutral and theme != "其他":
        return True
    return False


def recent_spear_indices(frame: pd.DataFrame, window: int = 10) -> list[int]:
    idx: list[int] = []
    for i in range(max(0, len(frame) - window), len(frame)):
        row = frame.iloc[i]
        if is_spear(row) or bool(row.get("is_failed_board", False)):
            idx.append(i)
    return idx


def recent_event_gate(frame: pd.DataFrame, symbol: str, window: int = 10) -> float:
    idx = recent_spear_indices(frame, window=window)
    if not idx:
        row = frame.iloc[-1]
        return float(max(row["open"], row["close"]))
    total = 0.0
    weight = 0.0
    for i in idx:
        row = frame.iloc[i]
        amt = float(row.get("amount", 0.0) or 0.0)
        total += dense_mid(row) * max(amt, 1.0)
        weight += max(amt, 1.0)
    return total / weight if weight > 0 else float(frame.iloc[-1]["close"])


def resolved_breakout_gate(cur: pd.Series, dense_gate: float | None = None) -> float:
    body_top = float(max(cur["open"], cur["close"]))
    high = float(cur["high"])
    candidates = [body_top]
    if dense_gate is not None and np.isfinite(dense_gate):
        candidates.append(float(dense_gate))
    avwap = float(cur.get("anchored_vwap", np.nan))
    if np.isfinite(avwap):
        candidates.append(avwap)
    gate = max(candidates)
    return min(gate, high)


def prior_limit_event(frame: pd.DataFrame, lookback: int = 8) -> tuple[int | None, pd.Series | None]:
    recent = frame.iloc[max(0, len(frame) - lookback - 1) : -1]
    lu_days = recent[recent["is_limit_up_close"]]
    if lu_days.empty:
        return None, None
    idx = frame.index.get_loc(lu_days.index[-1])
    return idx, frame.iloc[idx]


def board_after_gate(frame: pd.DataFrame, lookback: int = 8) -> float:
    cur = frame.iloc[-1]
    limit_idx, _ = prior_limit_event(frame, lookback=lookback)
    body_top = float(max(cur["open"], cur["close"]))
    avwap = float(cur.get("anchored_vwap", np.nan))
    if limit_idx is None:
        return resolved_breakout_gate(cur, dense_gate=float(cur.get("event_dense_mid", body_top)))

    event_idx: list[int] = []
    for i in range(limit_idx, len(frame)):
        row = frame.iloc[i]
        if is_spear(row) or bool(row.get("is_failed_board", False)) or bool(row.get("is_limit_up_close", False)):
            event_idx.append(i)
    if not event_idx:
        dense_gate = float(cur.get("event_dense_mid", body_top))
    else:
        mids = [float(frame.iloc[i].get("event_dense_mid", dense_mid(frame.iloc[i]))) for i in event_idx[-2:]]
        dense_gate = float(np.mean(mids))
    candidates = [body_top, dense_gate]
    if np.isfinite(avwap):
        candidates.append(avwap)
    return min(float(cur["high"]), max(candidates))


def dual_spear_cut_gate(frame: pd.DataFrame, window: int = 10) -> float:
    cur = frame.iloc[-1]
    cut = float(cur.get("last_two_spear_cut_price", np.nan))
    if np.isfinite(cut):
        return min(float(cur["high"]), max(float(max(cur["open"], cur["close"])), cut))
    return resolved_breakout_gate(cur, dense_gate=recent_event_gate(frame, cur.get("symbol", ""), window=window))


def trend_city_gate(frame: pd.DataFrame, window: int = 10) -> float:
    cur = frame.iloc[-1]
    recent_idx = recent_spear_indices(frame, window=window)
    body_top = float(max(cur["open"], cur["close"]))
    avwap = float(cur.get("anchored_vwap", np.nan))
    mids = [float(frame.iloc[i].get("event_dense_mid", dense_mid(frame.iloc[i]))) for i in recent_idx[-3:]]
    dense_gate = float(np.mean(mids)) if mids else body_top
    candidates = [body_top, dense_gate]
    if np.isfinite(avwap):
        candidates.append(avwap)
    return min(float(cur["high"]), max(candidates))


def recent_limit_gap(frame: pd.DataFrame, lookback: int) -> int | None:
    idx, _ = prior_limit_event(frame, lookback=lookback)
    if idx is None:
        return None
    return len(frame) - 1 - idx
