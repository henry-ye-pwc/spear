from __future__ import annotations

from collections import namedtuple

import pandas as pd

from cq_backtest.shared.signal_schema import SignalEventV2
from v4.models.arb import detect_arb
from v4.models.attack import detect_attack
from v4.models.escape import detect_escape
from v4.models.failed_board import detect_failed_board
from v4.models.post_limit import detect_post_limit
from v4.models.sector_spear import detect_sector_spear
from v4.models.trend_spear import detect_trend_spear
from v4.models.youzi import detect_youzi

SignalCount = namedtuple("SignalCount", ["event_type", "side", "confidence"])


def count_signals(
    frame: pd.DataFrame,
    symbol: str,
    post_limit_lookback: int = 8,
    trend_multi_days: int = 5,
    attack_limit_lookback: int = 10,
    arb_limit_lookback: int = 7,
    env: dict | None = None,
    max_idx: int | None = None,
) -> list[SignalCount]:
    """Lightweight version of detect_signals that returns only (event_type, side, confidence).
    Used in the first pass for cross-sectional counting where full SignalEventV2 objects
    are not needed."""
    if max_idx is not None:
        frame = frame.iloc[: max_idx + 1]
    dets = [
        detect_escape(frame, symbol),
        detect_post_limit(frame, symbol, lookback=post_limit_lookback, env=env),
        detect_failed_board(frame, symbol, env=env),
        detect_trend_spear(frame, symbol, multi_days=trend_multi_days, env=env),
        detect_attack(frame, symbol, lookback=attack_limit_lookback, env=env),
        detect_arb(frame, symbol, lookback=arb_limit_lookback, env=env),
        detect_youzi(frame, symbol, env=env),
        detect_sector_spear(frame, symbol, env=env),
    ]
    return [SignalCount(x.event_type, x.side, x.confidence) for x in dets if x is not None]


def detect_signals(
    frame: pd.DataFrame,
    symbol: str,
    post_limit_lookback: int = 8,
    trend_multi_days: int = 5,
    attack_limit_lookback: int = 10,
    arb_limit_lookback: int = 7,
    env: dict | None = None,
    max_idx: int | None = None,
) -> list[SignalEventV2]:
    if max_idx is not None:
        frame = frame.iloc[: max_idx + 1]
    dets = [
        detect_escape(frame, symbol),
        detect_post_limit(frame, symbol, lookback=post_limit_lookback, env=env),
        detect_failed_board(frame, symbol, env=env),
        detect_trend_spear(frame, symbol, multi_days=trend_multi_days, env=env),
        detect_attack(frame, symbol, lookback=attack_limit_lookback, env=env),
        detect_arb(frame, symbol, lookback=arb_limit_lookback, env=env),
        detect_youzi(frame, symbol, env=env),
        detect_sector_spear(frame, symbol, env=env),
    ]
    return [x for x in dets if x is not None]
