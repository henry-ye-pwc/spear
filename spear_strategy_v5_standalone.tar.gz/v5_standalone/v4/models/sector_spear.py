from __future__ import annotations

import pandas as pd

from cq_backtest.shared.signal_schema import SignalEventV2
from v4.models.helpers import is_spear


def detect_sector_spear(frame: pd.DataFrame, symbol: str, env: dict | None = None) -> SignalEventV2 | None:
    env = env or {}
    cur = frame.iloc[-1]
    if not bool(env.get("sector_hot", False)):
        return None
    if str(env.get("theme_label", "其他")) == "其他":
        return None
    if bool(env.get("lhb_net_sell", False)):
        return None
    if not is_spear(cur):
        return None
    if float(cur.get("range_position_120", 0.5)) >= 0.78:
        return None
    if bool(cur.get("is_amount_explosive", False)):
        return None
    if not (bool(cur.get("is_amount_confirm", False)) or bool(cur.get("touch_limit_up", False))):
        return None

    invalid = float(cur["low"])
    confidence = 0.65
    confidence += min(0.08, 0.02 * int(env.get("peer_confirmation", 0)))
    confidence += min(0.05, 0.03 * int(env.get("leader_strength", 0)))

    return SignalEventV2(
        event_type="sector_spear",
        symbol=symbol,
        ts=str(frame.index[-1])[:10],
        confidence=min(0.9, round(confidence, 3)),
        side="long",
        tags=["sector_hot", "top_down"],
        entry_plan={"style": "tail_close"},
        invalidation={"type": "below_day_low", "price": round(invalid, 3)},
        exit_plan={"style": "sector_burst", "hold_days": 4, "take_profit_pct": 0.12},
        context={
            "theme_label": str(env.get("theme_label", "其他")),
            "peer_confirmation": int(env.get("peer_confirmation", 0)),
            "leader_strength": int(env.get("leader_strength", 0)),
        },
    )
