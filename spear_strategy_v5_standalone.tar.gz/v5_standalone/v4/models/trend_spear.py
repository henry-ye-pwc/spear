from __future__ import annotations

import numpy as np
import pandas as pd

from cq_backtest.shared.signal_schema import SignalEventV2
from v4.models.helpers import is_spear, themed_env_ok, trend_city_gate


def detect_trend_spear(frame: pd.DataFrame, symbol: str, multi_days: int = 5, env: dict | None = None) -> SignalEventV2 | None:
    if len(frame) < 80:
        return None
    cur = frame.iloc[-1]
    if not bool(cur.get("trend_up", False)) or not is_spear(cur):
        return None
    if not themed_env_ok(env, allow_neutral=True):
        return None

    recent = frame.iloc[-multi_days:]
    recent_spears = recent[recent["is_spear"]]
    if len(recent_spears) < 2:
        return None
    prev_amounts = recent_spears["amount"].astype(float).iloc[:-1]
    last_amount = float(recent_spears["amount"].iloc[-1])
    if len(prev_amounts) > 0 and last_amount > float(np.median(prev_amounts)) * 1.15:
        return None
    if bool(cur.get("is_amount_explosive", False)):
        return None
    if str(cur.get("three_gun_pattern", "mixed")) == "progressive_expand":
        return None
    if not (
        bool(cur.get("last_spear_shrink", False))
        or str(cur.get("three_gun_pattern", "mixed")) == "last_shrink"
        or int(cur.get("spear_order_10", 0)) >= 3
    ):
        return None

    gate = trend_city_gate(frame, window=max(6, multi_days + 3))
    invalid = min(float(cur["low"]), float(cur["ma20"]) if pd.notna(cur["ma20"]) else float(cur["low"]))
    confidence = 0.70
    if bool(cur.get("last_spear_shrink", False)):
        confidence += 0.06
    if bool(cur.get("consolidation_ok", False)):
        confidence += 0.03
    if str(cur.get("three_gun_pattern", "mixed")) == "last_shrink":
        confidence += 0.04

    return SignalEventV2(
        event_type="trend_spear",
        symbol=symbol,
        ts=str(frame.index[-1])[:10],
        confidence=min(0.92, round(confidence, 3)),
        side="long",
        tags=["trend", "multi_spear"],
        entry_plan={"style": "breakout", "gate_price": round(gate, 3), "valid_for_days": 5},
        invalidation={"type": "trend_break", "price": round(invalid, 3)},
        exit_plan={"style": "trend_hold", "hold_days": 10, "take_profit_pct": 0.22},
        context={
            "gate_source": "trend_city",
            "multi_spear_count": int(len(recent_spears)),
            "three_gun_pattern": str(cur.get("three_gun_pattern", "none")),
            "spear_role": str(cur.get("current_spear_role", "none")),
        },
    )
