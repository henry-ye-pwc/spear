from __future__ import annotations

import pandas as pd

from cq_backtest.shared.signal_schema import SignalEventV2
from v4.models.helpers import is_spear, recent_event_gate


def detect_youzi(frame: pd.DataFrame, symbol: str, env: dict | None = None) -> SignalEventV2 | None:
    env = env or {}
    cur = frame.iloc[-1]
    if not is_spear(cur):
        return None
    if float(cur.get("range_position_120", 0.5)) >= 0.82:
        return None
    if bool(cur.get("is_amount_explosive", False)):
        return None
    if not (bool(cur.get("near_peak_pressure", False)) or bool(cur.get("two_side_active", False))):
        return None

    hist = frame.iloc[-min(len(frame), 200):]
    lu_200 = int(hist["is_limit_up_close"].sum())
    lu_recent = int(frame.iloc[-8:-1]["is_limit_up_close"].sum()) if len(frame) >= 8 else 0
    if lu_200 < 3 or lu_recent == 0:
        return None

    theme_label = str(env.get("theme_label", "其他"))
    peer_confirmation = int(env.get("peer_confirmation", 0))
    leader_strength = int(env.get("leader_strength", 0))
    if theme_label == "其他" and peer_confirmation < 2:
        return None
    if peer_confirmation < 1 and leader_strength < 1:
        return None
    if bool(env.get("lhb_net_sell", False)):
        return None

    dense_gate = recent_event_gate(frame, symbol)
    invalid = min(float(cur["low"]), dense_gate * 0.985)
    confidence = 0.66
    if peer_confirmation >= 2:
        confidence += 0.05
    if leader_strength >= 1:
        confidence += 0.04

    return SignalEventV2(
        event_type="youzi",
        symbol=symbol,
        ts=str(frame.index[-1])[:10],
        confidence=min(0.9, round(confidence, 3)),
        side="long",
        tags=["theme", "peer_confirmation"],
        entry_plan={"style": "tail_close"},
        invalidation={"type": "below_day_low", "price": round(invalid, 3)},
        exit_plan={"style": "theme_burst", "hold_days": 5, "take_profit_pct": 0.16},
        context={
            "theme_label": theme_label,
            "peer_confirmation": peer_confirmation,
            "leader_strength": leader_strength,
            "lu_200": lu_200,
        },
    )
