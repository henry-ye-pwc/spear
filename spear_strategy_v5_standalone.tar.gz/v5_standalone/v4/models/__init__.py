from v4.models.registry import detect_signals

__all__ = ["detect_signals"]

