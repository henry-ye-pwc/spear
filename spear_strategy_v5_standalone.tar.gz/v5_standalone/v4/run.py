#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from v4.backtest.engine import V4BacktestEngine
from v4.config.defaults import load_default_config
from v4.reports.writer import write_reports


def build_parser() -> argparse.ArgumentParser:
    cfg = load_default_config()
    p = argparse.ArgumentParser(prog="v4/run.py", description="V4 spear strategy backtest runner")
    p.add_argument("--start", default=cfg.backtest.start)
    p.add_argument("--end", default=cfg.backtest.end)
    p.add_argument("--pool", type=int, default=cfg.backtest.pool_size)
    p.add_argument("--output-dir", default=cfg.backtest.output_dir)
    p.add_argument("--cache-dir", default=cfg.data.cache_dir)
    p.add_argument("--pool-sampling", default=cfg.data.pool_sampling, choices=["random", "head"])
    p.add_argument("--pool-seed", type=int, default=cfg.data.pool_seed)
    p.add_argument("--init-cash", type=float, default=1_000_000.0)
    p.add_argument("--enable-events", default="all")
    p.add_argument("--show-config", action="store_true")
    return p


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()
    cfg = load_default_config()
    if args.show_config:
        print(json.dumps(cfg, default=lambda o: o.__dict__, ensure_ascii=False, indent=2))
        return
    cfg.data.cache_dir = args.cache_dir
    cfg.data.pool_sampling = args.pool_sampling
    cfg.data.pool_seed = args.pool_seed
    engine = V4BacktestEngine(cfg)
    active_event_types = None
    if args.enable_events.strip().lower() != "all":
        active_event_types = {x.strip() for x in args.enable_events.split(",") if x.strip()}
    result = engine.run(args.start, args.end, args.pool, init_cash=args.init_cash, active_event_types=active_event_types)
    write_reports(args.output_dir, result, cfg, args.start, args.end)
    print(json.dumps(result.summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
