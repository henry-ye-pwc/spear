from __future__ import annotations

import numpy as np
import pandas as pd

from cq_backtest.shared.feature_primitives import half_sample_mode, rolling_mad, rolling_rank_pct


def add_robust_volume_features(df: pd.DataFrame, window: int = 60) -> pd.DataFrame:
    out = df.copy()
    amount = out["amount"].astype(float)
    log_amount = out["log_amount"].astype(float)
    med = log_amount.rolling(window, min_periods=max(10, window // 3)).median()
    mad = rolling_mad(log_amount, window).replace(0.0, np.nan)
    hsm = amount.rolling(window, min_periods=max(10, window // 3)).apply(half_sample_mode, raw=False)

    out["amount_rank"] = rolling_rank_pct(amount, window).fillna(0.5)
    out["amount_z"] = ((log_amount - med) / mad).replace([np.inf, -np.inf], np.nan).fillna(0.0)
    out["amount_base_hsm"] = hsm.fillna(amount.rolling(window, min_periods=5).median())
    out["amount_q95"] = amount.rolling(window, min_periods=max(10, window // 3)).quantile(0.95).fillna(amount)
    out["is_amount_outlier"] = out["amount_z"] >= 4.0
    out["is_amount_confirm"] = (out["amount"] >= out["amount_base_hsm"] * 1.30) & (out["amount"] <= out["amount_q95"] * 1.05)
    out["is_amount_explosive"] = (out["amount_rank"] >= 0.985) | (out["amount_z"] >= 4.5)
    return out
