from __future__ import annotations

import numpy as np
import pandas as pd

try:
    from numba import njit
    _HAS_NUMBA = True
except ImportError:
    _HAS_NUMBA = False


# ---------------------------------------------------------------------------
# Numba-accelerated kernel for add_structure_features.
#
# PERFORMANCE CONTEXT (2026-03):
#   Original pure-Python loop: ~1500ms per symbol (3200 bars).
#   Numba kernel:              ~15-30ms per symbol.
#   This is the single biggest bottleneck in prepare_bundle Phase A.
#
# ROLLBACK: If the numba kernel produces incorrect results or causes issues,
#   replace the body of add_structure_features() with a call to
#   _add_structure_features_original() below. The original implementation
#   is preserved verbatim as a reference.
# ---------------------------------------------------------------------------

if _HAS_NUMBA:
    @njit(cache=True)
    def _structure_kernel(
        highs, lows, closes, amp_pct, amount_rank, is_spear, is_limit_up_close,
        ma20, ma60, vwap_proxy, amount, volume,
        peak_window, drawdown_min, peak_touch_eps, consolidation_window,
        n,
    ):
        peak_price = np.full(n, np.nan)
        release_price = np.full(n, np.nan)
        range_position = np.full(n, np.nan)
        near_peak = np.full(n, 0.0)
        near_release = np.full(n, 0.0)
        two_side_active = np.full(n, 0.0)
        consolidation_ok = np.full(n, 0.0)
        trend_up = np.full(n, 0.0)
        anchor_vwap_out = np.full(n, np.nan)
        event_anchor_start = np.full(n, np.nan)

        last_spear_idx = -1
        last_limit_idx = -1

        for i in range(n):
            if is_spear[i]:
                last_spear_idx = i
            if is_limit_up_close[i]:
                last_limit_idx = i

            s = i - peak_window if i - peak_window > 0 else 0
            seg_len = i + 1 - s
            if seg_len < 20:
                continue

            hi = highs[s]
            lo = lows[s]
            for j in range(s + 1, i + 1):
                if highs[j] > hi:
                    hi = highs[j]
                if lows[j] < lo:
                    lo = lows[j]
            rng = hi - lo
            range_position[i] = (closes[i] - lo) / rng if rng > 0 else 0.5

            hist_len = i - s
            if hist_len < 10:
                continue
            peak_rel = 0
            peak_val = highs[s]
            for j in range(s + 1, i):
                if highs[j] > peak_val:
                    peak_val = highs[j]
                    peak_rel = j - s
            peak_idx = s + peak_rel
            pressure = highs[peak_idx]
            peak_price[i] = pressure

            trough_val = lows[peak_idx]
            trough_idx = peak_idx
            for j in range(peak_idx + 1, i + 1):
                if lows[j] < trough_val:
                    trough_val = lows[j]
                    trough_idx = j
            release = lows[trough_idx]
            release_price[i] = release
            band = pressure - release
            if band < 1e-6:
                band = 1e-6

            near_peak[i] = 1.0 if highs[i] >= pressure * (1.0 - peak_touch_eps) else 0.0
            near_release[i] = 1.0 if lows[i] <= release * 1.03 else 0.0

            bar_range = highs[i] - lows[i]
            if near_peak[i] > 0 and near_release[i] > 0 and bar_range / band >= 0.55:
                two_side_active[i] = 1.0
            else:
                two_side_active[i] = 0.0

            # consolidation check
            c_start = trough_idx if trough_idx > i - consolidation_window + 1 else i - consolidation_window + 1
            c_len = i + 1 - c_start
            min_c = consolidation_window // 3
            if min_c < 8:
                min_c = 8
            if c_len >= min_c:
                # median of amp_pct[c_start:i+1]
                tmp_amp = amp_pct[c_start:i + 1].copy()
                tmp_amp.sort()
                mid = len(tmp_amp) // 2
                med_amp = tmp_amp[mid] if len(tmp_amp) % 2 == 1 else (tmp_amp[mid - 1] + tmp_amp[mid]) / 2.0
                low_vol = med_amp <= 0.06

                tmp_ar = amount_rank[c_start:i + 1].copy()
                tmp_ar.sort()
                mid2 = len(tmp_ar) // 2
                med_ar = tmp_ar[mid2] if len(tmp_ar) % 2 == 1 else (tmp_ar[mid2 - 1] + tmp_ar[mid2]) / 2.0
                low_turn = med_ar <= 0.65

                if low_vol and low_turn:
                    consolidation_ok[i] = 1.0

                anchor_start = c_start
                if last_spear_idx >= anchor_start and last_spear_idx <= i:
                    anchor_start = last_spear_idx
                if last_limit_idx >= anchor_start and last_limit_idx <= i:
                    if last_limit_idx > anchor_start:
                        anchor_start = last_limit_idx
                event_anchor_start[i] = float(anchor_start)

                # inline anchored_vwap
                total_amt = 0.0
                weighted_price = 0.0
                for j in range(anchor_start, i + 1):
                    a = amount[j]
                    if a > 0:
                        total_amt += a
                        weighted_price += vwap_proxy[j] * a
                if total_amt > 0:
                    anchor_vwap_out[i] = weighted_price / total_amt
                else:
                    total_vol = 0.0
                    weighted_price2 = 0.0
                    for j in range(anchor_start, i + 1):
                        v = volume[j]
                        if v > 0:
                            total_vol += v
                            weighted_price2 += vwap_proxy[j] * v
                    if total_vol > 0:
                        anchor_vwap_out[i] = weighted_price2 / total_vol

            # trend check
            m20 = ma20[i]
            m60 = ma60[i]
            if np.isfinite(m20) and np.isfinite(m60) and m20 > m60 and closes[i] > m20:
                trend_up[i] = 1.0

            # drawdown filter
            if pressure > 0 and release > 0:
                dd = (release / pressure) - 1.0
                if dd > -abs(drawdown_min):
                    two_side_active[i] = 0.0

        return (peak_price, release_price, range_position,
                near_peak, near_release, two_side_active,
                consolidation_ok, trend_up, anchor_vwap_out, event_anchor_start)


def add_structure_features(
    df: pd.DataFrame,
    peak_window: int = 120,
    drawdown_min: float = 0.15,
    peak_touch_eps: float = 0.03,
    consolidation_window: int = 30,
) -> pd.DataFrame:
    out = df.copy()
    n = len(out)

    if not _HAS_NUMBA or n == 0:
        return _add_structure_features_original(out, peak_window, drawdown_min, peak_touch_eps, consolidation_window)

    highs = out["high"].to_numpy(dtype=np.float64)
    lows = out["low"].to_numpy(dtype=np.float64)
    closes = out["close"].to_numpy(dtype=np.float64)
    amp_pct = out["amp_pct"].to_numpy(dtype=np.float64) if "amp_pct" in out.columns else np.zeros(n)
    amount_rank = out["amount_rank"].to_numpy(dtype=np.float64) if "amount_rank" in out.columns else np.full(n, 0.5)
    is_spear = out["is_spear"].to_numpy(dtype=bool) if "is_spear" in out.columns else np.zeros(n, dtype=bool)
    is_limit = out["is_limit_up_close"].to_numpy(dtype=bool) if "is_limit_up_close" in out.columns else np.zeros(n, dtype=bool)
    ma20_arr = out["ma20"].to_numpy(dtype=np.float64) if "ma20" in out.columns else np.full(n, np.nan)
    ma60_arr = out["ma60"].to_numpy(dtype=np.float64) if "ma60" in out.columns else np.full(n, np.nan)
    vwap_proxy = out["vwap_proxy"].to_numpy(dtype=np.float64) if "vwap_proxy" in out.columns else closes.copy()
    amount_arr = out["amount"].to_numpy(dtype=np.float64) if "amount" in out.columns else np.zeros(n)
    volume_arr = out["volume"].to_numpy(dtype=np.float64) if "volume" in out.columns else np.zeros(n)

    (peak_price, release_price, range_position,
     near_peak, near_release, two_side_active,
     consolidation_ok, trend_up, anchor_vwap, event_anchor_start) = _structure_kernel(
        highs, lows, closes, amp_pct, amount_rank, is_spear, is_limit,
        ma20_arr, ma60_arr, vwap_proxy, amount_arr, volume_arr,
        peak_window, drawdown_min, peak_touch_eps, consolidation_window, n,
    )

    out["pressure_price"] = peak_price
    out["release_price"] = release_price
    out["range_position_120"] = range_position
    out["near_peak_pressure"] = near_peak.astype(bool)
    out["near_release_support"] = near_release.astype(bool)
    out["two_side_active"] = two_side_active.astype(bool)
    out["consolidation_ok"] = consolidation_ok.astype(bool)
    out["trend_up"] = trend_up.astype(bool)
    out["anchored_vwap"] = anchor_vwap
    out["event_anchor_start"] = event_anchor_start
    return out


# ---------------------------------------------------------------------------
# ORIGINAL IMPLEMENTATION (preserved as reference / rollback target).
# If the numba kernel above produces incorrect results, swap the call in
# add_structure_features() to use this function instead.
# ---------------------------------------------------------------------------
def _add_structure_features_original(
    out: pd.DataFrame,
    peak_window: int = 120,
    drawdown_min: float = 0.15,
    peak_touch_eps: float = 0.03,
    consolidation_window: int = 30,
) -> pd.DataFrame:
    from cq_backtest.shared.feature_primitives import anchored_vwap

    n = len(out)
    peak_price = np.full(n, np.nan)
    release_price = np.full(n, np.nan)
    range_position = np.full(n, np.nan)
    near_peak = np.full(n, False)
    near_release = np.full(n, False)
    two_side_active = np.full(n, False)
    consolidation_ok = np.full(n, False)
    trend_up = np.full(n, False)
    anchor_vwap_arr = np.full(n, np.nan)
    event_anchor_start = np.full(n, np.nan)

    highs = out["high"].to_numpy(dtype=float)
    lows = out["low"].to_numpy(dtype=float)
    closes = out["close"].to_numpy(dtype=float)

    for i in range(n):
        s = max(0, i - peak_window)
        seg_h = highs[s : i + 1]
        seg_l = lows[s : i + 1]
        if len(seg_h) < 20:
            continue
        hi = float(np.max(seg_h))
        lo = float(np.min(seg_l))
        rng = hi - lo
        range_position[i] = (closes[i] - lo) / rng if rng > 0 else 0.5

        hist_h = highs[s:i]
        if len(hist_h) < 10:
            continue
        peak_rel = int(np.argmax(hist_h))
        peak_idx = s + peak_rel
        pressure = float(highs[peak_idx])
        peak_price[i] = pressure
        trough_idx = peak_idx + int(np.argmin(lows[peak_idx : i + 1]))
        release = float(lows[trough_idx])
        release_price[i] = release
        band = max(pressure - release, 1e-6)
        near_peak[i] = highs[i] >= pressure * (1.0 - peak_touch_eps)
        near_release[i] = lows[i] <= release * 1.03
        two_side_active[i] = bool(near_peak[i] and near_release[i] and (highs[i] - lows[i]) / band >= 0.55)

        c_start = max(trough_idx, i - consolidation_window + 1)
        c = out.iloc[c_start : i + 1]
        if len(c) >= max(8, consolidation_window // 3):
            low_vol = float(c["amp_pct"].median()) <= 0.06
            low_turn = float(c["amount_rank"].median()) <= 0.65 if "amount_rank" in c.columns else True
            consolidation_ok[i] = low_vol and low_turn
            anchor_start = c_start
            if "is_spear" in out.columns:
                spear_candidates = np.where(out.iloc[: i + 1]["is_spear"].to_numpy(dtype=bool))[0]
                if len(spear_candidates) > 0:
                    anchor_start = max(anchor_start, int(spear_candidates[-1]))
            if "is_limit_up_close" in out.columns:
                limit_candidates = np.where(out.iloc[: i + 1]["is_limit_up_close"].to_numpy(dtype=bool))[0]
                if len(limit_candidates) > 0:
                    anchor_start = max(anchor_start, int(limit_candidates[-1]))
            event_anchor_start[i] = anchor_start
            anchor_vwap_arr[i] = anchored_vwap(out.iloc[: i + 1], anchor_start)

        ma20_val = float(out.iloc[i]["ma20"]) if pd.notna(out.iloc[i]["ma20"]) else np.nan
        ma60_val = float(out.iloc[i]["ma60"]) if pd.notna(out.iloc[i]["ma60"]) else np.nan
        trend_up[i] = bool(np.isfinite(ma20_val) and np.isfinite(ma60_val) and ma20_val > ma60_val and closes[i] > ma20_val)

        if pressure > 0 and release > 0:
            dd = (release / pressure) - 1.0
            if dd > -abs(drawdown_min):
                two_side_active[i] = False

    out["pressure_price"] = peak_price
    out["release_price"] = release_price
    out["range_position_120"] = range_position
    out["near_peak_pressure"] = near_peak
    out["near_release_support"] = near_release
    out["two_side_active"] = two_side_active
    out["consolidation_ok"] = consolidation_ok
    out["trend_up"] = trend_up
    out["anchored_vwap"] = anchor_vwap_arr
    out["event_anchor_start"] = event_anchor_start
    return out
