from __future__ import annotations

import numpy as np
import pandas as pd

try:
    from numba import njit
    _HAS_NUMBA = True
except ImportError:
    _HAS_NUMBA = False


# ---------------------------------------------------------------------------
# Numba-accelerated kernel for add_sequence_features.
#
# PERFORMANCE CONTEXT (2026-03):
#   Original pure-Python loop: ~142ms per symbol (3200 bars).
#   Numba kernel:              ~3-8ms per symbol.
#
# String-valued columns (three_gun_pattern, current_spear_role) are encoded
# as int8 inside the kernel and mapped back to strings outside:
#   three_gun_pattern:  0=none, 1=progressive_expand, 2=last_shrink, 3=mixed
#   current_spear_role: 0=none, 1=first, 2=second, 3=last
#
# ROLLBACK: If the numba kernel produces incorrect results or causes issues,
#   replace the body of add_sequence_features() with a call to
#   _add_sequence_features_original() below. The original implementation
#   is preserved verbatim as a reference.
# ---------------------------------------------------------------------------

if _HAS_NUMBA:
    @njit(cache=True)
    def _sequence_kernel(
        upper_shadow_pct, board_upper_shadow_min_val,
        is_limit_up_close_arr,
        amounts, highs, opens, closes,
        window, n,
    ):
        is_spear = np.empty(n, dtype=np.bool_)
        for i in range(n):
            is_spear[i] = upper_shadow_pct[i] >= board_upper_shadow_min_val

        recent_5 = np.empty(n, dtype=np.int64)
        recent_10 = np.empty(n, dtype=np.int64)
        for i in range(n):
            cnt5 = 0
            s5 = i - 4 if i - 4 > 0 else 0
            for j in range(s5, i + 1):
                if is_spear[j]:
                    cnt5 += 1
            recent_5[i] = cnt5

            cnt10 = 0
            s10 = i - window + 1 if i - window + 1 > 0 else 0
            for j in range(s10, i + 1):
                if is_spear[j]:
                    cnt10 += 1
            recent_10[i] = cnt10

        last_limit_gap = np.full(n, np.nan)
        last_spear_gap = np.full(n, np.nan)
        last_spear_shrink = np.full(n, 0.0)
        spear_order = np.zeros(n, dtype=np.int64)
        last_two_cut = np.full(n, np.nan)
        dual_spear_distance = np.full(n, np.nan)
        event_dense_mid = np.full(n, np.nan)
        three_gun_code = np.zeros(n, dtype=np.int8)  # 0=none
        spear_role_code = np.zeros(n, dtype=np.int8)  # 0=none

        # pre-allocated storage for spear and limit indices (max n entries)
        spear_buf = np.empty(n, dtype=np.int64)
        limit_buf = np.empty(n, dtype=np.int64)
        n_spear = 0
        n_limit = 0

        for i in range(n):
            if is_limit_up_close_arr[i]:
                limit_buf[n_limit] = i
                n_limit += 1
            if is_spear[i]:
                spear_buf[n_spear] = i
                n_spear += 1
                top = opens[i] if opens[i] > closes[i] else closes[i]
                event_dense_mid[i] = (highs[i] + top) / 2.0

            if n_limit > 0:
                last_limit_gap[i] = float(i - limit_buf[n_limit - 1])
            if n_spear > 0:
                last_spear_gap[i] = float(i - spear_buf[n_spear - 1])

            # find recent spears in window [i-window+1, i]
            low_bound = i - window + 1
            if low_bound < 0:
                low_bound = 0
            # binary search for start of window in spear_buf
            lo_idx = 0
            hi_idx = n_spear
            while lo_idx < hi_idx:
                mid = (lo_idx + hi_idx) // 2
                if spear_buf[mid] < low_bound:
                    lo_idx = mid + 1
                else:
                    hi_idx = mid
            # recent spears are spear_buf[lo_idx:n_spear] where val <= i
            rc_start = lo_idx
            rc_end = n_spear
            # trim to those <= i (should already be true since we add in order)
            rc_count = 0
            for k in range(rc_start, rc_end):
                if spear_buf[k] <= i:
                    rc_count += 1
                else:
                    break
            spear_order[i] = rc_count

            if is_spear[i]:
                if rc_count == 1:
                    spear_role_code[i] = 1  # "first"
                elif rc_count == 2:
                    spear_role_code[i] = 2  # "second"
                else:
                    spear_role_code[i] = 3  # "last"

            if rc_count >= 2:
                # last two spears
                idx_last = spear_buf[rc_start + rc_count - 1]
                idx_prev = spear_buf[rc_start + rc_count - 2]
                # amounts median of all previous recent spears
                med_sum = 0.0
                prev_count = rc_count - 1
                prev_amounts = np.empty(prev_count, dtype=np.float64)
                for k in range(prev_count):
                    prev_amounts[k] = amounts[spear_buf[rc_start + k]]
                prev_amounts_sorted = prev_amounts.copy()
                prev_amounts_sorted.sort()
                mid_idx = prev_count // 2
                if prev_count % 2 == 1:
                    med_val = prev_amounts_sorted[mid_idx]
                else:
                    med_val = (prev_amounts_sorted[mid_idx - 1] + prev_amounts_sorted[mid_idx]) / 2.0

                if amounts[spear_buf[rc_start + rc_count - 1]] <= med_val * 0.95:
                    last_spear_shrink[i] = 1.0

                top1 = opens[idx_prev] if opens[idx_prev] > closes[idx_prev] else closes[idx_prev]
                mid1 = (highs[idx_prev] + top1) / 2.0
                top2 = opens[idx_last] if opens[idx_last] > closes[idx_last] else closes[idx_last]
                mid2 = (highs[idx_last] + top2) / 2.0
                last_two_cut[i] = (mid1 + mid2) / 2.0
                denom = mid1 if mid1 > 1e-6 else 1e-6
                dual_spear_distance[i] = abs(mid2 - mid1) / denom

            if rc_count >= 3:
                a1 = amounts[spear_buf[rc_start + rc_count - 3]]
                a2 = amounts[spear_buf[rc_start + rc_count - 2]]
                a3 = amounts[spear_buf[rc_start + rc_count - 1]]
                grow12 = a2 >= a1 * 1.05
                grow23 = a3 >= a2 * 1.05
                if grow12 and grow23:
                    three_gun_code[i] = 1  # progressive_expand
                else:
                    med12 = (a1 + a2) / 2.0
                    if a3 <= med12 * 0.95:
                        three_gun_code[i] = 2  # last_shrink
                    else:
                        three_gun_code[i] = 3  # mixed

        return (is_spear, recent_5, recent_10,
                last_limit_gap, last_spear_gap, last_spear_shrink,
                spear_order, last_two_cut, dual_spear_distance,
                event_dense_mid, three_gun_code, spear_role_code)


_THREE_GUN_MAP = np.array(["none", "progressive_expand", "last_shrink", "mixed"], dtype=object)
_SPEAR_ROLE_MAP = np.array(["none", "first", "second", "last"], dtype=object)


def add_sequence_features(df: pd.DataFrame, window: int = 10) -> pd.DataFrame:
    out = df.copy()
    n = len(out)

    if not _HAS_NUMBA or n == 0:
        return _add_sequence_features_original(out, window)

    upper_shadow_pct = out["upper_shadow_pct"].to_numpy(dtype=np.float64)
    board_min = float(out["board_upper_shadow_min"].iloc[0])
    is_limit_arr = out["is_limit_up_close"].to_numpy(dtype=bool) if "is_limit_up_close" in out.columns else np.zeros(n, dtype=bool)
    amounts = out["amount"].to_numpy(dtype=np.float64)
    highs = out["high"].to_numpy(dtype=np.float64)
    opens = out["open"].to_numpy(dtype=np.float64)
    closes = out["close"].to_numpy(dtype=np.float64)

    (is_spear, recent_5, recent_10,
     last_limit_gap, last_spear_gap, last_spear_shrink,
     spear_order, last_two_cut, dual_spear_distance,
     event_dense_mid, three_gun_code, spear_role_code) = _sequence_kernel(
        upper_shadow_pct, board_min, is_limit_arr,
        amounts, highs, opens, closes, window, n,
    )

    out["is_spear"] = is_spear
    out["recent_spear_count_5"] = recent_5
    out["recent_spear_count_10"] = recent_10
    out["last_limit_gap"] = last_limit_gap
    out["last_spear_gap"] = last_spear_gap
    out["last_spear_shrink"] = last_spear_shrink.astype(bool)
    out["spear_order_10"] = spear_order
    out["last_two_spear_cut_price"] = last_two_cut
    out["dual_spear_distance"] = dual_spear_distance
    out["event_dense_mid"] = pd.Series(event_dense_mid, index=out.index).fillna(out[["open", "close"]].max(axis=1))
    out["three_gun_pattern"] = _THREE_GUN_MAP[three_gun_code]
    out["current_spear_role"] = _SPEAR_ROLE_MAP[spear_role_code]
    return out


# ---------------------------------------------------------------------------
# ORIGINAL IMPLEMENTATION (preserved as reference / rollback target).
# If the numba kernel above produces incorrect results, swap the call in
# add_sequence_features() to use this function instead.
# ---------------------------------------------------------------------------
def _add_sequence_features_original(out: pd.DataFrame, window: int = 10) -> pd.DataFrame:
    is_spear = out["upper_shadow_pct"] >= out["board_upper_shadow_min"]
    out["is_spear"] = is_spear
    out["recent_spear_count_5"] = is_spear.rolling(5, min_periods=1).sum().astype(int)
    out["recent_spear_count_10"] = is_spear.rolling(window, min_periods=1).sum().astype(int)

    last_limit_gap = np.full(len(out), np.nan)
    last_spear_gap = np.full(len(out), np.nan)
    last_spear_shrink = np.full(len(out), False)
    spear_order = np.full(len(out), 0)
    last_two_cut = np.full(len(out), np.nan)
    dual_spear_distance = np.full(len(out), np.nan)
    event_dense_mid = np.full(len(out), np.nan)
    three_gun_pattern = np.full(len(out), "none", dtype=object)
    current_spear_role = np.full(len(out), "none", dtype=object)
    limit_idx: list[int] = []
    spear_idx: list[int] = []
    amounts = out["amount"].astype(float).tolist()
    highs = out["high"].astype(float).tolist()
    opens = out["open"].astype(float).tolist()
    closes = out["close"].astype(float).tolist()

    def _dense_mid(j: int) -> float:
        top = max(opens[j], closes[j])
        return (highs[j] + top) / 2.0

    for i in range(len(out)):
        if bool(out.iloc[i].get("is_limit_up_close", False)):
            limit_idx.append(i)
        if bool(is_spear.iloc[i]):
            spear_idx.append(i)
            event_dense_mid[i] = _dense_mid(i)
        if limit_idx:
            last_limit_gap[i] = i - limit_idx[-1]
        if spear_idx:
            last_spear_gap[i] = i - spear_idx[-1]
        recent = [j for j in spear_idx if j <= i and j >= i - window + 1]
        spear_order[i] = len(recent)
        if bool(is_spear.iloc[i]):
            if len(recent) == 1:
                current_spear_role[i] = "first"
            elif len(recent) == 2:
                current_spear_role[i] = "second"
            else:
                current_spear_role[i] = "last"
        if len(recent) >= 2:
            prev = [amounts[j] for j in recent[:-1]]
            if prev:
                last_spear_shrink[i] = bool(amounts[recent[-1]] <= np.median(prev) * 0.95)
            mids = [_dense_mid(j) for j in recent[-2:]]
            last_two_cut[i] = float(np.mean(mids))
            dual_spear_distance[i] = abs(mids[-1] - mids[-2]) / max(mids[-2], 1e-6)
        if len(recent) >= 3:
            recent_amounts = [amounts[j] for j in recent[-3:]]
            grow12 = recent_amounts[1] >= recent_amounts[0] * 1.05
            grow23 = recent_amounts[2] >= recent_amounts[1] * 1.05
            if grow12 and grow23:
                three_gun_pattern[i] = "progressive_expand"
            elif recent_amounts[2] <= np.median(recent_amounts[:2]) * 0.95:
                three_gun_pattern[i] = "last_shrink"
            else:
                three_gun_pattern[i] = "mixed"

    out["last_limit_gap"] = last_limit_gap
    out["last_spear_gap"] = last_spear_gap
    out["last_spear_shrink"] = last_spear_shrink
    out["spear_order_10"] = spear_order
    out["last_two_spear_cut_price"] = last_two_cut
    out["dual_spear_distance"] = dual_spear_distance
    out["event_dense_mid"] = pd.Series(event_dense_mid, index=out.index).fillna(out[["open", "close"]].max(axis=1))
    out["three_gun_pattern"] = three_gun_pattern
    out["current_spear_role"] = current_spear_role
    return out
