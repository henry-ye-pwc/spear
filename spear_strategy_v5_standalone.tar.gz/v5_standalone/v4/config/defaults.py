from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(slots=True)
class DataConfig:
    cache_dir: str = "./cache"
    bar_count: int = 420
    pool_sampling: str = "head"
    pool_seed: int = 42
    sector_cache_path: str = "./v5/data/static/stock_sectors_cache.csv"
    lhb_cache_path: str = "./output/lhb_cache.csv"


@dataclass(slots=True)
class FeatureConfig:
    vol_window: int = 60
    peak_window: int = 120
    drawdown_min: float = 0.15
    peak_touch_eps: float = 0.03
    consolidation_window: int = 30
    sequence_window: int = 10


@dataclass(slots=True)
class ModelConfig:
    post_limit_lookback: int = 8
    trend_multi_spear_days: int = 5
    attack_limit_lookback: int = 10
    arb_limit_lookback: int = 7


@dataclass(slots=True)
class ExecutionConfig:
    max_positions: int = 4
    base_pos_pct: float = 0.25
    trend_spear_pos_mult: float = 1.00
    post_limit_pos_mult: float = 0.90
    failed_board_pos_mult: float = 0.85
    youzi_pos_mult: float = 0.75
    sector_spear_pos_mult: float = 0.70
    attack_pos_mult: float = 0.55
    arb_pos_mult: float = 0.35
    cooldown_days: int = 3
    default_take_profit_pct: float = 0.18
    buy_slippage_bps: float = 5.0
    sell_slippage_bps: float = 5.0
    commission_bps: float = 3.0
    stamp_duty_bps: float = 10.0
    min_commission: float = 5.0


@dataclass(slots=True)
class BacktestConfig:
    start: str = "2024-01-02"
    end: str = "2024-12-30"
    pool_size: int = 300
    output_dir: str = "./v4/output"


@dataclass(slots=True)
class V4Config:
    data: DataConfig = field(default_factory=DataConfig)
    features: FeatureConfig = field(default_factory=FeatureConfig)
    models: ModelConfig = field(default_factory=ModelConfig)
    execution: ExecutionConfig = field(default_factory=ExecutionConfig)
    backtest: BacktestConfig = field(default_factory=BacktestConfig)


def load_default_config() -> V4Config:
    return V4Config()
