from __future__ import annotations

from pathlib import Path

import pandas as pd


def write_overview(root: str, summary: dict, closed: pd.DataFrame, event_summary: pd.DataFrame, exit_summary: pd.DataFrame, diagnosis_summary: pd.DataFrame) -> str:
    p = Path(root) / "results_overview.md"
    lines = []
    lines.append("# V4 Results Overview")
    lines.append("")
    lines.append("## Headline")
    lines.append(f"- Final cash: `{summary.get('final_cash', 0)}`")
    lines.append(f"- Cash return: `{summary.get('cash_return_pct', 0)}%`")
    lines.append(f"- Final equity: `{summary.get('equity_final', 0)}`")
    lines.append(f"- Equity return: `{summary.get('equity_return_pct', 0)}%`")
    lines.append(f"- Events: `{summary.get('event_count', 0)}`")
    lines.append(f"- Trades: `{summary.get('trade_count', 0)}`")
    lines.append(f"- Total fees: `{summary.get('total_fees', 0)}`")
    lines.append(f"- Open positions: `{summary.get('open_count', 0)}`")
    lines.append(f"- Open market value: `{summary.get('open_market_value', 0)}`")
    lines.append(f"- Open unrealized PnL: `{summary.get('open_unrealized_pnl', 0)}`")
    if not closed.empty:
        lines.append(f"- Closed trades: `{len(closed)}`")
        lines.append(f"- Closed win rate: `{(closed['pnl'] > 0).mean():.2%}`")
        lines.append(f"- Avg closed ret: `{closed['ret'].mean() * 100:.2f}%`")
    lines.append("")
    lines.append("## Event Summary")
    if event_summary.empty:
        lines.append("- n/a")
    else:
        for _, row in event_summary.iterrows():
            lines.append(f"- {row['event_type']}: events={int(row['events'])}, buys={int(row['buy_count'])}, conv={float(row['conversion']):.2%}, avg_conf={float(row['avg_confidence']):.3f}")
    lines.append("")
    lines.append("## Exit Summary")
    if exit_summary.empty:
        lines.append("- n/a")
    else:
        for _, row in exit_summary.iterrows():
            lines.append(f"- {row['exit_reason']}: trades={int(row['trades'])}, win={float(row['win_rate']):.2%}, avg_ret={float(row['avg_ret']) * 100:.2f}%, total_pnl={float(row['total_pnl']):.2f}")
    lines.append("")
    lines.append("## Diagnosis Summary")
    if diagnosis_summary.empty:
        lines.append("- n/a")
    else:
        for _, row in diagnosis_summary.iterrows():
            lines.append(
                f"- {row['diagnosis']}: trades={int(row['trades'])}, win={float(row['win_rate']):.2%}, "
                f"avg_ret={float(row['avg_ret']) * 100:.2f}%, avg_mfe={float(row['avg_mfe']) * 100:.2f}%, "
                f"avg_post_exit_rebound={float(row['avg_post_exit_rebound']) * 100:.2f}%"
            )
    p.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return str(p)
