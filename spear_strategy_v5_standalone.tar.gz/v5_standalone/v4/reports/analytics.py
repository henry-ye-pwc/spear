from __future__ import annotations

import json
from typing import Any

import pandas as pd

from v4.config.defaults import V4Config
from v4.data.adapter import V4DataAdapter
from v4.environment.provider import EnvironmentProvider
from v4.features import add_robust_volume_features, add_sequence_features, add_structure_features


def _prepare_symbol_feature_cache(
    symbols: list[str],
    cfg: V4Config,
    end: str,
    bars_cache: dict[str, pd.DataFrame] | None = None,
) -> dict[str, pd.DataFrame]:
    cache = {} if bars_cache is None else bars_cache
    missing = [str(s).zfill(6) for s in symbols if str(s).zfill(6) not in cache]
    if not missing:
        return cache

    adapter = V4DataAdapter(
        cache_dir=cfg.data.cache_dir,
        count=max(cfg.data.bar_count, 600),
        pool_sampling=cfg.data.pool_sampling,
        pool_seed=cfg.data.pool_seed,
        cache_only=True,
    )
    for symbol in missing:
        bars = adapter.load_symbol(symbol, start="", end=end)
        if bars.empty:
            cache[symbol] = pd.DataFrame()
            continue
        bars = add_robust_volume_features(bars)
        bars = add_sequence_features(bars)
        bars = add_structure_features(
            bars,
            peak_window=cfg.features.peak_window,
            drawdown_min=cfg.features.drawdown_min,
            peak_touch_eps=cfg.features.peak_touch_eps,
            consolidation_window=cfg.features.consolidation_window,
        )
        cache[symbol] = bars
    return cache


def build_closed_trades(trades: pd.DataFrame) -> pd.DataFrame:
    """Pair buy/sell trades into closed-trade records.

    Uses a proper FIFO queue per symbol so that multiple buys
    (e.g. averaging-down) are correctly matched against sells.
    A sell of N shares dequeues the oldest buys first, splitting
    a buy lot if it is only partially consumed.

    When multiple buy legs are consumed, ``entry_legs`` stores a
    JSON-serialised list of individual legs and ``entry_count``
    records the number of legs.
    """
    if trades.empty:
        return pd.DataFrame()
    rows: list[dict] = []
    # Each entry: (buy_row_dict, remaining_qty: float, cost_per_unit: float)
    open_buys: dict[str, list[tuple[dict, float, float]]] = {}

    for _, row in trades.sort_values(["date", "action"]).iterrows():
        symbol = str(row["symbol"])
        if row["action"] == "buy":
            b_meta = json.loads(str(row.get("meta", "{}")))
            buy_cash = -float(b_meta.get("net_cash_delta", 0.0))
            qty = float(row["qty"])
            cpu = buy_cash / qty if qty > 0 else float(row["price"])
            open_buys.setdefault(symbol, []).append((row.to_dict(), qty, cpu))
            continue

        queue = open_buys.get(symbol)
        if not queue:
            continue

        sell_qty_remaining = float(row["qty"])
        matched_cost = 0.0
        first_buy = queue[0][0]
        entry_legs: list[dict] = []

        while sell_qty_remaining > 1e-6 and queue:
            b_dict, b_rem, b_cpu = queue[0]
            take = min(sell_qty_remaining, b_rem)
            matched_cost += take * b_cpu
            entry_legs.append({
                "date": str(b_dict.get("date", ""))[:10],
                "price": round(b_cpu, 4),
                "qty": round(take, 2),
            })
            sell_qty_remaining -= take
            if b_rem - take < 1e-6:
                queue.pop(0)
            else:
                queue[0] = (b_dict, b_rem - take, b_cpu)

        sell_meta = json.loads(str(row.get("meta", "{}")))
        sell_cash = float(sell_meta.get("net_cash_delta", 0.0))
        pnl = sell_cash - matched_cost
        ret = pnl / matched_cost if matched_cost > 0 else 0.0
        sell_qty = float(row["qty"])
        hold_days = (pd.Timestamp(row["date"]) - pd.Timestamp(first_buy["date"])).days
        avg_entry = matched_cost / sell_qty if sell_qty > 0 else float(first_buy["price"])

        rows.append(
            {
                "symbol": symbol,
                "entry_date": first_buy["date"],
                "exit_date": row["date"],
                "entry_reason": first_buy["reason"],
                "exit_reason": row["reason"],
                "entry_price": round(avg_entry, 4),
                "exit_price": float(row["price"]),
                "qty": sell_qty,
                "pnl": round(pnl, 4),
                "ret": round(ret, 6),
                "hold_days": hold_days,
                "entry_count": len(entry_legs),
                "entry_legs": json.dumps(entry_legs, ensure_ascii=False),
            }
        )
        if not queue:
            open_buys.pop(symbol, None)

    return pd.DataFrame(rows)


def summarize_events(events: pd.DataFrame, trades: pd.DataFrame) -> pd.DataFrame:
    if events.empty:
        return pd.DataFrame()
    buy_counts = {}
    if not trades.empty:
        buy_reasons = trades[trades["action"] == "buy"]["reason"].str.replace("entry:", "", regex=False)
        buy_counts = buy_reasons.value_counts().to_dict()
    rows = []
    for event_type, grp in events.groupby("event_type"):
        rows.append(
            {
                "event_type": event_type,
                "events": int(len(grp)),
                "avg_confidence": round(float(grp["confidence"].mean()), 4),
                "buy_count": int(buy_counts.get(event_type, 0)),
                "conversion": round(float(buy_counts.get(event_type, 0)) / len(grp), 4) if len(grp) > 0 else 0.0,
            }
        )
    return pd.DataFrame(rows).sort_values("events", ascending=False)


def summarize_exits(closed: pd.DataFrame) -> pd.DataFrame:
    if closed.empty:
        return pd.DataFrame()
    rows = []
    for reason, grp in closed.groupby("exit_reason"):
        rows.append(
            {
                "exit_reason": reason,
                "trades": int(len(grp)),
                "win_rate": round(float((grp["pnl"] > 0).mean()), 4),
                "avg_ret": round(float(grp["ret"].mean()), 6),
                "total_pnl": round(float(grp["pnl"].sum()), 4),
            }
        )
    return pd.DataFrame(rows).sort_values("trades", ascending=False)


def enrich_closed_trades_with_path_stats(
    closed: pd.DataFrame,
    cfg: V4Config,
    start: str,
    end: str,
    bars_cache: dict[str, pd.DataFrame] | None = None,
) -> pd.DataFrame:
    if closed.empty:
        return closed.copy()
    out = closed.copy()
    symbols = [str(x).zfill(6) for x in out["symbol"].drop_duplicates().tolist()]
    cache = _prepare_symbol_feature_cache(symbols, cfg=cfg, end=end, bars_cache=bars_cache)
    rows = []
    for _, row in out.iterrows():
        symbol = str(row["symbol"]).zfill(6)
        bars = cache[symbol]
        if bars.empty:
            rows.append({})
            continue
        entry_dt = pd.Timestamp(row["entry_date"]).normalize()
        exit_dt = pd.Timestamp(row["exit_date"]).normalize()
        idx_norm = pd.to_datetime(bars.index).normalize()
        hold = bars[(idx_norm >= entry_dt) & (idx_norm <= exit_dt)]
        later = bars[idx_norm > exit_dt].iloc[:20]
        entry_price = float(row["entry_price"])
        exit_price = float(row["exit_price"])
        if hold.empty or entry_price <= 0:
            rows.append({})
            continue
        max_high = float(hold["high"].max())
        min_low = float(hold["low"].min())
        mfe = max_high / entry_price - 1.0
        mae = min_low / entry_price - 1.0
        mfe_date = hold["high"].idxmax()
        mae_date = hold["low"].idxmin()
        realized = float(row["ret"])
        mfe_capture = realized / mfe if mfe > 1e-9 else 0.0
        sold_near_mfe = bool(abs(exit_price / max_high - 1.0) <= 0.02) if max_high > 0 else False
        post_exit_max = float(later["high"].max()) if not later.empty else exit_price
        post_exit_rebound = post_exit_max / exit_price - 1.0 if exit_price > 0 else 0.0
        post_exit_entry_ret = post_exit_max / entry_price - 1.0 if entry_price > 0 else 0.0

        def _future_stats(days: int) -> tuple[float, float]:
            sub = bars[idx_norm > exit_dt].iloc[:days]
            if sub.empty or exit_price <= 0:
                return 0.0, 0.0
            hi = float(sub["high"].max()) / exit_price - 1.0
            lo = float(sub["low"].min()) / exit_price - 1.0
            return hi, lo

        hi5, lo5 = _future_stats(5)
        hi10, lo10 = _future_stats(10)
        hi20, lo20 = _future_stats(20)
        rows.append(
            {
                "mfe": round(mfe, 6),
                "mae": round(mae, 6),
                "mfe_date": str(mfe_date)[:10],
                "mae_date": str(mae_date)[:10],
                "mfe_capture": round(mfe_capture, 6),
                "sold_near_mfe": sold_near_mfe,
                "post_exit_20d_rebound": round(post_exit_rebound, 6),
                "post_exit_20d_entry_ret": round(post_exit_entry_ret, 6),
                "post_exit_5d_high": round(hi5, 6),
                "post_exit_5d_low": round(lo5, 6),
                "post_exit_10d_high": round(hi10, 6),
                "post_exit_10d_low": round(lo10, 6),
                "post_exit_20d_high": round(hi20, 6),
                "post_exit_20d_low": round(lo20, 6),
            }
        )
    extra = pd.DataFrame(rows)
    for col in extra.columns:
        out[col] = extra[col]
    out["diagnosis"] = out.apply(classify_trade_diagnosis, axis=1)
    return out


def classify_trade_diagnosis(row: pd.Series) -> str:
    ret = float(row.get("ret", 0.0) or 0.0)
    mfe = float(row.get("mfe", 0.0) or 0.0)
    post_exit_rebound = float(row.get("post_exit_20d_rebound", 0.0) or 0.0)
    post_exit_entry_ret = float(row.get("post_exit_20d_entry_ret", 0.0) or 0.0)
    sold_near_mfe = bool(row.get("sold_near_mfe", False))

    if ret > 0:
        if sold_near_mfe:
            return "盈利且接近MFE高点"
        if mfe >= ret + 0.10:
            return "盈利但明显卖早"
        return "盈利且兑现合理"

    if post_exit_rebound >= 0.10:
        return "卖飞/止损过早"
    if mfe >= 0.08:
        return "进出场时机错误"
    if mfe < 0.03 and post_exit_entry_ret < 0.05:
        return "标的完全选错"
    if mfe < 0.05 and post_exit_entry_ret >= 0.10:
        return "进场偏早/拿不住"
    return "一般性失败"


def summarize_diagnosis(closed: pd.DataFrame) -> pd.DataFrame:
    if closed.empty or "diagnosis" not in closed.columns:
        return pd.DataFrame()
    rows = []
    for diagnosis, grp in closed.groupby("diagnosis"):
        rows.append(
            {
                "diagnosis": diagnosis,
                "trades": int(len(grp)),
                "win_rate": round(float((grp["pnl"] > 0).mean()), 4),
                "avg_ret": round(float(grp["ret"].mean()), 6),
                "avg_mfe": round(float(grp["mfe"].mean()), 6),
                "avg_post_exit_rebound": round(float(grp["post_exit_20d_rebound"].mean()), 6),
            }
        )
    return pd.DataFrame(rows).sort_values("trades", ascending=False)


def _signal_label(event_type: str) -> str:
    return {
        "post_limit": "板后",
        "trend_spear": "趋势",
        "failed_board": "烂板",
        "attack": "进攻",
        "arb": "套利",
        "youzi": "游资",
        "sector_spear": "板块",
        "escape": "逃命",
    }.get(event_type, event_type)


def _shape_position(range_pos: float) -> str:
    if range_pos >= 0.7:
        return "UP"
    if range_pos <= 0.3:
        return "LOW"
    return "MID"


def _amount_state(row: pd.Series) -> tuple[str, str]:
    if bool(row.get("is_amount_explosive", False)):
        return "爆量", "explosive"
    if bool(row.get("is_amount_confirm", False)):
        return "确认量", "confirm"
    if float(row.get("amount_rank", 0.5)) <= 0.45:
        return "含蓄量", "subtle"
    return "平量", "neutral"


def _future_qualitative(row: pd.Series) -> str:
    hi20 = float(row.get("post_exit_20d_high", 0.0) or 0.0)
    lo20 = float(row.get("post_exit_20d_low", 0.0) or 0.0)
    if hi20 >= 0.20 and lo20 > -0.08:
        return "抛后继续走强"
    if hi20 >= 0.10 and lo20 <= -0.08:
        return "抛后深蹲反弹"
    if hi20 < 0.05 and lo20 <= -0.10:
        return "抛后继续走弱"
    return "抛后震荡"


def _exit_label(reason: str) -> str:
    return {
        "stop_loss": "止损",
        "take_profit": "止盈",
        "time_exit": "时间退出",
        "no_premium": "无溢价退出",
        "failed_continuation": "连续性失败退出",
        "theme_collapse": "题材坍塌退出",
        "rebreak": "二次跌破退出",
        "escape_risk_off": "逃命风险退出",
        "eod": "期末未定义退出",
    }.get(reason, reason)


def _event_lookup(events: pd.DataFrame) -> dict[tuple[str, str, str], dict[str, Any]]:
    if events.empty:
        return {}
    rows = events.copy()
    rows["symbol"] = rows["symbol"].astype(str).str.zfill(6)
    rows["date"] = rows["date"].astype(str)
    lookup: dict[tuple[str, str, str], dict[str, Any]] = {}
    for _, row in rows.iterrows():
        lookup[(str(row["symbol"]), str(row["event_type"]), str(row["date"]))] = row.to_dict()
    return lookup


def build_trade_master_table(
    closed: pd.DataFrame,
    events: pd.DataFrame,
    cfg: V4Config,
    start: str,
    end: str,
    bars_cache: dict[str, pd.DataFrame] | None = None,
    env: EnvironmentProvider | None = None,
) -> pd.DataFrame:
    if closed.empty:
        return pd.DataFrame()

    event_lookup = _event_lookup(events)
    symbols = [str(x).zfill(6) for x in closed["symbol"].drop_duplicates().tolist()]
    cache = _prepare_symbol_feature_cache(symbols, cfg=cfg, end=end, bars_cache=bars_cache)
    if env is None:
        env = EnvironmentProvider(
            cache_dir=cfg.data.cache_dir,
            sector_cache_path=cfg.data.sector_cache_path,
            lhb_cache_path=cfg.data.lhb_cache_path,
        )
        env.load()
    rows: list[dict[str, Any]] = []

    for _, trade in closed.iterrows():
        symbol = str(trade["symbol"]).zfill(6)
        event_type = str(trade["entry_reason"]).replace("entry:", "", 1)
        entry_dt = pd.Timestamp(trade["entry_date"])
        event_row = None
        matching = [
            ev for key, ev in event_lookup.items()
            if key[0] == symbol and key[1] == event_type and pd.Timestamp(key[2]) <= entry_dt
        ]
        if matching:
            matching.sort(key=lambda x: x["date"])
            event_row = matching[-1]

        bars = cache[symbol]
        event_dt = pd.Timestamp(event_row["date"]) if event_row is not None else entry_dt
        event_pos = bars.index.get_indexer([event_dt], method="pad")[0] if not bars.empty else -1
        sig = bars.iloc[event_pos] if event_pos >= 0 else pd.Series(dtype=float)

        ctx = json.loads(str(event_row["context"])) if event_row is not None and str(event_row.get("context", "")) else {}
        entry_plan = json.loads(str(event_row["entry_plan"])) if event_row is not None and str(event_row.get("entry_plan", "")) else {}
        amount_state, amount_detail = _amount_state(sig)
        tags: list[str] = []
        if bool(sig.get("near_peak_pressure", False)):
            tags.append("压区试探")
        if bool(sig.get("two_side_active", False)):
            tags.append("承上启下")
        if bool(sig.get("consolidation_ok", False)):
            tags.append("整理确认")
        if bool(sig.get("touch_limit_up", False)):
            tags.append("触板")
        if bool(sig.get("is_failed_board", False)):
            tags.append("炸板")
        tags.append(amount_state)

        gate_price = entry_plan.get("gate_price")
        if gate_price is None:
            gate_price = ctx.get("dense_gate")
        if gate_price is None:
            gate_price = ""

        meta = env.get_symbol_meta(symbol)
        rows.append(
            {
                "股票代码": symbol,
                "股票名称": str(meta.get("name", "")),
                "主题标签": str(ctx.get("theme_label", meta.get("industry") or meta.get("name_theme") or "其他")),
                "信号日期": str(event_dt)[:10],
                "买入日期": trade["entry_date"],
                "卖出日期": trade["exit_date"],
                "持仓天数": int(trade["hold_days"]),
                "实际盈亏(%)": round(float(trade["ret"]) * 100.0, 2),
                "识别类型": _signal_label(event_type),
                "事件类型": event_type,
                "信心分数": round(float(event_row["confidence"]) if event_row is not None else 0.0, 3),
                "入场样式": str(entry_plan.get("style", "")),
                "形态位置": _shape_position(float(sig.get("range_position_120", 0.5) or 0.5)),
                "城门价": round(float(gate_price), 3) if gate_price != "" else "",
                "上影线长度(%)": round(float(sig.get("upper_shadow_pct", 0.0) or 0.0) * 100.0, 2),
                "振幅(%)": round(float(sig.get("amp_pct", 0.0) or 0.0) * 100.0, 2),
                "收盘位置": round(float(sig.get("close_pos", 0.5) or 0.5), 3),
                "量价/形态标签": "|".join(tags),
                "量能判定": amount_state,
                "量能明细": amount_detail,
                "量能分位": round(float(sig.get("amount_rank", 0.0) or 0.0), 3),
                "量能Z分数": round(float(sig.get("amount_z", 0.0) or 0.0), 3),
                "板后相对量": round(float(ctx.get("gun_vs_prior_limit", 0.0) or 0.0), 3) if "gun_vs_prior_limit" in ctx else "",
                "结构模式": str(ctx.get("structure_mode", "")),
                "结构-压力位": round(float(sig.get("pressure_price", 0.0) or 0.0), 3),
                "结构-支撑位": round(float(sig.get("release_price", 0.0) or 0.0), 3),
                "买入价": round(float(trade["entry_price"]), 3),
                "卖出价": round(float(trade["exit_price"]), 3),
                "最高利润MFE(%)": round(float(trade.get("mfe", 0.0) or 0.0) * 100.0, 2),
                "最大回撤MAE(%)": round(float(trade.get("mae", 0.0) or 0.0) * 100.0, 2),
                "MFE捕获率": round(float(trade.get("mfe_capture", 0.0) or 0.0), 3),
                "出场原因": _exit_label(str(trade["exit_reason"])),
                "出场全称": str(trade["exit_reason"]),
                "抛后5天最高(%)": round(float(trade.get("post_exit_5d_high", 0.0) or 0.0) * 100.0, 2),
                "抛后5天最低(%)": round(float(trade.get("post_exit_5d_low", 0.0) or 0.0) * 100.0, 2),
                "抛后10天最高(%)": round(float(trade.get("post_exit_10d_high", 0.0) or 0.0) * 100.0, 2),
                "抛后10天最低(%)": round(float(trade.get("post_exit_10d_low", 0.0) or 0.0) * 100.0, 2),
                "抛后20天最高(%)": round(float(trade.get("post_exit_20d_high", 0.0) or 0.0) * 100.0, 2),
                "抛后20天最低(%)": round(float(trade.get("post_exit_20d_low", 0.0) or 0.0) * 100.0, 2),
                "后续走向定性": _future_qualitative(trade),
                "交易诊断": str(trade.get("diagnosis", "")),
                "进场次数": int(trade.get("entry_count", 1) or 1),
                "进场明细": str(trade.get("entry_legs", "[]")),
            }
        )
    return pd.DataFrame(rows)
