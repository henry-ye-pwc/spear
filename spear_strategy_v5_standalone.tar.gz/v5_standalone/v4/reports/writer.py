from __future__ import annotations

import json
from pathlib import Path

import pandas as pd

from cq_backtest.shared.utils import ensure_dir
from v4.backtest.engine import BacktestResult
from v4.config.defaults import V4Config
from v4.reports.analytics import (
    build_trade_master_table,
    build_closed_trades,
    _prepare_symbol_feature_cache,
    enrich_closed_trades_with_path_stats,
    summarize_diagnosis,
    summarize_events,
    summarize_exits,
)
from v4.environment.provider import EnvironmentProvider
from v4.reports.overview import write_overview


def write_reports(outdir: str, result: BacktestResult, cfg: V4Config, start: str, end: str) -> None:
    root = ensure_dir(outdir)
    trades = pd.DataFrame(result.trades)
    events = pd.DataFrame(result.events)
    open_positions = pd.DataFrame(result.open_positions)
    closed = build_closed_trades(trades)
    traded_symbols = sorted(
        {
            str(x).zfill(6)
            for x in pd.concat(
                [
                    closed["symbol"] if not closed.empty and "symbol" in closed.columns else pd.Series(dtype=str),
                    events["symbol"] if not events.empty and "symbol" in events.columns else pd.Series(dtype=str),
                ]
            ).tolist()
        }
    )
    bars_cache = _prepare_symbol_feature_cache(traded_symbols, cfg=cfg, end=end)
    env = EnvironmentProvider(
        cache_dir=cfg.data.cache_dir,
        sector_cache_path=cfg.data.sector_cache_path,
        lhb_cache_path=cfg.data.lhb_cache_path,
    )
    env.load()

    closed = enrich_closed_trades_with_path_stats(closed, cfg=cfg, start=start, end=end, bars_cache=bars_cache)
    event_summary = summarize_events(events, trades)
    exit_summary = summarize_exits(closed)
    diagnosis_summary = summarize_diagnosis(closed)
    master_table = build_trade_master_table(closed, events, cfg=cfg, start=start, end=end, bars_cache=bars_cache, env=env)

    trades.to_csv(Path(root) / "trades.csv", index=False, encoding="utf-8")
    events.to_csv(Path(root) / "events.csv", index=False, encoding="utf-8")
    open_positions.to_csv(Path(root) / "open_positions.csv", index=False, encoding="utf-8")
    closed.to_csv(Path(root) / "closed_trades.csv", index=False, encoding="utf-8")
    master_table.to_csv(Path(root) / "all_trades_master_table.csv", index=False, encoding="utf-8-sig")
    event_summary.to_csv(Path(root) / "event_summary.csv", index=False, encoding="utf-8")
    exit_summary.to_csv(Path(root) / "exit_summary.csv", index=False, encoding="utf-8")
    diagnosis_summary.to_csv(Path(root) / "diagnosis_summary.csv", index=False, encoding="utf-8")
    with (Path(root) / "summary.json").open("w", encoding="utf-8") as fh:
        json.dump(result.summary, fh, ensure_ascii=False, indent=2)
    write_overview(str(root), result.summary, closed, event_summary, exit_summary, diagnosis_summary)
