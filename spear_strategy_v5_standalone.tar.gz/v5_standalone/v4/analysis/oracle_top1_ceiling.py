from __future__ import annotations

import argparse
import json
import math
import sys
from bisect import bisect_right
from dataclasses import asdict, dataclass
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from cq_backtest.shared.market_rules import can_buy_strict, round_to_tick
from cq_backtest.shared.utils import ensure_dir
from v4.config.defaults import load_default_config
from v4.data.adapter import V4DataAdapter


@dataclass(slots=True)
class CandidateTrade:
    symbol: str
    event_date: str
    event_type: str
    entry_style: str
    confidence: float
    entry_date: str
    exit_date: str
    entry_price: float
    exit_price: float
    gross_ret: float
    net_ret_factor: float
    hold_days: int
    mfe: float
    entry_ts: float
    exit_ts: float
    valid: bool
    trigger_reason: str


def _buy_cost(price: float, qty: int, cfg) -> float:
    notion = price * qty
    commission = max(cfg.execution.min_commission, notion * cfg.execution.commission_bps / 10000.0) if qty > 0 else 0.0
    return notion + commission


def _sell_proceeds(price: float, qty: int, cfg) -> float:
    notion = price * qty
    commission = max(cfg.execution.min_commission, notion * cfg.execution.commission_bps / 10000.0) if qty > 0 else 0.0
    stamp = notion * cfg.execution.stamp_duty_bps / 10000.0
    return notion - commission - stamp


def _affordable_qty(cash: float, price: float, cfg) -> int:
    qty = int(cash // max(price, 1e-9))
    while qty > 0 and _buy_cost(price, qty, cfg) > cash:
        qty -= 1
    return qty


def _net_factor(entry_price: float, exit_price: float, cfg) -> float:
    buy_px = round_to_tick(entry_price * (1.0 + cfg.execution.buy_slippage_bps / 10000.0))
    sell_px = round_to_tick(exit_price * (1.0 - cfg.execution.sell_slippage_bps / 10000.0))
    buy_per_share = buy_px * (1.0 + cfg.execution.commission_bps / 10000.0)
    sell_per_share = sell_px * (1.0 - (cfg.execution.commission_bps + cfg.execution.stamp_duty_bps) / 10000.0)
    if buy_per_share <= 0:
        return 0.0
    return sell_per_share / buy_per_share


def _simulate_candidate(symbol: str, event_row: dict, bars: pd.DataFrame, cfg) -> CandidateTrade | None:
    event_date = str(event_row["date"])
    event_type = str(event_row["event_type"])
    confidence = float(event_row["confidence"])
    entry_plan = json.loads(event_row["entry_plan"])
    exit_plan = json.loads(event_row["exit_plan"])
    if event_row["side"] != "long":
        return None
    if bars.empty:
        return None
    event_pos = bars.index.get_indexer([pd.Timestamp(event_date)], method="pad")[0]
    if event_pos < 0:
        return None

    style = str(entry_plan.get("style", "breakout"))
    entry_pos: int | None = None
    entry_price: float | None = None

    if style == "tail_close":
        row = bars.iloc[event_pos]
        limit_up = float(row["limit_up"]) if pd.notna(row.get("limit_up")) else None
        close = float(row["close"])
        if limit_up is not None and not can_buy_strict(close, limit_up):
            return None
        entry_pos = event_pos
        entry_price = close
    else:
        gate = float(entry_plan.get("gate_price", bars.iloc[event_pos]["close"]))
        valid_for_days = int(entry_plan.get("valid_for_days", 5))
        for i in range(event_pos + 1, min(len(bars), event_pos + valid_for_days + 1)):
            row = bars.iloc[i]
            if float(row["high"]) < gate:
                continue
            fill = max(float(row["open"]), gate)
            limit_up = float(row["limit_up"]) if pd.notna(row.get("limit_up")) else None
            if limit_up is not None and not can_buy_strict(fill, limit_up):
                continue
            entry_pos = i
            entry_price = fill
            break
        if entry_pos is None or entry_price is None:
            return None

    hold_days = int(exit_plan.get("hold_days", 5))
    end_pos = min(len(bars) - 1, entry_pos + max(1, hold_days))
    hold = bars.iloc[entry_pos : end_pos + 1]
    if hold.empty:
        return None

    max_high = float(hold["high"].max())
    max_pos = hold["high"].idxmax()
    exit_date = str(max_pos)[:10]
    gross_ret = max_high / entry_price - 1.0 if entry_price > 0 else 0.0
    factor = _net_factor(entry_price, max_high, cfg)
    if factor <= 0:
        return None

    entry_ts = float(entry_pos) + (0.8 if style == "tail_close" else 0.5)
    exit_ts = float(bars.index.get_loc(max_pos)) + 0.1
    return CandidateTrade(
        symbol=symbol,
        event_date=event_date,
        event_type=event_type,
        entry_style=style,
        confidence=confidence,
        entry_date=str(bars.index[entry_pos])[:10],
        exit_date=exit_date,
        entry_price=round(entry_price, 4),
        exit_price=round(max_high, 4),
        gross_ret=round(gross_ret, 6),
        net_ret_factor=round(factor, 6),
        hold_days=int((pd.Timestamp(exit_date) - pd.Timestamp(str(bars.index[entry_pos])[:10])).days),
        mfe=round(gross_ret, 6),
        entry_ts=entry_ts,
        exit_ts=exit_ts,
        valid=True,
        trigger_reason="triggered",
    )


def _weighted_interval_oracle(cands: list[CandidateTrade]) -> list[CandidateTrade]:
    trades = sorted([c for c in cands if c.net_ret_factor > 1.0], key=lambda x: (x.exit_ts, x.entry_ts))
    if not trades:
        return []
    exits = [t.exit_ts for t in trades]
    prev = []
    for i, t in enumerate(trades):
        j = bisect_right(exits, t.entry_ts) - 1
        prev.append(j)

    dp = [0.0] * len(trades)
    take = [False] * len(trades)
    for i, t in enumerate(trades):
        weight = math.log(t.net_ret_factor)
        with_i = weight + (dp[prev[i]] if prev[i] >= 0 else 0.0)
        without_i = dp[i - 1] if i > 0 else 0.0
        if with_i > without_i:
            dp[i] = with_i
            take[i] = True
        else:
            dp[i] = without_i
    selected: list[CandidateTrade] = []
    i = len(trades) - 1
    while i >= 0:
        if take[i]:
            selected.append(trades[i])
            i = prev[i]
        else:
            i -= 1
    return list(reversed(selected))


def _simulate_path(selected: list[CandidateTrade], init_cash: float, cfg) -> tuple[list[dict], float]:
    cash = float(init_cash)
    rows: list[dict] = []
    for t in selected:
        buy_px = round_to_tick(t.entry_price * (1.0 + cfg.execution.buy_slippage_bps / 10000.0))
        sell_px = round_to_tick(t.exit_price * (1.0 - cfg.execution.sell_slippage_bps / 10000.0))
        qty = _affordable_qty(cash, buy_px, cfg)
        if qty <= 0:
            continue
        buy_cost = _buy_cost(buy_px, qty, cfg)
        sell_cash = _sell_proceeds(sell_px, qty, cfg)
        pnl = sell_cash - buy_cost
        ret = pnl / buy_cost if buy_cost > 0 else 0.0
        cash = cash - buy_cost + sell_cash
        rows.append(
            {
                "symbol": t.symbol,
                "event_type": t.event_type,
                "event_date": t.event_date,
                "entry_style": t.entry_style,
                "confidence": t.confidence,
                "entry_date": t.entry_date,
                "exit_date": t.exit_date,
                "entry_price_raw": t.entry_price,
                "exit_price_raw": t.exit_price,
                "entry_price_exec": buy_px,
                "exit_price_exec": sell_px,
                "qty": qty,
                "gross_ret": t.gross_ret,
                "ret": round(ret, 6),
                "pnl": round(pnl, 4),
                "cash_after": round(cash, 2),
            }
        )
    return rows, cash


def build_report(source_dir: str, output_dir: str) -> dict:
    cfg = load_default_config()
    events = pd.read_csv(Path(source_dir) / "events.csv")
    actual_summary = json.loads((Path(source_dir) / "summary.json").read_text(encoding="utf-8"))
    actual_closed = pd.read_csv(Path(source_dir) / "closed_trades.csv")

    adapter = V4DataAdapter(
        cache_dir=cfg.data.cache_dir,
        count=max(cfg.data.bar_count, 600),
        pool_sampling="random",
        pool_seed=42,
    )
    symbol_cache: dict[str, pd.DataFrame] = {}
    candidates: list[CandidateTrade] = []
    long_events = events[events["side"] == "long"].copy()
    for _, ev in long_events.iterrows():
        symbol = str(ev["symbol"]).zfill(6)
        bars = symbol_cache.get(symbol)
        if bars is None:
            bars = adapter.load_symbol(symbol, "2022-01-04", "2022-12-30")
            symbol_cache[symbol] = bars
        cand = _simulate_candidate(symbol, ev.to_dict(), bars, cfg)
        if cand is not None:
            candidates.append(cand)

    selected = _weighted_interval_oracle(candidates)
    oracle_rows, final_cash = _simulate_path(selected, 1_000_000.0, cfg)
    oracle_df = pd.DataFrame(oracle_rows)
    cand_df = pd.DataFrame([asdict(c) for c in candidates])
    out = ensure_dir(output_dir)
    cand_df.to_csv(out / "oracle_candidate_trades.csv", index=False)
    oracle_df.to_csv(out / "oracle_selected_trades.csv", index=False)

    actual_wrong = int((actual_closed["diagnosis"] == "标的完全选错").sum())
    actual_missed = int(((actual_closed["diagnosis"] == "卖飞/止损过早") | (actual_closed["diagnosis"] == "盈利但明显卖早") | (actual_closed["diagnosis"] == "进出场时机错误")).sum())
    oracle_summary = {
        "source_equity_final": float(actual_summary["equity_final"]),
        "source_equity_return_pct": float(actual_summary["equity_return_pct"]),
        "oracle_candidates_triggered": int(len(cand_df)),
        "oracle_candidates_positive": int((cand_df["net_ret_factor"] > 1.0).sum()) if not cand_df.empty else 0,
        "oracle_selected_trades": int(len(oracle_df)),
        "oracle_final_equity": round(final_cash, 2),
        "oracle_return_pct": round((final_cash / 1_000_000.0 - 1.0) * 100.0, 2),
        "actual_closed_trades": int(len(actual_closed)),
        "actual_full_wrong_trades": actual_wrong,
        "actual_missed_mfe_related_trades": actual_missed,
    }
    (out / "oracle_summary.json").write_text(json.dumps(oracle_summary, ensure_ascii=False, indent=2), encoding="utf-8")

    by_type = (
        oracle_df.groupby("event_type")
        .agg(trades=("symbol", "count"), total_pnl=("pnl", "sum"), avg_ret=("ret", "mean"))
        .reset_index()
        .sort_values("total_pnl", ascending=False)
        if not oracle_df.empty
        else pd.DataFrame(columns=["event_type", "trades", "total_pnl", "avg_ret"])
    )
    by_type.to_csv(out / "oracle_type_breakdown.csv", index=False)

    report = [
        "# Oracle Top-1 Ceiling",
        "",
        f"- Source strategy equity: `{actual_summary['equity_final']}` (`{actual_summary['equity_return_pct']}%`)",
        f"- Oracle selected trades: `{oracle_summary['oracle_selected_trades']}`",
        f"- Oracle final equity: `{oracle_summary['oracle_final_equity']}` (`{oracle_summary['oracle_return_pct']}%`)",
        f"- Triggered candidates: `{oracle_summary['oracle_candidates_triggered']}`",
        f"- Positive candidates: `{oracle_summary['oracle_candidates_positive']}`",
        f"- Actual closed trades: `{oracle_summary['actual_closed_trades']}`",
        f"- Actual full-wrong trades: `{oracle_summary['actual_full_wrong_trades']}`",
        f"- Actual missed-MFE related trades: `{oracle_summary['actual_missed_mfe_related_trades']}`",
        "",
        "## Oracle Type Breakdown",
        "",
    ]
    if by_type.empty:
        report.append("No oracle trades.")
    else:
        report.append("| event_type | trades | total_pnl | avg_ret |")
        report.append("|---|---:|---:|---:|")
        for _, row in by_type.iterrows():
            report.append(f"| {row['event_type']} | {int(row['trades'])} | {row['total_pnl']:.2f} | {row['avg_ret']:.4f} |")
    (out / "oracle_report.md").write_text("\n".join(report), encoding="utf-8")
    return oracle_summary


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--source-dir", required=True)
    p.add_argument("--output-dir", required=True)
    args = p.parse_args()
    summary = build_report(args.source_dir, args.output_dir)
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
