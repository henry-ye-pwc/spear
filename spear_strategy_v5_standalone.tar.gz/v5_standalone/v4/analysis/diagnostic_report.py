from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd


def _load_csv(path: Path) -> pd.DataFrame:
    if not path.exists():
        return pd.DataFrame()
    return pd.read_csv(path)


def _parse_event_context(events: pd.DataFrame) -> pd.DataFrame:
    if events.empty:
        return pd.DataFrame()
    rows = []
    for _, row in events.iterrows():
        ctx = {}
        try:
            ctx = json.loads(str(row.get("context", "{}")))
        except Exception:
            ctx = {}
        rows.append(
            {
                "date": str(row["date"]),
                "symbol": str(row["symbol"]),
                "event_type": row["event_type"],
                "confidence": float(row.get("confidence", 0.0) or 0.0),
                "theme_label": str(ctx.get("theme_label", "")),
                "peer_confirmation": float(ctx.get("peer_confirmation", 0.0) or 0.0),
                "leader_strength": float(ctx.get("leader_strength", 0.0) or 0.0),
                "sector_hot": bool(ctx.get("sector_hot", False)),
            }
        )
    return pd.DataFrame(rows)


def _attach_entry_context(closed: pd.DataFrame, events: pd.DataFrame) -> pd.DataFrame:
    if closed.empty or events.empty:
        return closed.copy()
    evt = _parse_event_context(events)
    if evt.empty:
        return closed.copy()
    out = closed.copy()
    out["symbol"] = out["symbol"].astype(str)
    out["entry_date"] = pd.to_datetime(out["entry_date"]).dt.normalize()
    evt["date"] = pd.to_datetime(evt["date"]).dt.normalize()
    out["event_type"] = out["entry_reason"].str.replace("entry:", "", regex=False)

    evt = evt.sort_values(["symbol", "event_type", "date", "confidence"])
    joined_rows = []
    for _, trade in out.iterrows():
        candidates = evt[
            (evt["symbol"] == trade["symbol"])
            & (evt["event_type"] == trade["event_type"])
            & (evt["date"] <= trade["entry_date"])
        ]
        if candidates.empty:
            joined_rows.append({})
            continue
        chosen = candidates.iloc[-1].to_dict()
        event_date = chosen.pop("date")
        chosen.pop("symbol", None)
        chosen.pop("event_type", None)
        chosen["ctx_event_date"] = event_date
        chosen["ctx_event_age_days"] = int((trade["entry_date"] - event_date).days)
        chosen = {f"ctx_{k}" if not k.startswith("ctx_") else k: v for k, v in chosen.items()}
        joined_rows.append(chosen)

    joined = pd.DataFrame(joined_rows)
    return pd.concat([out.reset_index(drop=True), joined.reset_index(drop=True)], axis=1)


def _format_pct(x: float) -> str:
    return f"{x * 100:.2f}%"


def _format_ratio(numerator: int, denominator: int) -> str:
    if denominator == 0:
        return "0.00%"
    return f"{numerator / denominator:.2%}"


def build_report(root: Path) -> str:
    summary = json.loads((root / "summary.json").read_text(encoding="utf-8"))
    closed = _load_csv(root / "closed_trades.csv")
    events = _load_csv(root / "events.csv")
    open_pos = _load_csv(root / "open_positions.csv")
    closed = _attach_entry_context(closed, events)

    losers = closed[closed["ret"] <= 0].copy()
    winners = closed[closed["ret"] > 0].copy()
    wrong_selection = closed[closed["diagnosis"] == "标的完全选错"].copy()
    has_move = closed[(closed["mfe"] >= 0.08) | (closed["post_exit_20d_rebound"] >= 0.10)].copy()
    op_error = closed[
        closed["diagnosis"].isin(["卖飞/止损过早", "进出场时机错误", "盈利但明显卖早"])
    ].copy()
    sold_high = closed[closed["sold_near_mfe"] == True].copy()

    overview = closed.groupby("entry_reason").agg(
        trades=("symbol", "size"),
        win_rate=("pnl", lambda s: (s > 0).mean()),
        avg_ret=("ret", "mean"),
        total_pnl=("pnl", "sum"),
        avg_mfe=("mfe", "mean"),
        avg_mae=("mae", "mean"),
        avg_capture=("mfe_capture", "mean"),
    ).round(4)

    wrong_by_type = closed.groupby("entry_reason").agg(
        trades=("symbol", "size"),
        wrong_picks=("diagnosis", lambda s: (s == "标的完全选错").sum()),
    )
    wrong_by_type["wrong_pick_rate"] = (
        wrong_by_type["wrong_picks"] / wrong_by_type["trades"].where(wrong_by_type["trades"] != 0, 1)
    )
    wrong_by_type = wrong_by_type.round(4)

    has_move_by_type = has_move.groupby("entry_reason").agg(
        move_trades=("symbol", "size"),
        op_error_trades=("diagnosis", lambda s: s.isin(["卖飞/止损过早", "进出场时机错误", "盈利但明显卖早"]).sum()),
    )
    if not has_move_by_type.empty:
        has_move_by_type["op_error_rate"] = (
            has_move_by_type["op_error_trades"]
            / has_move_by_type["move_trades"].where(has_move_by_type["move_trades"] != 0, 1)
        )
        has_move_by_type = has_move_by_type.round(4)

    sold_high_summary = pd.DataFrame()
    if not sold_high.empty:
        sold_high_summary = sold_high.groupby("entry_reason").agg(
            trades=("symbol", "size"),
            avg_confidence=("ctx_confidence", "mean"),
            avg_event_age_days=("ctx_event_age_days", "mean"),
            avg_peer_confirmation=("ctx_peer_confirmation", "mean"),
            avg_leader_strength=("ctx_leader_strength", "mean"),
            sector_hot_rate=("ctx_sector_hot", "mean"),
            avg_mfe_capture=("mfe_capture", "mean"),
        ).round(4)

    realized_total = float(closed["pnl"].sum()) if not closed.empty else 0.0
    ideal_total = realized_total
    ideal_by_type = pd.DataFrame()
    if not closed.empty:
        ideal = closed.copy()
        ideal["capital"] = ideal["entry_price"] * ideal["qty"]
        ideal["ideal_ret"] = ideal.apply(
            lambda r: r["ret"] if r["diagnosis"] == "标的完全选错" else max(float(r["ret"]), float(r["mfe"])),
            axis=1,
        )
        ideal["ideal_pnl"] = ideal["capital"] * ideal["ideal_ret"]
        ideal_total = float(ideal["ideal_pnl"].sum())
        ideal_by_type = ideal.groupby("entry_reason").agg(
            trades=("symbol", "size"),
            realized_pnl=("pnl", "sum"),
            ideal_pnl=("ideal_pnl", "sum"),
            uplift=("ideal_pnl", lambda s: float(s.sum())),
        )
        ideal_by_type["uplift"] = ideal_by_type["ideal_pnl"] - ideal_by_type["realized_pnl"]
        ideal_by_type = ideal_by_type.round(2)

    sold_high_samples = pd.DataFrame()
    if not sold_high.empty:
        cols = [
            "symbol",
            "entry_reason",
            "entry_date",
            "exit_date",
            "ret",
            "mfe",
            "mfe_capture",
            "ctx_confidence",
            "ctx_event_age_days",
            "ctx_theme_label",
            "ctx_peer_confirmation",
            "ctx_leader_strength",
            "ctx_sector_hot",
        ]
        sold_high_samples = sold_high[cols].sort_values(["entry_reason", "entry_date"]).copy()

    lines: list[str] = []
    lines.append("# 2022 Random Sampling Diagnostic Report")
    lines.append("")
    lines.append("## 1. 综合表现")
    lines.append(f"- Final cash: `{summary.get('final_cash', 0):,.2f}`")
    lines.append(f"- Cash return: `{summary.get('cash_return_pct', 0):.2f}%`")
    lines.append(f"- Final equity: `{summary.get('equity_final', 0):,.2f}`")
    lines.append(f"- Equity return: `{summary.get('equity_return_pct', 0):.2f}%`")
    lines.append(f"- Closed trades: `{len(closed)}`")
    lines.append(f"- Closed win rate: `{((closed['pnl'] > 0).mean() if not closed.empty else 0):.2%}`")
    lines.append(f"- Avg closed return: `{(closed['ret'].mean() * 100 if not closed.empty else 0):.2f}%`")
    lines.append(f"- Open positions: `{len(open_pos)}`")
    lines.append(f"- Total fees: `{summary.get('total_fees', 0):,.2f}`")
    lines.append("")
    lines.append("## 2. 每种类型表现 breakdown")
    if not overview.empty:
        for idx, row in overview.iterrows():
            lines.append(
                f"- {idx}: trades={int(row['trades'])}, win={float(row['win_rate']):.2%}, "
                f"avg_ret={float(row['avg_ret']) * 100:.2f}%, total_pnl={float(row['total_pnl']):.2f}, "
                f"avg_mfe={float(row['avg_mfe']) * 100:.2f}%, avg_capture={float(row['avg_capture']):.2f}"
            )
            if idx in wrong_by_type.index:
                lines.append(
                    f"  wrong_pick_rate={float(wrong_by_type.loc[idx, 'wrong_pick_rate']):.2%}, "
                    f"wrong_picks={int(wrong_by_type.loc[idx, 'wrong_picks'])}"
                )
            if idx in has_move_by_type.index:
                lines.append(
                    f"  move_trades={int(has_move_by_type.loc[idx, 'move_trades'])}, "
                    f"op_error_rate_on_moves={float(has_move_by_type.loc[idx, 'op_error_rate']):.2%}"
                )
    lines.append("")
    lines.append("## 3. 纯粹选错后续没有行情的票占比")
    lines.append(
        f"- Closed trades 中 `标的完全选错`: `{len(wrong_selection)}/{len(closed)}` = "
        f"`{_format_ratio(len(wrong_selection), len(closed))}`"
    )
    lines.append(
        f"- Closed losers 中 `标的完全选错`: `{len(wrong_selection)}/{len(losers)}` = "
        f"`{_format_ratio(len(wrong_selection), len(losers))}`"
    )
    lines.append("")
    lines.append("## 4. 有行情的票中多少操作错误导致亏损或赚少")
    lines.append(
        f"- 定义“有行情”: `MFE>=8%` 或 `post_exit_20d_rebound>=10%`"
    )
    lines.append(
        f"- 有行情的票: `{len(has_move)}/{len(closed)}` = `{_format_ratio(len(has_move), len(closed))}`"
    )
    has_move_error = has_move[has_move["diagnosis"].isin(["卖飞/止损过早", "进出场时机错误", "盈利但明显卖早"])]
    lines.append(
        f"- 有行情但操作错误(亏损或赚少): `{len(has_move_error)}/{len(has_move)}` = "
        f"`{_format_ratio(len(has_move_error), len(has_move))}`"
    )
    lines.append("")
    lines.append("## 5. 哪些信号和条件更容易卖在高点")
    lines.append(
        f"- sold_near_mfe = True 的盈利单: `{len(sold_high)}/{len(winners)}` = "
        f"`{_format_ratio(len(sold_high), len(winners))}`"
    )
    if not sold_high_summary.empty:
        for idx, row in sold_high_summary.iterrows():
            lines.append(
                f"- {idx}: trades={int(row['trades'])}, avg_conf={float(row['avg_confidence']):.3f}, "
                f"event_age={float(row['avg_event_age_days']):.2f}d, peer={float(row['avg_peer_confirmation']):.2f}, "
                f"leader={float(row['avg_leader_strength']):.2f}, "
                f"sector_hot_rate={float(row['sector_hot_rate']):.2%}, avg_capture={float(row['avg_mfe_capture']):.2f}"
            )
    if not sold_high_samples.empty:
        lines.append("- 样本明细:")
        for _, row in sold_high_samples.iterrows():
            lines.append(
                f"  {str(row['symbol'])} {row['entry_reason']} entry={str(row['entry_date'])[:10]} exit={str(row['exit_date'])[:10]} "
                f"ret={float(row['ret']) * 100:.2f}% mfe={float(row['mfe']) * 100:.2f}% "
                f"capture={float(row['mfe_capture']):.2f} conf={float(row['ctx_confidence']):.2f} "
                f"theme={row['ctx_theme_label']} peer={float(row['ctx_peer_confirmation']):.0f} leader={float(row['ctx_leader_strength']):.0f}"
            )
    lines.append("")
    lines.append("## 6. 理论 ideal 最大收益")
    lines.append(
        "- 定义：固定当前入场、固定当前仓位，不重算资金复用；`标的完全选错` 的票保持当前实际亏损，其余票假设在持仓窗口内按 `MFE` 完美退出。"
    )
    lines.append(f"- Realized closed-trade pnl: `{realized_total:,.2f}`")
    lines.append(f"- Ideal closed-trade pnl: `{ideal_total:,.2f}`")
    lines.append(f"- Ideal uplift vs realized: `{ideal_total - realized_total:,.2f}`")
    if not ideal_by_type.empty:
        for idx, row in ideal_by_type.iterrows():
            lines.append(
                f"- {idx}: realized={float(row['realized_pnl']):,.2f}, ideal={float(row['ideal_pnl']):,.2f}, uplift={float(row['uplift']):,.2f}"
            )
    lines.append("")
    lines.append("## 7. Insightful 总结")
    lines.append(
        f"- losers 平均 MFE = `{_format_pct(losers['mfe'].mean() if not losers.empty else 0)}`，"
        f"说明亏损票并不都是完全没行情。"
    )
    lines.append(
        f"- losers 平均抛后 20 日反弹 = `{_format_pct(losers['post_exit_20d_rebound'].mean() if not losers.empty else 0)}`，"
        f"说明存在显著的卖飞/止损过早问题。"
    )
    lines.append(
        f"- winners 平均 MFE capture = `{(winners['mfe_capture'].mean() if not winners.empty else 0):.2f}`，"
        f"说明盈利票整体也没有卖在极值附近。"
    )
    lines.append(
        f"- `arb` 若在 breakdown 中持续为负贡献，则应独立降权或拆掉。"
    )
    return "\n".join(lines) + "\n"


def main() -> None:
    parser = argparse.ArgumentParser(description="Generate diagnostic report from a V4 output directory.")
    parser.add_argument("output_dir")
    args = parser.parse_args()
    root = Path(args.output_dir)
    root.mkdir(parents=True, exist_ok=True)
    text = build_report(root)
    out = root / "diagnostic_report.md"
    out.write_text(text, encoding="utf-8")
    print(out)


if __name__ == "__main__":
    main()
