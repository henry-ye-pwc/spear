from __future__ import annotations

import argparse
import json
import sys
from dataclasses import asdict, dataclass
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from cq_backtest.shared.market_rules import can_buy_strict, can_sell_strict, round_to_tick
from cq_backtest.shared.utils import ensure_dir
from v4.config.defaults import load_default_config
from v4.data.adapter import V4DataAdapter


@dataclass(slots=True)
class WindowTrade:
    symbol: str
    event_type: str
    event_date: str
    entry_style: str
    confidence: float
    route_score: float
    entry_date: str
    exit_date: str
    entry_price: float
    exit_price: float
    qty: int
    ret: float
    pnl: float
    cash_after: float
    exit_reason: str
    mfe: float
    mfe_capture: float
    sold_near_mfe: bool
    post_exit_20d_rebound: float
    diagnosis: str


def _event_priority(event_type: str) -> float:
    priorities = {
        "post_limit": 0.10,
        "trend_spear": 0.08,
        "failed_board": 0.07,
        "youzi": 0.05,
        "sector_spear": 0.04,
        "attack": 0.01,
        "arb": 0.00,
    }
    return priorities.get(event_type, 0.0)


def _route_score(event_type: str, confidence: float, entry_style: str) -> float:
    return float(confidence) + _event_priority(event_type) + (0.01 if entry_style == "breakout" else 0.0)


def _buy_cost(price: float, qty: int, cfg) -> float:
    notion = price * qty
    commission = max(cfg.execution.min_commission, notion * cfg.execution.commission_bps / 10000.0) if qty > 0 else 0.0
    return notion + commission


def _sell_proceeds(price: float, qty: int, cfg) -> float:
    notion = price * qty
    commission = max(cfg.execution.min_commission, notion * cfg.execution.commission_bps / 10000.0) if qty > 0 else 0.0
    stamp = notion * cfg.execution.stamp_duty_bps / 10000.0
    return notion - commission - stamp


def _affordable_qty(cash: float, price: float, cfg) -> int:
    if price <= 0:
        return 0
    comm_rate = cfg.execution.commission_bps / 10000.0
    qty_prop = int(cash // (price * (1.0 + comm_rate)))
    qty_min = int(max((cash - cfg.execution.min_commission) // price, 0))
    qty = max(qty_prop, qty_min)
    for _ in range(4):
        if qty <= 0:
            return 0
        if _buy_cost(price, qty, cfg) <= cash:
            return qty
        qty -= 1
    return max(qty, 0)


def classify_trade_diagnosis(ret: float, mfe: float, sold_near_mfe: bool, post_exit_rebound: float, post_exit_entry_ret: float) -> str:
    if ret > 0:
        if sold_near_mfe:
            return "盈利且接近MFE高点"
        if mfe >= ret + 0.10:
            return "盈利但明显卖早"
        return "盈利且兑现合理"
    if post_exit_rebound >= 0.10:
        return "卖飞/止损过早"
    if mfe >= 0.08:
        return "进出场时机错误"
    if mfe < 0.03 and post_exit_entry_ret < 0.05:
        return "标的完全选错"
    if mfe < 0.05 and post_exit_entry_ret >= 0.10:
        return "进场偏早/拿不住"
    return "一般性失败"


def _load_bars(symbols: list[str], cfg) -> dict[str, pd.DataFrame]:
    adapter = V4DataAdapter(
        cache_dir=cfg.data.cache_dir,
        count=max(cfg.data.bar_count, 600),
        pool_sampling="random",
        pool_seed=42,
    )
    out: dict[str, pd.DataFrame] = {}
    for symbol in symbols:
        bars = adapter.load_symbol(symbol, "2022-01-04", "2022-12-30")
        if bars is not None and not bars.empty:
            out[symbol] = bars
    return out


def _entry_candidate(event_row: pd.Series, date: str, bar: pd.Series) -> tuple[bool, float | None]:
    entry_plan = json.loads(event_row["entry_plan"])
    style = str(entry_plan.get("style", "breakout"))
    if style == "tail_close":
        if event_row["date"] != date:
            return False, None
        close = float(bar["close"])
        limit_up = float(bar["limit_up"]) if pd.notna(bar.get("limit_up")) else None
        if limit_up is not None and not can_buy_strict(close, limit_up):
            return False, None
        return True, close
    gate = float(entry_plan.get("gate_price", bar["close"]))
    valid_for_days = int(entry_plan.get("valid_for_days", 5))
    ev_idx = int(event_row["_event_idx"])
    cur_idx = int(event_row["_cur_idx"])
    if cur_idx <= ev_idx or cur_idx > ev_idx + valid_for_days:
        return False, None
    if float(bar["high"]) < gate:
        return False, None
    fill = max(float(bar["open"]), gate)
    limit_up = float(bar["limit_up"]) if pd.notna(bar.get("limit_up")) else None
    if limit_up is not None and not can_buy_strict(fill, limit_up):
        return False, None
    return True, fill


def _build_actionable(events: pd.DataFrame, bars_by_symbol: dict[str, pd.DataFrame]) -> pd.DataFrame:
    rows: list[dict] = []
    for _, ev in events.iterrows():
        symbol = str(ev["symbol"]).zfill(6)
        bars = bars_by_symbol.get(symbol)
        if bars is None or bars.empty:
            continue
        try:
            event_idx = bars.index.get_indexer([pd.Timestamp(str(ev["date"]))], method="pad")[0]
        except Exception:
            continue
        if event_idx < 0:
            continue
        entry_plan = json.loads(ev["entry_plan"])
        style = str(entry_plan.get("style", "breakout"))
        if style == "tail_close":
            row = bars.iloc[event_idx]
            close = float(row["close"])
            limit_up = float(row["limit_up"]) if pd.notna(row.get("limit_up")) else None
            if limit_up is not None and not can_buy_strict(close, limit_up):
                continue
            rows.append(
                {
                    "symbol": symbol,
                    "event_type": str(ev["event_type"]),
                    "event_date": str(ev["date"]),
                    "action_date": str(bars.index[event_idx])[:10],
                    "entry_style": style,
                    "confidence": float(ev["confidence"]),
                    "route_score": float(ev["route_score"]),
                    "entry_price_raw": close,
                    "entry_idx": event_idx,
                    "event_row": ev.to_dict(),
                }
            )
            continue
        gate = float(entry_plan.get("gate_price", bars.iloc[event_idx]["close"]))
        valid_for_days = int(entry_plan.get("valid_for_days", 5))
        for i in range(event_idx + 1, min(len(bars), event_idx + valid_for_days + 1)):
            row = bars.iloc[i]
            if float(row["high"]) < gate:
                continue
            fill = max(float(row["open"]), gate)
            limit_up = float(row["limit_up"]) if pd.notna(row.get("limit_up")) else None
            if limit_up is not None and not can_buy_strict(fill, limit_up):
                continue
            rows.append(
                {
                    "symbol": symbol,
                    "event_type": str(ev["event_type"]),
                    "event_date": str(ev["date"]),
                    "action_date": str(bars.index[i])[:10],
                    "entry_style": style,
                    "confidence": float(ev["confidence"]),
                    "route_score": float(ev["route_score"]),
                    "entry_price_raw": fill,
                    "entry_idx": i,
                    "event_row": ev.to_dict(),
                }
            )
    return pd.DataFrame(rows)


def _simulate_exit_actual(
    symbol: str,
    event_row: pd.Series,
    entry_idx: int,
    entry_price: float,
    bars: pd.DataFrame,
    events_by_symbol_date: dict[tuple[str, str], list[dict]],
) -> tuple[int, float, str]:
    invalidation = json.loads(event_row["invalidation"])
    exit_plan = json.loads(event_row["exit_plan"])
    stop_price = float(invalidation.get("price", entry_price * 0.94))
    take_profit_pct = float(exit_plan.get("take_profit_pct", 0.18))
    take_price = entry_price * (1.0 + take_profit_pct)
    max_hold_days = int(exit_plan.get("hold_days", 5))
    exit_style = str(exit_plan.get("style", "default"))

    for i in range(entry_idx, len(bars)):
        row = bars.iloc[i]
        holding_days = i - entry_idx
        date = str(bars.index[i])[:10]
        limit_down = float(row["close"]) * (1.0 - float(row.get("limit_pct", 0.1))) if pd.notna(row.get("limit_pct")) else None
        if float(row["low"]) <= stop_price and (limit_down is None or can_sell_strict(stop_price, limit_down)):
            return i, stop_price, "stop_loss"
        if exit_style not in {"trend_hold"} and float(row["high"]) >= take_price and (limit_down is None or can_sell_strict(take_price, limit_down)):
            return i, take_price, "take_profit"
        if exit_style == "tactical_arb" and holding_days >= 3 and float(row["close"]) <= entry_price * 1.01 and (limit_down is None or can_sell_strict(float(row["close"]), limit_down)):
            return i, float(row["close"]), "no_premium"
        if exit_style == "continuation" and holding_days >= 3 and float(row["close"]) < entry_price * 0.99 and (limit_down is None or can_sell_strict(float(row["close"]), limit_down)):
            return i, float(row["close"]), "failed_continuation"
        if exit_style in {"swing_confirm", "rebalance_swing"} and holding_days >= 2 and float(row["close"]) <= stop_price * 1.01 and (limit_down is None or can_sell_strict(float(row["close"]), limit_down)):
            return i, float(row["close"]), "rebreak"
        day_events = events_by_symbol_date.get((symbol, date), [])
        if any(e["event_type"] == "escape" for e in day_events) and (limit_down is None or can_sell_strict(float(row["close"]), limit_down)):
            return i, float(row["close"]), "escape_risk_off"
        if holding_days >= max_hold_days and (limit_down is None or can_sell_strict(float(row["close"]), limit_down)):
            return i, float(row["close"]), "time_exit"
    last = bars.iloc[-1]
    return len(bars) - 1, float(last["close"]), "eod"


def _simulate_exit_ceiling(event_row: pd.Series, entry_idx: int, entry_price: float, bars: pd.DataFrame) -> tuple[int, float, str]:
    exit_plan = json.loads(event_row["exit_plan"])
    max_hold_days = int(exit_plan.get("hold_days", 5))
    end_idx = min(len(bars) - 1, entry_idx + max(1, max_hold_days))
    hold = bars.iloc[entry_idx : end_idx + 1]
    max_high = float(hold["high"].max())
    exit_idx = int(bars.index.get_loc(hold["high"].idxmax()))
    return exit_idx, max_high, "mfe_exit"


def _path_stats(bars: pd.DataFrame, entry_idx: int, exit_idx: int, entry_price: float, exit_price: float) -> tuple[float, float, bool, float]:
    hold = bars.iloc[entry_idx : exit_idx + 1]
    max_high = float(hold["high"].max())
    mfe = max_high / entry_price - 1.0 if entry_price > 0 else 0.0
    mfe_capture = ((exit_price / entry_price - 1.0) / mfe) if mfe > 1e-9 else 0.0
    sold_near_mfe = abs(exit_price / max_high - 1.0) <= 0.02 if max_high > 0 else False
    later = bars.iloc[exit_idx + 1 : exit_idx + 21]
    post_exit_max = float(later["high"].max()) if not later.empty else exit_price
    post_exit_rebound = post_exit_max / exit_price - 1.0 if exit_price > 0 else 0.0
    return mfe, mfe_capture, sold_near_mfe, post_exit_rebound


def _run_window(
    events: pd.DataFrame,
    actionables: pd.DataFrame,
    bars_by_symbol: dict[str, pd.DataFrame],
    window_days: int,
    mode: str,
    cfg,
) -> tuple[pd.DataFrame, dict]:
    all_dates = sorted({str(idx)[:10] for bars in bars_by_symbol.values() for idx in bars.index})
    date_pos = {d: i for i, d in enumerate(all_dates)}
    actionables = actionables.copy()
    actionables["action_date"] = actionables["action_date"].astype(str)
    actionables["event_date"] = actionables["event_date"].astype(str)

    events_by_symbol_date: dict[tuple[str, str], list[dict]] = {}
    for _, r in pd.read_csv(Path(source_dir) / "events.csv").iterrows():
        events_by_symbol_date.setdefault((str(r["symbol"]).zfill(6), str(r["date"])), []).append(r.to_dict())

    cash = 1_000_000.0
    selected: list[WindowTrade] = []
    i = 0
    while i < len(all_dates):
        date = all_dates[i]
        today = actionables[actionables["action_date"] == date].copy()
        if today.empty:
            i += 1
            continue
        today = today[today["event_date"].map(lambda d: 0 <= date_pos[date] - date_pos.get(str(d), -10_000) < window_days)]
        if today.empty:
            i += 1
            continue
        today = today.sort_values(["route_score", "confidence", "event_type"], ascending=[False, False, False])
        pick = today.iloc[0]
        ev = pd.Series(pick["event_row"])
        raw_entry_price = float(pick["entry_price_raw"])
        entry_idx = int(pick["entry_idx"])
        symbol = str(pick["symbol"]).zfill(6)
        bars = bars_by_symbol[symbol]
        if mode == "actual":
            exit_idx, raw_exit_price, exit_reason = _simulate_exit_actual(symbol, ev, entry_idx, raw_entry_price, bars, events_by_symbol_date)
        else:
            exit_idx, raw_exit_price, exit_reason = _simulate_exit_ceiling(ev, entry_idx, raw_entry_price, bars)

        buy_px = round_to_tick(raw_entry_price * (1.0 + cfg.execution.buy_slippage_bps / 10000.0))
        sell_px = round_to_tick(raw_exit_price * (1.0 - cfg.execution.sell_slippage_bps / 10000.0))
        qty = _affordable_qty(cash, buy_px, cfg)
        if qty <= 0:
            break
        buy_cost = _buy_cost(buy_px, qty, cfg)
        sell_cash = _sell_proceeds(sell_px, qty, cfg)
        pnl = sell_cash - buy_cost
        trade_ret = pnl / buy_cost if buy_cost > 0 else 0.0
        cash = cash - buy_cost + sell_cash
        mfe, mfe_capture, sold_near_mfe, post_exit_rebound = _path_stats(bars, entry_idx, exit_idx, buy_px, sell_px)
        later = bars.iloc[exit_idx + 1 : exit_idx + 21]
        post_exit_max = float(later["high"].max()) if not later.empty else sell_px
        post_exit_entry_ret = post_exit_max / buy_px - 1.0 if buy_px > 0 else 0.0
        selected.append(
            WindowTrade(
                symbol=symbol,
                event_type=str(pick["event_type"]),
                event_date=str(pick["event_date"]),
                entry_style=str(pick["entry_style"]),
                confidence=float(pick["confidence"]),
                route_score=float(pick["route_score"]),
                entry_date=date,
                exit_date=str(bars.index[exit_idx])[:10],
                entry_price=buy_px,
                exit_price=sell_px,
                qty=qty,
                ret=round(trade_ret, 6),
                pnl=round(pnl, 4),
                cash_after=round(cash, 2),
                exit_reason=exit_reason,
                mfe=round(mfe, 6),
                mfe_capture=round(mfe_capture, 6),
                sold_near_mfe=bool(sold_near_mfe),
                post_exit_20d_rebound=round(post_exit_rebound, 6),
                diagnosis=classify_trade_diagnosis(trade_ret, mfe, sold_near_mfe, post_exit_rebound, post_exit_entry_ret),
            )
        )
        i = date_pos[str(bars.index[exit_idx])[:10]] + 1

    df = pd.DataFrame([asdict(t) for t in selected])
    summary = {
        "window_days": window_days,
        "mode": mode,
        "trades": int(len(df)),
        "final_equity": round(cash, 2),
        "return_pct": round((cash / 1_000_000.0 - 1.0) * 100.0, 2),
        "avg_ret": round(float(df["ret"].mean()), 6) if not df.empty else 0.0,
        "win_rate": round(float((df["pnl"] > 0).mean()), 4) if not df.empty else 0.0,
        "full_wrong": int((df["diagnosis"] == "标的完全选错").sum()) if not df.empty else 0,
        "missed_mfe_related": int(df["diagnosis"].isin(["卖飞/止损过早", "进出场时机错误", "盈利但明显卖早"]).sum()) if not df.empty else 0,
    }
    return df, summary


def build_reports(source_dir: str, output_dir: str) -> None:
    cfg = load_default_config()
    events = pd.read_csv(Path(source_dir) / "events.csv")
    events = events[events["side"] == "long"].copy()
    events["date"] = events["date"].astype(str)
    events["entry_style"] = events["entry_plan"].apply(lambda s: json.loads(s).get("style", "breakout"))
    events["route_score"] = events.apply(lambda r: _route_score(str(r["event_type"]), float(r["confidence"]), str(r["entry_style"])), axis=1)
    symbols = sorted({str(x).zfill(6) for x in events["symbol"].unique()})
    bars_by_symbol = _load_bars(symbols, cfg)
    actionables = _build_actionable(events, bars_by_symbol)

    out = ensure_dir(output_dir)
    overviews = []
    for window in (3, 5):
        for mode in ("actual", "ceiling"):
            df, summary = _run_window(events, actionables, bars_by_symbol, window, mode, cfg)
            df.to_csv(out / f"window_{window}d_{mode}_trades.csv", index=False)
            by_type = (
                df.groupby("event_type")
                .agg(trades=("symbol", "count"), total_pnl=("pnl", "sum"), avg_ret=("ret", "mean"))
                .reset_index()
                .sort_values("total_pnl", ascending=False)
                if not df.empty
                else pd.DataFrame(columns=["event_type", "trades", "total_pnl", "avg_ret"])
            )
            by_type.to_csv(out / f"window_{window}d_{mode}_type_breakdown.csv", index=False)
            diag = (
                df.groupby("diagnosis")
                .agg(trades=("symbol", "count"), avg_ret=("ret", "mean"), avg_mfe=("mfe", "mean"))
                .reset_index()
                .sort_values("trades", ascending=False)
                if not df.empty
                else pd.DataFrame(columns=["diagnosis", "trades", "avg_ret", "avg_mfe"])
            )
            diag.to_csv(out / f"window_{window}d_{mode}_diagnosis.csv", index=False)
            (out / f"window_{window}d_{mode}_summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
            overviews.append(summary)

    overview_df = pd.DataFrame(overviews).sort_values(["window_days", "mode"])
    overview_df.to_csv(out / "window_top1_overview.csv", index=False)
    lines = ["# Window Top-1 Summary", "", "| window | mode | trades | final_equity | return_pct | avg_ret | win_rate | full_wrong | missed_mfe_related |", "|---|---|---:|---:|---:|---:|---:|---:|---:|"]
    for _, row in overview_df.iterrows():
        lines.append(
            f"| {int(row['window_days'])}d | {row['mode']} | {int(row['trades'])} | {row['final_equity']:.2f} | {row['return_pct']:.2f}% | {row['avg_ret']:.4f} | {row['win_rate']:.2%} | {int(row['full_wrong'])} | {int(row['missed_mfe_related'])} |"
        )
    (out / "window_top1_summary.md").write_text("\n".join(lines), encoding="utf-8")


source_dir = ""


def main() -> None:
    global source_dir
    p = argparse.ArgumentParser()
    p.add_argument("--source-dir", required=True)
    p.add_argument("--output-dir", required=True)
    args = p.parse_args()
    source_dir = args.source_dir
    build_reports(args.source_dir, args.output_dir)


if __name__ == "__main__":
    main()
