from __future__ import annotations

import numpy as np
import pandas as pd

from v4.data.adapter import preprocess_daily
from v4.features import add_robust_volume_features, add_sequence_features, add_structure_features
from v4.models.attack import detect_attack
from v4.models.post_limit import detect_post_limit
from v4.models.trend_spear import detect_trend_spear
from v4.models.youzi import detect_youzi


def _base_frame(n: int = 140) -> pd.DataFrame:
    idx = pd.date_range("2024-01-01", periods=n, freq="B")
    close = np.linspace(10, 16, n)
    open_ = close * 0.99
    high = close * 1.01
    low = close * 0.98
    volume = np.linspace(1e6, 1.6e6, n)
    amount = close * volume
    raw = pd.DataFrame({"open": open_, "high": high, "low": low, "close": close, "volume": volume, "amount": amount}, index=idx)
    out = preprocess_daily(raw, "000001")
    out.iloc[-2, out.columns.get_loc("is_limit_up_close")] = True
    out.iloc[-1, out.columns.get_loc("high")] = out.iloc[-1]["close"] * 1.06
    out.iloc[-1, out.columns.get_loc("upper_shadow_pct")] = 0.04
    out.iloc[-1, out.columns.get_loc("touch_limit_up")] = False
    out = add_robust_volume_features(out)
    out = add_sequence_features(out)
    out = add_structure_features(out)
    out.iloc[-1, out.columns.get_loc("consolidation_ok")] = True
    out.iloc[-1, out.columns.get_loc("anchored_vwap")] = out.iloc[-1]["close"] * 1.005
    return out


def test_post_limit_gate_not_forced_to_high():
    frame = _base_frame()
    frame.iloc[-2, frame.columns.get_loc("is_amount_explosive")] = False
    frame.iloc[-1, frame.columns.get_loc("is_amount_explosive")] = False
    frame.iloc[-1, frame.columns.get_loc("is_amount_confirm")] = True
    frame.iloc[-1, frame.columns.get_loc("amount")] = frame.iloc[-2]["amount"] * 0.98
    ev = detect_post_limit(frame, "000001", lookback=8, env={"theme_label": "科技", "peer_confirmation": 1, "leader_strength": 0, "_enforce_env": True})
    assert ev is not None
    gate = float(ev.entry_plan["gate_price"])
    high = float(frame.iloc[-1]["high"])
    assert gate < high


def test_post_limit_filters_consecutive_explosive_volume():
    frame = _base_frame()
    frame.iloc[-2, frame.columns.get_loc("amount")] = 2.0e8
    frame.iloc[-2, frame.columns.get_loc("is_amount_explosive")] = True
    frame.iloc[-1, frame.columns.get_loc("amount")] = 3.2e8
    frame.iloc[-1, frame.columns.get_loc("is_amount_explosive")] = True
    frame.iloc[-1, frame.columns.get_loc("is_amount_confirm")] = False
    ev = detect_post_limit(frame, "000001", lookback=8, env={"theme_label": "科技", "peer_confirmation": 1, "leader_strength": 0, "_enforce_env": True})
    assert ev is None


def test_post_limit_rejects_weak_consolidation_only_setup():
    frame = _base_frame()
    frame.iloc[-1, frame.columns.get_loc("consolidation_ok")] = True
    frame.iloc[-1, frame.columns.get_loc("near_peak_pressure")] = False
    frame.iloc[-1, frame.columns.get_loc("two_side_active")] = False
    frame.iloc[-1, frame.columns.get_loc("close_pos")] = 0.4
    frame.iloc[-1, frame.columns.get_loc("range_position_120")] = 0.78
    frame.iloc[-1, frame.columns.get_loc("is_amount_confirm")] = True
    frame.iloc[-1, frame.columns.get_loc("amount")] = frame.iloc[-2]["amount"] * 0.92
    ev = detect_post_limit(frame, "000001", lookback=8, env={"theme_label": "其他", "peer_confirmation": 0, "leader_strength": 0})
    assert ev is None


def test_post_limit_rejects_nonconfirm_touch_limit_spike():
    frame = _base_frame()
    frame.iloc[-1, frame.columns.get_loc("consolidation_ok")] = False
    frame.iloc[-1, frame.columns.get_loc("near_peak_pressure")] = True
    frame.iloc[-1, frame.columns.get_loc("touch_limit_up")] = True
    frame.iloc[-1, frame.columns.get_loc("is_amount_confirm")] = False
    frame.iloc[-1, frame.columns.get_loc("is_amount_explosive")] = False
    frame.iloc[-1, frame.columns.get_loc("amount_rank")] = 0.98
    frame.iloc[-1, frame.columns.get_loc("amount_z")] = 2.7
    frame.iloc[-1, frame.columns.get_loc("amount")] = frame.iloc[-2]["amount"] * 1.02
    ev = detect_post_limit(frame, "000001", lookback=8, env={"theme_label": "其他", "peer_confirmation": 0, "leader_strength": 0})
    assert ev is None


def test_trend_requires_environment_confirmation():
    frame = _base_frame()
    for idx in [-4, -1]:
        frame.iloc[idx, frame.columns.get_loc("upper_shadow_pct")] = 0.04
    for idx, amount in zip([-4, -1], [1.4e7, 1.2e7]):
        frame.iloc[idx, frame.columns.get_loc("amount")] = amount
        frame.iloc[idx, frame.columns.get_loc("is_amount_explosive")] = False
    frame = add_sequence_features(frame)
    frame = add_structure_features(frame)
    ev_none = detect_trend_spear(frame, "000001", multi_days=5, env={"theme_label": "其他", "peer_confirmation": 0, "leader_strength": 0, "_enforce_env": True})
    assert ev_none is None
    ev = detect_trend_spear(frame, "000001", multi_days=5, env={"theme_label": "科技", "peer_confirmation": 1, "leader_strength": 0, "_enforce_env": True})
    assert ev is not None


def test_attack_rejects_progressive_expand_three_guns():
    frame = _base_frame()
    for idx, amount in zip([-5, -3, -1], [1.2e8, 1.5e8, 2.0e8]):
        frame.iloc[idx, frame.columns.get_loc("upper_shadow_pct")] = 0.04
        frame.iloc[idx, frame.columns.get_loc("amount")] = amount
    frame.iloc[-1, frame.columns.get_loc("touch_limit_up")] = True
    frame.iloc[-1, frame.columns.get_loc("is_amount_explosive")] = False
    frame = add_sequence_features(frame)
    ev = detect_attack(frame, "000001", lookback=10, env={"theme_label": "科技", "peer_confirmation": 1, "leader_strength": 0, "_enforce_env": True})
    assert ev is None


def test_youzi_requires_peer_confirmation():
    frame = _base_frame(220)
    frame.iloc[-1, frame.columns.get_loc("upper_shadow_pct")] = 0.04
    frame.iloc[-1, frame.columns.get_loc("range_position_120")] = 0.55
    frame.iloc[-1, frame.columns.get_loc("near_peak_pressure")] = True
    frame.iloc[-1, frame.columns.get_loc("is_amount_explosive")] = False
    for idx in [-120, -60, -2]:
        frame.iloc[idx, frame.columns.get_loc("is_limit_up_close")] = True
    ev_none = detect_youzi(frame, "000001", env={"theme_label": "科技", "peer_confirmation": 0, "leader_strength": 0})
    assert ev_none is None
    ev = detect_youzi(frame, "000001", env={"theme_label": "科技", "peer_confirmation": 2, "leader_strength": 1})
    assert ev is not None
