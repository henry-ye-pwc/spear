from __future__ import annotations

import pandas as pd
from cq_backtest.data.feed import DataFeed
from v4.config.defaults import load_default_config

from v4.reports.analytics import _prepare_symbol_feature_cache, classify_trade_diagnosis


def test_classify_trade_diagnosis_selection_fail():
    row = pd.Series({"ret": -0.04, "mfe": 0.01, "post_exit_20d_rebound": 0.02, "post_exit_20d_entry_ret": 0.03})
    assert classify_trade_diagnosis(row) == "标的完全选错"


def test_classify_trade_diagnosis_exit_timing_fail():
    row = pd.Series({"ret": -0.03, "mfe": 0.12, "post_exit_20d_rebound": 0.04, "post_exit_20d_entry_ret": 0.06})
    assert classify_trade_diagnosis(row) == "进出场时机错误"


def test_classify_trade_diagnosis_sold_near_mfe():
    row = pd.Series({"ret": 0.11, "mfe": 0.12, "post_exit_20d_rebound": 0.01, "post_exit_20d_entry_ret": 0.12, "sold_near_mfe": True})
    assert classify_trade_diagnosis(row) == "盈利且接近MFE高点"


def test_get_kline_reuses_exact_cache_without_connect(tmp_path, monkeypatch):
    idx = pd.date_range("2026-01-01", periods=50, freq="B")
    df = pd.DataFrame(
        {
            "open": 10.0,
            "high": 10.5,
            "low": 9.8,
            "close": 10.1,
            "volume": 1_000_000.0,
            "amount": 10_100_000.0,
        },
        index=idx,
    )
    cache_file = tmp_path / "000001_full.pkl"
    df.to_pickle(cache_file)

    called = {"count": 0}

    def _boom(self):
        called["count"] += 1
        raise AssertionError("should not connect when cache already covers end_date")

    monkeypatch.setattr(DataFeed, "_connect", _boom)
    feed = DataFeed(cache_dir=str(tmp_path))
    out = feed.get_kline("000001", end_date=str(idx[-1])[:10], count=20)
    assert called["count"] == 0
    assert len(out) == 20
    assert str(out.index.max())[:10] == str(idx[-1])[:10]


def test_prepare_symbol_feature_cache_uses_local_cache_only(tmp_path):
    idx = pd.date_range("2025-01-01", periods=180, freq="B")
    close = pd.Series(range(180), index=idx, dtype=float) * 0.05 + 10
    raw = pd.DataFrame(
        {
            "open": close * 0.99,
            "high": close * 1.01,
            "low": close * 0.98,
            "close": close,
            "volume": 1_000_000.0,
            "amount": close * 1_000_000.0,
        },
        index=idx,
    )
    raw.to_pickle(tmp_path / "000001_full.pkl")
    cfg = load_default_config()
    cfg.data.cache_dir = str(tmp_path)
    cache = _prepare_symbol_feature_cache(["000001"], cfg=cfg, end=str(idx[-1])[:10])
    assert "000001" in cache
    frame = cache["000001"]
    assert not frame.empty
    assert "amount_rank" in frame.columns
    assert "recent_spear_count_10" in frame.columns
    assert "anchored_vwap" in frame.columns
