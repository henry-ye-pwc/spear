from __future__ import annotations

from cq_backtest.shared.signal_schema import SignalEventV2
from v4.execution.state_machine import V4ExecutionStateMachine


def test_tail_close_buys_same_day():
    sm = V4ExecutionStateMachine(max_positions=1)
    ev = SignalEventV2(
        event_type="arb",
        symbol="000001",
        ts="2024-03-01",
        confidence=0.8,
        side="long",
        entry_plan={"style": "tail_close"},
        invalidation={"price": 9.6},
        exit_plan={"hold_days": 3, "take_profit_pct": 0.1},
    )
    decisions = sm.on_day(
        date="2024-03-01",
        d_idx=100,
        symbol="000001",
        open_price=10.0,
        close=10.1,
        high=10.3,
        low=9.9,
        events=[ev],
        cash=1_000_000.0,
    )
    assert any(x.action == "buy" for x in decisions)


def test_escape_cancels_pending():
    sm = V4ExecutionStateMachine(max_positions=1)
    trend = SignalEventV2(
        event_type="trend_spear",
        symbol="000001",
        ts="2024-03-01",
        confidence=0.8,
        side="long",
        entry_plan={"style": "breakout", "gate_price": 10.0, "valid_for_days": 5},
        invalidation={"price": 9.5},
        exit_plan={"hold_days": 8, "take_profit_pct": 0.2},
    )
    sm.on_day(
        date="2024-03-01",
        d_idx=100,
        symbol="000001",
        open_price=9.8,
        close=9.9,
        high=9.95,
        low=9.7,
        events=[trend],
        cash=1_000_000.0,
    )
    escape = SignalEventV2(
        event_type="escape",
        symbol="000001",
        ts="2024-03-02",
        confidence=0.9,
        side="risk_off",
    )
    decisions = sm.on_day(
        date="2024-03-02",
        d_idx=101,
        symbol="000001",
        open_price=9.8,
        close=9.7,
        high=9.9,
        low=9.6,
        events=[escape],
        cash=1_000_000.0,
    )
    assert decisions == []
    assert "000001" not in sm.pending_entries


def test_multiple_breakout_routes_are_staged():
    sm = V4ExecutionStateMachine(max_positions=1)
    trend = SignalEventV2(
        event_type="trend_spear",
        symbol="000001",
        ts="2024-03-01",
        confidence=0.82,
        side="long",
        entry_plan={"style": "breakout", "gate_price": 10.2, "valid_for_days": 5},
        invalidation={"price": 9.7},
        exit_plan={"style": "trend_hold", "hold_days": 8, "take_profit_pct": 0.2},
    )
    post = SignalEventV2(
        event_type="post_limit",
        symbol="000001",
        ts="2024-03-01",
        confidence=0.76,
        side="long",
        entry_plan={"style": "breakout", "gate_price": 10.1, "valid_for_days": 4},
        invalidation={"price": 9.8},
        exit_plan={"style": "swing_confirm", "hold_days": 6, "take_profit_pct": 0.16},
    )
    decisions = sm.on_day(
        date="2024-03-01",
        d_idx=100,
        symbol="000001",
        open_price=9.9,
        close=10.0,
        high=10.05,
        low=9.8,
        events=[trend, post],
        cash=1_000_000.0,
    )
    assert decisions == []
    assert len(sm.pending_entries["000001"]) == 2


def test_breakout_route_wins_when_tail_is_not_clearly_better():
    sm = V4ExecutionStateMachine(max_positions=1)
    trend = SignalEventV2(
        event_type="trend_spear",
        symbol="000001",
        ts="2024-03-01",
        confidence=0.82,
        side="long",
        entry_plan={"style": "breakout", "gate_price": 10.2, "valid_for_days": 5},
        invalidation={"price": 9.7},
        exit_plan={"style": "trend_hold", "hold_days": 8, "take_profit_pct": 0.2},
    )
    attack = SignalEventV2(
        event_type="attack",
        symbol="000001",
        ts="2024-03-01",
        confidence=0.79,
        side="long",
        entry_plan={"style": "tail_close"},
        invalidation={"price": 9.6},
        exit_plan={"style": "continuation", "hold_days": 5, "take_profit_pct": 0.1},
    )
    decisions = sm.on_day(
        date="2024-03-01",
        d_idx=100,
        symbol="000001",
        open_price=10.0,
        close=10.05,
        high=10.1,
        low=9.9,
        events=[trend, attack],
        cash=1_000_000.0,
    )
    assert decisions == []
    assert len(sm.pending_entries["000001"]) >= 1


def test_tail_close_route_preempts_only_when_clearly_stronger():
    sm = V4ExecutionStateMachine(max_positions=1)
    post = SignalEventV2(
        event_type="post_limit",
        symbol="000001",
        ts="2024-03-01",
        confidence=0.64,
        side="long",
        entry_plan={"style": "breakout", "gate_price": 10.2, "valid_for_days": 5},
        invalidation={"price": 9.7},
        exit_plan={"style": "swing_confirm", "hold_days": 8, "take_profit_pct": 0.16},
    )
    attack = SignalEventV2(
        event_type="attack",
        symbol="000001",
        ts="2024-03-01",
        confidence=0.90,
        side="long",
        entry_plan={"style": "tail_close"},
        invalidation={"price": 9.6},
        exit_plan={"style": "continuation", "hold_days": 5, "take_profit_pct": 0.1},
    )
    decisions = sm.on_day(
        date="2024-03-01",
        d_idx=100,
        symbol="000001",
        open_price=10.0,
        close=10.05,
        high=10.1,
        low=9.9,
        events=[post, attack],
        cash=1_000_000.0,
    )
    assert any(x.action == "buy" and x.reason == "entry:attack" for x in decisions)
    assert "000001" not in sm.pending_entries


def test_tactical_arb_exits_on_no_premium():
    sm = V4ExecutionStateMachine(max_positions=1)
    ev = SignalEventV2(
        event_type="arb",
        symbol="000001",
        ts="2024-03-01",
        confidence=0.8,
        side="long",
        entry_plan={"style": "tail_close"},
        invalidation={"price": 9.6},
        exit_plan={"style": "tactical_arb", "hold_days": 3, "take_profit_pct": 0.1},
    )
    d1 = sm.on_day(
        date="2024-03-01",
        d_idx=100,
        symbol="000001",
        open_price=10.0,
        close=10.0,
        high=10.1,
        low=9.9,
        events=[ev],
        cash=1_000_000.0,
    )
    assert any(x.action == "buy" for x in d1)
    d2 = sm.on_day(
        date="2024-03-04",
        d_idx=103,
        symbol="000001",
        open_price=9.95,
        close=10.0,
        high=10.05,
        low=9.8,
        events=[],
        cash=900_000.0,
        day_context={"sector_hot": False},
    )
    assert any(x.action == "sell" and x.reason == "no_premium" for x in d2)


def test_limit_up_blocks_tail_buy():
    sm = V4ExecutionStateMachine(max_positions=1)
    ev = SignalEventV2(
        event_type="attack",
        symbol="000001",
        ts="2024-03-01",
        confidence=0.8,
        side="long",
        entry_plan={"style": "tail_close"},
        invalidation={"price": 9.6},
        exit_plan={"style": "continuation", "hold_days": 5, "take_profit_pct": 0.1},
    )
    decisions = sm.on_day(
        date="2024-03-01",
        d_idx=100,
        symbol="000001",
        open_price=10.0,
        close=11.0,
        high=11.0,
        low=10.8,
        limit_up=11.0,
        limit_down=9.0,
        events=[ev],
        cash=1_000_000.0,
    )
    assert decisions == []


def test_position_sizing_respects_event_type_multiplier():
    sm = V4ExecutionStateMachine(
        max_positions=2,
        position_multipliers={"trend_spear": 1.0, "arb": 0.35},
    )
    trend = SignalEventV2(
        event_type="trend_spear",
        symbol="000001",
        ts="2024-03-01",
        confidence=0.82,
        side="long",
        entry_plan={"style": "tail_close"},
        invalidation={"price": 9.5},
        exit_plan={"style": "trend_hold", "hold_days": 8, "take_profit_pct": 0.2},
    )
    arb = SignalEventV2(
        event_type="arb",
        symbol="000002",
        ts="2024-03-01",
        confidence=0.70,
        side="long",
        entry_plan={"style": "tail_close"},
        invalidation={"price": 9.5},
        exit_plan={"style": "tactical_arb", "hold_days": 3, "take_profit_pct": 0.1},
    )
    d1 = sm.on_day(
        date="2024-03-01",
        d_idx=100,
        symbol="000001",
        open_price=10.0,
        close=10.0,
        high=10.1,
        low=9.9,
        events=[trend],
        cash=1_000_000.0,
    )
    d2 = sm.on_day(
        date="2024-03-01",
        d_idx=100,
        symbol="000002",
        open_price=10.0,
        close=10.0,
        high=10.1,
        low=9.9,
        events=[arb],
        cash=1_000_000.0,
    )
    trend_buy = next(x for x in d1 if x.action == "buy")
    arb_buy = next(x for x in d2 if x.action == "buy")
    assert trend_buy.qty > arb_buy.qty
    assert trend_buy.meta["position_mult"] == 1.0
    assert arb_buy.meta["position_mult"] == 0.35
