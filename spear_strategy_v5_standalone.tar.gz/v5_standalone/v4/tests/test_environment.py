from __future__ import annotations

import pandas as pd

from v4.environment.provider import EnvironmentProvider, infer_name_theme


def test_infer_name_theme():
    assert infer_name_theme("中贝通信") == "科技"
    assert infer_name_theme("南京公用") == "国资"


def test_recent_lhb_net_sell_empty():
    env = EnvironmentProvider()
    env.lhb = pd.DataFrame()
    assert env.recent_lhb_net_sell("000001", "2024-03-01") is False
