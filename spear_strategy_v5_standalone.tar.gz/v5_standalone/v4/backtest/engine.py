from __future__ import annotations

import json
from dataclasses import dataclass, field

import pandas as pd

from cq_backtest.shared.market_rules import round_to_tick
from cq_backtest.shared.utils import ensure_dir
from v4.config.defaults import V4Config
from v4.data.adapter import V4DataAdapter
from v4.environment.provider import EnvironmentProvider
from v4.execution.state_machine import Decision, V4ExecutionStateMachine
from v4.features import add_robust_volume_features, add_sequence_features, add_structure_features
from v4.models.registry import detect_signals


@dataclass(slots=True)
class BacktestResult:
    trades: list[dict] = field(default_factory=list)
    events: list[dict] = field(default_factory=list)
    open_positions: list[dict] = field(default_factory=list)
    summary: dict = field(default_factory=dict)


class V4BacktestEngine:
    def __init__(self, cfg: V4Config) -> None:
        self.cfg = cfg
        self.data = V4DataAdapter(
            cache_dir=cfg.data.cache_dir,
            count=cfg.data.bar_count,
            pool_sampling=cfg.data.pool_sampling,
            pool_seed=cfg.data.pool_seed,
        )
        self.env = EnvironmentProvider(
            cache_dir=cfg.data.cache_dir,
            sector_cache_path=cfg.data.sector_cache_path,
            lhb_cache_path=cfg.data.lhb_cache_path,
        )
        self.env.load()
        self.exec = V4ExecutionStateMachine(
            max_positions=cfg.execution.max_positions,
            base_pos_pct=cfg.execution.base_pos_pct,
            position_multipliers={
                "trend_spear": cfg.execution.trend_spear_pos_mult,
                "post_limit": cfg.execution.post_limit_pos_mult,
                "failed_board": cfg.execution.failed_board_pos_mult,
                "youzi": cfg.execution.youzi_pos_mult,
                "sector_spear": cfg.execution.sector_spear_pos_mult,
                "attack": cfg.execution.attack_pos_mult,
                "arb": cfg.execution.arb_pos_mult,
            },
            cooldown_days=cfg.execution.cooldown_days,
            default_take_profit_pct=cfg.execution.default_take_profit_pct,
        )

    def _prepare(self, df: pd.DataFrame) -> pd.DataFrame:
        out = add_robust_volume_features(df, window=self.cfg.features.vol_window)
        out = add_sequence_features(out, window=self.cfg.features.sequence_window)
        out = add_structure_features(
            out,
            peak_window=self.cfg.features.peak_window,
            drawdown_min=self.cfg.features.drawdown_min,
            peak_touch_eps=self.cfg.features.peak_touch_eps,
            consolidation_window=self.cfg.features.consolidation_window,
        )
        return out

    def run(
        self,
        start: str,
        end: str,
        pool_size: int,
        init_cash: float = 1_000_000.0,
        active_event_types: set[str] | None = None,
    ) -> BacktestResult:
        symbols = self.data.load_universe(pool_size)
        cash = float(init_cash)
        trades: list[dict] = []
        events_out: list[dict] = []
        prepared: dict[str, pd.DataFrame] = {}
        symbol_dates: dict[str, list[str]] = {}
        symbol_date_to_idx: dict[str, dict[str, int]] = {}
        raw_events: dict[tuple[str, str], list] = {}
        day_theme_counts: dict[tuple[str, str], int] = {}
        day_theme_leaders: dict[tuple[str, str], int] = {}
        all_dates: set[str] = set()

        for symbol in symbols:
            # Keep warm-up history before `start`; otherwise short YTD ranges
            # lose the lookback needed for features and no events can form.
            bars = self.data.load_symbol(symbol, start="", end=end)
            if bars.empty or len(bars) < 120:
                continue
            bars = self._prepare(bars)
            prepared[symbol] = bars
            dates = [str(x)[:10] for x in bars.index]
            symbol_dates[symbol] = dates
            symbol_date_to_idx[symbol] = {d: i for i, d in enumerate(dates)}
            for i in range(120, len(bars)):
                frame = bars.iloc[: i + 1]
                date = str(frame.index[-1])[:10]
                if start and date < start:
                    continue
                all_dates.add(date)
                meta = self.env.get_symbol_meta(symbol)
                raw = detect_signals(
                    frame,
                    symbol,
                    post_limit_lookback=self.cfg.models.post_limit_lookback,
                    trend_multi_days=self.cfg.models.trend_multi_spear_days,
                    attack_limit_lookback=self.cfg.models.attack_limit_lookback,
                    arb_limit_lookback=self.cfg.models.arb_limit_lookback,
                    env={
                        "theme_label": meta.get("industry") or meta.get("name_theme") or "其他",
                        "lhb_net_sell": self.env.recent_lhb_net_sell(symbol, date),
                    },
                )
                raw_events[(symbol, date)] = raw
                theme_label = str(meta.get("industry") or meta.get("name_theme") or "其他")
                long_events = [e for e in raw if e.side == "long"]
                if long_events and theme_label:
                    key = (date, theme_label)
                    day_theme_counts[key] = day_theme_counts.get(key, 0) + 1
                    leader_hit = 1 if any(e.event_type in {"post_limit", "trend_spear", "failed_board"} and e.confidence >= 0.7 for e in long_events) else 0
                    day_theme_leaders[key] = day_theme_leaders.get(key, 0) + leader_hit

        for date in sorted(all_dates):
            active_symbols = [s for s, dates in symbol_dates.items() if date in dates]
            for symbol in active_symbols:
                bars = prepared[symbol]
                idx = symbol_date_to_idx[symbol][date]
                cur = bars.iloc[idx]
                if idx < 120:
                    continue
                if start and date < start:
                    continue
                meta = self.env.get_symbol_meta(symbol)
                theme_label = str(meta.get("industry") or meta.get("name_theme") or "其他")
                peer_confirmation = day_theme_counts.get((date, theme_label), 0) - (1 if raw_events.get((symbol, date)) else 0)
                leader_strength = max(0, day_theme_leaders.get((date, theme_label), 0) - (1 if any(e.event_type in {"post_limit", "trend_spear", "failed_board"} and e.confidence >= 0.7 for e in raw_events.get((symbol, date), [])) else 0))
                env_ctx = {
                    "theme_label": theme_label,
                    "peer_confirmation": peer_confirmation,
                    "leader_strength": leader_strength,
                    "lhb_net_sell": self.env.recent_lhb_net_sell(symbol, date),
                    "sector_hot": bool(peer_confirmation >= 2 and leader_strength >= 1),
                    "_enforce_env": True,
                }
                events = detect_signals(
                    bars.iloc[: idx + 1],
                    symbol,
                    post_limit_lookback=self.cfg.models.post_limit_lookback,
                    trend_multi_days=self.cfg.models.trend_multi_spear_days,
                    attack_limit_lookback=self.cfg.models.attack_limit_lookback,
                    arb_limit_lookback=self.cfg.models.arb_limit_lookback,
                    env=env_ctx,
                )
                enriched_events = []
                for ev in events:
                    ctx = dict(ev.context)
                    ctx.update({k: v for k, v in env_ctx.items() if not str(k).startswith("_")})
                    ev.context = ctx
                    if ev.side == "long" and ctx["lhb_net_sell"]:
                        continue
                    enriched_events.append(ev)
                events = enriched_events

                if active_event_types is not None:
                    events = [e for e in events if e.event_type in active_event_types]
                for ev in events:
                    events_out.append(
                        {
                            "date": ev.ts,
                            "symbol": ev.symbol,
                            "event_type": ev.event_type,
                            "confidence": ev.confidence,
                            "side": ev.side,
                            "entry_plan": json.dumps(ev.entry_plan, ensure_ascii=False, sort_keys=True),
                            "invalidation": json.dumps(ev.invalidation, ensure_ascii=False, sort_keys=True),
                            "exit_plan": json.dumps(ev.exit_plan, ensure_ascii=False, sort_keys=True),
                            "context": json.dumps(ev.context, ensure_ascii=False, sort_keys=True),
                        }
                    )

                decisions = self.exec.on_day(
                    date=date,
                    d_idx=idx,
                    symbol=symbol,
                    open_price=float(cur["open"]),
                    close=float(cur["close"]),
                    high=float(cur["high"]),
                    low=float(cur["low"]),
                    limit_up=float(cur["limit_up"]) if pd.notna(cur.get("limit_up")) else None,
                    limit_down=float(cur["close"]) * (1 - float(cur.get("limit_pct", 0.1))) if pd.notna(cur.get("limit_pct")) else None,
                    events=events,
                    cash=cash,
                    day_context=env_ctx,
                )
                for dec in decisions:
                    applied = self._apply_trade_costs(dec)
                    cash = self._apply_cash(cash, applied)
                    trades.append(
                        {
                            "date": date,
                            "symbol": applied.symbol,
                            "action": applied.action,
                            "price": applied.price,
                            "qty": applied.qty,
                            "reason": applied.reason,
                            "meta": json.dumps(applied.meta, ensure_ascii=False, sort_keys=True),
                            "cash_after": round(cash, 2),
                        }
                    )

        open_positions = self._collect_open_positions(prepared)
        summary = self._build_summary(trades, events_out, cash, init_cash, open_positions)
        return BacktestResult(trades=trades, events=events_out, open_positions=open_positions, summary=summary)

    @staticmethod
    def _apply_cash(cash: float, dec: Decision) -> float:
        delta = float(dec.meta.get("net_cash_delta", 0.0))
        if delta != 0.0:
            return cash + delta
        notion = dec.price * dec.qty
        if dec.action == "buy":
            return cash - notion
        if dec.action == "sell":
            return cash + notion
        return cash

    def _apply_trade_costs(self, dec: Decision) -> Decision:
        slip_bps = self.cfg.execution.buy_slippage_bps if dec.action == "buy" else self.cfg.execution.sell_slippage_bps
        sign = 1.0 if dec.action == "buy" else -1.0
        price = round_to_tick(dec.price * (1.0 + sign * slip_bps / 10000.0))
        notion = price * dec.qty
        commission = max(self.cfg.execution.min_commission, notion * self.cfg.execution.commission_bps / 10000.0) if dec.qty > 0 else 0.0
        stamp = notion * self.cfg.execution.stamp_duty_bps / 10000.0 if dec.action == "sell" else 0.0
        fee_total = commission + stamp
        net_cash_delta = -(notion + fee_total) if dec.action == "buy" else (notion - fee_total)
        meta = dict(dec.meta)
        meta.update(
            {
                "gross_notional": round(notion, 4),
                "commission": round(commission, 4),
                "stamp_duty": round(stamp, 4),
                "fee_total": round(fee_total, 4),
                "slippage_bps": float(slip_bps),
                "net_cash_delta": round(net_cash_delta, 4),
            }
        )
        return Decision(dec.action, dec.symbol, price, dec.qty, dec.reason, meta)

    @staticmethod
    def _build_summary(trades: list[dict], events: list[dict], final_cash: float, init_cash: float, open_positions: list[dict]) -> dict:
        buys = [x for x in trades if x["action"] == "buy"]
        sells = [x for x in trades if x["action"] == "sell"]
        total_fees = 0.0
        for row in trades:
            try:
                meta = json.loads(row.get("meta", "{}"))
                total_fees += float(meta.get("fee_total", 0.0) or 0.0)
            except Exception:
                pass
        open_market_value = sum(float(x.get("market_value", 0.0) or 0.0) for x in open_positions)
        open_unrealized = sum(float(x.get("unrealized_pnl", 0.0) or 0.0) for x in open_positions)
        equity_final = final_cash + open_market_value
        return {
            "init_cash": init_cash,
            "final_cash": round(final_cash, 2),
            "cash_return_pct": round((final_cash / init_cash - 1.0) * 100, 2),
            "open_count": len(open_positions),
            "open_market_value": round(open_market_value, 2),
            "open_unrealized_pnl": round(open_unrealized, 2),
            "equity_final": round(equity_final, 2),
            "equity_return_pct": round((equity_final / init_cash - 1.0) * 100, 2),
            "trade_count": len(trades),
            "buy_count": len(buys),
            "sell_count": len(sells),
            "event_count": len(events),
            "total_fees": round(total_fees, 2),
        }

    def _collect_open_positions(self, prepared: dict[str, pd.DataFrame]) -> list[dict]:
        rows: list[dict] = []
        for symbol, pos in self.exec.positions.items():
            bars = prepared.get(symbol)
            if bars is None or bars.empty:
                continue
            last = bars.iloc[-1]
            market_value = float(last["close"]) * float(pos.qty)
            cost = float(pos.entry_price) * float(pos.qty)
            rows.append(
                {
                    "symbol": symbol,
                    "entry_date": pos.entry_date,
                    "entry_price": float(pos.entry_price),
                    "qty": float(pos.qty),
                    "source_event": pos.source_event,
                    "last_close": float(last["close"]),
                    "market_value": round(market_value, 4),
                    "cost_basis": round(cost, 4),
                    "unrealized_pnl": round(market_value - cost, 4),
                }
            )
        return rows

    @staticmethod
    def write_outputs(output_dir: str, result: BacktestResult) -> None:
        out = ensure_dir(output_dir)
        pd.DataFrame(result.events).to_csv(out / "events.csv", index=False)
        pd.DataFrame(result.trades).to_csv(out / "trades.csv", index=False)
        pd.DataFrame(result.open_positions).to_csv(out / "open_positions.csv", index=False)
        with (out / "summary.json").open("w", encoding="utf-8") as fh:
            json.dump(result.summary, fh, ensure_ascii=False, indent=2)
