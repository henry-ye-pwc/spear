from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable

from cq_backtest.shared.market_rules import can_buy_strict, can_sell_strict
from cq_backtest.shared.signal_schema import SignalEventV2


@dataclass(slots=True)
class PositionState:
    symbol: str
    entry_date: str
    entry_idx: int
    entry_price: float
    qty: float
    source_event: str
    stop_price: float
    take_price: float
    max_hold_days: int
    exit_style: str


@dataclass(slots=True)
class Decision:
    action: str
    symbol: str
    price: float | None
    qty: float = 0.0
    reason: str = ""
    meta: dict = field(default_factory=dict)


@dataclass(slots=True)
class PendingEntry:
    symbol: str
    created_idx: int
    valid_from_idx: int
    valid_until_idx: int
    trigger_price: float
    source_event: str
    confidence: float
    invalidate_price: float
    max_hold_days: int
    take_profit_pct: float
    exit_style: str
    entry_style: str = "breakout"


@dataclass(slots=True)
class PendingFill:
    action: str
    symbol: str
    execute_idx: int
    qty: float
    source_event: str
    entry_style: str = ""
    invalidate_price: float = 0.0
    max_hold_days: int = 5
    take_profit_pct: float = 0.18
    exit_style: str = "default"
    position_mult: float = 1.0


@dataclass(slots=True)
class PendingHunt:
    symbol: str
    created_idx: int
    valid_from_idx: int
    valid_until_idx: int
    target_price: float
    buffer_pct: float
    source_event: str
    confidence: float
    invalidate_price: float
    max_hold_days: int
    take_profit_pct: float
    exit_style: str
    entry_style: str = "hunt"
    qty: float = 0.0
    position_mult: float = 1.0


@dataclass(slots=True)
class PendingSellHunt:
    symbol: str
    created_idx: int
    valid_from_idx: int
    valid_until_idx: int
    target_price: float
    buffer_pct: float
    qty: float
    reason: str
    source_event: str
    exit_style: str


class V4ExecutionStateMachine:
    def __init__(
        self,
        *,
        max_positions: int = 4,
        base_pos_pct: float = 0.25,
        position_multipliers: dict[str, float] | None = None,
        cooldown_days: int = 3,
        default_take_profit_pct: float = 0.18,
        execution_profile: str = "day_level_ideal",
        hunt_price_buffer_pct: float = 0.005,
        hunt_window_days: int = 3,
        exit_hunt_buffer_pct: float = 0.005,
        exit_hunt_window_days: int = 3,
        exit_mode: str = "ideal",
        trace_hook: Callable[[dict[str, Any]], None] | None = None,
    ) -> None:
        self.max_positions = max_positions
        self.base_pos_pct = base_pos_pct
        self.position_multipliers = position_multipliers or {}
        self.cooldown_days = cooldown_days
        self.default_take_profit_pct = default_take_profit_pct
        self.execution_profile = execution_profile
        self.hunt_price_buffer_pct = hunt_price_buffer_pct
        self.hunt_window_days = hunt_window_days
        self.exit_hunt_buffer_pct = exit_hunt_buffer_pct
        self.exit_hunt_window_days = exit_hunt_window_days
        self.exit_mode = exit_mode
        self.trace_hook = trace_hook
        self.positions: dict[str, PositionState] = {}
        self.cooldowns: dict[str, int] = {}
        self.pending_entries: dict[str, list[PendingEntry]] = {}
        self.pending_fills: dict[str, PendingFill] = {}
        self.pending_hunts: dict[str, PendingHunt] = {}
        self.pending_sell_hunts: dict[str, PendingSellHunt] = {}

    def _trace(self, kind: str, **payload: Any) -> None:
        if self.trace_hook is None:
            return
        self.trace_hook({"kind": kind, **payload})

    def _can_open(self, symbol: str, d_idx: int) -> bool:
        if len(self.positions) >= self.max_positions:
            return False
        until = self.cooldowns.get(symbol)
        return until is None or d_idx > until

    def _position_multiplier(self, event: SignalEventV2) -> float:
        mult = float(self.position_multipliers.get(str(event.event_type), 1.0))
        return max(0.10, min(mult, 1.25))

    def _is_realistic(self) -> bool:
        return self.execution_profile == "next_open_realistic" or self.exit_mode in ("next_open", "hunt_exit")

    def _is_hunt(self) -> bool:
        return self.execution_profile == "delayed_limit_hunt"

    def _buy_now(self, date: str, d_idx: int, symbol: str, price: float, cash: float, event: SignalEventV2) -> Decision | None:
        pos_mult = self._position_multiplier(event)
        budget = cash * self.base_pos_pct * pos_mult
        qty = int(budget // price)
        if qty <= 0:
            return None
        stop_price = float(event.invalidation.get("price", price * 0.94))
        take_profit_pct = float(event.exit_plan.get("take_profit_pct", self.default_take_profit_pct))
        max_hold_days = int(event.exit_plan.get("hold_days", 5))
        exit_style = str(event.exit_plan.get("style", "default"))
        self.positions[symbol] = PositionState(
            symbol=symbol,
            entry_date=date,
            entry_idx=d_idx,
            entry_price=price,
            qty=qty,
            source_event=event.event_type,
            stop_price=stop_price,
            take_price=price * (1.0 + take_profit_pct),
            max_hold_days=max_hold_days,
            exit_style=exit_style,
        )
        return Decision(
            "buy",
            symbol,
            price,
            qty,
            f"entry:{event.event_type}",
            {"style": event.entry_plan.get("style", ""), "exit_style": exit_style, "position_mult": pos_mult},
        )

    def _queue_buy_next_open(
        self,
        *,
        d_idx: int,
        symbol: str,
        cash: float,
        sizing_price: float,
        event: SignalEventV2,
    ) -> Decision | None:
        pos_mult = self._position_multiplier(event)
        budget = cash * self.base_pos_pct * pos_mult
        qty = int(budget // max(sizing_price, 0.01))
        if qty <= 0:
            return None
        stop_price = float(event.invalidation.get("price", sizing_price * 0.94))
        take_profit_pct = float(event.exit_plan.get("take_profit_pct", self.default_take_profit_pct))
        max_hold_days = int(event.exit_plan.get("hold_days", 5))
        exit_style = str(event.exit_plan.get("style", "default"))
        self.pending_fills[symbol] = PendingFill(
            action="buy",
            symbol=symbol,
            execute_idx=d_idx + 1,
            qty=qty,
            source_event=event.event_type,
            entry_style=str(event.entry_plan.get("style", "")),
            invalidate_price=stop_price,
            max_hold_days=max_hold_days,
            take_profit_pct=take_profit_pct,
            exit_style=exit_style,
            position_mult=pos_mult,
        )
        return Decision(
            "buy",
            symbol,
            None,
            qty,
            f"entry:{event.event_type}",
            {
                "style": event.entry_plan.get("style", ""),
                "exit_style": exit_style,
                "position_mult": pos_mult,
                "order_type": "market",
                "execution_profile": self.execution_profile,
            },
        )

    def _queue_hunt(
        self,
        *,
        d_idx: int,
        date: str,
        symbol: str,
        cash: float,
        target_price: float,
        event: SignalEventV2,
    ) -> Decision | None:
        pos_mult = self._position_multiplier(event)
        budget = cash * self.base_pos_pct * pos_mult
        qty = int(budget // max(target_price, 0.01))
        if qty <= 0:
            return None
        stop_price = float(event.invalidation.get("price", target_price * 0.94))
        take_profit_pct = float(event.exit_plan.get("take_profit_pct", self.default_take_profit_pct))
        max_hold_days = int(event.exit_plan.get("hold_days", 5))
        exit_style = str(event.exit_plan.get("style", "default"))
        existing = self.pending_hunts.get(symbol)
        if existing is not None:
            self._trace(
                "hunt_overwritten",
                date=date,
                symbol=symbol,
                old_source_event=existing.source_event,
                old_target_price=existing.target_price,
                new_source_event=event.event_type,
                new_target_price=target_price,
            )
        self.pending_hunts[symbol] = PendingHunt(
            symbol=symbol,
            created_idx=d_idx,
            valid_from_idx=d_idx + 1,
            valid_until_idx=d_idx + max(1, self.hunt_window_days),
            target_price=target_price,
            buffer_pct=self.hunt_price_buffer_pct,
            source_event=event.event_type,
            confidence=float(event.confidence),
            invalidate_price=stop_price,
            max_hold_days=max_hold_days,
            take_profit_pct=take_profit_pct,
            exit_style=exit_style,
            entry_style=str(event.entry_plan.get("style", "")),
            qty=qty,
            position_mult=pos_mult,
        )
        self._trace(
            "hunt_queued",
            date=date,
            symbol=symbol,
            source_event=event.event_type,
            target_price=target_price,
            valid_from_idx=d_idx + 1,
            valid_until_idx=d_idx + max(1, self.hunt_window_days),
            buffer_pct=self.hunt_price_buffer_pct,
            exit_style=exit_style,
        )
        return None

    def _queue_sell_next_open(self, *, d_idx: int, symbol: str, pos: PositionState, reason: str) -> Decision:
        self.pending_fills[symbol] = PendingFill(
            action="sell",
            symbol=symbol,
            execute_idx=d_idx + 1,
            qty=float(pos.qty),
            source_event=pos.source_event,
            exit_style=pos.exit_style,
        )
        return Decision(
            "sell",
            symbol,
            None,
            pos.qty,
            reason,
            {
                "style": "",
                "exit_style": pos.exit_style,
                "position_mult": self.position_multipliers.get(pos.source_event, 1.0),
                "order_type": "market",
                "execution_profile": self.execution_profile,
            },
        )

    def _apply_pending_fill(self, *, date: str, d_idx: int, symbol: str, open_price: float) -> None:
        fill = self.pending_fills.get(symbol)
        if fill is None or fill.execute_idx != d_idx:
            return
        self.pending_fills.pop(symbol, None)
        if fill.action == "buy":
            self.positions[symbol] = PositionState(
                symbol=symbol,
                entry_date=date,
                entry_idx=d_idx,
                entry_price=open_price,
                qty=fill.qty,
                source_event=fill.source_event,
                stop_price=fill.invalidate_price,
                take_price=open_price * (1.0 + fill.take_profit_pct),
                max_hold_days=fill.max_hold_days,
                exit_style=fill.exit_style,
            )
            return
        self.positions.pop(symbol, None)
        self.cooldowns[symbol] = d_idx + self.cooldown_days

    def _queue_sell_hunt(
        self, *, d_idx: int, date: str, symbol: str, pos: PositionState,
        target_price: float, reason: str,
    ) -> None:
        self.pending_sell_hunts[symbol] = PendingSellHunt(
            symbol=symbol,
            created_idx=d_idx,
            valid_from_idx=d_idx + 1,
            valid_until_idx=d_idx + max(1, self.exit_hunt_window_days),
            target_price=target_price,
            buffer_pct=self.exit_hunt_buffer_pct,
            qty=pos.qty,
            reason=reason,
            source_event=pos.source_event,
            exit_style=pos.exit_style,
        )
        self._trace(
            "sell_hunt_queued", date=date, symbol=symbol,
            target_price=target_price, reason=reason,
            valid_until_idx=d_idx + max(1, self.exit_hunt_window_days),
        )

    def _try_sell_hunt_fill(
        self, *, date: str, d_idx: int, symbol: str,
        open_price: float, high: float, low: float,
    ) -> Decision | None:
        hunt = self.pending_sell_hunts.get(symbol)
        if hunt is None:
            return None
        if d_idx < hunt.valid_from_idx:
            return None
        if d_idx > hunt.valid_until_idx:
            self._trace("sell_hunt_expired", date=date, symbol=symbol,
                        target_price=hunt.target_price, reason=hunt.reason)
            self.pending_sell_hunts.pop(symbol, None)
            self.positions.pop(symbol, None)
            self.cooldowns[symbol] = d_idx + self.cooldown_days
            return Decision("sell", symbol, open_price, hunt.qty, f"{hunt.reason}_forced",
                            {"exit_style": hunt.exit_style, "order_type": "market_forced"})
        threshold = hunt.target_price * (1.0 - hunt.buffer_pct)
        if high < threshold:
            return None
        if open_price >= threshold:
            fill_price = open_price
        else:
            fill_price = hunt.target_price
        self._trace("sell_hunt_filled", date=date, symbol=symbol,
                    target_price=hunt.target_price, fill_price=fill_price, reason=hunt.reason)
        self.pending_sell_hunts.pop(symbol, None)
        self.positions.pop(symbol, None)
        self.cooldowns[symbol] = d_idx + self.cooldown_days
        return Decision("sell", symbol, fill_price, hunt.qty, hunt.reason,
                        {"exit_style": hunt.exit_style, "order_type": "hunt_limit"})

    def _try_hunt_fill(
        self,
        *,
        date: str,
        d_idx: int,
        symbol: str,
        high: float,
        low: float,
        cash: float,
    ) -> Decision | None:
        hunt = self.pending_hunts.get(symbol)
        if hunt is None:
            return None
        if d_idx < hunt.valid_from_idx:
            return None
        if d_idx > hunt.valid_until_idx:
            self._trace(
                "hunt_expired",
                date=date,
                symbol=symbol,
                source_event=hunt.source_event,
                target_price=hunt.target_price,
                expired_idx=d_idx,
            )
            self.pending_hunts.pop(symbol, None)
            return None
        if not self._can_open(symbol, d_idx):
            self._trace(
                "hunt_blocked_max_positions",
                date=date,
                symbol=symbol,
                source_event=hunt.source_event,
                positions=len(self.positions),
            )
            return None
        lower = hunt.target_price * (1.0 - hunt.buffer_pct)
        upper = hunt.target_price * (1.0 + hunt.buffer_pct)
        if high < lower or low > upper:
            return None
        fill_price = hunt.target_price
        budget = cash * self.base_pos_pct * hunt.position_mult
        qty = int(budget // fill_price)
        if qty <= 0:
            self._trace(
                "hunt_skipped_no_budget",
                date=date,
                symbol=symbol,
                source_event=hunt.source_event,
                cash=round(cash, 2),
                fill_price=fill_price,
            )
            self.pending_hunts.pop(symbol, None)
            return None
        self.pending_hunts.pop(symbol, None)
        self._trace(
            "hunt_filled",
            date=date,
            symbol=symbol,
            source_event=hunt.source_event,
            target_price=hunt.target_price,
            fill_price=fill_price,
            qty=qty,
            budget=round(budget, 2),
            high=high,
            low=low,
        )
        self.positions[symbol] = PositionState(
            symbol=symbol,
            entry_date=date,
            entry_idx=d_idx,
            entry_price=fill_price,
            qty=qty,
            source_event=hunt.source_event,
            stop_price=hunt.invalidate_price,
            take_price=fill_price * (1.0 + hunt.take_profit_pct),
            max_hold_days=hunt.max_hold_days,
            exit_style=hunt.exit_style,
        )
        return Decision(
            "buy",
            symbol,
            fill_price,
            qty,
            f"entry:{hunt.source_event}",
            {
                "style": hunt.entry_style,
                "exit_style": hunt.exit_style,
                "position_mult": hunt.position_mult,
                "execution_profile": self.execution_profile,
                "hunt_target_price": hunt.target_price,
                "hunt_buffer_pct": hunt.buffer_pct,
            },
        )

    @staticmethod
    def _route_candidates(events: list[SignalEventV2]) -> tuple[list[SignalEventV2], list[SignalEventV2]]:
        cands = [e for e in events if e.side == "long" and e.confidence >= 0.6]
        tail = [e for e in cands if str(e.entry_plan.get("style", "")) == "tail_close"]
        breakout = [e for e in cands if str(e.entry_plan.get("style", "breakout")) == "breakout"]
        tail.sort(key=lambda x: (V4ExecutionStateMachine._route_score(x), str(x.event_type)), reverse=True)
        breakout.sort(key=lambda x: (V4ExecutionStateMachine._route_score(x), str(x.event_type)), reverse=True)
        return tail, breakout

    @staticmethod
    def _event_priority(event_type: str) -> float:
        priorities = {
            "post_limit": 0.10,
            "trend_spear": 0.08,
            "failed_board": 0.07,
            "youzi": 0.05,
            "sector_spear": 0.04,
            "attack": 0.01,
            "arb": 0.00,
        }
        return priorities.get(event_type, 0.0)

    @classmethod
    def _route_score(cls, event: SignalEventV2) -> float:
        style = str(event.entry_plan.get("style", "breakout"))
        style_bonus = 0.01 if style == "breakout" else 0.0
        return float(event.confidence) + cls._event_priority(str(event.event_type)) + style_bonus

    def _dedupe_pending(self, symbol: str) -> None:
        routes = list(self.pending_entries.get(symbol, []))
        deduped: list[PendingEntry] = []
        seen: set[tuple[str, float, str]] = set()
        for route in routes:
            key = (route.source_event, round(route.trigger_price, 3), route.entry_style)
            if key in seen:
                continue
            seen.add(key)
            deduped.append(route)
        deduped.sort(key=lambda x: (x.confidence, x.trigger_price), reverse=True)
        self.pending_entries[symbol] = deduped[:2]

    def on_day(
        self,
        *,
        date: str,
        d_idx: int,
        symbol: str,
        open_price: float,
        close: float,
        high: float,
        low: float,
        limit_up: float | None = None,
        limit_down: float | None = None,
        events: list[SignalEventV2],
        cash: float,
        day_context: dict | None = None,
    ) -> list[Decision]:
        decisions: list[Decision] = []
        day_context = day_context or {}
        if self._is_realistic():
            self._apply_pending_fill(date=date, d_idx=d_idx, symbol=symbol, open_price=open_price)
        sell_hunt_active = symbol in self.pending_sell_hunts
        if sell_hunt_active:
            dec = self._try_sell_hunt_fill(date=date, d_idx=d_idx, symbol=symbol,
                                           open_price=open_price, high=high, low=low)
            if dec is not None:
                return [dec]
        pos = self.positions.get(symbol)
        if sell_hunt_active and pos is not None:
            if low <= pos.stop_price and (limit_down is None or can_sell_strict(pos.stop_price, limit_down)):
                self.pending_sell_hunts.pop(symbol, None)
                self._trace("sell_hunt_cancelled", date=date, symbol=symbol, reason="stop_loss_override")
                decisions.append(self._queue_sell_next_open(d_idx=d_idx, symbol=symbol, pos=pos, reason="stop_loss"))
                return decisions
            if symbol in self.pending_sell_hunts:
                return decisions
        pending = list(self.pending_entries.get(symbol, []))
        queued_fill = self.pending_fills.get(symbol)
        if pos is None and self._is_hunt():
            dec = self._try_hunt_fill(date=date, d_idx=d_idx, symbol=symbol, high=high, low=low, cash=cash)
            if dec is not None:
                return [dec]
            if symbol in self.pending_hunts:
                return decisions

        if pos is not None:
            holding_days = d_idx - pos.entry_idx
            if self._is_realistic() and queued_fill is not None and queued_fill.action == "sell":
                return decisions
            if low <= pos.stop_price and (limit_down is None or can_sell_strict(pos.stop_price, limit_down)):
                if self._is_realistic():
                    decisions.append(self._queue_sell_next_open(d_idx=d_idx, symbol=symbol, pos=pos, reason="stop_loss"))
                else:
                    decisions.append(Decision("sell", symbol, pos.stop_price, pos.qty, "stop_loss"))
                    self.positions.pop(symbol, None)
                    self.cooldowns[symbol] = d_idx + self.cooldown_days
                return decisions
            if pos.exit_style not in {"trend_hold"} and high >= pos.take_price and (limit_down is None or can_sell_strict(pos.take_price, limit_down)):
                if self.exit_mode == "hunt_exit":
                    self._queue_sell_hunt(d_idx=d_idx, date=date, symbol=symbol, pos=pos,
                                         target_price=pos.take_price, reason="take_profit")
                elif self._is_realistic():
                    decisions.append(self._queue_sell_next_open(d_idx=d_idx, symbol=symbol, pos=pos, reason="take_profit"))
                else:
                    decisions.append(Decision("sell", symbol, pos.take_price, pos.qty, "take_profit"))
                    self.positions.pop(symbol, None)
                    self.cooldowns[symbol] = d_idx + self.cooldown_days
                return decisions
            if pos.exit_style == "tactical_arb" and holding_days >= 3 and close <= pos.entry_price * 1.01 and (limit_down is None or can_sell_strict(close, limit_down)):
                if self._is_realistic():
                    decisions.append(self._queue_sell_next_open(d_idx=d_idx, symbol=symbol, pos=pos, reason="no_premium"))
                else:
                    decisions.append(Decision("sell", symbol, close, pos.qty, "no_premium"))
                    self.positions.pop(symbol, None)
                    self.cooldowns[symbol] = d_idx + self.cooldown_days
                return decisions
            if pos.exit_style == "continuation" and holding_days >= 3 and close < pos.entry_price * 0.99 and (limit_down is None or can_sell_strict(close, limit_down)):
                if self._is_realistic():
                    decisions.append(self._queue_sell_next_open(d_idx=d_idx, symbol=symbol, pos=pos, reason="failed_continuation"))
                else:
                    decisions.append(Decision("sell", symbol, close, pos.qty, "failed_continuation"))
                    self.positions.pop(symbol, None)
                    self.cooldowns[symbol] = d_idx + self.cooldown_days
                return decisions
            if pos.exit_style in {"theme_burst", "sector_burst"} and holding_days >= 1:
                if (not bool(day_context.get("sector_hot", False))) and close < pos.entry_price and (limit_down is None or can_sell_strict(close, limit_down)):
                    if self._is_realistic():
                        decisions.append(self._queue_sell_next_open(d_idx=d_idx, symbol=symbol, pos=pos, reason="theme_collapse"))
                    else:
                        decisions.append(Decision("sell", symbol, close, pos.qty, "theme_collapse"))
                        self.positions.pop(symbol, None)
                        self.cooldowns[symbol] = d_idx + self.cooldown_days
                    return decisions
            if pos.exit_style in {"swing_confirm", "rebalance_swing"} and holding_days >= 2 and close <= pos.stop_price * 1.01 and (limit_down is None or can_sell_strict(close, limit_down)):
                if self._is_realistic():
                    decisions.append(self._queue_sell_next_open(d_idx=d_idx, symbol=symbol, pos=pos, reason="rebreak"))
                else:
                    decisions.append(Decision("sell", symbol, close, pos.qty, "rebreak"))
                    self.positions.pop(symbol, None)
                    self.cooldowns[symbol] = d_idx + self.cooldown_days
                return decisions
            if holding_days >= pos.max_hold_days and (limit_down is None or can_sell_strict(close, limit_down)):
                if self._is_realistic():
                    decisions.append(self._queue_sell_next_open(d_idx=d_idx, symbol=symbol, pos=pos, reason="time_exit"))
                else:
                    decisions.append(Decision("sell", symbol, close, pos.qty, "time_exit"))
                    self.positions.pop(symbol, None)
                    self.cooldowns[symbol] = d_idx + self.cooldown_days
                return decisions
            if any(e.event_type == "escape" for e in events) and (limit_down is None or can_sell_strict(close, limit_down)):
                if self._is_realistic():
                    decisions.append(self._queue_sell_next_open(d_idx=d_idx, symbol=symbol, pos=pos, reason="escape_risk_off"))
                else:
                    decisions.append(Decision("sell", symbol, close, pos.qty, "escape_risk_off"))
                    self.positions.pop(symbol, None)
                    self.cooldowns[symbol] = d_idx + self.cooldown_days
                return decisions
            return decisions

        if any(e.event_type == "escape" for e in events):
            if symbol in self.pending_hunts:
                hunt = self.pending_hunts[symbol]
                self._trace(
                    "hunt_cleared_escape",
                    date=date,
                    symbol=symbol,
                    source_event=hunt.source_event,
                    target_price=hunt.target_price,
                )
            self.pending_entries.pop(symbol, None)
            self.pending_hunts.pop(symbol, None)
            return decisions

        if self._is_realistic() and queued_fill is not None and queued_fill.action == "buy":
            return decisions

        if pending:
            active_pending: list[PendingEntry] = []
            triggered: list[PendingEntry] = []
            for route in pending:
                if d_idx > route.valid_until_idx:
                    continue
                active_pending.append(route)
                if d_idx >= route.valid_from_idx and high >= route.trigger_price:
                    if self._can_open(symbol, d_idx):
                        triggered.append(route)
                    elif self._is_hunt():
                        self._trace(
                            "hunt_blocked_can_open_on_trigger",
                            date=date,
                            symbol=symbol,
                            source_event=route.source_event,
                            trigger_price=route.trigger_price,
                        )
            if triggered:
                route = sorted(triggered, key=lambda x: (x.confidence, x.trigger_price), reverse=True)[0]
                fill = max(open_price, route.trigger_price)
                if self._is_realistic():
                    event = SignalEventV2(
                        event_type=route.source_event,
                        symbol=symbol,
                        ts=date,
                        confidence=route.confidence,
                        side="long",
                        entry_plan={"style": route.entry_style},
                        invalidation={"price": route.invalidate_price},
                        exit_plan={"style": route.exit_style, "hold_days": route.max_hold_days, "take_profit_pct": route.take_profit_pct},
                    )
                    dec = self._queue_buy_next_open(
                        d_idx=d_idx,
                        symbol=symbol,
                        cash=cash,
                        sizing_price=max(close, route.trigger_price),
                        event=event,
                    )
                elif self._is_hunt():
                    event = SignalEventV2(
                        event_type=route.source_event,
                        symbol=symbol,
                        ts=date,
                        confidence=route.confidence,
                        side="long",
                        entry_plan={"style": route.entry_style},
                        invalidation={"price": route.invalidate_price},
                        exit_plan={"style": route.exit_style, "hold_days": route.max_hold_days, "take_profit_pct": route.take_profit_pct},
                    )
                    dec = self._queue_hunt(
                        d_idx=d_idx,
                        date=date,
                        symbol=symbol,
                        cash=cash,
                        target_price=fill,
                        event=event,
                    )
                else:
                    if limit_up is not None and not can_buy_strict(fill, limit_up):
                        self.pending_entries[symbol] = active_pending
                        return decisions
                    event = SignalEventV2(
                        event_type=route.source_event,
                        symbol=symbol,
                        ts=date,
                        confidence=route.confidence,
                        side="long",
                        entry_plan={"style": route.entry_style},
                        invalidation={"price": route.invalidate_price},
                        exit_plan={"style": route.exit_style, "hold_days": route.max_hold_days, "take_profit_pct": route.take_profit_pct},
                    )
                    dec = self._buy_now(date, d_idx, symbol, fill, cash, event)
                self.pending_entries.pop(symbol, None)
                return [dec] if dec is not None else []
            if active_pending:
                self.pending_entries[symbol] = active_pending
            else:
                self.pending_entries.pop(symbol, None)

        if not self._can_open(symbol, d_idx):
            if self._is_hunt() and any(e.side == "long" and e.confidence >= 0.6 for e in events):
                self._trace(
                    "hunt_blocked_can_open_on_signal",
                    date=date,
                    symbol=symbol,
                    event_types=[e.event_type for e in events if e.side == "long" and e.confidence >= 0.6],
                )
            return decisions

        tail_routes, breakout_routes = self._route_candidates(events)
        best_tail = tail_routes[0] if tail_routes else None
        best_breakout = breakout_routes[0] if breakout_routes else None

        if best_tail is not None:
            tail_score = self._route_score(best_tail)
            breakout_score = self._route_score(best_breakout) if best_breakout is not None else -1e9
            if tail_score >= breakout_score + 0.03:
                if self._is_realistic():
                    dec = self._queue_buy_next_open(
                        d_idx=d_idx,
                        symbol=symbol,
                        cash=cash,
                        sizing_price=close,
                        event=best_tail,
                    )
                    self.pending_entries.pop(symbol, None)
                    return [dec] if dec is not None else []
                if self._is_hunt():
                    dec = self._queue_hunt(
                        d_idx=d_idx,
                        date=date,
                        symbol=symbol,
                        cash=cash,
                        target_price=close,
                        event=best_tail,
                    )
                    self.pending_entries.pop(symbol, None)
                    return [dec] if dec is not None else []
                if limit_up is None or can_buy_strict(low, limit_up):
                    dec = self._buy_now(date, d_idx, symbol, low, cash, best_tail)
                    self.pending_entries.pop(symbol, None)
                    return [dec] if dec is not None else []

        if not breakout_routes:
            if best_tail is not None:
                if self._is_realistic():
                    dec = self._queue_buy_next_open(
                        d_idx=d_idx,
                        symbol=symbol,
                        cash=cash,
                        sizing_price=close,
                        event=best_tail,
                    )
                    self.pending_entries.pop(symbol, None)
                    return [dec] if dec is not None else []
                if self._is_hunt():
                    dec = self._queue_hunt(
                        d_idx=d_idx,
                        date=date,
                        symbol=symbol,
                        cash=cash,
                        target_price=close,
                        event=best_tail,
                    )
                    self.pending_entries.pop(symbol, None)
                    return [dec] if dec is not None else []
                if limit_up is None or can_buy_strict(low, limit_up):
                    dec = self._buy_now(date, d_idx, symbol, low, cash, best_tail)
                    self.pending_entries.pop(symbol, None)
                    return [dec] if dec is not None else []
            return decisions

        staged = list(self.pending_entries.get(symbol, []))
        for route in breakout_routes[:2]:
            gate = float(route.entry_plan.get("gate_price", close))
            valid_for_days = int(route.entry_plan.get("valid_for_days", 5))
            staged.append(
                PendingEntry(
                    symbol=symbol,
                    created_idx=d_idx,
                    valid_from_idx=d_idx + 1,
                    valid_until_idx=d_idx + max(1, valid_for_days),
                    trigger_price=gate,
                    source_event=route.event_type,
                    confidence=float(route.confidence),
                    invalidate_price=float(route.invalidation.get("price", close * 0.94)),
                    max_hold_days=int(route.exit_plan.get("hold_days", 5)),
                    take_profit_pct=float(route.exit_plan.get("take_profit_pct", self.default_take_profit_pct)),
                    exit_style=str(route.exit_plan.get("style", "default")),
                    entry_style="breakout",
                )
            )
        self.pending_entries[symbol] = staged
        self._dedupe_pending(symbol)
        return decisions
