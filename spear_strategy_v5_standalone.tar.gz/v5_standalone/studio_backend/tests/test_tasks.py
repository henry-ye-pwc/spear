from __future__ import annotations

from studio_backend.models import BacktestRequest, SignalScanRequest
from studio_backend.services.tasks import command_preview


def test_backtest_command_uses_current_interpreter() -> None:
    preview = command_preview(
        "backtest",
        BacktestRequest(start="2024-01-02", end="2024-01-31", pool=10, output_dir="x").model_dump(),
    )
    assert "v5/run.py" in preview
    assert "python" in preview


def test_signal_scan_command_defaults_to_dry_run_without_webhook() -> None:
    preview = command_preview(
        "signal_scan",
        SignalScanRequest(date="2026-03-06", output_dir="y").model_dump(),
    )
    assert "daily_signal_job.py" in preview
    assert "--dry-run" in preview

