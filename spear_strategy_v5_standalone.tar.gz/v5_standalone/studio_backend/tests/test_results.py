from __future__ import annotations

from pathlib import Path

from studio_backend.services.results import _guess_kind


def test_guess_kind_backtest(tmp_path: Path) -> None:
    path = tmp_path / "run_a"
    path.mkdir()
    (path / "summary.json").write_text("{}", encoding="utf-8")
    assert _guess_kind(path) == "backtest"


def test_guess_kind_signal_scan(tmp_path: Path) -> None:
    path = tmp_path / "run_b"
    path.mkdir()
    (path / "snapshot_2026-03-06.json").write_text("{}", encoding="utf-8")
    assert _guess_kind(path) == "signal_scan"

