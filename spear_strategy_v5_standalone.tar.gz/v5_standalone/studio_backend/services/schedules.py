from __future__ import annotations

from studio_backend.config import get_settings
from studio_backend.models import ScheduleConfig
from studio_backend.services.tasks import command_preview
from studio_backend.storage import read_json, write_json


def list_schedules() -> list[ScheduleConfig]:
    raw = read_json(get_settings().schedules_path, [])
    return [ScheduleConfig.model_validate(item) for item in raw]


def save_schedule(schedule: ScheduleConfig) -> ScheduleConfig:
    schedules = [x for x in list_schedules() if x.id != schedule.id]
    schedules.append(schedule)
    write_json(get_settings().schedules_path, [x.model_dump(mode="json") for x in schedules])
    return schedule


def build_cron_line(schedule: ScheduleConfig) -> str:
    payload = dict(schedule.payload)
    preview = command_preview(schedule.kind, payload)
    return f"{schedule.minute} {schedule.hour} * * {schedule.weekdays} cd {get_settings().root_dir} && {preview}"

