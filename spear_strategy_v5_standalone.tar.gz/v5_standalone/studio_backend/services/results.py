from __future__ import annotations

import json
from datetime import datetime, UTC
from pathlib import Path

from studio_backend.config import get_settings
from studio_backend.models import ResultEntry


def _guess_kind(path: Path) -> str:
    if (path / "snapshot.json").exists() or any(path.glob("snapshot_*.json")):
        return "signal_scan"
    if (path / "summary.json").exists():
        return "backtest"
    return "other"


def _updated_at(path: Path) -> datetime:
    return datetime.fromtimestamp(path.stat().st_mtime, tz=UTC)


def _read_meta(path: Path) -> dict | None:
    meta_path = path / "meta.json"
    if not meta_path.exists():
        return None
    try:
        return json.loads(meta_path.read_text(encoding="utf-8"))
    except Exception:
        return None


def _find_snapshot(path: Path) -> str | None:
    """Find snapshot.json or snapshot_*.json in a result directory."""
    direct = path / "snapshot.json"
    if direct.exists():
        return str(direct)
    candidates = sorted(path.glob("snapshot_*.json"))
    if candidates:
        return str(candidates[0])
    return None


def _entry_from_dir(path: Path, kind: str, meta: dict | None = None) -> ResultEntry:
    return ResultEntry(
        name=path.name,
        path=str(path),
        summary_path=str(path / "summary.json") if (path / "summary.json").exists() else None,
        overview_path=str(path / "results_overview.md") if (path / "results_overview.md").exists() else None,
        master_table_path=str(path / "all_trades_master_table.csv") if (path / "all_trades_master_table.csv").exists() else None,
        snapshot_path=_find_snapshot(path),
        updated_at=_updated_at(path),
        kind=kind,  # type: ignore[arg-type]
        meta=meta,
    )


def list_results() -> list[ResultEntry]:
    settings = get_settings()
    out: list[ResultEntry] = []
    seen_names: set[str] = set()

    for path in settings.backtests_dir.iterdir():
        if not path.is_dir():
            continue
        meta = _read_meta(path)
        kind = (meta.get("kind", "backtest") if meta else "backtest")
        out.append(_entry_from_dir(path, kind, meta if kind != "backtest" else None))
        seen_names.add(path.name)

    for path in settings.signals_dir.iterdir():
        if not path.is_dir():
            continue
        meta = _read_meta(path)
        if meta:
            kind = meta.get("kind", "signal_scan")
            out.append(_entry_from_dir(path, kind, meta))
            seen_names.add(path.name)
        else:
            for sub in sorted(path.iterdir(), reverse=True):
                if sub.is_dir() and _read_meta(sub):
                    m = _read_meta(sub)
                    kind = m.get("kind", "signal_scan") if m else "signal_scan"
                    out.append(_entry_from_dir(sub, kind, m))
                    seen_names.add(sub.name)
            seen_names.add(path.name)

    if settings.legacy_results_dir.exists():
        for path in settings.legacy_results_dir.iterdir():
            if not path.is_dir() or path.name in seen_names:
                continue
            kind = _guess_kind(path)
            meta = _read_meta(path) if kind == "signal_scan" else None
            out.append(_entry_from_dir(path, kind, meta))

    out.sort(key=lambda x: x.updated_at, reverse=True)
    return out


def delete_result(name: str) -> bool:
    import shutil
    path = find_result_dir(name)
    if path is None or not path.is_dir():
        return False
    shutil.rmtree(path)
    return True


def find_result_dir(name: str) -> Path | None:
    settings = get_settings()
    for base in [settings.backtests_dir, settings.signals_dir, settings.legacy_results_dir]:
        candidate = base / name
        if candidate.is_dir():
            if (candidate / "meta.json").exists() or (candidate / "summary.json").exists():
                return candidate
            for sub in sorted(candidate.iterdir(), reverse=True):
                if sub.is_dir() and (sub / "meta.json").exists():
                    return sub
            return candidate
    return None
