# Audit Report: Backtest Result Inconsistency

**Date**: 2026-03-11  
**Scope**: v5_standalone backtest results for year 2024, same pool (`code_txt_pool`), `delayed_limit_hunt` profile  
**Status**: Root causes identified, remediation pending

---

## 1. Executive Summary

Multiple backtest runs targeting the **2024 calendar year** with nominally identical configurations produced significantly different results (equity return ranging from **34.4% to 69.9%**). Investigation reveals **three independent root causes**, the most severe being a **data integrity issue** where 81.4% of cached price data remains in raw (unadjusted) format while 18.6% has been forward-adjusted (QFQ/前复权), creating a **mixed-adjustment dataset** fed to both signal detection and trade execution.

---

## 2. Affected Runs

All runs use pool `code_txt_pool` with `execution_profile: delayed_limit_hunt`.

| Run ID | Date | Return | Trades | Events | Key Config Diff |
|--------|------|--------|--------|--------|-----------------|
| `20260309_..._dlh` | Mar 9 | 39.59% | 530 | 2324 | baseline (no warmup, no exit_mode) |
| `..._6080b5` | Mar 10 | 57.47% | 565 | 2324 | same config as above |
| `..._c6854f` | Mar 10 | 62.68% | 516 | 2411 | `warmup_bars: 600` added |
| `..._6b1f13` | Mar 10 | 69.93% | 493 | 2330 | `warmup_bars: 600` (same) |
| `..._9a3daf` | Mar 11 | 34.44% | 465 | 2303 | + `exit_mode: ideal`, `disable_env: true`, `base_pos_pct: 0.25` |
| `..._29c6ad` | Mar 11 | 34.44% | 465 | 2303 | same as above, pool_size 576 (=full) |

### Key Observations

- **Identical config, different results**: Run `0309` and `6080b5` share the same config and produce the same 2324 events, but differ in trades (530 vs 565) and return (39.59% vs 57.47%). This proves **execution logic changed between runs**.
- **Same-day, same warmup, different events**: `c6854f` (2411 events) vs `6b1f13` (2330 events) both ran on Mar 10 with `warmup_bars: 600`. Different event counts prove **data or signal logic changed between these runs**.
- **9a3daf == 29c6ad**: Both produce identical results despite pool_size difference (300 vs 576 with `head` sampling), confirming pool resolution is correct.

---

## 3. Root Cause Analysis

### 3.1 [CRITICAL] PKL Cache Data Integrity — Mixed Raw/QFQ Prices

**Impact**: ALL features, signals, and trade prices affected  
**Severity**: Critical  
**Introduced**: Commit `5ad3311` (2026-03-10 15:06)

#### Background

Commit `5ad3311` introduced a custom forward-adjustment (`_apply_qfq`) function in `cq_backtest/data/feed.py`. Before this commit, `_fetch_full_history()` returned **raw unadjusted** bars from 通达信. After the commit, it returns **QFQ-adjusted** bars.

#### The Problem

The PKL cache layer (`cache/{code}_full.pkl`) is **time-stamped but not version-tagged**. Cache files created before QFQ was introduced contain raw prices. Cache files created after contain adjusted prices. The cache hit logic for historical backtests (`end_date=2024-12-31`) always returns cached data without re-fetching because `_cache_exactly_covers_end_date()` returns True (cache extends to 2026).

#### Evidence: Cache File Timeline

```
Modification Hour          | Files | Data Type
---------------------------|-------|-----------
2026-03-10 14:00           | 482   | RAW (unadjusted)
2026-03-10 23:00           | 196   | QFQ (adjusted)
2026-03-11 01:00           | 394   | QFQ (adjusted)
2026-03-11 02:00           | 363   | QFQ (adjusted)
2026-03-11 08:00–10:00     | 244   | QFQ (adjusted)
```

**Total**: 482 raw + 1197 QFQ = 1679 cached stocks.

#### Evidence: Pool Composition

For `code_txt_pool` (592 symbols, `head` sampling to 300):

```
Subset        | RAW cache | QFQ cache | No cache
--------------|-----------|-----------|----------
Full pool     | 482       | 110       | 0
Head 300      | 252       | 48        | 0
```

**84% of the actively-used pool has raw prices; 16% has QFQ-adjusted prices.**

#### Evidence: Price Comparison

**Pre-QFQ cache sample** (000010, modified 03-10 14:29):
```
date                  open    close   high    low
2005-09-01 15:00:00   0.7925  0.830   0.8375  0.7800   ← round numbers = RAW
2024-01-02 15:00:00   3.18    3.23    3.24    3.17     ← round numbers = RAW
```

**Post-QFQ cache sample** (000001, modified 03-11 08:40):
```
date                  open       close      high       low
2012-12-27 15:00:00   4.151543   4.164996   4.186520   4.108494  ← fractional = QFQ
```

#### Why Incremental Refresh Doesn't Fix This

The `get_kline()` incremental path (`_fetch_latest_bars` + `adj_break` detection) only runs when the cache **doesn't cover** the end date. For `end_date=2024-12-31`, the cache always covers, so incremental refresh **never triggers** for historical backtests.

For signal scans (`end_date=today`), the incremental path does run, but the `adj_break` threshold (`max_dev > 0.005`) may not trigger for stocks without recent dividends, resulting in **mixed raw+QFQ data within a single pkl file**.

#### QFQ Algorithm Reference

The `_apply_qfq` function in `feed.py` (lines 13–55):
- Fetches XDXR (除权除息) records via `client.xdxr(symbol=code)`
- Filters for `category==1` events only
- Computes cumulative adjustment factor: `adj = (preclose_shift / close).cumprod(reverse)`
- Multiplies OHLC by `adj`

This is a standard preclose-based forward-adjustment, matching 通达信's internal algorithm.

---

### 3.2 [HIGH] Execution State Machine Logic Changes

**Impact**: Trade counts, position sizing, fill prices  
**Severity**: High  
**Introduced**: Commit `7c60b99` (2026-03-11 09:30) + working copy

#### Changes in `v4/execution/state_machine.py`

| Change | Before | After | Impact |
|--------|--------|-------|--------|
| `_try_hunt_fill` qty | Fixed from `PendingHunt.qty` | Recalculated: `int(cash * base_pos_pct * mult // fill_price)` | Different position sizes per trade |
| `_try_hunt_fill` max_positions | Not checked | `_can_open()` enforced | Some hunts now blocked |
| `_try_hunt_fill` budget check | None | `qty <= 0` → skip | Hunts skipped when cash low |
| `_is_realistic()` | Only `next_open_realistic` | Also `exit_mode in ("next_open", "hunt_exit")` | More profiles trigger realistic fills |
| `PendingSellHunt` | Not existed | New sell-side limit hunt mechanism | New exit logic path |
| `exit_mode: ideal` | Not existed | Added | Different take-profit/stop-loss execution |

#### Evidence

Runs `0309` (39.59%) and `6080b5` (57.47%) share identical config and event count (2324), proving the signals are the same. The trade count difference (530 vs 565) and return difference (+17.88 pp) are entirely due to execution logic changes between the two runs.

---

### 3.3 [MEDIUM] Configuration Parameter Evolution

Some runs that appear to have the "same config" actually have different parameters added over time:

| Parameter | First appeared | Default before | Effect |
|-----------|---------------|----------------|--------|
| `warmup_bars` | Mar 10 | None (0) | More data for feature computation → different signals |
| `base_pos_pct` | Mar 11 | 1.0 (full allocation) | Smaller positions → less concentrated |
| `exit_mode` | Mar 11 | `"ideal"` (instant) | Changed fill timing |
| `disable_env_mapping` | Mar 11 | `False` | Removes sector/industry gating → fewer signals |

---

### 3.4 [LOW] Numba Feature Computation Precision

**Impact**: Marginal feature value differences at window boundaries  
**Severity**: Low  
**Introduced**: Commit `5ad3311` (feature_primitives.py) + working copy (sequence.py, structure.py)

#### Changes

- `rolling_rank_pct`: Numba kernel counts `arr[j] <= val` in a loop vs pandas `rolling().apply()`. Semantically equivalent but may differ at exact-equality boundaries due to floating-point ordering.
- `rolling_mad`: Numba NaN handling is strict (`has_nan → skip`) vs pandas `np.median` which propagates NaN automatically. For windows with NaN, Numba returns NaN (same), but the edge behavior at `min_periods` boundary may differ by 1 position.
- `_sequence_kernel` / `_structure_kernel`: Numba versions are algebraically equivalent to the original Python loops. The original implementations are preserved as `_add_sequence_features_original` and `_add_structure_features_original` for rollback.

#### Verification Status

The Numba kernels were verified against the original implementations during development. Small differences (< 1e-10) may exist due to floating-point operation ordering but are not expected to cause signal flips in practice.

---

### 3.5 [LOW] Phase C Skip Optimization

**Impact**: Potential signal omission if logic is incorrect  
**Severity**: Low (verified equivalent)  
**Introduced**: Working copy (uncommitted)

The Phase C second-pass `detect_signals` loop was optimized to skip (symbol, date) pairs that:
1. Had no Phase B signals (raw_events empty), AND
2. Belong to an inactive (date, theme) combination (peer=0, leader=0, sector_hot=False)

This was verified by tracing all 8 detect functions under these conditions and confirming they would return `None`. The `flat_events` list is sorted by `(date, symbol)` at the end to restore chronological order.

---

## 4. Commit Timeline

```
Hash     Date              Description                                      Key Changes
──────── ───────────────── ──────────────────────────────────────────────── ──────────────────────────
49f1bd4  2026-03-03 13:37  Initial commit                                   cq_backtest baseline
06499ca  2026-03-03 13:47  Clean up references                              Comment cleanup
e93a600  2026-03-03 14:05  Unify cache dir                                  ./cache standardized
18760ce  2026-03-05 02:03  v3 init                                          v3 module
e0711aa  2026-03-07 23:22  v4 baseline                                      v4 engine, state machine
a870734  2026-03-07 23:46  v4 book consistency                              Refactored fills
2c4e0aa  2026-03-08 01:07  v4 relaxed routing                               Position sizing
09e0e96  2026-03-09 09:42  v5-standalone                                    v5 stack, studio skeleton
5ad3311  2026-03-10 15:06  QFQ fix, Numba, unified mootdx                   ⚠️ QFQ introduced in feed.py
7c60b99  2026-03-11 09:30  Signal scan improvements, YTD                    ⚠️ State machine reworked
(wc)     2026-03-11        Uncommitted: Numba features, Phase C opt         ⚠️ sequence.py, structure.py, prepare.py
```

---

## 5. Remediation Plan

### 5.1 Immediate: Rebuild Cache (P0)

```bash
# Option A: Delete and let next run rebuild with QFQ
rm -rf cache/

# Option B: Force-refresh all stocks
# (requires code change to iterate pool and call get_kline with force_refresh=True)
```

After cache rebuild, re-run the 2024 baseline backtest with a fixed config to establish a clean benchmark.

### 5.2 Short-term: Add Cache Versioning (P1)

Add a version tag to PKL cache files to detect and invalidate stale data:

```python
# Proposed: include a cache_version in the pkl metadata
CACHE_VERSION = 2  # Bump when QFQ algorithm or data schema changes

def _is_cache_valid(cache_file):
    meta = read_cache_meta(cache_file)
    return meta.get('cache_version') == CACHE_VERSION
```

### 5.3 Medium-term: Reproducibility Infrastructure (P2)

1. **Config hash in output dir name** — deterministic hash of all config parameters
2. **Data snapshot hash** — hash of input data to detect data drift
3. **Code version tag** — record git commit hash in `meta.json`
4. **Regression test** — fixed pool + fixed data snapshot → expected result range

### 5.4 Long-term: Frozen Data Mode (P3)

For reproducible backtests, support a mode where all price data is read from a frozen parquet/csv snapshot rather than live-fetched PKL cache. This eliminates all data drift.

---

## 6. Files Involved

| File | Role in Issue |
|------|---------------|
| `cq_backtest/data/feed.py` | QFQ implementation, PKL cache logic, incremental append |
| `v4/execution/state_machine.py` | Execution logic changes (hunt fill, sell hunt, exit mode) |
| `v4/features/sequence.py` | Numba optimization (uncommitted) |
| `v4/features/structure.py` | Numba optimization (uncommitted) |
| `v5/backtest/prepare.py` | Phase A+B merge, Phase C skip optimization (uncommitted) |
| `v5/backtest/runner.py` | `_build_open_positions` reworked, `_enrich_limit_prices` added |
| `v5/backtest/strategy_host.py` | New exit_mode params passed to state machine |
| `v5/config/defaults.py` | New config fields (exit_mode, exit_hunt params) |
| `cq_backtest/shared/feature_primitives.py` | Numba rolling_rank_pct, rolling_mad |

---

## 7. How to Verify

### Verify QFQ cache state for a given stock

```python
import pandas as pd, os, datetime

def check_cache_state(code):
    path = f'cache/{code}_full.pkl'
    df = pd.read_pickle(path)
    mt = datetime.datetime.fromtimestamp(os.path.getmtime(path))
    is_qfq = not (df['close'].iloc[0] == round(df['close'].iloc[0], 2))
    print(f'{code}: modified={mt}, bars={len(df)}, likely_{"QFQ" if is_qfq else "RAW"}')
    print(f'  first close: {df["close"].iloc[0]:.6f}')
    print(f'  last close:  {df["close"].iloc[-1]:.6f}')
```

### Verify execution logic equivalence

Run a fixed-config backtest twice with the same code version and compare:
- `summary.json` (equity_return_pct, trade_count, event_count)
- `events.csv` row count
- `trades.csv` row count and total PnL

If these match exactly, the system is deterministic for the given code+data snapshot.

---

## 8. Conclusion

The primary cause of backtest inconsistency is **not a logic bug** but a **data integrity issue** caused by the introduction of QFQ forward-adjustment without invalidating the existing PKL cache. 81.4% of cached stock data remains in raw format while 18.6% has been adjusted, creating a fundamentally inconsistent dataset. Secondary causes include execution logic evolution (state machine changes) and configuration parameter additions.

**The fix is straightforward**: delete the cache directory and rebuild. All subsequent runs will use consistently QFQ-adjusted data. For long-term reproducibility, cache versioning and frozen data snapshots should be implemented.
