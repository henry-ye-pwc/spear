# Codemap: spear-strategy v5_standalone

**Last updated**: 2026-03-11  
**Git HEAD**: `7c60b99` (+ uncommitted working copy changes)  
**Purpose**: Authoritative reference for the repository structure, data flow, and component responsibilities.

---

## 1. Repository Overview

```
v5_standalone/                 ← Project root (CWD for all commands)
├── cq_backtest/               ← Core data layer: mootdx feed, market rules, feature primitives
├── v4/                        ← Signal detection models, features, execution state machine
├── v5/                        ← Orchestration: backtest runner, signal scan, data routing, config
├── studio_backend/            ← FastAPI REST API for the Studio UI
├── studio_frontend/           ← React + Vite frontend
├── docs/                      ← Documentation (this file, audit reports)
├── pools/                     ← User-created named pool files (.txt + .json)
├── cache/                     ← PKL cache for daily K-line data (git-ignored)
├── outputs/                   ← Backtest and signal scan results (git-ignored)
│   ├── backtests/             ← One dir per backtest run
│   ├── signals/               ← One dir per signal scan run
│   └── state/                 ← Persistent watch state for signal tracking
├── code.txt                   ← Built-in pool: XML stock list for code_txt_pool
├── requirements.txt           ← Python dependencies
├── start_studio_backend.py    ← Uvicorn entry point (port 8000)
└── .gitignore
```

---

## 2. Architecture & Data Flow

### 2.1 Backtest Pipeline

```
User Config (V5Config)
    │
    ▼
prepare_bundle()                    [v5/backtest/prepare.py]
    │
    ├── Phase A+B (parallel):       ProcessPoolExecutor
    │   ├── V5DataRouter            [v5/data/router.py]
    │   │   └── MootdxProvider      [v5/data/providers/mootdx_provider.py]
    │   │       └── DataFeed        [cq_backtest/data/feed.py]
    │   │           ├── PKL cache   [cache/{code}_full.pkl]
    │   │           ├── _apply_qfq  (forward adjustment)
    │   │           └── 通达信 TCP   (mootdx.Quotes)
    │   ├── preprocess_daily()      [v4/data/adapter.py]
    │   ├── add_robust_volume()     [v4/features/robust.py]
    │   ├── add_sequence_features() [v4/features/sequence.py]    ← Numba JIT
    │   ├── add_structure_features()[v4/features/structure.py]   ← Numba JIT
    │   └── count_signals()         [v4/models/registry.py]      (lightweight first-pass)
    │
    ├── Phase C (sequential):       enriched second-pass
    │   ├── V5EnvironmentProvider   [v5/environment/provider.py]
    │   ├── detect_signals()        [v4/models/registry.py]
    │   │   ├── detect_escape       [v4/models/escape.py]
    │   │   ├── detect_post_limit   [v4/models/post_limit.py]
    │   │   ├── detect_failed_board [v4/models/failed_board.py]
    │   │   ├── detect_trend_spear  [v4/models/trend_spear.py]
    │   │   ├── detect_attack       [v4/models/attack.py]
    │   │   ├── detect_arb          [v4/models/arb.py]
    │   │   ├── detect_youzi        [v4/models/youzi.py]
    │   │   └── detect_sector_spear [v4/models/sector_spear.py]
    │   └── themed_env_ok()         [v4/models/helpers.py]       (environment gating)
    │
    └── PreparedBundle              (raw_data, feature_data, events, env)
            │
            ▼
run_backtest()                      [v5/backtest/runner.py]
    ├── AKQuantSpearStrategy        [v5/backtest/strategy_host.py]
    │   └── V4ExecutionStateMachine  [v4/execution/state_machine.py]
    │       ├── PendingEntry / PendingFill / PendingHunt
    │       ├── PendingSellHunt
    │       └── Decision (buy/sell)
    ├── akquant.run_backtest()       (external engine)
    └── write_reports()              [v5/reports/writer.py]
            │
            ▼
        outputs/backtests/{run_id}/
            ├── meta.json
            ├── summary.json
            ├── events.csv
            ├── trades.csv
            ├── closed_trades.csv
            ├── open_positions.csv
            └── equity_curve.csv
```

### 2.2 Signal Scan Pipeline

```
daily_signal_job.py                 [v5/daily_signal_job.py]
    │
    ├── resolve_named_pool()         [v5/config/pools.py]
    ├── prepare_bundle()             (same as backtest)
    ├── run_backtest()               (mini-backtest for trade simulation)
    ├── NotificationSnapshot         [v5/notify/scanner.py]
    │   └── enrich_snapshot_with_trades()
    ├── save_watch_state()           [v5/notify/state.py]
    ├── send_feishu_webhook()        [v5/notify/feishu.py]
    └── write outputs
            │
            ▼
        outputs/signals/{run_id}/
            ├── meta.json
            ├── events.csv
            ├── trades.csv
            ├── equity_curve.csv
            └── watch_state.json
```

### 2.3 Studio UI

```
studio_frontend/  ←────── HTTP ──────→  studio_backend/
    │                                        │
    ├── Dashboard.tsx                        ├── GET  /api/health
    ├── BacktestLauncher.tsx                 ├── POST /api/backtest/launch
    ├── SignalScanner.tsx                    ├── POST /api/signal/scan
    ├── ResultsExplorer.tsx                  ├── GET  /api/results
    │   ├── ConfigBanner                     ├── GET  /api/results/{type}/{id}/*
    │   ├── EquityChart                      ├── GET  /api/tasks
    │   ├── TradesTable                      ├── GET  /api/pools
    │   └── OverviewPanel                    ├── POST /api/pools
    └── hooks/useTaskPoller.ts               └── GET  /api/data/latest-bar
```

---

## 3. Module Reference

### 3.1 `cq_backtest/` — Core Data & Primitives

The foundational data layer. All other modules depend on this.

| File | Purpose | Key Exports |
|------|---------|-------------|
| `data/feed.py` | Mootdx K-line data feed with PKL cache and QFQ adjustment | `DataFeed`, `_apply_qfq` |
| `shared/feature_primitives.py` | Numba-accelerated rolling computations | `rolling_rank_pct`, `rolling_mad`, `anchored_vwap` |
| `shared/signal_schema.py` | Signal event data model | `SignalEventV2` |
| `shared/market_rules.py` | Tick rounding, board type inference, limit_pct | `round_tick`, `infer_board`, `limit_pct_for_board` |
| `shared/calendar.py` | Trading calendar helpers | `next_trade_day`, `to_trade_ts` |
| `shared/types.py` | Core data types | `Bar`, `Event`, `Signal` |
| `shared/utils.py` | Utility functions | `rolling_zscore`, `ensure_dir`, `stable_hash` |
| `engine/backtester.py` | Legacy event-driven backtester (v1/v2 era) | `Backtester` |
| `engine/portfolio.py` | Legacy portfolio management | `Portfolio`, `Trade`, `RiskProfile` |
| `strategy/indicators.py` | Spear pattern detection (legacy) | `detect_spear`, `classify_position` |
| `strategy/signals.py` | Legacy signal detection | `detect_escape`, `detect_all` |
| `config.py` | Legacy strategy config | `StrategyConfig` |
| `counterfactual/` | Counterfactual exit analysis | `CounterfactualEngine`, `CounterfactualRunner` |
| `v1/` | Frozen copy of v1 cq_backtest (for backwards compatibility) | — |

### 3.2 `v4/` — Models, Features & Execution

The signal detection and trade execution layer.

| File | Purpose | Key Exports |
|------|---------|-------------|
| **config/** | | |
| `defaults.py` | V4 configuration defaults | `V4Config`, `load_v4_default_config` |
| **data/** | | |
| `adapter.py` | Preprocesses raw daily bars into feature-ready DataFrames | `preprocess_daily` |
| **features/** | | |
| `sequence.py` | Spear sequence features (Numba-optimized) | `add_sequence_features`, `_sequence_kernel` |
| `structure.py` | Market structure features (Numba-optimized) | `add_structure_features`, `_structure_kernel` |
| `robust.py` | Robust volume features | `add_robust_volume_features` |
| **models/** | | |
| `registry.py` | Model dispatcher — runs all 8 detectors | `detect_signals`, `count_signals`, `SignalCount` |
| `helpers.py` | Shared model utilities | `is_spear`, `themed_env_ok`, `trend_city_gate` |
| `escape.py` | Escape pattern detector | `detect_escape` |
| `post_limit.py` | Post-limit-up continuation | `detect_post_limit` |
| `failed_board.py` | Failed board (炸板) recovery | `detect_failed_board` |
| `trend_spear.py` | Trend spear (趋势长枪) | `detect_trend_spear` |
| `attack.py` | Attack pattern | `detect_attack` |
| `arb.py` | Arbitrage/rebound pattern | `detect_arb` |
| `youzi.py` | Youzi (游资) pattern | `detect_youzi` |
| `sector_spear.py` | Sector-driven spear | `detect_sector_spear` |
| **execution/** | | |
| `state_machine.py` | Order/position lifecycle state machine | `V4ExecutionStateMachine`, `Decision`, `PositionState`, `PendingHunt`, `PendingSellHunt` |
| **reports/** | | |
| `analytics.py` | Closed trade analysis, event summaries, diagnostics | `build_closed_trades`, `build_event_summary` |
| `writer.py` | CSV/JSON report writer | `write_reports` |
| `overview.py` | Markdown overview generator | `write_overview` |
| **environment/** | | |
| `provider.py` | Environment context (sector, theme, meta) | `EnvironmentProvider`, `infer_name_theme` |
| **tests/** | | |
| `test_models.py`, `test_execution.py`, etc. | Unit tests | — |

### 3.3 `v5/` — Orchestration & Configuration

The top-level orchestration layer that ties everything together.

| File | Purpose | Key Exports |
|------|---------|-------------|
| **config/** | | |
| `defaults.py` | Master config: `V5Config` with sub-configs | `V5Config`, `DataConfig`, `FeatureConfig`, `ModelConfig`, `ExecutionConfig`, `BacktestConfig`, `apply_execution_profile` |
| `pools.py` | Named pool management (built-in + custom) | `resolve_named_pool`, `list_named_pools`, `save_custom_pool`, `NamedPool` |
| **data/** | | |
| `router.py` | Multi-provider data routing (AKShare, Mootdx, LocalParquet) | `V5DataRouter` |
| `providers/mootdx_provider.py` | Mootdx adapter implementing provider interface | `MootdxProvider` |
| `providers/akshare_provider.py` | AKShare adapter | `AKShareProvider` |
| `providers/local_parquet_provider.py` | Local parquet file adapter | `LocalParquetProvider` |
| `providers/base.py` | Provider interface definition | `BaseProvider` |
| `intraday.py` | Intraday minute-bar handling and synthetic bar generation | `build_synthetic_daily_bar` |
| `prefetch.py` | Parallel data prefetch for entire pool | `prefetch_symbols` |
| `fetch_sectors.py` | Sector/industry data fetch | `fetch_sector_data` |
| **backtest/** | | |
| `prepare.py` | `prepare_bundle`: parallel data loading + features + 3-phase signal detection | `PreparedBundle`, `prepare_bundle` |
| `runner.py` | AKQuant backtest runner, trade enrichment | `run_backtest`, `V5RunArtifacts` |
| `strategy_host.py` | AKQuant strategy adapter wrapping V4ExecutionStateMachine | `AKQuantSpearStrategy`, `SubmittedOrderMeta` |
| **environment/** | | |
| `provider.py` | V5-specific environment provider with sector cache | `V5EnvironmentProvider` |
| **notify/** | | |
| `scanner.py` | Post-scan notification snapshot builder | `NotificationSnapshot`, `enrich_snapshot_with_trades` |
| `feishu.py` | Feishu webhook integration | `send_feishu_webhook` |
| `models.py` | Notification data models | `SignalSnapshot`, `WatchItem`, `ClosedTrade` |
| `state.py` | Watch state persistence | `make_watch_key`, `save_watch_state`, `load_watch_state` |
| `templates.py` | Feishu message templates | `build_feishu_post_payload`, `render_markdown_summary` |
| `audit.py` | Audit log append | `append_audit` |
| **reports/** | | |
| `writer.py` | V5 report writer (meta.json, summary.json, CSVs) | `write_reports` |
| **Entry points** | | |
| `run.py` | CLI: `python -m v5.run --start 2024-01-02 --end 2024-12-30 --profile dlh` | — |
| `daily_signal_job.py` | CLI: `python -m v5.daily_signal_job --pool code_txt_pool --mode confirm` | — |
| `prefetch_snapshot.py` | CLI: prefetch data snapshot for a pool | — |

### 3.4 `studio_backend/` — FastAPI REST API

| File | Purpose | Key Exports |
|------|---------|-------------|
| `main.py` | FastAPI app with all routes (~1200 lines) | `app` |
| `config.py` | Settings: paths, directories | `StudioSettings`, `get_settings`, `ROOT` |
| `models.py` | Pydantic request/response models | `BacktestRequest`, `SignalScanRequest`, `TaskRecord` |
| `storage.py` | JSON file read/write helpers | `read_json`, `write_json` |
| `services/tasks.py` | Background task management (subprocess-based) | `create_task`, `run_task`, `list_tasks`, `cancel_task` |
| `services/results.py` | Result directory listing and lookup | `list_results`, `find_result_dir`, `delete_result` |
| `services/schedules.py` | Cron schedule management | `list_schedules`, `save_schedule` |

#### Key API Endpoints

| Method | Path | Purpose |
|--------|------|---------|
| GET | `/api/health` | Health check + system info |
| POST | `/api/backtest/launch` | Launch backtest as background task |
| POST | `/api/signal/scan` | Launch signal scan as background task |
| GET | `/api/results` | List all backtest + signal results |
| GET | `/api/results/{type}/{id}/meta` | Get result metadata |
| GET | `/api/results/{type}/{id}/events` | Get events CSV as JSON |
| GET | `/api/results/{type}/{id}/trades` | Get trades CSV as JSON |
| GET | `/api/results/{type}/{id}/equity` | Get equity curve |
| GET | `/api/tasks` | List all tasks with status |
| DELETE | `/api/tasks/{id}` | Cancel/delete a task |
| GET | `/api/pools` | List named pools |
| POST | `/api/pools` | Create/update custom pool |
| GET | `/api/data/latest-bar` | Data freshness probe |

### 3.5 `studio_frontend/src/` — React UI

| File | Purpose |
|------|---------|
| `App.tsx` | React Router setup, 4 routes |
| `main.tsx` | React DOM entry point |
| `index.css` | Global styles (Tailwind-based) |
| `lib/api.ts` | API client with TypeScript types for all endpoints |
| `lib/utils.ts` | `cn()` classname helper, formatters |
| `hooks/useApi.ts` | Generic data-fetching hook |
| `hooks/useTaskPoller.ts` | Polls task status until completion |
| **pages/** | |
| `Dashboard.tsx` | Overview: recent tasks, data health, quick actions |
| `BacktestLauncher.tsx` | Config form: dates, pool, profile, params → launch |
| `SignalScanner.tsx` | Signal scan form: pool, mode (preview/confirm), flags |
| `ResultsExplorer.tsx` | Browse results, detail panel with ConfigBanner, EquityChart, TradesTable |
| **components/** | |
| `Layout.tsx` | App shell: sidebar navigation |
| `EquityChart.tsx` | Recharts line chart for equity curve |
| `TradesTable.tsx` | Sortable, paginated trades table with limit-price highlighting |
| `OverviewPanel.tsx` | Summary stats display (return, trades, win rate) |
| `TaskLogPanel.tsx` | Real-time task log viewer |
| `Pagination.tsx` | Pagination component |
| `ProfileBadge.tsx` | Execution profile badge (DLI/DLH/NOR) |
| `SignalCard.tsx` | Signal event card |
| `WatchStateTable.tsx` | Watch state tracking table |
| `SavePoolDialog.tsx` | Dialog for saving custom pools |

---

## 4. Configuration System

### 4.1 V5Config Hierarchy

```
V5Config
├── data: DataConfig
│   ├── cache_dir             "./v5/cache/akshare"
│   ├── universe_provider     "mootdx"
│   ├── bar_provider          "mootdx"          ← primary data source
│   ├── mootdx_cache_dir      "./cache"          ← PKL cache location
│   ├── adjust                "qfq"              ← forward adjustment
│   ├── warmup_bars           600                ← extra bars before start date
│   ├── pool_sampling         "head"             ← how to sample pool
│   ├── pool_seed             42
│   ├── disable_env_mapping   False              ← skip sector/industry gating
│   └── sector_cache_path     "./v5/data/static/stock_sectors_cache.csv"
│
├── features: FeatureConfig
│   ├── vol_window            60
│   ├── peak_window           120
│   ├── drawdown_min          0.15
│   ├── peak_touch_eps        0.03
│   ├── consolidation_window  30
│   └── sequence_window       10
│
├── models: ModelConfig
│   ├── post_limit_lookback   8
│   ├── trend_multi_spear_days 5
│   ├── attack_limit_lookback 10
│   └── arb_limit_lookback    7
│
├── execution: ExecutionConfig
│   ├── execution_profile     "day_level_ideal"  ← DLI / DLH / NOR
│   ├── execution_mode        "CurrentClose"     ← derived from profile
│   ├── exit_mode             "ideal"            ← ideal / next_open / hunt_exit
│   ├── max_positions         4
│   ├── base_pos_pct          0.25               ← % of cash per position
│   ├── hunt_price_buffer_pct 0.005
│   ├── hunt_window_days      3
│   ├── cooldown_days         3
│   ├── default_take_profit   0.18
│   ├── *_pos_mult            per-model position multipliers
│   └── slippage/commission   buy/sell slippage, commission, stamp duty
│
└── backtest: BacktestConfig
    ├── start / end           date range
    ├── pool_size             300
    ├── initial_cash          1,000,000
    └── output_dir
```

### 4.2 Execution Profiles

| Profile | Code | Entry | Exit | Use Case |
|---------|------|-------|------|----------|
| Day-Level Ideal | `dli` / `day_level_ideal` | Fill at signal-day price | Instant at target | Theoretical ceiling |
| Next-Open Realistic | `nor` / `next_open_realistic` | Fill at next open | Queued sell at next open | Conservative estimate |
| Delayed Limit Hunt | `dlh` / `delayed_limit_hunt` | Limit order near signal price, window=3 days | Per `exit_mode` | Most realistic |

### 4.3 Named Pools

Built-in:
- `code_txt_pool`: Parsed from `code.txt` (592 symbols, XML format)

Custom (in `pools/`):
- `50-150cyc`: 832 symbols from `50-150cyc.txt`
- Custom pools are defined by `{name}.txt` (symbols) + `{name}.json` (metadata)

---

## 5. Signal Detection Models

All models live in `v4/models/` and follow the same interface:

```python
def detect_xxx(frame: pd.DataFrame, symbol: str, *, env: dict | None = None, ...) -> SignalEventV2 | None
```

| Model | Event Type | Environment Gated | Description |
|-------|-----------|-------------------|-------------|
| `escape` | `escape` | No | Breakout from consolidation range |
| `post_limit` | `post_limit` | Yes (`_enforce_env`) | Continuation after limit-up |
| `failed_board` | `failed_board` | Yes (`_enforce_env`) | Recovery after failed limit-up (炸板) |
| `trend_spear` | `trend_spear` | Partial (`allow_neutral`) | Spear pattern in uptrend |
| `attack` | `attack` | Yes (`_enforce_env`) | Aggressive breakout attack |
| `arb` | `arb` | Partial (`allow_neutral`) | Rebound/arbitrage opportunity |
| `youzi` | `youzi` | Yes (`_enforce_env`) | Hot-money (游资) driven |
| `sector_spear` | `sector_spear` | Yes (strict) | Sector-rotation driven spear |

**Environment context** (`env` dict):
- `peer_confirmation`: count of same-theme signals on same day
- `leader_strength`: max confidence among same-theme signals
- `sector_hot`: boolean from sector rotation data
- `lhb_net_sell`: boolean from 龙虎榜 data
- `_enforce_env`: master gate (set by `themed_env_ok()`)

---

## 6. Data Flow: PKL Cache System

```
通达信 TCP Server
    │
    ▼
DataFeed._fetch_raw_bars()     ← raw unadjusted OHLCV
    │
    ▼
DataFeed._fetch_xdxr()         ← XDXR 除权除息 records
    │
    ▼
_apply_qfq()                   ← forward adjustment (QFQ/前复权)
    │
    ▼
cache/{code}_full.pkl          ← persisted to disk
    │
    ▼
DataFeed.get_kline()           ← cache hit / miss logic
    │
    ├── Memory cache (TTL: 4h)
    ├── Disk cache (exact cover → return)
    ├── Stable historical (> 7 days ago → return cached)
    ├── Incremental append (_fetch_latest_bars + adj_break check)
    └── Full refresh (fallback)
```

**Known issue (2026-03)**: Cache files created before QFQ implementation contain raw prices. See `docs/AUDIT_backtest_inconsistency_2026-03.md`.

---

## 7. Output Directory Structure

### Backtests

```
outputs/backtests/{YYYYMMDD}_{start}-{end}_{pool}_{profile}_{hash}/
├── meta.json          ← full run config, timestamps
├── summary.json       ← equity return, trade counts, fees
├── events.csv         ← all detected signal events
├── trades.csv         ← all executed trades (buy/sell)
├── closed_trades.csv  ← round-trip trades with PnL
├── open_positions.csv ← positions still open at end
├── equity_curve.csv   ← daily equity values
├── event_summary.csv  ← event type breakdown
├── exit_summary.csv   ← exit reason breakdown
└── results_overview.md ← human-readable summary
```

### Signal Scans

```
outputs/signals/{YYYYMMDD}_{mode}_{pool}_{profile}_{hash}/
├── meta.json          ← scan config, effective_date, signal counts
├── events.csv         ← detected signals for target date(s)
├── trades.csv         ← mini-backtest trades
├── equity_curve.csv   ← mini-backtest equity
└── watch_state.json   ← tracked signal state for notifications
```

---

## 8. Key Dependencies

| Package | Version | Purpose |
|---------|---------|---------|
| `mootdx` | latest | 通达信 data source (TCP protocol) |
| `pandas` | >= 2.0 | DataFrames, time series |
| `numpy` | >= 1.24 | Numerical computation |
| `numba` | >= 0.59 | JIT compilation for feature kernels |
| `fastapi` | >= 0.100 | REST API framework |
| `uvicorn` | >= 0.22 | ASGI server |
| `akquant` | custom | External backtest engine (optional) |
| `akshare` | latest | Alternative data source |
| `requests` | latest | HTTP client (Feishu webhook) |

Frontend:
- React 19, Vite, TypeScript, Tailwind CSS, Recharts, shadcn/ui components

---

## 9. Entry Points & Commands

### Backtest (CLI)

```bash
cd v5_standalone
python -m v5.run \
  --start 2024-01-02 --end 2024-12-30 \
  --pool code_txt_pool --pool-size 300 \
  --profile dlh \
  --output-dir ./outputs/backtests/my_run
```

### Signal Scan (CLI)

```bash
python -m v5.daily_signal_job \
  --pool code_txt_pool \
  --mode confirm \
  --profile dlh \
  --ytd \
  --disable-env-mapping
```

### Studio Backend

```bash
python start_studio_backend.py
# → http://localhost:8000
# → API docs: http://localhost:8000/docs
```

### Studio Frontend

```bash
cd studio_frontend
npm install
npm run dev
# → http://localhost:5173
```

---

## 10. Known Issues & Technical Debt

| ID | Severity | Description | Status |
|----|----------|-------------|--------|
| DATA-001 | Critical | PKL cache mixed raw/QFQ data (see Audit) | Remediation pending |
| PERF-001 | Medium | Phase C `detect_signals` still sequential | Optimized with skip logic |
| PERF-002 | Low | `cq_backtest/v1/` is a full frozen copy, adds clutter | Could be removed |
| ARCH-001 | Low | `cq_backtest/strategy/` overlaps with `v4/models/` | Legacy, not actively used |
| TEST-001 | Medium | No integration test for end-to-end reproducibility | Planned |

---

## 11. Glossary

| Term | Meaning |
|------|---------|
| QFQ (前复权) | Forward-adjusted prices — historical OHLC retroactively adjusted for dividends/splits |
| DLH | Delayed Limit Hunt — execution profile using limit orders near signal price |
| DLI | Day-Level Ideal — instant fill at signal-day price (theoretical) |
| NOR | Next-Open Realistic — fill at next trading day's open price |
| 长枪 (Spear) | Upper-shadow K-line pattern — the core signal pattern |
| 炸板 (Failed Board) | Limit-up that fails to hold by close |
| 涨停 (Limit Up) | Daily price ceiling hit (10% for main board, 20% for ChiNext) |
| 跌停 (Limit Down) | Daily price floor hit |
| 游资 (Hot Money) | Short-term speculative capital pattern |
| 龙虎榜 (LHB) | Top buyer/seller disclosure list |
| PreparedBundle | The central data object containing all loaded data, features, and signals |
| Phase A | Parallel data loading + feature computation |
| Phase B | First-pass lightweight signal counting (merged into Phase A) |
| Phase C | Second-pass signal detection with cross-sectional environment context |
