from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]

OUTPUTS_DIR = ROOT / "outputs"
BACKTESTS_DIR = OUTPUTS_DIR / "backtests"
SIGNALS_DIR = OUTPUTS_DIR / "signals"
OUTPUTS_STATE_DIR = OUTPUTS_DIR / "state"
ANALYSIS_DIR = OUTPUTS_DIR / "analysis"
LEGACY_RESULTS_DIR = ROOT / "v5" / "results"

STUDIO_STATE_DIR = ROOT / ".studio"
TASKS_DIR = STUDIO_STATE_DIR / "tasks"
CONFIGS_DIR = STUDIO_STATE_DIR / "configs"
SCHEDULES_PATH = STUDIO_STATE_DIR / "schedules.json"


@dataclass(slots=True)
class StudioSettings:
    root_dir: Path = ROOT
    outputs_dir: Path = OUTPUTS_DIR
    backtests_dir: Path = BACKTESTS_DIR
    signals_dir: Path = SIGNALS_DIR
    outputs_state_dir: Path = OUTPUTS_STATE_DIR
    analysis_dir: Path = ANALYSIS_DIR
    legacy_results_dir: Path = LEGACY_RESULTS_DIR
    studio_state_dir: Path = STUDIO_STATE_DIR
    tasks_dir: Path = TASKS_DIR
    configs_dir: Path = CONFIGS_DIR
    schedules_path: Path = SCHEDULES_PATH


def get_settings() -> StudioSettings:
    settings = StudioSettings()
    settings.outputs_dir.mkdir(parents=True, exist_ok=True)
    settings.backtests_dir.mkdir(parents=True, exist_ok=True)
    settings.signals_dir.mkdir(parents=True, exist_ok=True)
    settings.outputs_state_dir.mkdir(parents=True, exist_ok=True)
    settings.analysis_dir.mkdir(parents=True, exist_ok=True)
    settings.studio_state_dir.mkdir(parents=True, exist_ok=True)
    settings.tasks_dir.mkdir(parents=True, exist_ok=True)
    settings.configs_dir.mkdir(parents=True, exist_ok=True)
    settings.legacy_results_dir.mkdir(parents=True, exist_ok=True)
    return settings

