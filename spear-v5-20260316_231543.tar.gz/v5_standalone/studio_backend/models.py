from __future__ import annotations

from datetime import datetime
from typing import Literal

from pydantic import BaseModel, Field


ExecutionProfile = Literal["day_level_ideal", "next_open_realistic", "delayed_limit_hunt"]
TaskKind = Literal["backtest", "signal_scan", "data_prepare"]
TaskStatus = Literal["pending", "running", "succeeded", "failed"]


class BacktestRequest(BaseModel):
    start: str
    end: str
    pool: int = Field(default=300, ge=1)
    pool_name: str = ""
    output_dir: str
    cache_dir: str | None = None
    pool_sampling: Literal["random", "head"] = "random"
    pool_seed: int = 99
    execution_profile: ExecutionProfile = "next_open_realistic"
    hunt_price_buffer_pct: float = 0.005
    hunt_window_days: int = 3
    exit_mode: Literal["ideal", "next_open", "hunt_exit"] = "ideal"
    exit_hunt_buffer_pct: float = 0.005
    exit_hunt_window_days: int = 3
    init_cash: float = 1_000_000.0
    symbols: list[str] = Field(default_factory=list)
    enable_events: list[str] = Field(default_factory=list)
    max_positions: int = 20
    base_pos_pct: float = 0.25
    position_sizing_base: str = "cash"
    cooldown_days: int = 3
    take_profit_pct: float = 0.18
    warmup_bars: int = Field(default=600, ge=120, le=900)
    mootdx_cache_only: bool = False
    show_progress: bool = False
    trend_spear_pos_mult: float = 1.00
    post_limit_pos_mult: float = 0.90
    failed_board_pos_mult: float = 0.85
    youzi_pos_mult: float = 0.75
    sector_spear_pos_mult: float = 0.70
    attack_pos_mult: float = 0.55
    arb_pos_mult: float = 0.35
    disable_env_mapping: bool = False
    trend_spear_dynamic_hold: bool = False
    trend_spear_limitup_extend_days: int = 15
    trend_spear_limitup_wide_atr_mult: float = 2.5
    trend_spear_limitup_stop_floor_pct: float = 0.92
    trend_spear_noboard_tighten_days: int = 5
    trend_spear_noboard_tight_atr_mult: float = 1.5
    trend_spear_noboard_max_hold: int = 5
    trend_spear_vol_exhaustion_exit: bool = False
    ts_atr_stop: bool = True
    ts_iqr_filter: bool = False
    ts_iqr_threshold: float = 0.85
    ts_elev_filter: bool = False
    ts_elev_threshold: float = 1.0
    db_path: str = "cache/market.duckdb"


SignalMode = Literal["auto", "preview", "confirm"]


class SignalScanRequest(BaseModel):
    date: str
    lookback_days: int = 240
    warmup_bars: int = Field(default=600, ge=120, le=900)
    pool: int = Field(default=300, ge=1)
    pool_name: str = ""
    pool_sampling: Literal["random", "head"] = "random"
    pool_seed: int = 99
    execution_profile: ExecutionProfile = "delayed_limit_hunt"
    hunt_price_buffer_pct: float = 0.005
    hunt_window_days: int = 3
    watch_window_days: int = 5
    output_dir: str
    symbols: list[str] = Field(default_factory=list)
    mode: SignalMode = "auto"
    max_positions: int = 20
    base_pos_pct: float = 0.25
    position_sizing_base: str = "cash"
    trend_spear_pos_mult: float = 1.00
    post_limit_pos_mult: float = 0.90
    failed_board_pos_mult: float = 0.85
    youzi_pos_mult: float = 0.75
    sector_spear_pos_mult: float = 0.70
    attack_pos_mult: float = 0.55
    arb_pos_mult: float = 0.35
    # Notification config (pre-run, cron-friendly)
    push_top_new: int = Field(default=3, ge=0, le=50)
    push_top_watch: int = Field(default=5, ge=0, le=50)
    push_top_drops: int = Field(default=5, ge=0, le=50)
    min_confidence: float = Field(default=0.0, ge=0.0, le=1.0)
    auto_push: bool = False
    feishu_webhook: str = ""
    feishu_secret: str = ""
    send_now: bool = False
    disable_env_mapping: bool = False
    trend_spear_dynamic_hold: bool = False
    trend_spear_limitup_extend_days: int = 15
    trend_spear_limitup_wide_atr_mult: float = 2.5
    trend_spear_limitup_stop_floor_pct: float = 0.92
    trend_spear_noboard_tighten_days: int = 5
    trend_spear_noboard_tight_atr_mult: float = 1.5
    trend_spear_noboard_max_hold: int = 5
    trend_spear_vol_exhaustion_exit: bool = False
    ts_atr_stop: bool = True
    ts_iqr_filter: bool = False
    ts_iqr_threshold: float = 0.85
    ts_elev_filter: bool = False
    ts_elev_threshold: float = 1.0
    ytd: bool = False
    db_path: str = "cache/market.duckdb"


class TaskRecord(BaseModel):
    id: str
    kind: TaskKind
    status: TaskStatus
    command: list[str]
    output_dir: str
    created_at: datetime
    updated_at: datetime
    return_code: int | None = None
    log_path: str
    payload: dict


class ResultEntry(BaseModel):
    name: str
    path: str
    summary_path: str | None = None
    overview_path: str | None = None
    master_table_path: str | None = None
    snapshot_path: str | None = None
    updated_at: datetime
    kind: Literal["backtest", "signal_scan", "other"]
    meta: dict | None = None


class NamedPoolEntry(BaseModel):
    name: str
    label: str
    source_path: str
    description: str = ""
    symbol_count: int
    builtin: bool = True


class ScheduleConfig(BaseModel):
    id: str
    name: str
    enabled: bool = True
    minute: str = "5"
    hour: str = "15"
    weekdays: str = "1-5"
    command_preview: str
    kind: TaskKind
    payload: dict
