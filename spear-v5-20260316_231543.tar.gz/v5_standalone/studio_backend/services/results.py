from __future__ import annotations

import json
import os
import time
from datetime import datetime, UTC
from pathlib import Path

from studio_backend.config import get_settings
from studio_backend.models import ResultEntry

_cache: tuple[float, list[ResultEntry]] | None = None
_CACHE_TTL = 5.0


def _guess_kind(path: Path) -> str:
    if (path / "snapshot.json").exists() or any(path.glob("snapshot_*.json")):
        return "signal_scan"
    if (path / "summary.json").exists():
        return "backtest"
    return "other"


def _read_meta(path: Path) -> dict | None:
    meta_path = path / "meta.json"
    if not meta_path.exists():
        return None
    try:
        return json.loads(meta_path.read_text(encoding="utf-8"))
    except Exception:
        return None


def _entry_from_dir_fast(path: Path, kind: str, children: set[str] | None = None,
                         meta: dict | None = None) -> ResultEntry:
    if children is None:
        children = set(os.listdir(path))
    return ResultEntry(
        name=path.name,
        path=str(path),
        summary_path=str(path / "summary.json") if "summary.json" in children else None,
        overview_path=str(path / "results_overview.md") if "results_overview.md" in children else None,
        master_table_path=str(path / "all_trades_master_table.csv") if "all_trades_master_table.csv" in children else None,
        snapshot_path=_find_snapshot_fast(path, children),
        updated_at=datetime.fromtimestamp(path.stat().st_mtime, tz=UTC),
        kind=kind,  # type: ignore[arg-type]
        meta=meta,
    )


def _find_snapshot_fast(path: Path, children: set[str]) -> str | None:
    if "snapshot.json" in children:
        return str(path / "snapshot.json")
    snaps = sorted(f for f in children if f.startswith("snapshot_") and f.endswith(".json"))
    return str(path / snaps[0]) if snaps else None


def list_results() -> list[ResultEntry]:
    global _cache
    now = time.monotonic()
    if _cache is not None and (now - _cache[0]) < _CACHE_TTL:
        return _cache[1]

    settings = get_settings()
    out: list[ResultEntry] = []
    seen_names: set[str] = set()

    if settings.backtests_dir.exists():
        for entry in os.scandir(settings.backtests_dir):
            if not entry.is_dir():
                continue
            path = Path(entry.path)
            out.append(_entry_from_dir_fast(path, "backtest"))
            seen_names.add(entry.name)

    if settings.signals_dir.exists():
        for entry in os.scandir(settings.signals_dir):
            if not entry.is_dir():
                continue
            path = Path(entry.path)
            meta = _read_meta(path)
            if meta:
                kind = meta.get("kind", "signal_scan")
                out.append(_entry_from_dir_fast(path, kind, meta=meta))
                seen_names.add(entry.name)
            else:
                for sub in sorted(path.iterdir(), reverse=True):
                    if sub.is_dir() and _read_meta(sub):
                        m = _read_meta(sub)
                        kind = m.get("kind", "signal_scan") if m else "signal_scan"
                        out.append(_entry_from_dir_fast(sub, kind, meta=m))
                        seen_names.add(sub.name)
                seen_names.add(entry.name)

    if settings.legacy_results_dir.exists():
        for entry in os.scandir(settings.legacy_results_dir):
            if not entry.is_dir() or entry.name in seen_names:
                continue
            path = Path(entry.path)
            kind = _guess_kind(path)
            meta = _read_meta(path) if kind == "signal_scan" else None
            out.append(_entry_from_dir_fast(path, kind, meta=meta))

    out.sort(key=lambda x: x.updated_at, reverse=True)
    _cache = (now, out)
    return out


def invalidate_results_cache() -> None:
    global _cache
    _cache = None


def delete_result(name: str) -> bool:
    import shutil
    path = find_result_dir(name)
    if path is None or not path.is_dir():
        return False
    shutil.rmtree(path)
    invalidate_results_cache()
    return True


def find_result_dir(name: str) -> Path | None:
    settings = get_settings()
    for base in [settings.backtests_dir, settings.signals_dir, settings.legacy_results_dir]:
        candidate = base / name
        if candidate.is_dir():
            if (candidate / "meta.json").exists() or (candidate / "summary.json").exists():
                return candidate
            for sub in sorted(candidate.iterdir(), reverse=True):
                if sub.is_dir() and (sub / "meta.json").exists():
                    return sub
            return candidate
    return None
