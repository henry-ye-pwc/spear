from __future__ import annotations

import asyncio
import shlex
import sys
import uuid
from datetime import datetime, UTC
from pathlib import Path

from studio_backend.config import get_settings
from studio_backend.models import BacktestRequest, SignalScanRequest, TaskRecord
from studio_backend.storage import read_json, write_json


def _now() -> datetime:
    return datetime.now(UTC)


def _task_path(task_id: str) -> Path:
    return get_settings().tasks_dir / f"{task_id}.json"


def _build_backtest_command(payload: BacktestRequest) -> tuple[list[str], Path]:
    settings = get_settings()
    if payload.output_dir and not payload.output_dir.startswith("outputs/"):
        run_tag = payload.output_dir
    else:
        from datetime import date as _date
        _prof = {"day_level_ideal": "dli", "next_open_realistic": "nor", "delayed_limit_hunt": "dlh"}.get(payload.execution_profile, payload.execution_profile[:3])
        pool_desc = payload.pool_name or f"pool{payload.pool}_{payload.pool_sampling}{payload.pool_seed}"
        _uid = uuid.uuid4().hex[:6]
        run_tag = f"{_date.today().strftime('%Y%m%d')}_{payload.start[:4]}-{payload.end[:4]}_{pool_desc}_{_prof}_{_uid}"
    output_dir = settings.backtests_dir / run_tag
    cmd = [
        sys.executable,
        str(settings.root_dir / "v5" / "run.py"),
        "--start",
        payload.start,
        "--end",
        payload.end,
        "--output-dir",
        str(output_dir),
        "--execution-profile",
        payload.execution_profile,
        "--hunt-price-buffer-pct",
        str(payload.hunt_price_buffer_pct),
        "--hunt-window-days",
        str(payload.hunt_window_days),
        "--init-cash",
        str(payload.init_cash),
        "--warmup-bars",
        str(payload.warmup_bars),
    ]
    if payload.pool_name:
        cmd.extend(["--pool-name", payload.pool_name])
    elif payload.symbols:
        cmd.extend(["--symbols", ",".join(payload.symbols)])
    else:
        cmd.extend([
            "--pool", str(payload.pool),
            "--pool-sampling", payload.pool_sampling,
            "--pool-seed", str(payload.pool_seed),
        ])
    if payload.cache_dir:
        cmd.extend(["--cache-dir", payload.cache_dir])
    if payload.enable_events:
        cmd.extend(["--enable-events", ",".join(payload.enable_events)])
    cmd.extend([
        "--max-positions", str(payload.max_positions),
        "--base-pos-pct", str(payload.base_pos_pct),
        "--position-sizing-base", str(payload.position_sizing_base),
        "--cooldown-days", str(payload.cooldown_days),
        "--take-profit-pct", str(payload.take_profit_pct),
        "--trend-spear-pos-mult", str(payload.trend_spear_pos_mult),
        "--post-limit-pos-mult", str(payload.post_limit_pos_mult),
        "--failed-board-pos-mult", str(payload.failed_board_pos_mult),
        "--youzi-pos-mult", str(payload.youzi_pos_mult),
        "--sector-spear-pos-mult", str(payload.sector_spear_pos_mult),
        "--attack-pos-mult", str(payload.attack_pos_mult),
        "--arb-pos-mult", str(payload.arb_pos_mult),
    ])
    if payload.exit_mode != "ideal":
        cmd.extend(["--exit-mode", payload.exit_mode])
    if payload.exit_mode == "hunt_exit":
        cmd.extend([
            "--exit-hunt-buffer-pct", str(payload.exit_hunt_buffer_pct),
            "--exit-hunt-window-days", str(payload.exit_hunt_window_days),
        ])
    if payload.mootdx_cache_only:
        cmd.append("--mootdx-cache-only")
    if payload.show_progress:
        cmd.append("--show-progress")
    if payload.disable_env_mapping:
        cmd.append("--disable-env-mapping")
    if payload.trend_spear_dynamic_hold:
        cmd.append("--trend-spear-dynamic-hold")
        cmd.extend(["--trend-spear-limitup-extend-days", str(payload.trend_spear_limitup_extend_days)])
        cmd.extend(["--trend-spear-limitup-wide-atr-mult", str(payload.trend_spear_limitup_wide_atr_mult)])
        cmd.extend(["--trend-spear-limitup-stop-floor-pct", str(payload.trend_spear_limitup_stop_floor_pct)])
        cmd.extend(["--trend-spear-noboard-tighten-days", str(payload.trend_spear_noboard_tighten_days)])
        cmd.extend(["--trend-spear-noboard-tight-atr-mult", str(payload.trend_spear_noboard_tight_atr_mult)])
        cmd.extend(["--trend-spear-noboard-max-hold", str(payload.trend_spear_noboard_max_hold)])
    if payload.trend_spear_vol_exhaustion_exit:
        cmd.append("--trend-spear-vol-exhaustion-exit")
    if not payload.ts_atr_stop:
        cmd.append("--no-ts-atr-stop")
    if not payload.ts_iqr_filter:
        cmd.append("--no-ts-iqr-filter")
    if payload.ts_iqr_threshold != 0.85:
        cmd.extend(["--ts-iqr-threshold", str(payload.ts_iqr_threshold)])
    if not payload.ts_elev_filter:
        cmd.append("--no-ts-elev-filter")
    if payload.ts_elev_threshold != 1.0:
        cmd.extend(["--ts-elev-threshold", str(payload.ts_elev_threshold)])
    if payload.db_path:
        cmd.extend(["--db-path", payload.db_path])
    return cmd, output_dir


def _build_signal_command(payload: SignalScanRequest) -> tuple[list[str], Path]:
    settings = get_settings()
    if payload.output_dir and not payload.output_dir.startswith("outputs/"):
        out_tag = payload.output_dir
    else:
        _ts = datetime.now(UTC).strftime("%Y%m%dT%H%M%S")
        out_tag = f"{payload.date}_{_ts}"
    output_dir = settings.signals_dir / out_tag
    cmd = [
        sys.executable,
        str(settings.root_dir / "v5" / "daily_signal_job.py"),
        "--date",
        payload.date,
        "--lookback-days",
        str(payload.lookback_days),
        "--warmup-bars",
        str(payload.warmup_bars),
        "--execution-profile",
        payload.execution_profile,
        "--hunt-price-buffer-pct",
        str(payload.hunt_price_buffer_pct),
        "--hunt-window-days",
        str(payload.hunt_window_days),
        "--watch-window-days",
        str(payload.watch_window_days),
        "--output-dir",
        str(output_dir),
        "--mode",
        payload.mode,
        "--push-top-new",
        str(payload.push_top_new),
        "--push-top-watch",
        str(payload.push_top_watch),
        "--push-top-drops",
        str(payload.push_top_drops),
        "--min-confidence",
        str(payload.min_confidence),
        "--max-positions",
        str(payload.max_positions),
        "--base-pos-pct",
        str(payload.base_pos_pct),
        "--position-sizing-base",
        str(payload.position_sizing_base),
        "--trend-spear-pos-mult",
        str(payload.trend_spear_pos_mult),
        "--post-limit-pos-mult",
        str(payload.post_limit_pos_mult),
        "--failed-board-pos-mult",
        str(payload.failed_board_pos_mult),
        "--youzi-pos-mult",
        str(payload.youzi_pos_mult),
        "--sector-spear-pos-mult",
        str(payload.sector_spear_pos_mult),
        "--attack-pos-mult",
        str(payload.attack_pos_mult),
        "--arb-pos-mult",
        str(payload.arb_pos_mult),
    ]
    if payload.pool_name:
        cmd.extend(["--pool-name", payload.pool_name])
    elif payload.symbols:
        cmd.extend(["--symbols", ",".join(payload.symbols)])
    else:
        cmd.extend([
            "--pool", str(payload.pool),
            "--pool-sampling", payload.pool_sampling,
            "--pool-seed", str(payload.pool_seed),
        ])
    if payload.disable_env_mapping:
        cmd.append("--disable-env-mapping")
    if payload.trend_spear_dynamic_hold:
        cmd.append("--trend-spear-dynamic-hold")
        cmd.extend(["--trend-spear-limitup-extend-days", str(payload.trend_spear_limitup_extend_days)])
        cmd.extend(["--trend-spear-limitup-wide-atr-mult", str(payload.trend_spear_limitup_wide_atr_mult)])
        cmd.extend(["--trend-spear-limitup-stop-floor-pct", str(payload.trend_spear_limitup_stop_floor_pct)])
        cmd.extend(["--trend-spear-noboard-tighten-days", str(payload.trend_spear_noboard_tighten_days)])
        cmd.extend(["--trend-spear-noboard-tight-atr-mult", str(payload.trend_spear_noboard_tight_atr_mult)])
        cmd.extend(["--trend-spear-noboard-max-hold", str(payload.trend_spear_noboard_max_hold)])
    if payload.trend_spear_vol_exhaustion_exit:
        cmd.append("--trend-spear-vol-exhaustion-exit")
    if not payload.ts_atr_stop:
        cmd.append("--no-ts-atr-stop")
    if not payload.ts_iqr_filter:
        cmd.append("--no-ts-iqr-filter")
    if payload.ts_iqr_threshold != 0.85:
        cmd.extend(["--ts-iqr-threshold", str(payload.ts_iqr_threshold)])
    if not payload.ts_elev_filter:
        cmd.append("--no-ts-elev-filter")
    if payload.ts_elev_threshold != 1.0:
        cmd.extend(["--ts-elev-threshold", str(payload.ts_elev_threshold)])
    if payload.ytd:
        cmd.append("--ytd")
    if payload.db_path:
        cmd.extend(["--db-path", payload.db_path])
    webhook = payload.feishu_webhook
    secret = payload.feishu_secret
    if (payload.send_now or payload.auto_push) and not webhook:
        from studio_backend.feishu_config import load_feishu_config
        saved = load_feishu_config()
        webhook = saved["webhook"]
        secret = secret or saved["secret"]
    if (payload.send_now or payload.auto_push) and webhook:
        cmd.extend(["--feishu-webhook", webhook])
        if secret:
            cmd.extend(["--feishu-secret", secret])
    else:
        cmd.append("--dry-run")
    return cmd, output_dir


def create_task(kind: str, payload: BacktestRequest | SignalScanRequest) -> TaskRecord:
    task_id = uuid.uuid4().hex[:12]
    created = _now()
    if kind == "backtest":
        command, output_dir = _build_backtest_command(payload)  # type: ignore[arg-type]
    else:
        command, output_dir = _build_signal_command(payload)  # type: ignore[arg-type]
    log_path = get_settings().tasks_dir / f"{task_id}.log"
    record = TaskRecord(
        id=task_id,
        kind=kind,  # type: ignore[arg-type]
        status="pending",
        command=command,
        output_dir=str(output_dir),
        created_at=created,
        updated_at=created,
        log_path=str(log_path),
        payload=payload.model_dump(),
    )
    save_task(record)
    return record


def save_task(task: TaskRecord) -> None:
    write_json(_task_path(task.id), task.model_dump(mode="json"))


def load_task(task_id: str) -> TaskRecord | None:
    path = _task_path(task_id)
    if not path.exists():
        return None
    return TaskRecord.model_validate(read_json(path, {}))


def list_tasks() -> list[TaskRecord]:
    tasks = []
    for path in sorted(get_settings().tasks_dir.glob("*.json"), reverse=True):
        tasks.append(TaskRecord.model_validate(read_json(path, {})))
    tasks.sort(key=lambda x: x.created_at, reverse=True)
    return tasks


def recover_orphaned_tasks() -> int:
    """Mark any 'running'/'pending' tasks as failed on startup (server restart killed them)."""
    fixed = 0
    for path in get_settings().tasks_dir.glob("*.json"):
        try:
            task = TaskRecord.model_validate(read_json(path, {}))
        except Exception:
            continue
        if task.status in ("running", "pending"):
            task.status = "failed"
            task.return_code = -9
            task.updated_at = _now()
            save_task(task)
            fixed += 1
    return fixed


async def run_task(task_id: str) -> TaskRecord:
    task = load_task(task_id)
    if task is None:
        raise ValueError(f"Unknown task: {task_id}")
    task.status = "running"
    task.updated_at = _now()
    save_task(task)
    log_path = Path(task.log_path)
    log_path.parent.mkdir(parents=True, exist_ok=True)
    process = await asyncio.create_subprocess_exec(
        *task.command,
        cwd=str(get_settings().root_dir),
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.STDOUT,
    )
    assert process.stdout is not None
    with log_path.open("w", encoding="utf-8") as handle:
        while True:
            line = await process.stdout.readline()
            if not line:
                break
            handle.write(line.decode("utf-8", errors="replace"))
            handle.flush()
    return_code = await process.wait()
    task.return_code = return_code
    task.status = "succeeded" if return_code == 0 else "failed"
    task.updated_at = _now()
    save_task(task)
    return task


def cancel_task(task_id: str) -> TaskRecord | None:
    task = load_task(task_id)
    if task is None:
        return None
    if task.status in ("running", "pending"):
        task.status = "failed"
        task.return_code = -1
        task.updated_at = _now()
        save_task(task)
    return task


def delete_task(task_id: str) -> bool:
    path = _task_path(task_id)
    if not path.exists():
        return False
    path.unlink()
    log = get_settings().tasks_dir / f"{task_id}.log"
    if log.exists():
        log.unlink()
    return True


def command_preview(kind: str, payload: dict) -> str:
    if kind == "backtest":
        cmd, _ = _build_backtest_command(BacktestRequest.model_validate(payload))
    else:
        cmd, _ = _build_signal_command(SignalScanRequest.model_validate(payload))
    return shlex.join(cmd)
