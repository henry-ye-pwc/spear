from __future__ import annotations

import asyncio
import logging
from typing import Any

from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.cron import CronTrigger

from studio_backend.config import get_settings
from studio_backend.models import ScheduleConfig
from studio_backend.services.tasks import command_preview
from studio_backend.storage import read_json, write_json

_log = logging.getLogger("schedules")
_scheduler: AsyncIOScheduler | None = None


def get_scheduler() -> AsyncIOScheduler:
    global _scheduler
    if _scheduler is None:
        _scheduler = AsyncIOScheduler(timezone="Asia/Shanghai")
    return _scheduler


def list_schedules() -> list[ScheduleConfig]:
    raw = read_json(get_settings().schedules_path, [])
    return [ScheduleConfig.model_validate(item) for item in raw]


def save_schedule(schedule: ScheduleConfig) -> ScheduleConfig:
    schedules = [x for x in list_schedules() if x.id != schedule.id]
    schedules.append(schedule)
    write_json(get_settings().schedules_path, [x.model_dump(mode="json") for x in schedules])
    sync_scheduler()
    return schedule


def delete_schedule(schedule_id: str) -> bool:
    schedules = list_schedules()
    before = len(schedules)
    schedules = [x for x in schedules if x.id != schedule_id]
    if len(schedules) == before:
        return False
    write_json(get_settings().schedules_path, [x.model_dump(mode="json") for x in schedules])
    sync_scheduler()
    return True


def toggle_schedule(schedule_id: str, enabled: bool) -> ScheduleConfig | None:
    schedules = list_schedules()
    target = None
    for s in schedules:
        if s.id == schedule_id:
            s.enabled = enabled
            target = s
    if target is None:
        return None
    write_json(get_settings().schedules_path, [x.model_dump(mode="json") for x in schedules])
    sync_scheduler()
    return target


def build_cron_line(schedule: ScheduleConfig) -> str:
    payload = dict(schedule.payload)
    preview = command_preview(schedule.kind, payload)
    return f"{schedule.minute} {schedule.hour} * * {schedule.weekdays} cd {get_settings().root_dir} && {preview}"


def _job_id(schedule_id: str) -> str:
    return f"sched_{schedule_id}"


async def _run_scheduled_task(kind: str, payload: dict[str, Any]) -> None:
    from studio_backend.models import SignalScanRequest, BacktestRequest
    from studio_backend.services.tasks import create_task, run_task

    _log.info(f"[cron] Triggering {kind} task")
    try:
        if kind == "signal_scan":
            req = SignalScanRequest.model_validate(payload)
        elif kind == "backtest":
            req = BacktestRequest.model_validate(payload)
        else:
            _log.warning(f"[cron] Unknown kind: {kind}")
            return
        task = create_task(kind, req)
        asyncio.ensure_future(run_task(task.id))
        _log.info(f"[cron] Task {task.id} started for {kind}")
    except Exception as e:
        _log.error(f"[cron] Failed to start {kind}: {e}")


def sync_scheduler() -> None:
    scheduler = get_scheduler()
    schedules = list_schedules()
    wanted_ids = set()

    for s in schedules:
        jid = _job_id(s.id)
        wanted_ids.add(jid)
        if not s.enabled:
            if scheduler.get_job(jid):
                scheduler.remove_job(jid)
            continue
        weekdays = s.weekdays.replace("1-5", "mon-fri").replace("0-6", "*")
        trigger = CronTrigger(minute=s.minute, hour=s.hour, day_of_week=weekdays, timezone="Asia/Shanghai")
        if scheduler.get_job(jid):
            scheduler.reschedule_job(jid, trigger=trigger)
        else:
            scheduler.add_job(
                _run_scheduled_task,
                trigger=trigger,
                args=[s.kind, s.payload],
                id=jid,
                replace_existing=True,
            )
        _log.info(f"[cron] Scheduled {jid}: {s.hour}:{s.minute} weekdays={s.weekdays} enabled={s.enabled}")

    for job in scheduler.get_jobs():
        if job.id.startswith("sched_") and job.id not in wanted_ids:
            scheduler.remove_job(job.id)


def start_scheduler() -> None:
    scheduler = get_scheduler()
    sync_scheduler()
    if not scheduler.running:
        scheduler.start()
        _log.info("[cron] Scheduler started")

