from __future__ import annotations

import asyncio
import json
import os
import pickle
import threading
from contextlib import asynccontextmanager
from pathlib import Path

import pandas as pd
from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

from studio_backend.config import ROOT, get_settings
from studio_backend.models import BacktestRequest, NamedPoolEntry, ResultEntry, ScheduleConfig, SignalScanRequest
from studio_backend.services.results import delete_result, find_result_dir, list_results
from studio_backend.services.schedules import build_cron_line, delete_schedule, list_schedules, save_schedule, start_scheduler, toggle_schedule
from studio_backend.services.tasks import cancel_task, create_task, delete_task, list_tasks, load_task, recover_orphaned_tasks, run_task
from v5.config.pools import delete_custom_pool, list_named_pools, save_custom_pool


def _load_dotenv() -> None:
    env_path = ROOT / ".env"
    if not env_path.exists():
        return
    for line in env_path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, value = line.partition("=")
        os.environ.setdefault(key.strip(), value.strip())


_load_dotenv()

@asynccontextmanager
async def _lifespan(_app: FastAPI):
    fixed = recover_orphaned_tasks()
    if fixed:
        print(f"[startup] Recovered {fixed} orphaned task(s)", flush=True)
    start_scheduler()
    print("[startup] Scheduler started", flush=True)
    yield


app = FastAPI(title="Spear Strategy Studio", version="0.1.0", lifespan=_lifespan)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/api/health")
def health() -> dict:
    settings = get_settings()
    return {
        "status": "ok",
        "root_dir": str(settings.root_dir),
        "outputs_dir": str(settings.outputs_dir),
    }


def _load_feishu_config() -> dict:
    from studio_backend.feishu_config import load_feishu_config
    return load_feishu_config()


def _feishu_config_path() -> Path:
    from studio_backend.feishu_config import feishu_config_path
    return feishu_config_path()


@app.get("/api/config/feishu")
def api_feishu_config() -> dict:
    return _load_feishu_config()


@app.post("/api/config/feishu")
def api_save_feishu_config(body: dict) -> dict:
    webhook = str(body.get("webhook", "")).strip()
    secret = str(body.get("secret", "")).strip()
    path = _feishu_config_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps({"webhook": webhook, "secret": secret}, ensure_ascii=False, indent=2), encoding="utf-8")
    os.environ["FEISHU_WEBHOOK"] = webhook
    os.environ["FEISHU_SECRET"] = secret
    return {"webhook": webhook, "secret": secret}


@app.post("/api/feishu-push")
def api_feishu_push(body: dict) -> dict:
    """Push a saved feishu_payload.json to Feishu without re-running the scan."""
    from v5.notify.feishu import send_feishu_webhook

    date = body.get("date", "")
    output_dir = body.get("output_dir", "")
    saved = _load_feishu_config()
    webhook = body.get("webhook") or saved["webhook"]
    secret = body.get("secret") or saved["secret"]
    if not webhook:
        raise HTTPException(400, "No Feishu webhook configured")

    settings = get_settings()
    candidates: list[Path] = []
    if output_dir:
        od = Path(output_dir)
        candidates.append(od / "feishu_payload.json")
        candidates.extend(sorted(od.glob("*/feishu_payload.json")))
    if date:
        candidates.append(settings.signals_dir / date / "feishu_payload.json")
        candidates.extend(sorted(settings.signals_dir.glob(f"{date}/*/feishu_payload.json")))
        candidates.extend(sorted(settings.signals_dir.glob(f"*/{date}/feishu_payload.json")))

    payload_path = next((p for p in candidates if p.exists()), None)
    if not payload_path:
        raise HTTPException(404, f"No feishu_payload.json found (date={date}, output_dir={output_dir})")

    payload = json.loads(payload_path.read_text(encoding="utf-8"))
    resp = send_feishu_webhook(
        webhook_url=webhook,
        payload=payload,
        secret=secret or None,
    )
    return {"ok": True, "date": date, "feishu_response": resp}


@app.get("/api/results", response_model=list[ResultEntry])
def api_results() -> list[ResultEntry]:
    return list_results()


@app.delete("/api/results/{name}")
def api_delete_result(name: str) -> dict:
    if not delete_result(name):
        raise HTTPException(status_code=404, detail="result not found")
    _invalidate_batch_stats_cache()
    return {"ok": True}


_batch_stats_cache: tuple[float, list[dict], dict] | None = None
_BATCH_STATS_TTL = 120.0
_BATCH_STATS_DISK_TTL = 3600.0
_batch_stats_build_lock = threading.Lock()

_STAT_SORT_KEYS = frozenset(
    {"win_rate", "total_return_pct", "peak_equity", "max_drawdown_pct", "total_closed"}
)


def _read_report(
    directory: Path,
    stem: str,
    *,
    columns: list[str] | None = None,
    dtype: dict | None = None,
) -> pd.DataFrame:
    """Read a report file: try Parquet first, fall back to CSV.

    This provides backward-compatible reads for both old (CSV) and new
    (Parquet) result directories.
    """
    pq = directory / f"{stem}.parquet"
    if pq.exists() and pq.stat().st_size > 0:
        try:
            return pd.read_parquet(pq, columns=columns, engine="pyarrow")
        except Exception:
            pass
    csv = directory / f"{stem}.csv"
    if csv.exists() and csv.stat().st_size > 0:
        try:
            kw: dict = {}
            if columns:
                kw["usecols"] = lambda c: c in columns  # type: ignore[arg-type]
            if dtype:
                kw["dtype"] = dtype
            return pd.read_csv(csv, **kw)
        except pd.errors.EmptyDataError:
            return pd.DataFrame()
    return pd.DataFrame()


def _compute_one_stat(entry_name: str, path: Path) -> dict:
    """Compute stats for a single backtest result."""
    item: dict = {"name": entry_name, "config": {}, "stats": {}}
    summary_data: dict = {}
    summary_path = path / "summary.json"
    if summary_path.exists():
        try:
            summary_data = json.loads(summary_path.read_text(encoding="utf-8"))
        except Exception:
            pass
    meta_path = path / "meta.json"
    if meta_path.exists():
        try:
            meta = json.loads(meta_path.read_text(encoding="utf-8"))
            if "config" in meta:
                item["config"] = meta["config"]
        except Exception:
            pass
    if not item["config"] and summary_data:
        item["config"] = summary_data
    if summary_data.get("equity_return_pct") is not None:
        item["stats"]["total_return_pct"] = summary_data["equity_return_pct"]
        item["stats"]["final_equity"] = summary_data.get("equity_final", 0)
    ct = _read_report(path, "closed_trades", columns=["ret", "hold_days", "pnl", "symbol"], dtype={"symbol": str}).fillna(0)
    if not ct.empty:
        try:
            total = len(ct)
            if total > 0:
                wins = ct[ct["ret"] > 0]
                item["stats"].update({
                    "total_closed": total,
                    "win_count": int(len(wins)),
                    "loss_count": total - int(len(wins)),
                    "win_rate": round(len(wins) / total, 4),
                    "avg_ret_pct": round(float(ct["ret"].mean()) * 100, 2),
                    "avg_hold_days": round(float(ct["hold_days"].mean()), 1) if "hold_days" in ct.columns else 0,
                    "total_pnl": round(float(ct["pnl"].sum()), 2) if "pnl" in ct.columns else 0,
                })
        except Exception:
            pass
    if "total_return_pct" not in item["stats"] or "max_drawdown_pct" not in item["stats"]:
        eq_df = _read_report(path, "equity_curve", columns=["equity"])
        if not eq_df.empty:
            try:
                eq_vals = eq_df["equity"].astype(float)
                init_cash = float(item["config"].get("init_cash", 1_000_000))
                final_equity = float(eq_vals.iloc[-1])
                if "total_return_pct" not in item["stats"]:
                    item["stats"]["final_equity"] = round(final_equity, 2)
                    item["stats"]["total_return_pct"] = round((final_equity / init_cash - 1) * 100, 2)
                running_max = eq_vals.cummax()
                item["stats"]["peak_equity"] = round(float(running_max.iloc[-1]), 2)
                drawdowns = (eq_vals - running_max) / running_max
                item["stats"]["max_drawdown_pct"] = round(float(drawdowns.min()) * 100, 2)
            except Exception:
                pass
    return item


def _batch_stats_cache_path() -> Path:
    return get_settings().studio_state_dir / "cache" / "batch_stats.pkl"


def _invalidate_batch_stats_cache() -> None:
    global _batch_stats_cache
    _batch_stats_cache = None
    path = _batch_stats_cache_path()
    if path.exists():
        try:
            path.unlink()
        except OSError:
            pass


def _load_batch_stats_from_disk() -> tuple[list[dict], dict] | None:
    import time as _time
    path = _batch_stats_cache_path()
    if not path.exists():
        return None
    try:
        if _time.time() - path.stat().st_mtime >= _BATCH_STATS_DISK_TTL:
            return None
    except OSError:
        return None
    try:
        with path.open("rb") as f:
            data = pickle.load(f)
        if isinstance(data, tuple) and len(data) == 2:
            computed, summary = data
            if isinstance(computed, list) and isinstance(summary, dict):
                return computed, summary
    except Exception:
        pass
    return None


def _save_batch_stats_to_disk(computed: list[dict], summary: dict) -> None:
    path = _batch_stats_cache_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    try:
        with path.open("wb") as f:
            pickle.dump((computed, summary), f)
    except OSError:
        pass


def _build_batch_stats_cache() -> tuple[list[dict], dict]:
    """Build the full computed-stats list and aggregate summary."""
    entries = list_results()
    all_bt = [e for e in entries if e.kind == "backtest"]
    all_bt.sort(key=lambda e: e.updated_at, reverse=True)
    computed: list[dict] = []
    for entry in all_bt:
        path = find_result_dir(entry.name)
        if path is None:
            continue
        item = _compute_one_stat(entry.name, path)
        item["updated_at"] = entry.updated_at.isoformat()
        computed.append(item)
    summary = _summarize(computed)
    _save_batch_stats_to_disk(computed, summary)
    return computed, summary


def _summarize(items: list[dict]) -> dict:
    return {
        "total_trades": sum(it.get("stats", {}).get("total_closed", 0) for it in items),
    }


import re as _re

_YEAR_RE = _re.compile(r"\d{8}_(\d{4})-(\d{4})")


def _parse_year_key(name: str) -> str:
    m = _YEAR_RE.search(name)
    if m:
        return m.group(1) if m.group(1) == m.group(2) else f"{m.group(1)}-{m.group(2)}"
    return "其他"


@app.get("/api/results/batch-stats")
def api_batch_stats(
    year: str = "",
    offset: int = 0,
    limit: int = 20,
    sort_by: str = "updated_at",
    sort_dir: str = "desc",
) -> dict:
    """Paginated stats for backtest results, optionally filtered by year key."""
    global _batch_stats_cache
    import time as _time
    now = _time.monotonic()

    if _batch_stats_cache is None or (now - _batch_stats_cache[0]) >= _BATCH_STATS_TTL:
        with _batch_stats_build_lock:
            if _batch_stats_cache is not None and (now - _batch_stats_cache[0]) < _BATCH_STATS_TTL:
                pass
            else:
                disk = _load_batch_stats_from_disk()
                if disk is not None:
                    computed, summary = disk
                    _batch_stats_cache = (now, computed, summary)
                else:
                    computed, summary = _build_batch_stats_cache()
                    _batch_stats_cache = (now, computed, summary)

    all_items = list(_batch_stats_cache[1])
    summary = _batch_stats_cache[2]

    if year:
        all_items = [e for e in all_items if _parse_year_key(e["name"]) == year]
        summary = _summarize(all_items)

    reverse = sort_dir != "asc"
    if sort_by in ("name", "updated_at"):
        all_items.sort(key=lambda x: x.get(sort_by, ""), reverse=reverse)
    elif sort_by in _STAT_SORT_KEYS:
        none_sentinel = float("-inf") if reverse else float("inf")
        all_items.sort(
            key=lambda x: v if (v := x.get("stats", {}).get(sort_by)) is not None else none_sentinel,
            reverse=reverse,
        )

    total = len(all_items)
    items = all_items[offset:offset + limit]
    return {"total": total, "summary": summary, "items": items}


@app.get("/api/pools", response_model=list[NamedPoolEntry])
def api_pools() -> list[NamedPoolEntry]:
    return [NamedPoolEntry.model_validate(item) for item in list_named_pools()]


@app.post("/api/pools")
def api_save_pool(body: dict) -> dict:
    """Save custom symbols as a named pool."""
    name = body.get("name", "").strip()
    label = body.get("label", "").strip()
    symbols = body.get("symbols", [])
    description = body.get("description", "").strip()
    if not name:
        raise HTTPException(400, "Pool name is required")
    if not symbols:
        raise HTTPException(400, "At least one symbol is required")
    try:
        return save_custom_pool(name, label, symbols, description)
    except ValueError as e:
        raise HTTPException(400, str(e))


@app.delete("/api/pools/{pool_name}")
def api_delete_pool(pool_name: str) -> dict:
    """Delete a custom pool."""
    try:
        deleted = delete_custom_pool(pool_name)
    except ValueError as e:
        raise HTTPException(400, str(e))
    if not deleted:
        raise HTTPException(404, f"Pool not found: {pool_name}")
    return {"ok": True, "name": pool_name}


# ─── Named backtest/config ───
def _config_name_safe(name: str) -> str:
    """Sanitize config name for use as filename (no path traversal)."""
    safe = "".join(c if c.isalnum() or c in "_-" else "_" for c in (name or "").strip())
    return safe or "unnamed"


@app.get("/api/configs")
def api_list_configs() -> list[dict]:
    """List saved named configurations (backtest full config)."""
    settings = get_settings()
    out = []
    for p in sorted(settings.configs_dir.glob("*.json"), key=lambda x: x.stat().st_mtime, reverse=True):
        try:
            out.append({
                "name": p.stem,
                "updated_at": p.stat().st_mtime,
            })
        except OSError:
            pass
    return out


@app.get("/api/configs/{name}")
def api_get_config(name: str) -> dict:
    """Load a saved configuration by name."""
    settings = get_settings()
    safe = _config_name_safe(name)
    path = settings.configs_dir / f"{safe}.json"
    if not path.is_file():
        raise HTTPException(404, f"Config not found: {name}")
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError) as e:
        raise HTTPException(500, f"Failed to read config: {e}")


@app.post("/api/configs")
def api_save_config(body: dict) -> dict:
    """Save a full backtest config under a name. Body: { name: string, payload: object }."""
    settings = get_settings()
    raw_name = (body.get("name") or "").strip()
    if not raw_name:
        raise HTTPException(400, "name is required")
    payload = body.get("payload")
    if payload is None:
        raise HTTPException(400, "payload is required")
    safe = _config_name_safe(raw_name)
    path = settings.configs_dir / f"{safe}.json"
    try:
        path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    except OSError as e:
        raise HTTPException(500, f"Failed to save config: {e}")
    return {"ok": True, "name": safe}


@app.delete("/api/configs/{name}")
def api_delete_config(name: str) -> dict:
    """Delete a saved configuration."""
    settings = get_settings()
    safe = _config_name_safe(name)
    path = settings.configs_dir / f"{safe}.json"
    if not path.is_file():
        raise HTTPException(404, f"Config not found: {name}")
    try:
        path.unlink()
    except OSError as e:
        raise HTTPException(500, f"Failed to delete config: {e}")
    return {"ok": True, "name": safe}


@app.get("/api/pool-preview")
def api_pool_preview(size: int = 300, sampling: str = "random", seed: int = 42, pool_name: str | None = None) -> dict:
    from v5.config.defaults import load_default_config
    from v5.data.router import V5DataRouter

    if pool_name:
        from v5.config.pools import resolve_named_pool
        raw_syms = resolve_named_pool(pool_name)
        cfg = load_default_config()
        router = V5DataRouter(cfg=cfg)
        catalog = router.load_universe(1_000_000)
        if not catalog.empty:
            catalog = catalog.copy()
            catalog["symbol"] = catalog["symbol"].astype(str).str.zfill(6)
            meta = catalog.drop_duplicates(subset=["symbol"]).set_index("symbol")["name"].to_dict()
        else:
            meta = {}
        symbols = [{"symbol": s, "name": str(meta.get(s, ""))} for s in raw_syms]
    else:
        cfg = load_default_config()
        cfg.data.pool_sampling = sampling
        cfg.data.pool_seed = seed
        router = V5DataRouter(cfg=cfg)
        df = router.load_universe(size)
        symbols = [
            {"symbol": str(r["symbol"]), "name": str(r.get("name", ""))}
            for _, r in df.iterrows()
        ]

    cache_dir = ROOT / "cache"
    cached = set(_list_cached_symbols(cache_dir))
    missing_set = set()
    for s in symbols:
        code = str(s["symbol"]).zfill(6)
        if code not in cached:
            missing_set.add(code)

    return {
        "count": len(symbols),
        "symbols": symbols,
        "missing_symbols": sorted(missing_set),
        "cached_count": len(symbols) - len(missing_set),
    }


# ── Data cache status & prepare ──────────────────────────────

def _resolve_pool_symbols(pool_name: str | None, pool_size: int, pool_sampling: str, pool_seed: int) -> list[str]:
    """Resolve a pool specification to a list of symbol codes."""
    if pool_name:
        from v5.config.pools import resolve_named_pool
        return resolve_named_pool(pool_name)
    from v5.config.defaults import load_default_config
    from v5.data.router import V5DataRouter
    cfg = load_default_config()
    cfg.data.pool_sampling = pool_sampling
    cfg.data.pool_seed = pool_seed
    router = V5DataRouter(cfg=cfg)
    df = router.load_universe(pool_size)
    return [str(r["symbol"]).zfill(6) for _, r in df.iterrows()]


@app.get("/api/data/status")
def api_data_status(
    pool_name: str | None = None,
    pool_size: int = 300,
    pool_sampling: str = "random",
    pool_seed: int = 42,
) -> dict:
    """Check mootdx cache coverage for a given pool."""
    cache_dir = ROOT / "cache"
    try:
        symbols = _resolve_pool_symbols(pool_name, pool_size, pool_sampling, pool_seed)
    except Exception as e:
        raise HTTPException(400, str(e))

    all_cached = set(_list_cached_symbols(cache_dir))

    cached = 0
    stale = 0
    missing_syms: list[str] = []
    import time as _time
    now = _time.time()

    # Use DuckDB refresh timestamps for staleness check
    refresh_ts: dict[str, float] = {}
    db_path = cache_dir / "market.duckdb"
    if db_path.exists():
        try:
            from v5.data.store import MarketStore
            with MarketStore(str(db_path), read_only=True) as _s:
                refresh_ts = _s.get_refresh_timestamps()
        except Exception:
            pass

    for sym in symbols:
        if sym in all_cached:
            ts = refresh_ts.get(sym, 0.0)
            if ts and (now - ts) / 3600 > 24 * 30:
                stale += 1
            cached += 1
        else:
            missing_syms.append(sym)

    total = len(symbols)
    coverage_pct = round(cached / total * 100, 1) if total else 100
    est_seconds = len(missing_syms) * 2

    return {
        "total_symbols": total,
        "cached": cached,
        "missing": len(missing_syms),
        "missing_symbols": missing_syms[:50],
        "stale": stale,
        "coverage_pct": coverage_pct,
        "est_download_seconds": est_seconds,
        "cache_dir": str(cache_dir),
    }


@app.get("/api/data/latest-bar")
def api_latest_bar() -> dict:
    """Probe data freshness: minute bars for latest date, sample daily caches for daily readiness."""
    from cq_backtest.data.feed import DataFeed
    import random as _random
    probe_symbol = "000001"
    feed = DataFeed(cache_dir=str(ROOT / "cache"))
    try:
        minutes = feed.get_minute_bars(probe_symbol, frequency=8, count=250)
        if minutes is None or minutes.empty:
            return {"latest_date": None, "symbol": probe_symbol, "error": "无法获取分钟线数据（通达信连接失败）"}
        minutes = minutes.sort_index()
        valid = minutes[minutes["volume"].astype(float) > 100]
        if valid.empty:
            return {"latest_date": None, "symbol": probe_symbol, "error": "分钟线无有效成交量"}
        minute_latest = str(pd.Timestamp(valid.index.max()).date())

        cache_dir = ROOT / "cache"
        daily_ok = 0
        daily_checked = 0

        db_path = cache_dir / "market.duckdb"
        if db_path.exists():
            try:
                from v5.data.store import MarketStore
                with MarketStore(str(db_path), read_only=True) as _s:
                    all_syms = [r[0] for r in _s._conn.execute(
                        "SELECT DISTINCT symbol FROM daily_bars"
                    ).fetchall()]
                    sample_syms = _random.sample(all_syms, min(20, len(all_syms))) if all_syms else []
                    for sym in sample_syms:
                        try:
                            df = _s.read_bars(sym)
                            if df.empty:
                                continue
                            last = df.iloc[-1]
                            d = str(pd.Timestamp(df.index[-1]).date())
                            if d < minute_latest:
                                daily_checked += 1
                                continue
                            vol = float(last["volume"])
                            flat = (last["open"] == last["high"]) and (last["high"] == last["low"]) and (last["low"] == last["close"])
                            daily_checked += 1
                            if vol > 1000 and not flat:
                                daily_ok += 1
                        except Exception:
                            continue
            except Exception:
                pass

        daily_ready = daily_checked > 0 and (daily_ok / daily_checked) >= 0.8
        daily_pct = round(daily_ok / daily_checked * 100) if daily_checked > 0 else 0

        result: dict = {
            "latest_date": minute_latest,
            "symbol": probe_symbol,
            "source": "minute",
            "daily_ready": daily_ready,
            "daily_sample": f"{daily_ok}/{daily_checked}",
        }
        if not daily_ready:
            result["hint"] = f"分钟线已有 {minute_latest} 数据，日线尚在更新中（{daily_pct}% 就绪）。盘后确认模式会自动用分钟线补齐。"
        return result
    except Exception as e:
        return {"latest_date": None, "symbol": probe_symbol, "error": str(e)}


@app.post("/api/data/prepare")
async def api_data_prepare(payload: dict) -> dict:
    """Trigger a parallel data prefetch for the specified pool."""
    pool_name = payload.get("pool_name")
    pool_size = int(payload.get("pool_size", 300))
    pool_sampling = str(payload.get("pool_sampling", "random"))
    pool_seed = int(payload.get("pool_seed", 42))
    end_date = payload.get("end_date")

    try:
        symbols = _resolve_pool_symbols(pool_name, pool_size, pool_sampling, pool_seed)
    except Exception as e:
        raise HTTPException(400, str(e))

    import uuid as _uuid, sys as _sys
    task_id = _uuid.uuid4().hex[:12]
    from datetime import datetime, UTC
    created = datetime.now(UTC)
    cache_dir = str(ROOT / "cache")
    cmd = [
        _sys.executable, "-c",
        f"from v5.data.prefetch import prefetch_symbols; "
        f"prefetch_symbols({symbols!r}, cache_dir={cache_dir!r}, end_date={end_date!r}, workers=4)",
    ]
    log_path = get_settings().tasks_dir / f"{task_id}.log"
    from studio_backend.models import TaskRecord
    record = TaskRecord(
        id=task_id,
        kind="data_prepare",
        status="pending",
        command=cmd,
        output_dir="",
        created_at=created,
        updated_at=created,
        log_path=str(log_path),
        payload={"_type": "data_prepare", "pool_name": pool_name, "pool_size": pool_size, "total_symbols": len(symbols)},
    )
    from studio_backend.services.tasks import save_task
    save_task(record)
    asyncio.create_task(run_task(task_id))
    return {"task_id": task_id, "total_symbols": len(symbols)}


def _list_cached_symbols(cache_dir: Path) -> list[str]:
    """List all symbol codes from DuckDB store (fallback to PKL glob)."""
    db_path = cache_dir / "market.duckdb"
    if db_path.exists():
        try:
            from v5.data.store import MarketStore
            with MarketStore(str(db_path), read_only=True) as store:
                rows = store._conn.execute(
                    "SELECT DISTINCT symbol FROM daily_bars ORDER BY symbol"
                ).fetchall()
                if rows:
                    return [str(r[0]) for r in rows]
        except Exception:
            pass
    return sorted(
        p.stem.replace("_full", "")
        for p in cache_dir.glob("*_full.pkl")
        if p.stem.replace("_full", "").isdigit()
    )


@app.get("/api/data/consistency-check")
async def api_data_consistency_check(
    pool_name: str | None = None,
    pool_size: int = 0,
    pool_sampling: str = "random",
    pool_seed: int = 42,
    sample_size: int = 30,
) -> dict:
    """Sample stocks and compare PKL cache against live mootdx 前复权 data.

    Key insight: 前复权 vs 不复权 prices are IDENTICAL for recent bars —
    the difference only shows in HISTORICAL bars (before the last 除权 event).
    So we must compare bars from ~6+ months ago, not the latest 10.
    """
    import random as _random
    from datetime import datetime, UTC

    cache_dir = ROOT / "cache"

    # Auto-detect symbols from cache if no pool specified
    if pool_name or pool_size > 0:
        try:
            symbols = _resolve_pool_symbols(pool_name, pool_size or 300, pool_sampling, pool_seed)
        except Exception as e:
            raise HTTPException(400, str(e))
    else:
        symbols = _list_cached_symbols(cache_dir)

    if not symbols:
        return {
            "total_symbols": 0, "total_cached": 0, "checked": 0,
            "consistent": 0, "inconsistent": 0, "errors": 0,
            "inconsistent_symbols": [], "checked_at": datetime.now(UTC).isoformat(),
            "oldest_update": None, "newest_update": None,
        }

    cached_syms = _list_cached_symbols(cache_dir)
    sample = _random.sample(cached_syms, min(sample_size, len(cached_syms)))

    db_path = cache_dir / "market.duckdb"
    store = None
    if db_path.exists():
        try:
            from v5.data.store import MarketStore
            store = MarketStore(str(db_path), read_only=True)
        except Exception:
            pass

    from cq_backtest.data.feed import DataFeed
    feed = DataFeed(cache_dir=str(cache_dir), store=store)
    feed._ensure_connected()
    if feed.client is None:
        if store:
            store.close()
        raise HTTPException(503, "Cannot connect to mootdx server")

    inconsistent: list[dict] = []
    consistent_count = 0
    error_count = 0
    skipped = 0

    for sym in sample:
        try:
            disk_df = None
            if store:
                disk_df = store.read_bars(sym)
            if disk_df is None or disk_df.empty:
                pkl_path = cache_dir / f"{sym}_full.pkl"
                if pkl_path.exists():
                    disk_df = pd.read_pickle(pkl_path)
            if disk_df is None or disk_df.empty or len(disk_df) < 50:
                skipped += 1
                continue
            disk_df.index = pd.to_datetime(disk_df.index)

            fresh_df = feed._fetch_full_history(sym, max_bars=400)
            if fresh_df.empty:
                skipped += 1
                continue

            overlap = disk_df.index.intersection(fresh_df.index)
            if len(overlap) < 5:
                consistent_count += 1
                continue

            overlap_sorted = overlap.sort_values()
            old_half = overlap_sorted[: len(overlap_sorted) // 2]
            if len(old_half) < 3:
                old_half = overlap_sorted

            old_close = disk_df.loc[old_half, "close"].astype(float)
            new_close = fresh_df.loc[old_half, "close"].astype(float)
            dev = ((new_close - old_close) / old_close.replace(0, float("nan"))).abs()
            max_dev = float(dev.max()) if not dev.empty else 0.0

            if max_dev > 0.005:
                inconsistent.append({
                    "symbol": sym,
                    "max_deviation_pct": round(max_dev * 100, 2),
                    "overlap_bars": int(len(old_half)),
                    "sample_date": str(old_half[0])[:10],
                })
            else:
                consistent_count += 1
        except Exception:
            error_count += 1

    try:
        if feed.client is not None:
            feed.client.close()
    except Exception:
        pass
    if store:
        store.close()

    total_cached = len(cached_syms)
    sentinel = cache_dir / ".qfq_migrated"

    # Timestamps from DuckDB metadata
    oldest_update = None
    newest_update = None
    if db_path.exists():
        try:
            from v5.data.store import MarketStore
            with MarketStore(str(db_path), read_only=True) as _s:
                ts_map = _s.get_refresh_timestamps()
                if ts_map:
                    oldest_update = datetime.fromtimestamp(min(ts_map.values()), tz=UTC).isoformat()
                    newest_update = datetime.fromtimestamp(max(ts_map.values()), tz=UTC).isoformat()
        except Exception:
            pass

    return {
        "total_symbols": len(symbols),
        "total_cached": total_cached,
        "checked": len(sample),
        "consistent": consistent_count,
        "inconsistent": len(inconsistent),
        "errors": error_count,
        "skipped": skipped,
        "inconsistent_symbols": inconsistent,
        "checked_at": datetime.now(UTC).isoformat(),
        "oldest_update": oldest_update,
        "newest_update": newest_update,
        "qfq_migrated": sentinel.exists(),
    }


@app.post("/api/data/full-refresh")
async def api_data_full_refresh(payload: dict) -> dict:
    """Trigger a full history re-fetch (force_refresh) for all or specific symbols."""
    pool_name = payload.get("pool_name")
    pool_size = int(payload.get("pool_size", 300))
    pool_sampling = str(payload.get("pool_sampling", "random"))
    pool_seed = int(payload.get("pool_seed", 42))
    target_symbols = payload.get("symbols")

    if target_symbols and isinstance(target_symbols, list):
        symbols = [str(s).zfill(6) for s in target_symbols]
    else:
        try:
            symbols = _resolve_pool_symbols(pool_name, pool_size, pool_sampling, pool_seed)
        except Exception as e:
            raise HTTPException(400, str(e))

    import uuid as _uuid, sys as _sys
    from datetime import datetime, UTC
    task_id = _uuid.uuid4().hex[:12]
    created = datetime.now(UTC)
    cache_dir = str(ROOT / "cache")
    sentinel_path = str(ROOT / "cache" / ".qfq_migrated")
    cmd = [
        _sys.executable, "-c",
        f"from v5.data.prefetch import prefetch_symbols; "
        f"prefetch_symbols({symbols!r}, cache_dir={cache_dir!r}, workers=4, force_refresh=True); "
        f"open({sentinel_path!r}, 'w').write('qfq')",
    ]
    log_path = get_settings().tasks_dir / f"{task_id}.log"
    from studio_backend.models import TaskRecord
    record = TaskRecord(
        id=task_id,
        kind="data_prepare",
        status="pending",
        command=cmd,
        output_dir="",
        created_at=created,
        updated_at=created,
        log_path=str(log_path),
        payload={"_type": "full_refresh", "total_symbols": len(symbols), "force_refresh": True},
    )
    from studio_backend.services.tasks import save_task
    save_task(record)
    asyncio.create_task(run_task(task_id))
    return {"task_id": task_id, "total_symbols": len(symbols), "force_refresh": True}


@app.post("/api/data/refresh-symbol/{symbol}")
async def api_refresh_symbol(symbol: str) -> dict:
    """Force full re-fetch for a single symbol (debugging helper)."""
    sym = symbol.zfill(6)
    cache_dir = str(ROOT / "cache")

    import uuid as _uuid, sys as _sys
    from datetime import datetime, UTC
    task_id = _uuid.uuid4().hex[:12]
    created = datetime.now(UTC)
    cmd = [
        _sys.executable, "-c",
        f"from v5.data.prefetch import prefetch_symbols; "
        f"prefetch_symbols([{sym!r}], cache_dir={cache_dir!r}, workers=1, force_refresh=True)",
    ]
    log_path = get_settings().tasks_dir / f"{task_id}.log"
    from studio_backend.models import TaskRecord
    record = TaskRecord(
        id=task_id,
        kind="data_prepare",
        status="pending",
        command=cmd,
        output_dir="",
        created_at=created,
        updated_at=created,
        log_path=str(log_path),
        payload={"_type": "refresh_symbol", "symbol": sym, "force_refresh": True},
    )
    from studio_backend.services.tasks import save_task
    save_task(record)
    asyncio.create_task(run_task(task_id))
    return {"task_id": task_id, "symbol": sym}


@app.get("/api/tasks")
def api_tasks() -> list[dict]:
    return [x.model_dump(mode="json") for x in list_tasks()]


async def _run_and_invalidate(task_id: str) -> None:
    await run_task(task_id)
    _invalidate_batch_stats_cache()


@app.post("/api/tasks/backtest")
async def api_create_backtest(payload: BacktestRequest) -> dict:
    task = create_task("backtest", payload)
    asyncio.create_task(_run_and_invalidate(task.id))
    return task.model_dump(mode="json")


@app.post("/api/tasks/signal-scan")
async def api_create_signal_scan(payload: SignalScanRequest) -> dict:
    task = create_task("signal_scan", payload)
    asyncio.create_task(_run_and_invalidate(task.id))
    return task.model_dump(mode="json")


@app.get("/api/task-log")
def api_task_log(task_id: str, tail: int = 80) -> dict:
    task = load_task(task_id)
    if task is None:
        raise HTTPException(status_code=404, detail="task not found")
    log_path = Path(task.log_path)
    if not log_path.exists():
        return {"lines": [], "total_lines": 0}
    all_lines = log_path.read_text(encoding="utf-8", errors="replace").splitlines()
    total = len(all_lines)
    return {"lines": all_lines[-tail:], "total_lines": total}


@app.get("/api/tasks/{task_id}")
def api_task(task_id: str) -> dict:
    task = load_task(task_id)
    if task is None:
        raise HTTPException(status_code=404, detail="task not found")
    return task.model_dump(mode="json")


@app.post("/api/tasks/{task_id}/cancel")
def api_cancel_task(task_id: str) -> dict:
    task = cancel_task(task_id)
    if task is None:
        raise HTTPException(status_code=404, detail="task not found")
    return task.model_dump(mode="json")


@app.delete("/api/tasks/{task_id}")
def api_delete_task(task_id: str) -> dict:
    if not delete_task(task_id):
        raise HTTPException(status_code=404, detail="task not found")
    return {"ok": True}


@app.get("/api/files")
def api_file(path: str) -> FileResponse:
    file_path = Path(path)
    if not file_path.exists():
        raise HTTPException(status_code=404, detail="file not found")
    return FileResponse(file_path)


@app.get("/api/files/text")
def api_file_text(path: str) -> dict:
    file_path = Path(path)
    if not file_path.exists():
        raise HTTPException(status_code=404, detail="file not found")
    return {
        "path": str(file_path),
        "content": file_path.read_text(encoding="utf-8"),
    }


@app.get("/api/results/{name}/meta")
def api_result_meta(name: str) -> dict:
    path = find_result_dir(name)
    if path is None:
        raise HTTPException(status_code=404, detail="result not found")
    meta_path = path / "meta.json"
    if not meta_path.exists():
        raise HTTPException(status_code=404, detail="meta.json not found")
    return json.loads(meta_path.read_text(encoding="utf-8"))


def _compute_overview(result_dir: Path) -> dict:
    """Build a combined overview from summary.json + closed_trades.csv."""
    summary: dict = {}
    summary_path = result_dir / "summary.json"
    if summary_path.exists():
        summary = json.loads(summary_path.read_text(encoding="utf-8"))

    ct = _read_report(result_dir, "closed_trades", dtype={"symbol": str}).fillna(0)
    if ct.empty:
        return {"summary": summary, "stats": {}, "ceiling": None}
    total = len(ct)
    if total == 0:
        return {"summary": summary, "stats": {}, "ceiling": None}

    wins = ct[ct["ret"] > 0]
    losses = ct[ct["ret"] <= 0]
    win_rate = len(wins) / total
    avg_ret = float(ct["ret"].mean())
    avg_hold = float(ct["hold_days"].mean()) if "hold_days" in ct.columns else 0
    avg_mfe = float(ct["mfe"].mean()) if "mfe" in ct.columns else 0
    avg_mae = float(ct["mae"].mean()) if "mae" in ct.columns else 0
    avg_mfe_capture = float(ct["mfe_capture"].mean()) if "mfe_capture" in ct.columns else 0
    total_pnl = float(ct["pnl"].sum()) if "pnl" in ct.columns else 0

    diag_counts: dict = {}
    if "diagnosis" in ct.columns:
        diag_counts = ct["diagnosis"].value_counts().to_dict()

    # Peak equity & max drawdown from equity curve
    peak_equity: float | None = None
    max_drawdown_pct: float | None = None
    max_drawdown_amount: float | None = None
    eq_df = _read_report(result_dir, "equity_curve")
    if not eq_df.empty:
        if "equity" in eq_df.columns and len(eq_df) > 0:
            eq_vals = eq_df["equity"].astype(float)
            peak_equity = float(eq_vals.max())
            running_max = eq_vals.cummax()
            drawdowns = (eq_vals - running_max) / running_max
            max_drawdown_pct = round(float(drawdowns.min()) * 100, 2)
            max_drawdown_amount = round(float((eq_vals - running_max).min()), 2)

    stats = {
        "total_closed": total,
        "win_count": int(len(wins)),
        "loss_count": int(len(losses)),
        "win_rate": round(win_rate, 4),
        "avg_ret_pct": round(avg_ret * 100, 2),
        "avg_hold_days": round(avg_hold, 1),
        "avg_mfe_pct": round(avg_mfe * 100, 2),
        "avg_mae_pct": round(avg_mae * 100, 2),
        "avg_mfe_capture": round(avg_mfe_capture, 3),
        "total_pnl": round(total_pnl, 2),
        "diagnosis": {str(k): int(v) for k, v in diag_counts.items()},
    }
    if peak_equity is not None:
        stats["peak_equity"] = round(peak_equity, 2)
    if max_drawdown_pct is not None:
        stats["max_drawdown_pct"] = max_drawdown_pct
        stats["max_drawdown_amount"] = max_drawdown_amount
    if len(wins) > 0:
        stats["avg_win_ret_pct"] = round(float(wins["ret"].mean()) * 100, 2)
    if len(losses) > 0:
        stats["avg_loss_ret_pct"] = round(float(losses["ret"].mean()) * 100, 2)

    # --- Ceiling / Oracle calculation ---
    # Extended MFE = max(holding-period MFE, post-exit-20d high vs entry).
    # This captures "卖飞" trades where the stock continued rising after we sold.
    # "标的完全选错" trades keep actual ret (oracle can't save a wrong pick).
    has_mfe = "mfe" in ct.columns
    has_diag = "diagnosis" in ct.columns
    has_post = "post_exit_20d_entry_ret" in ct.columns
    ceiling = None
    if has_mfe:
        init_cash = float(summary.get("init_cash", 1_000_000))
        ceiling_pnl = 0.0
        actual_pnl = 0.0
        ceiling_wins = 0
        wrong_count = 0
        # Per-trade deltas keyed by exit_date for oracle curve
        trade_deltas: list[tuple[str, float]] = []
        for _, row in ct.iterrows():
            entry_cost = float(row["entry_price"]) * float(row["qty"])
            actual_ret = float(row["ret"])
            mfe = float(row.get("mfe", 0))
            post_ret = float(row.get("post_exit_20d_entry_ret", 0)) if has_post else 0.0
            extended_mfe = max(mfe, post_ret)
            diag = str(row.get("diagnosis", "")) if has_diag else ""
            is_wrong = diag == "标的完全选错"
            if is_wrong:
                wrong_count += 1
            ceiling_ret = actual_ret if is_wrong else max(extended_mfe, actual_ret)
            ceiling_trade_pnl = entry_cost * ceiling_ret
            actual_trade_pnl = entry_cost * actual_ret
            delta = ceiling_trade_pnl - actual_trade_pnl
            ceiling_pnl += ceiling_trade_pnl
            actual_pnl += actual_trade_pnl
            if ceiling_ret > 0:
                ceiling_wins += 1
            exit_date = str(row.get("exit_date", ""))[:10]
            if exit_date and delta != 0:
                trade_deltas.append((exit_date, delta))

        ceiling_equity = init_cash + ceiling_pnl
        actual_equity = init_cash + actual_pnl

        # Build oracle equity curve: actual curve + cumulative trade deltas
        oracle_curve = _build_oracle_curve(result_dir, summary_path, trade_deltas)

        ceiling = {
            "ceiling_equity": round(ceiling_equity, 2),
            "ceiling_return_pct": round((ceiling_equity / init_cash - 1) * 100, 2),
            "ceiling_win_rate": round(ceiling_wins / total, 4) if total > 0 else 0,
            "ceiling_total_pnl": round(ceiling_pnl, 2),
            "actual_equity": round(actual_equity, 2),
            "actual_return_pct": round((actual_equity / init_cash - 1) * 100, 2),
            "wrong_count": wrong_count,
            "ceiling_uplift_pct": round((ceiling_pnl - actual_pnl) / init_cash * 100, 2) if init_cash > 0 else 0,
            "oracle_curve": oracle_curve,
        }

    return {"summary": summary, "stats": stats, "ceiling": ceiling}


def _build_oracle_curve(
    result_dir: Path,
    summary_path: Path,
    trade_deltas: list[tuple[str, float]],
) -> list[dict]:
    """Overlay oracle PnL deltas onto the actual equity curve."""
    eq_df = _read_report(result_dir, "equity_curve")
    if eq_df.empty or "equity" not in eq_df.columns:
        return []
    if len(eq_df) > 2000:
        eq_df["date"] = eq_df["date"].astype(str)
        eq_df = eq_df.groupby("date", sort=True)["equity"].last().reset_index()
    actual_points = [(str(r["date"])[:10], float(r["equity"])) for _, r in eq_df.iterrows()]

    if not actual_points or not trade_deltas:
        return []

    # Aggregate deltas by date (multiple trades can exit same day)
    delta_by_date: dict[str, float] = {}
    for d, delta in trade_deltas:
        delta_by_date[d] = delta_by_date.get(d, 0.0) + delta

    # Sort dates for cumulative walk
    sorted_delta_dates = sorted(delta_by_date.keys())
    cum_delta = 0.0
    delta_idx = 0
    oracle: list[dict] = []
    for date, equity in actual_points:
        while delta_idx < len(sorted_delta_dates) and sorted_delta_dates[delta_idx] <= date:
            cum_delta += delta_by_date[sorted_delta_dates[delta_idx]]
            delta_idx += 1
        oracle.append({"date": date, "equity": round(equity + cum_delta, 2)})

    return oracle


@app.get("/api/results/{name}/overview")
def api_result_overview(name: str) -> dict:
    path = find_result_dir(name)
    if path is None:
        raise HTTPException(status_code=404, detail="result not found")
    return _compute_overview(path)


def _reconstruct_equity_from_trades(trades: pd.DataFrame, summary_path: Path) -> list[dict]:
    """Reconstruct equity curve from trades by tracking positions.

    At each trade point: equity = cash + sum(held_qty * last_known_price).
    """
    init_cash = 1_000_000.0
    if summary_path.exists():
        s = json.loads(summary_path.read_text(encoding="utf-8"))
        init_cash = float(s.get("init_cash", init_cash))

    positions: dict[str, dict] = {}  # symbol -> {qty, last_price}
    points: list[dict] = []
    last_date = ""

    for _, row in trades.iterrows():
        symbol = str(row.get("symbol", ""))
        action = str(row.get("action", ""))
        price = float(row.get("price", 0))
        qty = float(row.get("qty", 0))
        cash = float(row.get("cash_after", 0))
        date = str(row.get("date", ""))

        if action == "buy":
            pos = positions.setdefault(symbol, {"qty": 0.0, "last_price": price})
            pos["qty"] += qty
            pos["last_price"] = price
        elif action == "sell":
            if symbol in positions:
                positions[symbol]["qty"] -= qty
                positions[symbol]["last_price"] = price
                if positions[symbol]["qty"] <= 1e-9:
                    del positions[symbol]

        market_value = sum(p["qty"] * p["last_price"] for p in positions.values())
        equity = round(cash + market_value, 2)

        if date == last_date and points:
            points[-1]["equity"] = equity
        else:
            points.append({"date": date, "equity": equity})
            last_date = date

    if not points or points[0]["equity"] != init_cash:
        first_date = points[0]["date"] if points else ""
        points.insert(0, {"date": first_date, "equity": init_cash})

    return points


@app.get("/api/results/{name}/equity-curve")
def api_equity_curve(name: str) -> list[dict]:
    path = find_result_dir(name)
    if path is None:
        raise HTTPException(status_code=404, detail="result not found")
    df = _read_report(path, "equity_curve")
    if not df.empty and "equity" in df.columns:
        if len(df) > 2000:
            df["date"] = df["date"].astype(str)
            df = df.groupby("date", sort=True)["equity"].last().reset_index()
        return [{"date": str(r["date"]), "equity": float(r["equity"])} for _, r in df.iterrows()]
    trades = _read_report(path, "trades")
    if trades.empty:
        raise HTTPException(status_code=404, detail="no equity data found")
    if "cash_after" not in trades.columns:
        raise HTTPException(status_code=404, detail="cash_after column not found")
    return _reconstruct_equity_from_trades(trades, path / "summary.json")


def _load_stock_names() -> dict[str, str]:
    """Load symbol -> name mapping from mootdx stock_list cache."""
    pkl = ROOT / "cache" / "stock_list.pkl"
    if not pkl.exists():
        return {}
    try:
        df = pd.read_pickle(pkl)
        code_col = "code" if "code" in df.columns else df.columns[1]
        name_col = "name" if "name" in df.columns else None
        if not name_col:
            return {}
        out: dict[str, str] = {}
        for _, row in df.iterrows():
            sym = str(row[code_col]).zfill(6)
            out[sym] = str(row[name_col]).strip()
        return out
    except Exception:
        return {}


_stock_name_cache: dict[str, str] | None = None


def _get_stock_names() -> dict[str, str]:
    global _stock_name_cache
    if _stock_name_cache is None:
        _stock_name_cache = _load_stock_names()
    return _stock_name_cache


@app.get("/api/results/{name}/notable-trades")
def api_notable_trades(name: str, top_n: int = 5) -> list[dict]:
    """Return top best and worst closed trades for chart markers.

    Uses the same PnL% as the trades table (fee-adjusted `ret` from
    closed_trades or 实际盈亏(%) from master table) so chart markers
    and table values are consistent.
    """
    path = find_result_dir(name)
    if path is None:
        raise HTTPException(status_code=404, detail="result not found")

    names = _get_stock_names()

    # --- Strategy 1: master table (same source as the trades table UI) ---
    master_path = path / "all_trades_master_table.csv"
    if master_path.exists():
        mt = pd.read_csv(master_path, encoding="utf-8-sig").fillna("")
        sym_col = "股票代码" if "股票代码" in mt.columns else None
        pnl_col = "实际盈亏(%)" if "实际盈亏(%)" in mt.columns else None
        buy_col = "买入日期" if "买入日期" in mt.columns else None
        sell_col = "卖出日期" if "卖出日期" in mt.columns else None
        name_col = "股票名称" if "股票名称" in mt.columns else None
        reason_col = "出场原因" if "出场原因" in mt.columns else None
        buy_price_col = "买入价" if "买入价" in mt.columns else None
        sell_price_col = "卖出价" if "卖出价" in mt.columns else None
        if sym_col and pnl_col and buy_col and sell_col:
            mt[sym_col] = mt[sym_col].astype(str).str.zfill(6)
            mt[pnl_col] = pd.to_numeric(mt[pnl_col], errors="coerce").fillna(0)
            mt_sorted = mt.sort_values(pnl_col)
            worst = mt_sorted.head(top_n)
            best = mt_sorted.tail(top_n).iloc[::-1]
            combined = pd.concat([best, worst]).drop_duplicates(subset=[sym_col, sell_col])
            out = []
            for _, row in combined.iterrows():
                sym = str(row[sym_col])
                entry: dict = {
                    "symbol": sym,
                    "name": str(row[name_col]) if name_col else names.get(sym, ""),
                    "buy_date": str(row[buy_col]),
                    "sell_date": str(row[sell_col]),
                    "buy_price": round(float(row[buy_price_col]), 2) if buy_price_col and row.get(buy_price_col, "") != "" else 0,
                    "sell_price": round(float(row[sell_price_col]), 2) if sell_price_col and row.get(sell_price_col, "") != "" else 0,
                    "pnl_pct": round(float(row[pnl_col]), 2),
                    "reason": str(row[reason_col]) if reason_col else "",
                }
                _safe = lambda c: str(row[c]) if c in mt.columns and str(row.get(c, "")) != "" else ""
                entry["signal_type"] = _safe("识别类型")
                entry["post_trend"] = _safe("后续走向定性")
                entry["diagnosis"] = _safe("交易诊断")
                mfe_col = "最高利润MFE(%)" if "最高利润MFE(%)" in mt.columns else None
                entry["mfe_pct"] = round(float(row[mfe_col]), 2) if mfe_col and row.get(mfe_col, "") != "" else None
                out.append(entry)
            return out

    # --- Strategy 2: closed_trades with fee-adjusted ret ---
    ct = _read_report(path, "closed_trades").fillna("")
    if not ct.empty:
        if "ret" in ct.columns and "symbol" in ct.columns:
            ct["symbol"] = ct["symbol"].astype(str).str.zfill(6)
            ct["pnl_pct"] = pd.to_numeric(ct["ret"], errors="coerce").fillna(0) * 100
            ct_sorted = ct.sort_values("pnl_pct")
            worst = ct_sorted.head(top_n)
            best = ct_sorted.tail(top_n).iloc[::-1]
            combined = pd.concat([best, worst]).drop_duplicates(subset=["symbol", "exit_date"])
            out = []
            for _, row in combined.iterrows():
                sym = str(row["symbol"])
                out.append({
                    "symbol": sym,
                    "name": names.get(sym, ""),
                    "buy_date": str(row.get("entry_date", "")),
                    "sell_date": str(row.get("exit_date", "")),
                    "buy_price": round(float(row.get("entry_price", 0)), 2),
                    "sell_price": round(float(row.get("exit_price", 0)), 2),
                    "pnl_pct": round(float(row["pnl_pct"]), 2),
                    "reason": str(row.get("exit_reason", "")),
                    "signal_type": "",
                    "post_trend": "",
                    "diagnosis": str(row.get("diagnosis", "")),
                    "mfe_pct": round(float(row.get("mfe", 0)) * 100, 2) if row.get("mfe", "") != "" else None,
                })
            return out

    # --- Strategy 3: pair buys/sells from trades.csv ---
    df = _read_report(path, "trades", dtype={"symbol": str}).fillna("")
    if df.empty:
        return []
    df["symbol"] = df["symbol"].astype(str).str.zfill(6)
    buys = df[df["action"] == "buy"]
    sells = df[df["action"] == "sell"]
    if buys.empty or sells.empty:
        return []
    closed: list[dict] = []
    buy_map: dict[str, list[dict]] = {}
    has_limits = "limit_up" in df.columns
    for _, row in buys.iterrows():
        sym = str(row["symbol"])
        entry = {"date": str(row["date"]), "price": float(row["price"])}
        if has_limits:
            lu = row.get("limit_up")
            if lu != "" and pd.notna(lu):
                entry["limit_up"] = float(lu)
        buy_map.setdefault(sym, []).append(entry)
    for _, row in sells.iterrows():
        sym = str(row["symbol"])
        if sym not in buy_map or not buy_map[sym]:
            continue
        b = buy_map[sym].pop(0)
        sell_price = float(row["price"])
        buy_price = float(b["price"])
        pnl_pct = (sell_price / buy_price - 1) * 100 if buy_price else 0
        rec: dict = {
            "symbol": sym,
            "name": names.get(sym, ""),
            "buy_date": b["date"],
            "sell_date": str(row["date"]),
            "buy_price": round(buy_price, 2),
            "sell_price": round(sell_price, 2),
            "pnl_pct": round(pnl_pct, 2),
            "reason": str(row.get("reason", "")),
        }
        if "limit_up" in b:
            rec["buy_limit_up"] = round(b["limit_up"], 2)
        if has_limits:
            ld = row.get("limit_down")
            if ld != "" and pd.notna(ld):
                rec["sell_limit_down"] = round(float(ld), 2)
        closed.append(rec)
    if not closed:
        return []
    closed.sort(key=lambda x: x["pnl_pct"])
    worst = closed[:top_n]
    best = closed[-top_n:]
    best.reverse()
    seen = set()
    out = []
    for t in best + worst:
        key = (t["symbol"], t["sell_date"])
        if key not in seen:
            seen.add(key)
            out.append(t)
    return out


@app.get("/api/results/{name}/summary")
def api_result_summary(name: str) -> dict:
    """Return the markdown summary and structured snapshot from a signal scan."""
    path = find_result_dir(name)
    if path is None:
        raise HTTPException(status_code=404, detail="result not found")

    result: dict = {"markdown": "", "snapshot": None}
    summary_path = path / "summary.md"
    if summary_path.exists():
        result["markdown"] = summary_path.read_text(encoding="utf-8")
    snapshot_path = path / "snapshot.json"
    if snapshot_path.exists():
        result["snapshot"] = json.loads(snapshot_path.read_text(encoding="utf-8"))
    if not result["markdown"] and result["snapshot"] is None:
        raise HTTPException(status_code=404, detail="no summary or snapshot found")
    return result


@app.get("/api/results/{name}/trades")
def api_trades(name: str, page: int = 1, page_size: int = 50,
               sort_by: str = "", sort_dir: str = "desc",
               find_symbol: str = "", find_sell_date: str = "") -> dict:
    path = find_result_dir(name)
    if path is None:
        raise HTTPException(status_code=404, detail="result not found")
    master_path = path / "all_trades_master_table.csv"
    if master_path.exists() and master_path.stat().st_size > 0:
        try:
            trades = pd.read_csv(master_path, dtype={"股票代码": str}).fillna("")
        except pd.errors.EmptyDataError:
            trades = pd.DataFrame()
        source = "master"
    else:
        trades = _read_report(path, "trades", dtype={"symbol": str}).fillna("")
        source = "trades"
    if trades.empty:
        return {"total": 0, "page": 1, "page_size": page_size, "source": "empty", "columns": [], "rows": []}
    for col in ["股票代码", "symbol"]:
        if col in trades.columns:
            trades[col] = trades[col].astype(str).str.zfill(6)

    if sort_by and sort_by in trades.columns:
        col_numeric = pd.to_numeric(trades[sort_by], errors="coerce")
        if col_numeric.notna().sum() > len(trades) * 0.5:
            trades["_sort_key"] = col_numeric
        else:
            trades["_sort_key"] = trades[sort_by].astype(str)
        trades = trades.sort_values("_sort_key", ascending=(sort_dir == "asc"), na_position="last")
        trades = trades.drop(columns=["_sort_key"])
        trades = trades.reset_index(drop=True)

    total = len(trades)

    found_page: int | None = None
    found_index: int | None = None
    if find_symbol and find_sell_date:
        sym = find_symbol.zfill(6)
        sym_col = "股票代码" if "股票代码" in trades.columns else "symbol"
        sell_col = "卖出日期" if "卖出日期" in trades.columns else "exit_date"
        if sym_col in trades.columns and sell_col in trades.columns:
            mask = (trades[sym_col] == sym) & (trades[sell_col].astype(str) == find_sell_date)
            idxs = trades.index[mask].tolist()
            if idxs:
                row_num = idxs[0]
                found_page = row_num // page_size + 1
                found_index = row_num % page_size
                page = found_page

    start_idx = (page - 1) * page_size
    end_idx = start_idx + page_size
    page_data = trades.iloc[start_idx:end_idx]
    result = {
        "total": total,
        "page": page,
        "page_size": page_size,
        "source": source,
        "columns": list(trades.columns),
        "rows": page_data.to_dict(orient="records"),
    }
    if found_page is not None:
        result["found_page"] = found_page
        result["found_index"] = found_index
    return result


@app.get("/api/state/watch")
def api_watch_state() -> dict:
    settings = get_settings()
    state_path = settings.outputs_state_dir / "watch_state.json"
    if not state_path.exists():
        return {}
    return json.loads(state_path.read_text(encoding="utf-8"))


@app.get("/api/signal-oracle")
def api_signal_oracle() -> dict:
    from v5.notify.oracle_constants import ORACLE_META, POOL_BASELINE, SIGNAL_ORACLE
    return {"oracle": SIGNAL_ORACLE, "pool_baseline": POOL_BASELINE, "meta": ORACLE_META}


@app.get("/api/state/audit")
def api_audit(limit: int = 200) -> list[dict]:
    settings = get_settings()
    path = settings.outputs_state_dir / "audit.jsonl"
    if not path.exists():
        return []
    lines = path.read_text(encoding="utf-8").strip().split("\n")
    return [json.loads(line) for line in lines[-limit:] if line.strip()]


@app.get("/api/schedules")
def api_schedules() -> list[dict]:
    schedules = list_schedules()
    out = []
    for item in schedules:
        payload = item.model_dump(mode="json")
        payload["cron_line"] = build_cron_line(item)
        out.append(payload)
    return out


@app.post("/api/schedules")
def api_save_schedule(payload: ScheduleConfig) -> dict:
    item = save_schedule(payload)
    out = item.model_dump(mode="json")
    out["cron_line"] = build_cron_line(item)
    return out


@app.delete("/api/schedules/{schedule_id}")
def api_delete_schedule(schedule_id: str) -> dict:
    if not delete_schedule(schedule_id):
        raise HTTPException(404, f"Schedule {schedule_id} not found")
    return {"deleted": schedule_id}


@app.patch("/api/schedules/{schedule_id}")
def api_toggle_schedule(schedule_id: str, body: dict) -> dict:
    enabled = bool(body.get("enabled", True))
    item = toggle_schedule(schedule_id, enabled)
    if item is None:
        raise HTTPException(404, f"Schedule {schedule_id} not found")
    out = item.model_dump(mode="json")
    out["cron_line"] = build_cron_line(item)
    return out


# ---------------------------------------------------------------------------
# SPA static file serving (production: built frontend in studio_frontend/dist)
# ---------------------------------------------------------------------------
_DIST_DIR = ROOT / "studio_frontend" / "dist"

if _DIST_DIR.is_dir():
    app.mount("/assets", StaticFiles(directory=_DIST_DIR / "assets"), name="static-assets")

    @app.get("/{full_path:path}")
    async def _spa_fallback(request: Request, full_path: str):
        file_path = _DIST_DIR / full_path
        if file_path.is_file():
            return FileResponse(file_path)
        return FileResponse(_DIST_DIR / "index.html")
