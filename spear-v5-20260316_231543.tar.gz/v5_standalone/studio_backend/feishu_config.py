from __future__ import annotations

import json
import os
from pathlib import Path

from studio_backend.config import get_settings


def feishu_config_path() -> Path:
    return get_settings().studio_state_dir / "feishu.json"


def load_feishu_config() -> dict[str, str]:
    """Load feishu config from file, falling back to env vars."""
    path = feishu_config_path()
    if path.exists():
        try:
            cfg = json.loads(path.read_text(encoding="utf-8"))
            return {
                "webhook": cfg.get("webhook") or os.environ.get("FEISHU_WEBHOOK", ""),
                "secret": cfg.get("secret") or os.environ.get("FEISHU_SECRET", ""),
            }
        except Exception:
            pass
    return {
        "webhook": os.environ.get("FEISHU_WEBHOOK", ""),
        "secret": os.environ.get("FEISHU_SECRET", ""),
    }
