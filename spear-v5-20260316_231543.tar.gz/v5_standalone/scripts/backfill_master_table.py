#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from v4.reports.analytics import build_trade_master_table
from v5.backtest.prepare import prepare_bundle
from v5.config.defaults import apply_execution_profile, load_default_config
from v5.config.pools import resolve_named_pool


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="Backfill all_trades_master_table.csv for v5 backtest outputs.")
    p.add_argument("result_dirs", nargs="*", help="Result directory names or absolute paths.")
    p.add_argument("--root", default=str(ROOT / "outputs" / "backtests"), help="Backtest results root directory.")
    p.add_argument("--force", action="store_true", help="Rebuild even if all_trades_master_table.csv already exists.")
    p.add_argument("--mootdx-cache-only", action="store_true", help="Use cache-only mode when rebuilding context.")
    return p


def _resolve_targets(root: Path, result_dirs: list[str], force: bool) -> list[Path]:
    if result_dirs:
        targets = []
        for item in result_dirs:
            path = Path(item)
            if not path.is_absolute():
                path = root / item
            targets.append(path)
        return targets
    targets = []
    for path in sorted(p for p in root.iterdir() if p.is_dir()):
        if force or not (path / "all_trades_master_table.csv").exists():
            targets.append(path)
    return targets


def _load_cfg(meta_cfg: dict, mootdx_cache_only: bool) -> tuple:
    cfg = load_default_config()
    cfg.data.warmup_bars = int(meta_cfg.get("warmup_bars", cfg.data.warmup_bars))
    cfg.data.pool_sampling = str(meta_cfg.get("pool_sampling", cfg.data.pool_sampling))
    cfg.data.pool_seed = int(meta_cfg.get("pool_seed", cfg.data.pool_seed))
    cfg.data.disable_env_mapping = bool(meta_cfg.get("disable_env_mapping", cfg.data.disable_env_mapping))
    cfg.data.mootdx_cache_only = mootdx_cache_only
    cfg = apply_execution_profile(cfg, str(meta_cfg.get("execution_profile", cfg.execution.execution_profile)))
    cfg.execution.hunt_price_buffer_pct = float(meta_cfg.get("hunt_price_buffer_pct", cfg.execution.hunt_price_buffer_pct))
    cfg.execution.hunt_window_days = int(meta_cfg.get("hunt_window_days", cfg.execution.hunt_window_days))
    cfg.execution.exit_mode = str(meta_cfg.get("exit_mode", cfg.execution.exit_mode))
    cfg.execution.exit_hunt_buffer_pct = float(meta_cfg.get("exit_hunt_buffer_pct", cfg.execution.exit_hunt_buffer_pct))
    cfg.execution.exit_hunt_window_days = int(meta_cfg.get("exit_hunt_window_days", cfg.execution.exit_hunt_window_days))
    cfg.execution.trend_spear_stop_mode = str(meta_cfg.get("trend_spear_stop_mode", cfg.execution.trend_spear_stop_mode))
    cfg.execution.trend_spear_stop_grace_days = int(meta_cfg.get("trend_spear_stop_grace_days", cfg.execution.trend_spear_stop_grace_days))
    cfg.execution.max_positions = int(meta_cfg.get("max_positions", cfg.execution.max_positions))
    cfg.execution.base_pos_pct = float(meta_cfg.get("base_pos_pct", cfg.execution.base_pos_pct))
    cfg.execution.cooldown_days = int(meta_cfg.get("cooldown_days", cfg.execution.cooldown_days))
    cfg.execution.default_take_profit_pct = float(meta_cfg.get("take_profit_pct", cfg.execution.default_take_profit_pct))
    pos_mults = meta_cfg.get("position_multipliers", {}) or {}
    cfg.execution.trend_spear_pos_mult = float(pos_mults.get("trend_spear", cfg.execution.trend_spear_pos_mult))
    cfg.execution.post_limit_pos_mult = float(pos_mults.get("post_limit", cfg.execution.post_limit_pos_mult))
    cfg.execution.failed_board_pos_mult = float(pos_mults.get("failed_board", cfg.execution.failed_board_pos_mult))
    cfg.execution.youzi_pos_mult = float(pos_mults.get("youzi", cfg.execution.youzi_pos_mult))
    cfg.execution.sector_spear_pos_mult = float(pos_mults.get("sector_spear", cfg.execution.sector_spear_pos_mult))
    cfg.execution.attack_pos_mult = float(pos_mults.get("attack", cfg.execution.attack_pos_mult))
    cfg.execution.arb_pos_mult = float(pos_mults.get("arb", cfg.execution.arb_pos_mult))
    start = str(meta_cfg["start"])
    end = str(meta_cfg["end"])
    active_event_types = meta_cfg.get("enable_events")
    if isinstance(active_event_types, list) and active_event_types:
        active_event_types = {str(x) for x in active_event_types}
    else:
        active_event_types = None
    return cfg, start, end, active_event_types


def _load_symbols(result_dir: Path, meta_cfg: dict) -> list[str]:
    pool_name = str(meta_cfg.get("pool_name", "") or "")
    if pool_name:
        return resolve_named_pool(pool_name)
    events_path = result_dir / "events.csv"
    if events_path.exists():
        events = pd.read_csv(events_path, dtype={"symbol": str})
        if "symbol" in events.columns:
            symbols = events["symbol"].astype(str).str.zfill(6).drop_duplicates().tolist()
            if symbols:
                return symbols
    trades_path = result_dir / "trades.csv"
    if trades_path.exists():
        trades = pd.read_csv(trades_path, dtype={"symbol": str})
        if "symbol" in trades.columns:
            symbols = trades["symbol"].astype(str).str.zfill(6).drop_duplicates().tolist()
            if symbols:
                return symbols
    raise ValueError(f"Unable to infer symbols for {result_dir}")


def backfill_one(result_dir: Path, force: bool, mootdx_cache_only: bool) -> str:
    meta_path = result_dir / "meta.json"
    closed_path = result_dir / "closed_trades.csv"
    events_path = result_dir / "events.csv"
    output_path = result_dir / "all_trades_master_table.csv"
    if not meta_path.exists() or not closed_path.exists() or not events_path.exists():
        raise FileNotFoundError(f"Missing required files under {result_dir}")
    if output_path.exists() and not force:
        return "skip"

    meta = json.loads(meta_path.read_text(encoding="utf-8"))
    meta_cfg = dict(meta.get("config", {}))
    cfg, start, end, active_event_types = _load_cfg(meta_cfg, mootdx_cache_only=mootdx_cache_only)
    symbols = _load_symbols(result_dir, meta_cfg)

    bundle = prepare_bundle(
        cfg,
        start=start,
        end=end,
        pool_size=len(symbols),
        symbols=symbols,
        active_event_types=active_event_types,
    )
    closed = pd.read_csv(closed_path)
    events = pd.read_csv(events_path)
    master = build_trade_master_table(
        closed,
        events,
        cfg=cfg,
        start=start,
        end=end,
        bars_cache=bundle.feature_data,
        env=bundle.env,
    )
    master.to_csv(output_path, index=False, encoding="utf-8-sig")
    return "write"


def main() -> None:
    args = build_parser().parse_args()
    root = Path(args.root)
    targets = _resolve_targets(root, args.result_dirs, force=args.force)
    if not targets:
        print("No result directories need backfill.")
        return
    for path in targets:
        status = backfill_one(path, force=args.force, mootdx_cache_only=args.mootdx_cache_only)
        print(f"{status.upper()} {path}")


if __name__ == "__main__":
    main()
