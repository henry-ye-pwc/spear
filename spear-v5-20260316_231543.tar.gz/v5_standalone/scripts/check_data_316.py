#!/usr/bin/env python3
"""Diagnose daily vs minute data for pool symbols: 3-16 availability and placeholder status."""
from __future__ import annotations

import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import pandas as pd

def main():
    from v5.config.defaults import load_default_config
    from v5.data.providers.mootdx_provider import MootdxProvider
    from v5.config.pools import list_named_pools, resolve_named_pool

    cfg = load_default_config()
    cache_dir = cfg.data.mootdx_cache_dir
    if not os.path.isabs(cache_dir):
        cache_dir = str(ROOT / cache_dir)
    target_date = "2026-03-16"

    # Pool symbols (small sample for speed)
    pool_size = min(30, getattr(cfg.backtest, "pool_size", 500))
    prov = MootdxProvider(
        cache_dir=cache_dir,
        pool_sampling=cfg.data.pool_sampling,
        pool_seed=cfg.data.pool_seed,
        cache_only=True,
    )
    uni = prov.load_universe(pool_size)
    if uni.empty:
        print("[check] No universe from MootdxProvider; trying code.txt ...")
        from v5.config.pools import ROOT as POOLS_ROOT, _extract_symbols
        code_txt = POOLS_ROOT / "code.txt"
        if code_txt.exists():
            syms = _extract_symbols(code_txt.read_text(encoding="utf-8", errors="ignore"))[:30]
            uni = pd.DataFrame({"symbol": syms, "name": [""] * len(syms)})
    if uni.empty:
        print("[check] No symbols. Exit.")
        return
    symbols = uni["symbol"].astype(str).str.zfill(6).tolist()
    print(f"[check] Pool sample: {len(symbols)} symbols, cache_dir={cache_dir}")
    print()

    # ---- 1) Daily: from DuckDB store if present ----
    db_path = os.path.join(cache_dir, "market.duckdb")
    if os.path.exists(db_path):
        from v5.data.store import MarketStore
        store = MarketStore(db_path, read_only=True)
        print("--- Daily (DuckDB store) ---")
        last_dates = []
        has_316 = 0
        placeholder_316 = 0  # 316 row exists but volume<100 or same as prev
        missing_316 = 0
        sample = symbols[:15]
        for sym in sample:
            df = store.read_bars(sym)
            if df is None or df.empty:
                last_dates.append((sym, "no_data"))
                missing_316 += 1
                continue
            df = df.sort_index()
            last_d = str(df.index[-1])[:10]
            last_dates.append((sym, last_d))
            if last_d < target_date:
                missing_316 += 1
            elif last_d == target_date:
                has_316 += 1
                row = df.loc[df.index[-1]]
                vol = float(row.get("volume", 0))
                if vol < 100:
                    placeholder_316 += 1
                elif len(df) >= 2:
                    prev = df.iloc[-2]
                    if (float(row.get("close")) == float(prev.get("close")) and
                        float(row.get("volume")) == float(prev.get("volume"))):
                        placeholder_316 += 1
        store.close()
        for sym, d in last_dates:
            print(f"  {sym}: last_date={d}")
        print(f"  Summary: last_date<{target_date}=>{missing_316}, last_date=={target_date}=>{has_316} (placeholder_316={placeholder_316})")
        print()
    else:
        print("--- Daily: no DuckDB store at", db_path)
        print()

    # ---- 2) Daily: from PKL (what prefetch writes without store) ----
    print("--- Daily (PKL cache, sample 5) ---")
    for sym in symbols[:5]:
        pkl = os.path.join(cache_dir, f"{sym}_full.pkl")
        if not os.path.exists(pkl):
            print(f"  {sym}: no PKL")
            continue
        try:
            df = pd.read_pickle(pkl)
            if df is None or df.empty:
                print(f"  {sym}: PKL empty")
                continue
            df.index = pd.to_datetime(df.index)
            df = df.sort_index()
            last_d = str(df.index[-1])[:10]
            vol = float(df.iloc[-1].get("volume", 0))
            status = "placeholder" if (last_d == target_date and vol < 100) else "ok"
            print(f"  {sym}: last_date={last_d} volume={vol:.0f} ({status})")
        except Exception as e:
            print(f"  {sym}: read err {e}")
    print()

    # ---- 3) Daily: fetch from remote (mootdx) for 2 symbols ----
    print("--- Daily (remote mootdx, 2 symbols) ---")
    from cq_backtest.data.feed import DataFeed
    feed = DataFeed(cache_dir=cache_dir)
    for sym in symbols[:2]:
        try:
            df = feed.get_kline(sym, end_date=target_date, count=500, cache_only=False, force_refresh=False)
            if df is None or df.empty:
                print(f"  {sym}: remote returned empty")
                continue
            df.index = pd.to_datetime(df.index)
            df = df.sort_index()
            last_d = str(df.index[-1])[:10]
            row = df.iloc[-1]
            vol = float(row.get("volume", 0))
            print(f"  {sym}: last_date={last_d} close={row.get('close')} volume={vol:.0f}")
            if last_d == target_date:
                print(f"         -> 3-16 available, placeholder={vol < 100}")
            else:
                print(f"         -> 3-16 not in series (data through {last_d})")
        except Exception as e:
            print(f"  {sym}: err {e}")
    try:
        if feed.client is not None:
            feed.client.close()
    except Exception:
        pass
    print()

    # ---- 4) Minute: how far updated ----
    print("--- Minute bars (remote, 3 symbols) ---")
    feed2 = DataFeed(cache_dir=cache_dir)
    for sym in symbols[:3]:
        try:
            minutes = feed2.get_minute_bars(sym, frequency=8, count=500)
            if minutes is None or minutes.empty:
                print(f"  {sym}: no minute data")
                continue
            minutes.index = pd.to_datetime(minutes.index)
            dates = minutes.index.normalize().strftime("%Y-%m-%d").unique()
            last_d = str(minutes.index[-1])[:10]
            print(f"  {sym}: last_minute={last_d} dates_in_window={list(dates[-3:]) if len(dates) >= 3 else list(dates)}")
            if target_date.replace("-", "") in [d.replace("-", "") for d in dates]:
                day_str = pd.Series(minutes.index).dt.strftime("%Y-%m-%d")
                today = minutes[day_str.values == target_date]
                print(f"         -> 3-16 minutes: {len(today)} bars")
            else:
                print(f"         -> 3-16 not in minute window")
        except Exception as e:
            print(f"  {sym}: err {e}")
    try:
        if feed2.client is not None:
            feed2.client.close()
    except Exception:
        pass
    print("Done.")


if __name__ == "__main__":
    main()
