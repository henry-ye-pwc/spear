#!/usr/bin/env python3
"""Ablation test: 3 factors x 2^3 = 8 configurations under dlh mode."""
from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
os.chdir(ROOT)
sys.path.insert(0, str(ROOT))

TREND_SPEAR = ROOT / "v4" / "models" / "trend_spear.py"
STATE_MACHINE = ROOT / "v4" / "execution" / "state_machine.py"

# Save originals
ORIG_TS = TREND_SPEAR.read_text()
ORIG_SM = STATE_MACHINE.read_text()

# ---- Patch definitions ----

# FILTER patch: replace iqr/elev checks with pass-through (disable filter)
def disable_filter(code: str) -> str:
    code = code.replace(
        '    iqr = cur.get("vol60_iqr_norm")\n'
        '    if pd.notna(iqr) and float(iqr) > 1.2:\n'
        '        return None\n'
        '    elev = cur.get("vol_elevation")\n'
        '    if pd.notna(elev) and float(elev) > 1.3:\n'
        '        return None',
        '    # [ABLATION] entry filter disabled'
    )
    return code

# ATR patch: replace ATR-based invalidation with original min(low, ma20)
def disable_atr(code: str) -> str:
    code = code.replace(
        '    atr_pct = cur.get("atr_20d_pct")\n'
        '    if pd.notna(atr_pct) and float(atr_pct) > 0:\n'
        '        atr_stop = gate * (1.0 - 2.0 * float(atr_pct))\n'
        '        floor_stop = gate * 0.92\n'
        '        invalid = max(atr_stop, floor_stop)\n'
        '    else:\n'
        '        invalid = min(float(cur["low"]), float(cur["ma20"]) if pd.notna(cur["ma20"]) else float(cur["low"]))',
        '    invalid = min(float(cur["low"]), float(cur["ma20"]) if pd.notna(cur["ma20"]) else float(cur["low"]))\n'
        '    atr_pct = cur.get("atr_20d_pct")  # [ABLATION] ATR stop disabled, kept for context'
    )
    return code

# HOLD patch: remove adaptive hold + vol_exhaustion blocks from state_machine
def disable_hold(code: str) -> str:
    # Remove adaptive hold block
    code = code.replace(
        '            if pos.exit_style == "trend_hold":\n'
        '                if pos.atr_at_entry == 0.0:\n'
        '                    ctx_atr = float(day_context.get("atr_20d_pct", 0.0))\n'
        '                    if ctx_atr > 0:\n'
        '                        pos.atr_at_entry = pos.entry_price * ctx_atr\n'
        '\n'
        '                if bool(day_context.get("is_limit_up_close", False)):\n'
        '                    pos.board_count += 1\n'
        '                    pos.last_board_idx = d_idx\n'
        '                    pos.max_hold_days = max(pos.max_hold_days, 15)\n'
        '                    if pos.atr_at_entry > 0:\n'
        '                        wide_stop = pos.entry_price - 2.5 * pos.atr_at_entry\n'
        '                        pos.stop_price = min(pos.stop_price, max(wide_stop, pos.entry_price * 0.92))\n'
        '\n'
        '                if pos.board_count == 0 and holding_days >= 5 and pos.atr_at_entry > 0:\n'
        '                    tight_stop = pos.entry_price - 1.5 * pos.atr_at_entry\n'
        '                    pos.stop_price = max(pos.stop_price, tight_stop)\n'
        '                    pos.max_hold_days = min(pos.max_hold_days, 5)\n'
        '\n'
        '            if self._is_realistic()',
        '            # [ABLATION] adaptive hold disabled\n'
        '            if self._is_realistic()'
    )
    # Remove vol_exhaustion block
    code = code.replace(
        '            if pos.exit_style == "trend_hold" and pos.board_count > 0 and holding_days >= 2:\n'
        '                if bool(day_context.get("is_amount_explosive", False)) and close < open_price:\n'
        '                    if limit_down is None or can_sell_strict(close, limit_down):\n'
        '                        if self._is_realistic():\n'
        '                            decisions.append(self._queue_sell_next_open(d_idx=d_idx, symbol=symbol, pos=pos, reason="vol_exhaustion"))\n'
        '                        else:\n'
        '                            decisions.append(Decision("sell", symbol, close, pos.qty, "vol_exhaustion"))\n'
        '                            self.positions.pop(symbol, None)\n'
        '                            self.cooldowns[symbol] = d_idx + self.cooldown_days\n'
        '                        return decisions\n'
        '            if holding_days >= pos.max_hold_days',
        '            # [ABLATION] vol_exhaustion disabled\n'
        '            if holding_days >= pos.max_hold_days'
    )
    return code


CONFIGS = [
    ("---_baseline",   True,  True,  True),   # all disabled = baseline behavior
    ("F--_filter",     False, True,  True),   # filter only
    ("-A-_atr",        True,  False, True),   # ATR only
    ("--H_hold",       True,  True,  False),  # hold only
    ("FA-_filt+atr",   False, False, True),   # filter + ATR
    ("F-H_filt+hold",  False, True,  False),  # filter + hold
    ("-AH_atr+hold",   True,  False, False),  # ATR + hold
    ("FAH_all",        False, False, False),  # all enabled (current code)
]

import argparse
_ap = argparse.ArgumentParser()
_ap.add_argument("--year", type=int, default=2025)
_args = _ap.parse_args()
YEAR = _args.year

BACKTEST_CMD = [
    sys.executable, "v5/run.py",
    "--start", f"{YEAR}-01-01", "--end", f"{YEAR}-12-31",
    "--pool-name", "50-150cyc",
    "--execution-profile", "delayed_limit_hunt",
    "--exit-mode", "ideal",
    "--max-positions", "8",
    "--base-pos-pct", "0.25",
    "--cooldown-days", "3",
    "--take-profit-pct", "0.18",
    "--disable-env-mapping",
    "--warmup-bars", "600",
]

results = []

for name, dis_filter, dis_atr, dis_hold in CONFIGS:
    print(f"\n{'='*60}")
    print(f"Running: {name}  (filter={'OFF' if dis_filter else 'ON'}, atr={'OFF' if dis_atr else 'ON'}, hold={'OFF' if dis_hold else 'ON'})")
    print(f"{'='*60}")

    ts_code = ORIG_TS
    sm_code = ORIG_SM

    if dis_filter:
        ts_code = disable_filter(ts_code)
    if dis_atr:
        ts_code = disable_atr(ts_code)
    if dis_hold:
        sm_code = disable_hold(sm_code)

    TREND_SPEAR.write_text(ts_code)
    STATE_MACHINE.write_text(sm_code)

    t0 = time.time()
    proc = subprocess.run(
        BACKTEST_CMD,
        capture_output=True, text=True, cwd=str(ROOT),
    )
    elapsed = time.time() - t0

    # Extract JSON summary from stdout (last JSON block)
    summary = None
    lines = proc.stdout.strip().split("\n")
    json_lines = []
    in_json = False
    for line in lines:
        if line.strip() == "{":
            in_json = True
            json_lines = [line]
        elif in_json:
            json_lines.append(line)
            if line.strip() == "}":
                in_json = False
                try:
                    summary = json.loads("\n".join(json_lines))
                except:
                    pass

    if summary is None:
        print(f"  FAILED ({elapsed:.0f}s)")
        print(f"  stderr: {proc.stderr[-500:]}")
        results.append((name, None))
    else:
        print(f"  equity_return: {summary['equity_return_pct']:.2f}%  trades: {summary['trade_count']}  events: {summary['event_count']}  ({elapsed:.0f}s)")
        results.append((name, summary))

# Restore originals
TREND_SPEAR.write_text(ORIG_TS)
STATE_MACHINE.write_text(ORIG_SM)

# Print comparison table
print(f"\n\n{'='*100}")
print(f"ABLATION RESULTS — {YEAR} dlh mode")
print(f"{'='*100}")
print(f"{'Config':<20} {'Filter':>7} {'ATR':>5} {'Hold':>6} {'Eq Ret%':>10} {'Trades':>8} {'Events':>8} {'Fees':>10} {'OpenMV':>12}")
print("-" * 90)
for (name, dis_f, dis_a, dis_h), (_, summary) in zip(CONFIGS, results):
    if summary is None:
        print(f"{name:<20} {'OFF' if dis_f else 'ON':>7} {'OFF' if dis_a else 'ON':>5} {'OFF' if dis_h else 'ON':>6}   FAILED")
        continue
    print(f"{name:<20} {'OFF' if dis_f else 'ON':>7} {'OFF' if dis_a else 'ON':>5} {'OFF' if dis_h else 'ON':>6} {summary['equity_return_pct']:>9.2f}% {summary['trade_count']:>8} {summary['event_count']:>8} {summary['total_fees']:>10,.0f} {summary['open_market_value']:>12,.0f}")

print(f"\n{'='*100}")
print("MARGINAL EFFECTS (average contribution of each factor)")
print(f"{'='*100}")
# Calculate marginal effects
returns = {}
for (name, dis_f, dis_a, dis_h), (_, summary) in zip(CONFIGS, results):
    if summary:
        returns[(dis_f, dis_a, dis_h)] = summary['equity_return_pct']

if len(returns) == 8:
    # Marginal effect of FILTER = avg(ON) - avg(OFF)
    filter_on = [v for (f, a, h), v in returns.items() if not f]
    filter_off = [v for (f, a, h), v in returns.items() if f]
    atr_on = [v for (f, a, h), v in returns.items() if not a]
    atr_off = [v for (f, a, h), v in returns.items() if a]
    hold_on = [v for (f, a, h), v in returns.items() if not h]
    hold_off = [v for (f, a, h), v in returns.items() if h]

    print(f"  FILTER:  ON avg = {sum(filter_on)/len(filter_on):.2f}%  |  OFF avg = {sum(filter_off)/len(filter_off):.2f}%  |  marginal = {sum(filter_on)/len(filter_on) - sum(filter_off)/len(filter_off):+.2f}pp")
    print(f"  ATR:     ON avg = {sum(atr_on)/len(atr_on):.2f}%  |  OFF avg = {sum(atr_off)/len(atr_off):.2f}%  |  marginal = {sum(atr_on)/len(atr_on) - sum(atr_off)/len(atr_off):+.2f}pp")
    print(f"  HOLD:    ON avg = {sum(hold_on)/len(hold_on):.2f}%  |  OFF avg = {sum(hold_off)/len(hold_off):.2f}%  |  marginal = {sum(hold_on)/len(hold_on) - sum(hold_off)/len(hold_off):+.2f}pp")
