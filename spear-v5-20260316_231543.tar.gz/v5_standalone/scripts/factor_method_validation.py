"""
Factor Investing Methodology Validation for Trend Spear
========================================================
Applies 7 rigorous statistical tests from the factor investing literature
to validate (or reject) features found in our previous trend_spear analysis.

No strategy code is modified. This is a read-only analysis script.

Usage:
    python scripts/factor_method_validation.py
"""
import sys, os, json, glob, math, warnings
import numpy as np
import pandas as pd
from collections import defaultdict

warnings.filterwarnings("ignore", category=FutureWarning)

VENV = "/Users/yhanlin001/spear-strategy/.venv/bin/python"
BASE = "/Users/yhanlin001/spear-strategy/v5_standalone"
OUT_DIR = os.path.join(BASE, "outputs/backtests")
CACHE_DIR = os.path.join(BASE, "cache")

BACKTESTS_BY_YEAR = {
    2019: "oracle_2019_50-150cyc_dlh",
    2020: "oracle_2020_50-150cyc_dlh",
    2021: "oracle_2021_50-150cyc_dlh",
    2022: "oracle_2022_50-150cyc_dlh",
    2023: "oracle_2023_50-150cyc_dlh",
    2024: "oracle_2024_50-150cyc_dlh",
    2025: "oracle_2025_50-150cyc_dlh",
}

PRIOR_TIERS = {
    "strong": 0.50,   # volume tightness features — backed by low-turnover effect + theory
    "moderate": 0.20,  # structural/position features — some theory
    "weak": 0.05,      # data-mined or exploratory
}

FEATURE_PRIORS = {
    "vol60_mad_norm": "strong", "vol60_iqr_norm": "strong",
    "vol60_cv": "strong", "hdi_width": "strong",
    "vol60_log_std": "strong", "vol60_gini": "strong",
    "vol60_entropy": "strong", "vol_autocorr": "strong",
    "vol_trend_slope": "moderate", "vol_trend_r2": "weak",
    "vol60_skew": "weak", "vol60_kurtosis": "weak",
    "vol60_p90_p50": "moderate", "vol60_p75_p25": "moderate",
    "vol60_max_median": "weak",
    "zhang_ratio": "strong", "han_ratio": "strong", "xu_ratio": "moderate",
    "accum_spikes_30": "moderate", "accum_spike_vol_ratio": "moderate",
    "range_pos_120": "moderate", "near_peak": "moderate",
    "two_side_active": "moderate", "consolidation_ok": "weak",
    "amount_rank": "moderate", "amount_z": "moderate",
    "vol_ratio_10_60": "strong",
}

ROUND_TRIP_COST = 0.0016  # stamp 0.1% + commission 0.03%*2 + slippage ~0.1% ≈ 0.16%


def safe_spearmanr(a, b):
    """Wrapper around spearmanr that always returns (float, float)."""
    from scipy import stats as sp_stats
    try:
        res = sp_stats.spearmanr(a, b)
        rho = res.statistic
        p = res.pvalue
        if np.ndim(rho) > 0:
            rho = rho[0, 1] if rho.shape[0] > 1 else float(rho.flat[0])
            p = p[0, 1] if p.shape[0] > 1 else float(p.flat[0])
        return float(rho), float(p)
    except Exception:
        return np.nan, 1.0

# ═══════════════════════════════════════════════════════════════════════════
# DATA LOADING (reused from analyze_limitup_patterns.py)
# ═══════════════════════════════════════════════════════════════════════════

def find_bar_data_dir():
    for c in [os.path.join(CACHE_DIR, "bars"), os.path.join(CACHE_DIR, "daily"),
              CACHE_DIR, os.path.join(BASE, "data")]:
        if os.path.isdir(c):
            if glob.glob(os.path.join(c, "**/*.parquet"), recursive=True):
                return c
    return None

def load_all_bars_for_symbol(symbol: str, bar_dir: str):
    sym6 = str(symbol).zfill(6)
    for subdir in ["features", ""]:
        search_dir = os.path.join(bar_dir, subdir) if subdir else bar_dir
        if not os.path.isdir(search_dir):
            continue
        for pattern in [os.path.join(search_dir, f"{sym6}_*.parquet"),
                        os.path.join(search_dir, f"{sym6}.parquet")]:
            files = glob.glob(pattern)
            if files:
                df = pd.read_parquet(files[0])
                if "date" in df.index.names:
                    df = df.reset_index()
                if "date" not in df.columns:
                    if {"year", "month", "day"}.issubset(df.columns):
                        df["date"] = pd.to_datetime(
                            df[["year", "month", "day"]].astype(int).astype(str).agg("-".join, axis=1)
                        ).dt.strftime("%Y-%m-%d")
                else:
                    df["date"] = pd.to_datetime(df["date"]).dt.strftime("%Y-%m-%d")
                return df.sort_values("date").reset_index(drop=True)
    return None

def is_limit_up(row, tol=0.005):
    if "limit_up" in row.index and pd.notna(row.get("limit_up")):
        return abs(row["close"] - row["limit_up"]) / row["limit_up"] < tol
    pct = row.get("pct_chg") or row.get("change_pct")
    if pct is not None and pd.notna(pct):
        return pct >= 9.8
    if row.get("high") == row.get("close") and row.get("open") == row.get("close"):
        prev_close = row.get("pre_close")
        if prev_close and prev_close > 0:
            return (row["close"] - prev_close) / prev_close * 100 >= 9.5
    return False

# ═══════════════════════════════════════════════════════════════════════════
# FEATURE COMPUTATION
# ═══════════════════════════════════════════════════════════════════════════

def compute_features(pre_bars, hold_bars, window=60):
    """Compute ~25 pre-entry features from the last `window` days of pre_bars."""
    feat = {}
    pre = pre_bars.tail(window)
    if len(pre) < 20 or "volume" not in pre.columns:
        return None

    vol = pre["volume"].values.astype(float)
    vol = vol[vol > 0]
    if len(vol) < 20:
        return None

    med = np.median(vol)
    if med <= 0:
        return None

    # --- Dispersion metrics (normalized by median) ---
    feat["vol60_mad_norm"] = np.median(np.abs(vol - med)) / med
    q75, q25 = np.percentile(vol, 75), np.percentile(vol, 25)
    feat["vol60_iqr_norm"] = (q75 - q25) / med
    feat["vol60_cv"] = np.std(vol) / np.mean(vol) if np.mean(vol) > 0 else np.nan
    feat["vol60_log_std"] = np.std(np.log(vol))

    # HDI width (89% highest density interval via sorted approach)
    sorted_vol = np.sort(vol)
    n = len(sorted_vol)
    ci_n = int(np.ceil(0.89 * n))
    if ci_n < n:
        widths = sorted_vol[ci_n:] - sorted_vol[:n - ci_n]
        hdi_low_idx = np.argmin(widths)
        feat["hdi_width"] = (widths[hdi_low_idx] / med) if med > 0 else np.nan
    else:
        feat["hdi_width"] = (sorted_vol[-1] - sorted_vol[0]) / med

    # Gini coefficient
    sorted_v = np.sort(vol)
    n_v = len(sorted_v)
    indices = np.arange(1, n_v + 1)
    feat["vol60_gini"] = (2 * np.sum(indices * sorted_v) / (n_v * np.sum(sorted_v))) - (n_v + 1) / n_v

    # Shannon entropy (on binned distribution)
    hist_counts, _ = np.histogram(vol, bins=min(20, len(vol) // 3 + 1))
    hist_counts = hist_counts[hist_counts > 0]
    probs = hist_counts / hist_counts.sum()
    feat["vol60_entropy"] = -np.sum(probs * np.log(probs))

    # Shape
    feat["vol60_skew"] = float(pd.Series(vol).skew())
    feat["vol60_kurtosis"] = float(pd.Series(vol).kurtosis())

    # Percentile ratios
    p90 = np.percentile(vol, 90)
    p50 = np.percentile(vol, 50)
    feat["vol60_p90_p50"] = p90 / p50 if p50 > 0 else np.nan
    feat["vol60_p75_p25"] = q75 / q25 if q25 > 0 else np.nan
    feat["vol60_max_median"] = np.max(vol) / med

    # Temporal dynamics
    if len(vol) >= 5:
        ac = np.corrcoef(vol[:-1], vol[1:])[0, 1]
        feat["vol_autocorr"] = ac if np.isfinite(ac) else 0.0
    else:
        feat["vol_autocorr"] = 0.0

    log_v = np.log(vol)
    if len(log_v) >= 10:
        from scipy.stats import linregress
        x = np.arange(len(log_v))
        sl = linregress(x, log_v)
        feat["vol_trend_slope"] = sl.slope
        feat["vol_trend_r2"] = sl.rvalue ** 2
    else:
        feat["vol_trend_slope"] = 0.0
        feat["vol_trend_r2"] = 0.0

    # "张扬含蓄" components
    closes = pre["close"].values.astype(float)
    opens = pre["open"].values.astype(float)
    up_mask = closes > opens
    down_mask = closes < opens
    up_vols = vol[up_mask[:len(vol)]] if len(vol) == len(closes) else np.array([])
    dn_vols = vol[down_mask[:len(vol)]] if len(vol) == len(closes) else np.array([])

    feat["zhang_ratio"] = np.median(up_vols) / np.median(dn_vols) if len(up_vols) > 2 and len(dn_vols) > 2 and np.median(dn_vols) > 0 else np.nan
    feat["han_ratio"] = np.median(dn_vols) / np.median(up_vols) if len(up_vols) > 2 and len(dn_vols) > 2 and np.median(up_vols) > 0 else np.nan

    recent_10 = pre.tail(10)
    if len(recent_10) > 0 and "volume" in recent_10.columns:
        feat["xu_ratio"] = recent_10["volume"].max() / p90 if p90 > 0 else np.nan
    else:
        feat["xu_ratio"] = np.nan

    # Accumulation spikes (high-vol up-days in last 30 days)
    last30 = pre.tail(30)
    if len(last30) > 5:
        l30_vol = last30["volume"].values.astype(float)
        l30_close = last30["close"].values.astype(float)
        l30_open = last30["open"].values.astype(float)
        up_high = (l30_close > l30_open) & (l30_vol > np.percentile(vol, 75))
        feat["accum_spikes_30"] = int(np.sum(up_high))
        spike_vols = l30_vol[up_high]
        feat["accum_spike_vol_ratio"] = np.median(spike_vols) / med if len(spike_vols) > 0 and med > 0 else 0.0
    else:
        feat["accum_spikes_30"] = 0
        feat["accum_spike_vol_ratio"] = 0.0

    # Structural features (from bar data if available)
    if len(pre) >= 120:
        highs_120 = pre.tail(120)["high"].values.astype(float)
        lows_120 = pre.tail(120)["low"].values.astype(float)
        peak = np.max(highs_120)
        trough = np.min(lows_120)
        cur_close = closes[-1]
        feat["range_pos_120"] = (cur_close - trough) / (peak - trough) if (peak - trough) > 0 else 0.5
        feat["near_peak"] = 1.0 if cur_close >= peak * 0.9 else 0.0
    else:
        feat["range_pos_120"] = np.nan
        feat["near_peak"] = np.nan

    feat["two_side_active"] = np.nan  # needs full feature pipeline
    feat["consolidation_ok"] = np.nan

    # Amount rank / z-score (within this trade's pre-entry context)
    last_vol = vol[-1] if len(vol) > 0 else np.nan
    feat["amount_rank"] = np.searchsorted(np.sort(vol), last_vol) / len(vol) if len(vol) > 0 and np.isfinite(last_vol) else np.nan
    feat["amount_z"] = (last_vol - np.mean(vol)) / np.std(vol) if np.std(vol) > 0 else 0.0

    # Short/long volume ratio
    vol_10 = pre.tail(10)["volume"].median() if len(pre) >= 10 else np.nan
    vol_60 = med
    feat["vol_ratio_10_60"] = vol_10 / vol_60 if vol_60 > 0 and pd.notna(vol_10) else np.nan

    return feat


def compute_holding_metrics(hold_bars, pre_vol_median):
    """Compute has_board and per-day returns during holding."""
    has_board = False
    daily_rets = []
    daily_cum_rets = []
    cum = 0.0
    for i, (_, bar) in enumerate(hold_bars.iterrows()):
        if is_limit_up(bar):
            has_board = True
        if "close" in bar.index and "open" in bar.index and bar["open"] > 0:
            dr = (bar["close"] - bar["open"]) / bar["open"]
            daily_rets.append(dr)
            cum += dr
            daily_cum_rets.append(cum)
    return has_board, daily_rets, daily_cum_rets


# ═══════════════════════════════════════════════════════════════════════════
# MAIN DATA LOADING
# ═══════════════════════════════════════════════════════════════════════════

def load_all_data():
    bar_dir = find_bar_data_dir()
    print(f"Bar data directory: {bar_dir}")

    all_trades = []
    for year, bt_name in sorted(BACKTESTS_BY_YEAR.items()):
        ct_path = os.path.join(OUT_DIR, bt_name, "closed_trades.csv")
        if not os.path.exists(ct_path):
            print(f"  WARNING: {ct_path} not found")
            continue
        ct = pd.read_csv(ct_path, dtype={"symbol": str})
        ct["symbol"] = ct["symbol"].astype(str).str.zfill(6)
        spear = ct[ct["entry_reason"].str.contains("trend_spear", na=False)].copy()
        spear["year"] = year
        spear["backtest"] = bt_name
        all_trades.append(spear)
        print(f"  {year}: {len(spear)} trades from {bt_name}")

    df_trades = pd.concat(all_trades, ignore_index=True)
    print(f"\nTotal trades: {len(df_trades)}")

    bar_cache = {}
    unique_syms = df_trades["symbol"].unique()
    loaded = 0
    for sym in unique_syms:
        bars = load_all_bars_for_symbol(sym, bar_dir) if bar_dir else None
        if bars is not None:
            bar_cache[sym] = bars
            loaded += 1
    print(f"Loaded bar data for {loaded}/{len(unique_syms)} symbols")

    records = []
    for _, trade in df_trades.iterrows():
        sym = trade["symbol"]
        bars = bar_cache.get(sym)
        if bars is None:
            continue
        entry_d = trade["entry_date"]
        exit_d = trade["exit_date"]

        pre_bars = bars[bars["date"] < entry_d].tail(120)
        hold_bars = bars[(bars["date"] >= entry_d) & (bars["date"] <= exit_d)]
        if len(pre_bars) < 20 or hold_bars.empty:
            continue

        feats = compute_features(pre_bars, hold_bars, window=60)
        if feats is None:
            continue

        pre_vol_med = pre_bars.tail(60)["volume"].median()
        has_board, daily_rets, daily_cum = compute_holding_metrics(hold_bars, pre_vol_med)

        rec = {
            "symbol": sym,
            "entry_date": entry_d,
            "year": trade["year"],
            "actual_ret": trade["ret"],
            "has_board": has_board,
            "exit_reason": trade["exit_reason"],
            "hold_days": trade["hold_days"],
        }
        rec.update(feats)

        # Store partial returns for IC decay analysis
        for d_idx in [1, 3, 5, 7, 10]:
            rec[f"ret_day{d_idx}"] = daily_cum[d_idx - 1] if len(daily_cum) >= d_idx else np.nan

        records.append(rec)

    df = pd.DataFrame(records)
    print(f"Final dataset: {len(df)} trades with features")
    print(f"  Board: {df['has_board'].sum()} ({df['has_board'].mean()*100:.1f}%)")
    print(f"  No-board: {(~df['has_board']).sum()} ({(~df['has_board']).mean()*100:.1f}%)")
    print(f"  Years: {sorted(df['year'].unique())}")
    return df


# ═══════════════════════════════════════════════════════════════════════════
# FEATURE COLUMNS HELPER
# ═══════════════════════════════════════════════════════════════════════════

def get_feature_cols(df):
    exclude = {"symbol", "entry_date", "year", "actual_ret", "has_board",
               "exit_reason", "hold_days", "two_side_active", "consolidation_ok",
               "near_peak", "ret_net"}
    exclude.update(c for c in df.columns if c.startswith("ret_day"))
    candidates = [c for c in df.columns if c not in exclude and df[c].dtype in [np.float64, np.int64, float, int]]
    return [c for c in candidates if df[c].nunique() > 5]


# ═══════════════════════════════════════════════════════════════════════════
# TEST 1: BENJAMINI-HOCHBERG FDR CORRECTION
# ═══════════════════════════════════════════════════════════════════════════

def test1_fdr(df):
    from scipy import stats as sp_stats

    print("\n" + "=" * 80)
    print("TEST 1: MULTIPLE HYPOTHESIS TESTING — BENJAMINI-HOCHBERG FDR CORRECTION")
    print("=" * 80)
    print("""
┌─────────────────────────────────────────────────────────────────────────┐
│ WHAT: When we test 25 features at once, some will look "significant"  │
│       purely by chance. If we check 25 independent tests at p<0.05,   │
│       we expect ~1.25 false positives even if NOTHING is real.        │
│                                                                       │
│ WHY:  The factor investing book (Harvey et al. 2016) showed that      │
│       most published factors are false discoveries. Single-test       │
│       p-values are misleading; we need to control the False           │
│       Discovery Rate (FDR).                                           │
│                                                                       │
│ HOW:  Benjamini-Hochberg procedure:                                   │
│       1. Sort all p-values from smallest to largest                   │
│       2. For rank i out of m tests, the adjusted threshold is         │
│          p_adjusted = p_raw * m / i                                   │
│       3. A feature "survives" if its adjusted p-value < q (e.g. 0.10)│
│                                                                       │
│ The result tells us which features are REAL vs likely NOISE.          │
└─────────────────────────────────────────────────────────────────────────┘
""")

    feature_cols = get_feature_cols(df)
    board = df[df["has_board"]]
    noboard = df[~df["has_board"]]

    # --- Part A: Mann-Whitney (board vs no-board) ---
    print("─── Part A: Mann-Whitney U test (board vs no-board) ───")
    mw_results = []
    for col in feature_cols:
        bv = board[col].dropna().values.astype(float)
        nv = noboard[col].dropna().values.astype(float)
        if len(bv) < 5 or len(nv) < 5:
            continue
        try:
            u, p = sp_stats.mannwhitneyu(bv, nv, alternative="two-sided")
        except Exception:
            continue
        n1, n2 = len(bv), len(nv)
        rbc = 1 - (2 * u) / (n1 * n2)
        mw_results.append({"feature": col, "p_raw": p, "effect_rbc": rbc,
                           "b_med": np.median(bv), "n_med": np.median(nv)})

    mw_df = pd.DataFrame(mw_results).sort_values("p_raw")
    m = len(mw_df)
    mw_df["rank"] = range(1, m + 1)
    mw_df["p_bh_010"] = mw_df["p_raw"] * m / mw_df["rank"]
    mw_df["p_bh_010"] = mw_df["p_bh_010"].clip(upper=1.0)
    mw_df["survives_010"] = mw_df["p_bh_010"] <= 0.10
    mw_df["survives_005"] = mw_df["p_bh_010"] <= 0.05

    print(f"\n{'Feature':<25s} {'p_raw':>8s} {'p_BH':>8s} {'effect':>8s} {'q<0.10':>7s} {'q<0.05':>7s}")
    print("─" * 68)
    for _, r in mw_df.iterrows():
        surv10 = "✓" if r["survives_010"] else ""
        surv05 = "✓" if r["survives_005"] else ""
        print(f"  {r['feature']:<23s} {r['p_raw']:8.4f} {r['p_bh_010']:8.4f} {r['effect_rbc']:+8.3f} {surv10:>7s} {surv05:>7s}")
    n_surv = mw_df["survives_010"].sum()
    print(f"\n  → {n_surv}/{m} features survive FDR correction at q=0.10 for board/no-board")

    # --- Part B: Spearman (feature vs actual_ret) ---
    print("\n─── Part B: Spearman rank correlation (feature vs actual_ret) ───")
    sp_results = []
    for col in feature_cols:
        vals = df[col].dropna()
        rets = df.loc[vals.index, "actual_ret"]
        if len(vals) < 10:
            continue
        try:
            rho, p = safe_spearmanr(vals.values.astype(float), rets.values.astype(float))
        except Exception:
            continue
        if not np.isfinite(rho):
            continue
        sp_results.append({"feature": col, "rho": rho, "p_raw": p})

    sp_df = pd.DataFrame(sp_results).sort_values("p_raw")
    m2 = len(sp_df)
    sp_df["rank"] = range(1, m2 + 1)
    sp_df["p_bh"] = (sp_df["p_raw"] * m2 / sp_df["rank"]).clip(upper=1.0)
    sp_df["survives_010"] = sp_df["p_bh"] <= 0.10
    sp_df["survives_005"] = sp_df["p_bh"] <= 0.05

    print(f"\n{'Feature':<25s} {'rho':>8s} {'p_raw':>8s} {'p_BH':>8s} {'q<0.10':>7s} {'q<0.05':>7s}")
    print("─" * 68)
    for _, r in sp_df.iterrows():
        surv10 = "✓" if r["survives_010"] else ""
        surv05 = "✓" if r["survives_005"] else ""
        print(f"  {r['feature']:<23s} {r['rho']:+8.3f} {r['p_raw']:8.4f} {r['p_bh']:8.4f} {surv10:>7s} {surv05:>7s}")
    n_surv2 = sp_df["survives_010"].sum()
    print(f"\n  → {n_surv2}/{m2} features survive FDR correction at q=0.10 for return prediction")

    return mw_df, sp_df


# ═══════════════════════════════════════════════════════════════════════════
# TEST 2: BAYESIAN P-VALUE WITH PRIOR
# ═══════════════════════════════════════════════════════════════════════════

def test2_bayesian(df, mw_df, sp_df):
    print("\n" + "=" * 80)
    print("TEST 2: BAYESIAN P-VALUE — INCORPORATING PRIOR KNOWLEDGE")
    print("=" * 80)
    print("""
┌─────────────────────────────────────────────────────────────────────────┐
│ WHAT: Not all features are created equal. "Volume tightness predicts  │
│       returns" has strong theoretical backing (A-share low-turnover   │
│       effect, 张扬含蓄 theory, academic literature). A random data-  │
│       mined feature has none.                                         │
│                                                                       │
│ WHY:  Harvey (2017) showed that combining p-values with prior belief  │
│       gives us prob(H0|data) — what we ACTUALLY want to know —       │
│       instead of prob(data|H0) which is what p-values give.          │
│                                                                       │
│ HOW:  1. Compute Minimum Bayes Factor: φ = -e × p × ln(p)           │
│       2. Assign prior: π₀ (probability the feature is truly null)    │
│          - Strong theory (turnover/volume): π₀ = 0.50                │
│          - Moderate theory (structural):    π₀ = 0.80                │
│          - Weak/data-mined:                 π₀ = 0.95                │
│       3. Bayesian p = φ × π₀ / (φ × π₀ + (1 - π₀))                │
│                                                                       │
│ A low Bayesian p means: even accounting for how much we trust the    │
│ theory, the data STILL says this feature matters.                     │
└─────────────────────────────────────────────────────────────────────────┘
""")

    E = math.e

    # Use the BEST p-value for each feature from either MW or Spearman
    feat_best_p = {}
    feat_best_source = {}
    feat_effect = {}
    for _, row in mw_df.iterrows():
        feat = row["feature"]
        feat_best_p[feat] = row["p_raw"]
        feat_best_source[feat] = "MW"
        feat_effect[feat] = row["effect_rbc"]
    for _, row in sp_df.iterrows():
        feat = row["feature"]
        if feat not in feat_best_p or row["p_raw"] < feat_best_p[feat]:
            feat_best_p[feat] = row["p_raw"]
            feat_best_source[feat] = "Sp"
            feat_effect[feat] = row["rho"]

    results = []
    for feat, p in feat_best_p.items():
        if p <= 0 or p >= 1:
            continue

        phi = -E * p * math.log(p)
        tier = FEATURE_PRIORS.get(feat, "weak")
        prior_alt = PRIOR_TIERS[tier]
        prior_null = 1 - prior_alt

        bayes_p = (phi * prior_null) / (phi * prior_null + prior_alt)
        results.append({
            "feature": feat, "effect": feat_effect.get(feat, 0),
            "p_raw": p, "source": feat_best_source.get(feat, "?"),
            "phi": phi, "tier": tier, "prior_alt": prior_alt, "bayes_p": bayes_p,
        })

    res_df = pd.DataFrame(results).sort_values("bayes_p")
    print(f"{'Feature':<25s} {'effect':>7s} {'p_raw':>7s} {'src':>4s} {'φ':>7s} {'tier':>9s} {'π_alt':>6s} {'Bayes_p':>8s} {'sig?':>5s}")
    print("─" * 85)
    for _, r in res_df.iterrows():
        sig = "✓" if r["bayes_p"] < 0.10 else ""
        print(f"  {r['feature']:<23s} {r['effect']:+7.3f} {r['p_raw']:7.4f} {r['source']:>4s} {r['phi']:7.3f} {r['tier']:>9s} {r['prior_alt']:6.2f} {r['bayes_p']:8.4f} {sig:>5s}")

    n_sig = (res_df["bayes_p"] < 0.10).sum()
    print(f"\n  → {n_sig}/{len(res_df)} features have Bayesian p < 0.10")
    print("  → Features with STRONG prior + strong MW p-value have the best chance")
    print("  → Features with WEAK prior need extremely low raw p-values to survive")

    return res_df


# ═══════════════════════════════════════════════════════════════════════════
# TEST 3: IC TIME-SERIES & DECAY HALF-LIFE
# ═══════════════════════════════════════════════════════════════════════════

def test3_ic_decay(df):
    from scipy import stats as sp_stats

    print("\n" + "=" * 80)
    print("TEST 3: INFORMATION COEFFICIENT (IC) & DECAY HALF-LIFE")
    print("=" * 80)
    print("""
┌─────────────────────────────────────────────────────────────────────────┐
│ WHAT: IC = Rank correlation between a feature (measured at entry) and │
│       the actual return. We compute it PER YEAR, then look at the    │
│       time series: is the IC consistently negative/positive, or does │
│       it flip randomly?                                               │
│                                                                       │
│ WHY:  A pooled correlation can be dominated by one year's data.       │
│       IC_mean tells us the average predictive power.                  │
│       IC_std tells us how stable it is.                               │
│       IR = IC_mean / IC_std (Information Ratio) is the signal-to-    │
│       noise ratio — higher |IR| = more reliable.                     │
│       Hit rate = % of years where IC has the expected sign.           │
│                                                                       │
│ IC DECAY: We also compute IC against returns at Day 1, 3, 5, 7, 10. │
│       This tells us HOW QUICKLY the feature's signal fades.           │
│       Half-life = when IC drops to 50% of its peak.                  │
│       Short half-life → must act fast (or use for early exit).       │
│       Long half-life → safe for the full 10-day hold.                │
└─────────────────────────────────────────────────────────────────────────┘
""")

    feature_cols = get_feature_cols(df)
    years = sorted(df["year"].unique())

    # --- Part A: IC per year ---
    print("─── Part A: IC per year ───\n")
    ic_records = []
    for col in feature_cols:
        year_ics = []
        for y in years:
            sub = df[df["year"] == y][[col, "actual_ret"]].dropna()
            if len(sub) < 10:
                continue
            rho, _ = safe_spearmanr(sub[col].values, sub["actual_ret"].values)
            if np.isfinite(rho):
                year_ics.append(rho)
        if len(year_ics) < 3:
            continue
        ic_mean = np.mean(year_ics)
        ic_std = np.std(year_ics)
        ir = ic_mean / ic_std if ic_std > 0 else 0.0
        expected_sign = np.sign(ic_mean)
        hit_rate = np.mean([1 if np.sign(ic) == expected_sign else 0 for ic in year_ics])
        ic_records.append({
            "feature": col, "ic_mean": ic_mean, "ic_std": ic_std,
            "ir": ir, "hit_rate": hit_rate, "n_years": len(year_ics),
            "year_ics": year_ics,
        })

    ic_df = pd.DataFrame(ic_records).sort_values("ir", key=abs, ascending=False)
    header = f"{'Feature':<25s} {'IC_mean':>8s} {'IC_std':>8s} {'IR':>8s} {'HitRate':>8s} {'N_yr':>5s}"
    print(header)
    print("─" * len(header))
    for _, r in ic_df.iterrows():
        print(f"  {r['feature']:<23s} {r['ic_mean']:+8.3f} {r['ic_std']:8.3f} {r['ir']:+8.3f} {r['hit_rate']:8.1%} {r['n_years']:5d}")

    print(f"\n  Interpretation:")
    print(f"  - |IR| > 0.50 = strong and consistent signal")
    print(f"  - |IR| 0.20-0.50 = moderate signal")
    print(f"  - |IR| < 0.20 = weak / noisy")
    print(f"  - Hit rate > 80% = very stable across years")

    # --- Part B: IC decay ---
    print("\n─── Part B: IC decay (feature at entry vs returns at Day 1/3/5/7/10) ───\n")
    horizons = [1, 3, 5, 7, 10]
    top_features = ic_df.head(8)["feature"].tolist()

    decay_records = []
    for col in top_features:
        ics_by_h = []
        for h in horizons:
            ret_col = f"ret_day{h}"
            sub = df[[col, ret_col]].dropna()
            if len(sub) < 15:
                ics_by_h.append(np.nan)
                continue
            rho, _ = safe_spearmanr(sub[col].values, sub[ret_col].values)
            ics_by_h.append(rho)
        decay_records.append({"feature": col, **{f"IC_d{h}": ic for h, ic in zip(horizons, ics_by_h)}})

    decay_df = pd.DataFrame(decay_records)
    header2 = f"{'Feature':<25s}" + "".join(f" {'Day'+str(h):>8s}" for h in horizons) + " {'HalfLife':>10s}"
    # manually format
    print(f"{'Feature':<25s}", end="")
    for h in horizons:
        print(f" {'Day'+str(h):>8s}", end="")
    print(f" {'HalfLife':>10s}")
    print("─" * 80)

    for _, r in decay_df.iterrows():
        print(f"  {r['feature']:<23s}", end="")
        ics = [r.get(f"IC_d{h}", np.nan) for h in horizons]
        for ic in ics:
            if np.isfinite(ic):
                print(f" {ic:+8.3f}", end="")
            else:
                print(f" {'n/a':>8s}", end="")
        # Estimate half-life
        peak_ic = ics[0] if np.isfinite(ics[0]) else 0
        half_life = "n/a"
        if abs(peak_ic) > 0.01:
            for i, h in enumerate(horizons):
                ic_val = ics[i] if np.isfinite(ics[i]) else 0
                if abs(ic_val) <= abs(peak_ic) * 0.5:
                    half_life = f"~{h}d"
                    break
            else:
                half_life = ">10d"
        print(f" {half_life:>10s}")

    print(f"\n  Interpretation:")
    print(f"  - If IC at Day 1 is strong but Day 5 is weak → feature only predicts SHORT-TERM moves")
    print(f"  - If IC stays flat across horizons → feature predicts the OVERALL trade outcome")
    print(f"  - Half-life < 3d → need to act within first 3 days based on this signal")

    return ic_df, decay_df


# ═══════════════════════════════════════════════════════════════════════════
# TEST 4: PARAMETER ROBUSTNESS
# ═══════════════════════════════════════════════════════════════════════════

def test4_robustness(df):
    from scipy import stats as sp_stats

    print("\n" + "=" * 80)
    print("TEST 4: PARAMETER ROBUSTNESS — SENSITIVITY TO BASELINE WINDOW")
    print("=" * 80)
    print("""
┌─────────────────────────────────────────────────────────────────────────┐
│ WHAT: We computed volume features using a 60-day baseline. But what   │
│       if we used 30, 45, 90, or 120 days? A robust feature should    │
│       give similar results regardless of the exact window.            │
│                                                                       │
│ WHY:  The book says: "If the parameter changes slightly and the       │
│       result changes dramatically, you should suspect overfitting."   │
│       This is one of the three robustness dimensions (parameter,     │
│       algorithm, sample).                                             │
│                                                                       │
│ HOW:  For each window (30, 45, 60, 90, 120), recompute vol_mad_norm, │
│       vol_iqr_norm, and hdi_width. Then re-run Spearman correlation  │
│       with actual_ret. A consistent sign and similar rho = robust.   │
└─────────────────────────────────────────────────────────────────────────┘
""")

    bar_dir = find_bar_data_dir()
    bar_cache = {}
    for sym in df["symbol"].unique():
        bars = load_all_bars_for_symbol(sym, bar_dir) if bar_dir else None
        if bars is not None:
            bar_cache[sym] = bars

    windows = [30, 45, 60, 90, 120]
    target_features = ["vol60_mad_norm", "vol60_iqr_norm", "hdi_width", "vol60_cv", "vol_ratio_10_60"]

    results = {feat: {} for feat in target_features}

    for win in windows:
        feat_vals = {f: [] for f in target_features}
        rets = []
        for _, trade in df.iterrows():
            bars = bar_cache.get(trade["symbol"])
            if bars is None:
                continue
            pre_bars = bars[bars["date"] < trade["entry_date"]].tail(max(win, 120))
            if len(pre_bars) < win:
                continue

            pre = pre_bars.tail(win)
            vol = pre["volume"].values.astype(float)
            vol = vol[vol > 0]
            if len(vol) < 15:
                continue
            med = np.median(vol)
            if med <= 0:
                continue

            feat_vals["vol60_mad_norm"].append(np.median(np.abs(vol - med)) / med)
            q75, q25 = np.percentile(vol, 75), np.percentile(vol, 25)
            feat_vals["vol60_iqr_norm"].append((q75 - q25) / med)
            feat_vals["vol60_cv"].append(np.std(vol) / np.mean(vol) if np.mean(vol) > 0 else np.nan)

            # HDI
            sv = np.sort(vol)
            n = len(sv)
            ci_n = int(np.ceil(0.89 * n))
            if ci_n < n:
                widths = sv[ci_n:] - sv[:n - ci_n]
                feat_vals["hdi_width"].append(widths.min() / med)
            else:
                feat_vals["hdi_width"].append((sv[-1] - sv[0]) / med)

            # vol ratio
            vol_short = pre.tail(10)["volume"].median()
            feat_vals["vol_ratio_10_60"].append(vol_short / med if med > 0 else np.nan)

            rets.append(trade["actual_ret"])

        rets_arr = np.array(rets, dtype=float)
        for feat in target_features:
            vals = np.array(feat_vals[feat], dtype=float)
            mask = np.isfinite(vals) & np.isfinite(rets_arr)
            if mask.sum() < 15:
                results[feat][win] = (np.nan, np.nan)
                continue
            rho, p = safe_spearmanr(vals[mask], rets_arr[mask])
            results[feat][win] = (rho, p)

    # Print matrix
    print(f"\n{'Feature':<25s}", end="")
    for w in windows:
        print(f" {'W='+str(w):>12s}", end="")
    print(f" {'Robust?':>8s}")
    print("─" * 90)

    robust_scores = {}
    for feat in target_features:
        print(f"  {feat:<23s}", end="")
        rhos = []
        for w in windows:
            rho, p = results[feat][w]
            if np.isfinite(rho):
                star = "*" if p < 0.05 else ""
                print(f" {rho:+.3f}{star:1s}{'':>5s}", end="")
                rhos.append(rho)
            else:
                print(f" {'n/a':>12s}", end="")

        if len(rhos) >= 3:
            signs = [np.sign(r) for r in rhos]
            same_sign = all(s == signs[0] for s in signs) and signs[0] != 0
            robust = f"{'✓' if same_sign else '✗'} {len(rhos)}/{len(windows)}"
        else:
            robust = "insuf."
            same_sign = False
        robust_scores[feat] = same_sign
        print(f" {robust:>8s}")

    print(f"\n  Interpretation:")
    print(f"  - ✓ = sign is consistent across all windows (ROBUST)")
    print(f"  - ✗ = sign flips depending on window choice (FRAGILE)")
    print(f"  - * = statistically significant at p<0.05")

    return robust_scores


# ═══════════════════════════════════════════════════════════════════════════
# TEST 5: SUBSAMPLE STABILITY (YEAR-BY-YEAR)
# ═══════════════════════════════════════════════════════════════════════════

def test5_subsample(df, sp_df):
    from scipy import stats as sp_stats

    print("\n" + "=" * 80)
    print("TEST 5: SUBSAMPLE STABILITY — YEAR-BY-YEAR BREAKDOWN")
    print("=" * 80)
    print("""
┌─────────────────────────────────────────────────────────────────────────┐
│ WHAT: Does each feature work consistently across different years, or  │
│       is it driven by one lucky period?                               │
│                                                                       │
│ WHY:  A factor that works in 2022 but fails in 2021, 2023-2025 is    │
│       unreliable. The book requires subsample stability as one of     │
│       three robustness dimensions.                                    │
│                                                                       │
│ HOW:  For the top features (lowest BH-adjusted p-values from Test 1),│
│       compute Spearman rho separately for each year 2021-2025.       │
│       Flag features that maintain consistent sign = STABLE.           │
└─────────────────────────────────────────────────────────────────────────┘
""")

    top_feats = sp_df.head(10)["feature"].tolist()
    years = sorted(df["year"].unique())

    print(f"\n{'Feature':<25s}", end="")
    for y in years:
        n_y = len(df[df["year"] == y])
        print(f" {str(y)+'(n='+str(n_y)+')':>14s}", end="")
    print(f" {'Stable?':>8s}")
    print("─" * (25 + 14 * len(years) + 10))

    stability = {}
    for feat in top_feats:
        print(f"  {feat:<23s}", end="")
        rhos = []
        for y in years:
            sub = df[df["year"] == y][[feat, "actual_ret"]].dropna()
            if len(sub) < 8:
                print(f" {'n/a':>14s}", end="")
                continue
            rho, p = safe_spearmanr(sub[feat].values, sub["actual_ret"].values)
            star = "*" if p < 0.1 else ""
            print(f" {rho:+.3f}{star:1s}{'':>7s}", end="")
            if np.isfinite(rho):
                rhos.append(rho)

        if len(rhos) >= 3:
            signs = [np.sign(r) for r in rhos if r != 0]
            if len(signs) > 0:
                majority_sign = 1 if sum(s > 0 for s in signs) > len(signs) / 2 else -1
                same = sum(1 for s in signs if s == majority_sign)
                total = len(signs)
                stability[feat] = f"{same}/{total}"
                print(f" {same}/{total:>5d}")
            else:
                stability[feat] = "n/a"
                print(f" {'n/a':>8s}")
        else:
            stability[feat] = "insuf."
            print(f" {'insuf.':>8s}")

    print(f"\n  Interpretation:")
    print(f"  - 5/5 or 4/5 = feature direction is STABLE across years")
    print(f"  - 3/5 = moderate stability, some years disagree")
    print(f"  - 2/5 or less = UNSTABLE, likely noise or regime-dependent")

    return stability


# ═══════════════════════════════════════════════════════════════════════════
# TEST 6: LASSO FEATURE SELECTION
# ═══════════════════════════════════════════════════════════════════════════

def test6_lasso(df):
    print("\n" + "=" * 80)
    print("TEST 6: LASSO FEATURE SELECTION — MULTIVARIATE REGULARIZED REGRESSION")
    print("=" * 80)
    print("""
┌─────────────────────────────────────────────────────────────────────────┐
│ WHAT: Instead of testing features one-by-one, LASSO fits ALL features │
│       simultaneously and uses a penalty (λ) to shrink unimportant    │
│       ones to exactly zero. Only features with REAL predictive power  │
│       survive the regularization.                                     │
│                                                                       │
│ WHY:  The book recommends penalized regression (Ridge, LASSO, Elastic │
│       Net) as the key ML method for factor selection. LASSO is ideal  │
│       because it performs automatic feature selection.                │
│                                                                       │
│ HOW:  1. Z-score normalize all features                              │
│       2. Fit LassoCV (cross-validated LASSO) to predict actual_ret   │
│       3. Features with non-zero coefficients = selected by LASSO     │
│       4. Compare with FDR survivors from Test 1                      │
│                                                                       │
│ Cross-validation picks the optimal λ automatically — no manual tuning.│
└─────────────────────────────────────────────────────────────────────────┘
""")

    try:
        from sklearn.linear_model import LassoCV, ElasticNetCV
        from sklearn.preprocessing import StandardScaler
    except ImportError:
        print("  ERROR: scikit-learn not installed. Skipping Test 6.")
        return {}

    feature_cols = get_feature_cols(df)
    sub = df[feature_cols + ["actual_ret"]].dropna()
    if len(sub) < 30:
        print("  Not enough data for LASSO. Skipping.")
        return {}

    X = sub[feature_cols].values.astype(float)
    y = sub["actual_ret"].values.astype(float)

    scaler = StandardScaler()
    X_z = scaler.fit_transform(X)

    # Fit LassoCV with 5-fold time-aware CV
    lasso = LassoCV(cv=5, max_iter=10000, random_state=42)
    lasso.fit(X_z, y)

    coefs = dict(zip(feature_cols, lasso.coef_))
    selected = {k: v for k, v in coefs.items() if abs(v) > 1e-8}
    not_selected = {k: v for k, v in coefs.items() if abs(v) <= 1e-8}

    print(f"\n  Optimal λ (alpha) = {lasso.alpha_:.6f}")
    print(f"  R² on training data = {lasso.score(X_z, y):.4f}")
    print(f"\n  Features SELECTED by LASSO ({len(selected)}/{len(feature_cols)}):")
    print(f"  {'Feature':<25s} {'Coeff':>10s} {'Direction':>10s}")
    print("  " + "─" * 47)
    for feat, coef in sorted(selected.items(), key=lambda x: -abs(x[1])):
        direction = "positive" if coef > 0 else "negative"
        print(f"  {feat:<25s} {coef:+10.5f} {direction:>10s}")

    print(f"\n  Features ELIMINATED by LASSO ({len(not_selected)}):")
    for feat in sorted(not_selected.keys()):
        print(f"    {feat}")

    # Also fit Elastic Net for comparison
    enet = ElasticNetCV(cv=5, max_iter=10000, random_state=42, l1_ratio=[0.1, 0.5, 0.7, 0.9, 0.95])
    enet.fit(X_z, y)
    enet_selected = {k: v for k, v in zip(feature_cols, enet.coef_) if abs(v) > 1e-8}
    print(f"\n  Elastic Net comparison: {len(enet_selected)} features selected (l1_ratio={enet.l1_ratio_:.2f})")

    print(f"\n  Interpretation:")
    print(f"  - LASSO-selected features have genuine multivariate predictive power")
    print(f"  - Features eliminated by LASSO are either redundant or noise")
    print(f"  - If a feature passes FDR (Test 1) but fails LASSO → it may be")
    print(f"    correlated with a stronger feature that LASSO kept instead")

    return selected


# ═══════════════════════════════════════════════════════════════════════════
# TEST 7: TRANSACTION COST SENSITIVITY
# ═══════════════════════════════════════════════════════════════════════════

def test7_txcost(df, sp_df):
    from scipy import stats as sp_stats

    print("\n" + "=" * 80)
    print("TEST 7: TRANSACTION COST SENSITIVITY")
    print("=" * 80)
    print(f"""
┌─────────────────────────────────────────────────────────────────────────┐
│ WHAT: Academic factors often look great on paper but fail after costs. │
│       We subtract realistic A-share round-trip costs from each trade  │
│       and re-test whether the signal still works.                     │
│                                                                       │
│ WHY:  Chen & Velikov (2019) found that after transaction costs, most  │
│       of 120 published factors had NEGATIVE average returns. The book │
│       calls this the #3 reason factors fail out-of-sample.           │
│                                                                       │
│ COSTS: Round-trip = stamp tax (0.1% sell) + commission (0.03% × 2)   │
│        + estimated slippage (0.1%) ≈ {ROUND_TRIP_COST*100:.2f}% per trade              │
│                                                                       │
│ HOW:  1. ret_net = ret - {ROUND_TRIP_COST*100:.2f}% for each trade                     │
│       2. Re-run Spearman correlation: feature vs ret_net              │
│       3. Compare with raw results                                    │
│       4. For the "best quintile" (tightest volume), report avg net   │
│          return — is it still positive?                               │
└─────────────────────────────────────────────────────────────────────────┘
""")

    df["ret_net"] = df["actual_ret"] - ROUND_TRIP_COST

    avg_raw = df['actual_ret'].mean()
    avg_net = df['ret_net'].mean()
    print(f"  Average raw return:  {avg_raw*100:+.2f}%")
    print(f"  Average net return:  {avg_net*100:+.2f}%")
    print(f"  Cost impact:         {ROUND_TRIP_COST*100:.2f}% per trade")

    print("""
  NOTE: Rank correlations are invariant to constant shifts (subtracting
  a fixed cost from all returns doesn't change ranks). So the real test
  here is: does the "best" quintile of each feature still produce
  POSITIVE average net returns after costs?
""")

    feature_cols = get_feature_cols(df)
    cost_results = {}

    # Quintile analysis for ALL features
    print(f"─── Quintile analysis: Q1 (lowest) vs Q5 (highest) avg NET return ───\n")
    print(f"  {'Feature':<25s} {'Q1_net':>10s} {'Q5_net':>10s} {'Spread':>10s} {'Best_Q+?':>9s}")
    print("  " + "─" * 67)

    for col in feature_cols:
        sub = df[[col, "ret_net", "actual_ret"]].dropna()
        if len(sub) < 25:
            continue
        try:
            sub = sub.copy()
            sub["quintile"] = pd.qcut(sub[col], 5, labels=["Q1", "Q2", "Q3", "Q4", "Q5"], duplicates="drop")
        except ValueError:
            continue
        qstats = sub.groupby("quintile")["ret_net"].mean()
        if "Q1" not in qstats.index or "Q5" not in qstats.index:
            continue
        q1_net = qstats["Q1"]
        q5_net = qstats["Q5"]
        spread = q1_net - q5_net  # negative feature → Q1 is "tighter" = better
        rho_raw, _ = safe_spearmanr(sub[col].values, sub["actual_ret"].values)
        if rho_raw < 0:
            best_q_net = q1_net
            best_label = "Q1"
        else:
            best_q_net = q5_net
            best_label = "Q5"
        positive = "✓" if best_q_net > 0 else "✗"
        cost_results[col] = best_q_net > 0
        print(f"  {col:<25s} {q1_net*100:+9.2f}% {q5_net*100:+9.2f}% {spread*100:+9.2f}%  {best_label}:{positive}")

    # Detailed breakdown for top 5 features
    print(f"\n─── Detailed quintile breakdown (top features) ───\n")
    top5 = sp_df.head(5)["feature"].tolist()
    for feat in top5:
        sub = df[[feat, "ret_net"]].dropna().copy()
        if len(sub) < 25:
            continue
        try:
            sub["quintile"] = pd.qcut(sub[feat], 5, labels=["Q1(low)", "Q2", "Q3", "Q4", "Q5(high)"], duplicates="drop")
        except ValueError:
            continue
        qstats = sub.groupby("quintile")["ret_net"].agg(["mean", "count"])
        print(f"  {feat}:")
        for q, row in qstats.iterrows():
            bar_len = max(1, int(abs(row["mean"]) * 300))
            sign = "+" if row["mean"] > 0 else ""
            color = "█" if row["mean"] > 0 else "░"
            print(f"    {q:>10s}: n={int(row['count']):3d}  avg_net={sign}{row['mean']*100:.2f}%  {color * bar_len}")
        print()

    print(f"  Interpretation:")
    print(f"  - ✓ = the \"best\" quintile has positive NET return → signal is PROFITABLE")
    print(f"  - ✗ = the \"best\" quintile has negative NET return → not actionable")
    print(f"  - Large Q1-Q5 spread = strong economic significance")

    return cost_results


# ═══════════════════════════════════════════════════════════════════════════
# FINAL SUMMARY
# ═══════════════════════════════════════════════════════════════════════════

def print_summary(mw_df, sp_df, bayes_df, ic_df, robust_scores, stability, lasso_selected, cost_results):
    print("\n" + "=" * 80)
    print("FINAL SUMMARY — ALL 7 VALIDATION GATES")
    print("=" * 80)
    print("""
  Each column represents one validation test. A feature needs to pass
  MOST gates to be considered a reliable, actionable signal.

  BH-FDR:  Survives BH correction at q<0.10 (MW board-test OR Spearman ret-test)
  Bayes:   Bayesian p-value < 0.10 (using MW p-value with theory prior)
  IC_IR:   |Information Ratio| > 0.20 (consistent across years)
  Robust:  Consistent sign across 30/45/60/90/120-day windows
  Stable:  Consistent direction across ≥3 of 5 years
  LASSO:   Selected by regularized regression
  NetCost: Best quintile has positive average NET return after costs
""")

    # Merge feature lists (union of MW + Spearman)
    all_feats_set = set()
    for df_iter in [mw_df, sp_df]:
        if df_iter is not None:
            all_feats_set.update(df_iter["feature"].tolist())
    features = sorted(all_feats_set)

    # FDR: pass if either MW or Spearman survives
    fdr_mw = set(mw_df[mw_df["survives_010"]]["feature"]) if mw_df is not None else set()
    fdr_sp = set(sp_df[sp_df["survives_010"]]["feature"]) if sp_df is not None else set()
    fdr_pass = fdr_mw | fdr_sp

    # Bayesian: also use MW p-values (typically stronger)
    bayes_pass = set()
    if bayes_df is not None and len(bayes_df) > 0:
        bayes_pass = set(bayes_df[bayes_df["bayes_p"] < 0.10]["feature"])

    ic_pass = set()
    if ic_df is not None and len(ic_df) > 0:
        for _, r in ic_df.iterrows():
            if abs(r["ir"]) > 0.20:
                ic_pass.add(r["feature"])

    print(f"{'Feature':<25s} {'BH-FDR':>7s} {'Bayes':>7s} {'IC_IR':>7s} {'Robust':>7s} {'Stable':>7s} {'LASSO':>7s} {'Net':>7s} {'Score':>7s}")
    print("─" * 90)

    scored = []
    for feat in features:
        c1 = feat in fdr_pass
        c2 = feat in bayes_pass
        c3 = feat in ic_pass
        c4 = bool(robust_scores.get(feat, False))
        c5_raw = stability.get(feat, "0/0")
        if isinstance(c5_raw, str) and "/" in c5_raw:
            parts = c5_raw.split("/")
            c5 = int(parts[0]) >= 3 if len(parts) == 2 and parts[0].isdigit() else False
        else:
            c5 = False
        c6 = feat in (lasso_selected or {})
        c7 = cost_results.get(feat, False)

        checks = [c1, c2, c3, c4, c5, c6, c7]
        score = sum(checks)
        scored.append((feat, checks, score))

    scored.sort(key=lambda x: -x[2])
    for feat, checks, score in scored:
        c1, c2, c3, c4, c5, c6, c7 = checks
        print(f"  {feat:<23s} {'✓' if c1 else '·':>7s} {'✓' if c2 else '·':>7s} {'✓' if c3 else '·':>7s} {'✓' if c4 else '·':>7s} {'✓' if c5 else '·':>7s} {'✓' if c6 else '·':>7s} {'✓' if c7 else '·':>7s} {score:>5d}/7")

    print(f"\n  Legend: ✓ = pass, · = fail")
    print(f"  Features scoring 5+/7 are strong candidates for strategy integration.")
    print(f"  Features scoring 3-4/7 deserve further investigation.")
    print(f"  Features scoring ≤2/7 are likely noise or not actionable.")


# ═══════════════════════════════════════════════════════════════════════════
# MAIN
# ═══════════════════════════════════════════════════════════════════════════

def main():
    print("╔══════════════════════════════════════════════════════════════════════╗")
    print("║  FACTOR INVESTING METHODOLOGY VALIDATION — TREND SPEAR FEATURES    ║")
    print("║  7 Tests from 《因子投资：方法与实践》                               ║")
    print("╚══════════════════════════════════════════════════════════════════════╝")

    df = load_all_data()
    if df is None or len(df) < 30:
        print("Insufficient data. Aborting.")
        return

    mw_df, sp_df = test1_fdr(df)
    bayes_df = test2_bayesian(df, mw_df, sp_df)
    ic_df, decay_df = test3_ic_decay(df)
    robust_scores = test4_robustness(df)
    stability = test5_subsample(df, sp_df)
    lasso_selected = test6_lasso(df)
    cost_results = test7_txcost(df, sp_df)
    print_summary(mw_df, sp_df, bayes_df, ic_df, robust_scores, stability, lasso_selected, cost_results)


if __name__ == "__main__":
    main()
