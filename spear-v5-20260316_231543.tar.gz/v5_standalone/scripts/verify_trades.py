"""Verify backtest integrity: pair trades, reconcile PnL, detect ghosts."""
from __future__ import annotations

import json
import sys
from collections import defaultdict
from dataclasses import dataclass

from v5.config.defaults import load_default_config, apply_execution_profile
from v5.config.pools import resolve_named_pool
from v5.backtest.runner import run_backtest
from v5.backtest.prepare import prepare_bundle
from v5.data.store import MarketStore


CONFIGS = [
    ("equity 50% mp4 trend_only", "equity", 0.50, 4,
     {"trend_spear": 1.5, "post_limit": 0, "failed_board": 0, "youzi": 0, "sector_spear": 0, "attack": 0, "arb": 0}),
    ("equity 25% mp10 current", "equity", 0.25, 10,
     {"trend_spear": 1.2, "post_limit": 0.9, "failed_board": 0.85, "youzi": 0.75, "sector_spear": 0.7, "attack": 0.55, "arb": 0.35}),
    ("equity 33% mp10 trend_heavy", "equity", 0.33, 10,
     {"trend_spear": 1.5, "post_limit": 0.5, "failed_board": 0.3, "youzi": 0.75, "sector_spear": 0.7, "attack": 0.55, "arb": 0.25}),
    ("cash 33% mp4 trend_only", "cash", 0.33, 4,
     {"trend_spear": 1.5, "post_limit": 0, "failed_board": 0, "youzi": 0, "sector_spear": 0, "attack": 0, "arb": 0}),
    ("cash 25% mp20 balanced_cut", "cash", 0.25, 20,
     {"trend_spear": 1.3, "post_limit": 0.5, "failed_board": 0.3, "youzi": 0.75, "sector_spear": 0.7, "attack": 0.55, "arb": 0.25}),
]


@dataclass
class TradePair:
    symbol: str
    buy_date: str
    buy_price: float
    buy_qty: float
    buy_cost: float  # including fees
    sell_date: str
    sell_price: float
    sell_qty: float
    sell_proceeds: float  # after fees
    pnl: float
    reason: str


def verify(name: str, arts, init_cash: float) -> None:
    trades = arts.result.trades
    open_positions = arts.result.open_positions
    summary = arts.result.summary

    print(f"\n{'='*100}")
    print(f"  VERIFY: {name}")
    print(f"{'='*100}")

    # ── 1. Parse all trades ──
    buys: dict[str, list[dict]] = defaultdict(list)
    sells: dict[str, list[dict]] = defaultdict(list)
    all_buy_count = 0
    all_sell_count = 0

    for t in trades:
        sym = str(t["symbol"]).zfill(6)
        if t["action"] == "buy":
            buys[sym].append(t)
            all_buy_count += 1
        elif t["action"] == "sell":
            sells[sym].append(t)
            all_sell_count += 1

    # ── 2. Pair buys and sells (FIFO) ──
    paired: list[TradePair] = []
    unpaired_buys: list[dict] = []
    orphan_sells: list[dict] = []

    all_symbols = set(buys.keys()) | set(sells.keys())
    for sym in sorted(all_symbols):
        sym_buys = list(buys.get(sym, []))
        sym_sells = list(sells.get(sym, []))

        # Check for orphan sells (sell without prior buy)
        buy_idx = 0
        for s in sym_sells:
            if buy_idx < len(sym_buys):
                b = sym_buys[buy_idx]
                buy_meta = json.loads(b.get("meta", "{}")) if isinstance(b.get("meta"), str) else (b.get("meta") or {})
                sell_meta = json.loads(s.get("meta", "{}")) if isinstance(s.get("meta"), str) else (s.get("meta") or {})
                buy_cash_delta = float(buy_meta.get("net_cash_delta", 0))
                sell_cash_delta = float(sell_meta.get("net_cash_delta", 0))
                pnl = buy_cash_delta + sell_cash_delta  # buy_delta is negative, sell_delta is positive
                paired.append(TradePair(
                    symbol=sym,
                    buy_date=b["date"], buy_price=float(b["price"]), buy_qty=float(b["qty"]),
                    buy_cost=-buy_cash_delta,
                    sell_date=s["date"], sell_price=float(s["price"]), sell_qty=float(s["qty"]),
                    sell_proceeds=sell_cash_delta,
                    pnl=pnl,
                    reason=s.get("reason", ""),
                ))
                buy_idx += 1
            else:
                orphan_sells.append(s)

        # Remaining unmatched buys = open positions
        for i in range(buy_idx, len(sym_buys)):
            unpaired_buys.append(sym_buys[i])

    # ── 3. Reconcile ──
    realized_pnl = sum(p.pnl for p in paired)
    total_buy_cost = sum(p.buy_cost for p in paired)
    total_sell_proceeds = sum(p.sell_proceeds for p in paired)

    # Open position unrealized PnL
    open_market_value = 0.0
    open_cost_basis = 0.0
    for pos in open_positions:
        mv = float(pos.get("last_close", 0)) * float(pos.get("qty", 0))
        cb = float(pos.get("entry_price", 0)) * float(pos.get("qty", 0))
        open_market_value += mv
        open_cost_basis += cb
    unrealized_pnl = open_market_value - open_cost_basis

    # Cash reconciliation
    final_cash = summary["final_cash"]
    reported_equity = summary["equity_final"]
    reported_ret = summary["equity_return_pct"]

    # Reconstruct equity
    reconstructed_equity = final_cash + open_market_value
    equity_diff = abs(reconstructed_equity - reported_equity)

    # Cash flow check: init_cash + all cash deltas should = final_cash
    total_cash_flow = 0.0
    for t in trades:
        meta = json.loads(t.get("meta", "{}")) if isinstance(t.get("meta"), str) else (t.get("meta") or {})
        total_cash_flow += float(meta.get("net_cash_delta", 0))
    reconstructed_cash = init_cash + total_cash_flow
    cash_diff = abs(reconstructed_cash - final_cash)

    # ── 4. Report ──
    print(f"\n  Trades: {all_buy_count} buys, {all_sell_count} sells")
    print(f"  Paired: {len(paired)} round-trips")
    print(f"  Open positions: {len(open_positions)} (from {len(unpaired_buys)} unpaired buys)")
    print(f"  Orphan sells (no matching buy): {len(orphan_sells)}")

    print(f"\n  Realized PnL (sum of paired cash deltas):  {realized_pnl:>+12,.2f}")
    print(f"  Unrealized PnL (open MV - cost):            {unrealized_pnl:>+12,.2f}")
    print(f"  Total PnL:                                  {realized_pnl + unrealized_pnl:>+12,.2f}")
    print(f"  Expected PnL (equity - init):               {reported_equity - init_cash:>+12,.2f}")
    pnl_diff = abs((realized_pnl + unrealized_pnl) - (reported_equity - init_cash))
    print(f"  PnL mismatch:                               {pnl_diff:>12,.2f} {'✓' if pnl_diff < 1.0 else '✗ MISMATCH'}")

    print(f"\n  Cash reconciliation:")
    print(f"    init_cash:                {init_cash:>14,.2f}")
    print(f"    + sum(net_cash_delta):    {total_cash_flow:>+14,.2f}")
    print(f"    = reconstructed cash:     {reconstructed_cash:>14,.2f}")
    print(f"    reported final_cash:      {final_cash:>14,.2f}")
    print(f"    diff:                     {cash_diff:>14,.4f} {'✓' if cash_diff < 1.0 else '✗ MISMATCH'}")

    print(f"\n  Equity reconciliation:")
    print(f"    final_cash:               {final_cash:>14,.2f}")
    print(f"    + open market value:      {open_market_value:>14,.2f}")
    print(f"    = reconstructed equity:   {reconstructed_equity:>14,.2f}")
    print(f"    reported equity:          {reported_equity:>14,.2f}")
    print(f"    diff:                     {equity_diff:>14,.4f} {'✓' if equity_diff < 1.0 else '✗ MISMATCH'}")

    print(f"\n  Reported return: {reported_ret:>+.2f}%")

    # ── 5. Check for qty mismatches in pairs ──
    qty_mismatches = []
    for p in paired:
        if abs(p.buy_qty - p.sell_qty) > 0.01:
            qty_mismatches.append(p)
    if qty_mismatches:
        print(f"\n  ⚠ {len(qty_mismatches)} pairs with qty mismatch (buy_qty ≠ sell_qty):")
        for p in qty_mismatches[:5]:
            print(f"    {p.symbol} buy={p.buy_qty:.0f} sell={p.sell_qty:.0f} ({p.buy_date} → {p.sell_date})")

    # ── 6. Check open positions match unpaired buys ──
    open_syms = {str(p["symbol"]).zfill(6) for p in open_positions}
    unpaired_syms = {str(b["symbol"]).zfill(6) for b in unpaired_buys}
    ghost_positions = open_syms - unpaired_syms
    missing_positions = unpaired_syms - open_syms
    if ghost_positions:
        print(f"\n  ✗ GHOST positions (in open_positions but no buy trade): {ghost_positions}")
    if missing_positions:
        print(f"\n  ✗ MISSING positions (buy trade but not in open_positions): {missing_positions}")
    if not ghost_positions and not missing_positions:
        print(f"\n  Open positions match unpaired buys: ✓")

    # ── 7. Summarize worst/best trades ──
    if paired:
        by_pnl = sorted(paired, key=lambda p: p.pnl)
        print(f"\n  Top 3 losses:")
        for p in by_pnl[:3]:
            ret = (p.sell_price / p.buy_price - 1) * 100
            print(f"    {p.symbol} {p.buy_date}→{p.sell_date} buy={p.buy_price:.2f} sell={p.sell_price:.2f} qty={p.buy_qty:.0f} pnl={p.pnl:>+,.0f} ({ret:>+.1f}%) {p.reason}")
        print(f"  Top 3 wins:")
        for p in by_pnl[-3:]:
            ret = (p.sell_price / p.buy_price - 1) * 100
            print(f"    {p.symbol} {p.buy_date}→{p.sell_date} buy={p.buy_price:.2f} sell={p.sell_price:.2f} qty={p.buy_qty:.0f} pnl={p.pnl:>+,.0f} ({ret:>+.1f}%) {p.reason}")

    # Win rate
    wins = sum(1 for p in paired if p.pnl > 0)
    losses = sum(1 for p in paired if p.pnl < 0)
    flat = sum(1 for p in paired if p.pnl == 0)
    if paired:
        print(f"\n  Win/Loss/Flat: {wins}/{losses}/{flat} (win rate {wins/len(paired)*100:.1f}%)")
        avg_win = sum(p.pnl for p in paired if p.pnl > 0) / max(wins, 1)
        avg_loss = sum(p.pnl for p in paired if p.pnl < 0) / max(losses, 1)
        print(f"  Avg win: {avg_win:>+,.0f}  Avg loss: {avg_loss:>+,.0f}  Ratio: {abs(avg_win/avg_loss) if avg_loss != 0 else 0:.2f}")

    ok = equity_diff < 1.0 and cash_diff < 1.0 and pnl_diff < 1.0 and not ghost_positions and not missing_positions and not orphan_sells
    print(f"\n  {'✓ ALL CHECKS PASSED' if ok else '✗ ISSUES FOUND'}")
    return ok


def main() -> None:
    cfg = load_default_config()
    apply_execution_profile(cfg, "delayed_limit_hunt")
    cfg.data.disable_env_mapping = True

    year = sys.argv[1] if len(sys.argv) > 1 else "2026"
    init_cash = 1_000_000.0

    store = MarketStore("cache/market.duckdb")
    symbols = resolve_named_pool("50-150cyc")
    print(f"Pool: {len(symbols)} symbols | Year: {year}")

    bundle = prepare_bundle(
        cfg, start=f"{year}-01-01", end=f"{year}-12-31",
        pool_size=len(symbols), symbols=symbols, store=store,
    )

    all_ok = True
    for name, sizing, bp, mp, mults in CONFIGS:
        cfg.execution.position_sizing_base = sizing
        cfg.execution.base_pos_pct = bp
        cfg.execution.max_positions = mp
        cfg.execution.trend_spear_pos_mult = mults["trend_spear"]
        cfg.execution.post_limit_pos_mult = mults["post_limit"]
        cfg.execution.failed_board_pos_mult = mults["failed_board"]
        cfg.execution.youzi_pos_mult = mults["youzi"]
        cfg.execution.sector_spear_pos_mult = mults["sector_spear"]
        cfg.execution.attack_pos_mult = mults["attack"]
        cfg.execution.arb_pos_mult = mults["arb"]

        arts = run_backtest(
            cfg=cfg, start=f"{year}-01-01", end=f"{year}-12-31",
            pool_size=len(symbols), initial_cash=init_cash,
            symbols=symbols, bundle=bundle, store=store,
        )
        ok = verify(name, arts, init_cash)
        if not ok:
            all_ok = False

    print(f"\n{'='*100}")
    print(f"  FINAL: {'ALL CONFIGS PASSED ✓' if all_ok else 'SOME CONFIGS HAVE ISSUES ✗'}")
    print(f"{'='*100}")


if __name__ == "__main__":
    main()
