#!/usr/bin/env python3
"""
Build selected_stock_picks.csv from backtest events.csv + cached price data.

Modes:
  --from-backtests   Auto-detect latest 50-150cyc_dlh backtest per year
  --years 2019 2023  Only process specific years (default: all available)
  --append           Append to existing CSV (skip years already present)
  --replace          Rebuild from scratch (default)

Usage:
  python scripts/extend_signal_csv.py --from-backtests --replace
  python scripts/extend_signal_csv.py --from-backtests --append --years 2019 2020 2021 2023
"""
from __future__ import annotations

import argparse
import json
import pickle
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
CACHE_DIR = ROOT / "cache"
BACKTESTS_DIR = ROOT / "outputs" / "backtests"
OUTPUT_CSV = ROOT / "outputs" / "analysis" / "signal_value_status_20260313" / "selected_stock_picks.csv"

FORWARD_DAYS = [1, 3, 5, 10, 20]


def find_best_backtest(year: int, pool_pattern: str = "50-150cyc") -> Path | None:
    """Find the latest backtest for a year matching the pool pattern."""
    oracle_dir = BACKTESTS_DIR / f"oracle_{year}_{pool_pattern}_dlh"
    if oracle_dir.exists() and (oracle_dir / "events.csv").exists():
        return oracle_dir

    candidates = sorted(BACKTESTS_DIR.glob(f"*{year}-{year}*{pool_pattern}*dlh*"))
    best = None
    best_events = 0
    for c in candidates:
        events_path = c / "events.csv"
        meta_path = c / "meta.json"
        if not events_path.exists() or not meta_path.exists():
            continue
        try:
            meta = json.loads(meta_path.read_text())
            cfg = meta.get("config", {})
            if not cfg.get("disable_env_mapping"):
                continue
            if (cfg.get("warmup_bars") or 0) < 600:
                continue
        except Exception:
            continue
        n_events = sum(1 for _ in open(events_path)) - 1
        if n_events > best_events:
            best_events = n_events
            best = c
    return best


def load_price_data(symbol: str) -> pd.DataFrame | None:
    pkl_path = CACHE_DIR / f"{symbol}_full.pkl"
    if not pkl_path.exists():
        return None
    try:
        df = pickle.loads(pkl_path.read_bytes())
        if "date" not in df.columns and df.index.name == "date":
            df = df.reset_index()
        df["date_str"] = pd.to_datetime(df["date"]).dt.strftime("%Y-%m-%d")
        df = df.sort_values("date_str").reset_index(drop=True)
        return df
    except Exception:
        return None


def compute_forward_returns(signal_date: str, symbol: str, price_cache: dict) -> dict | None:
    if symbol not in price_cache:
        pdf = load_price_data(symbol)
        price_cache[symbol] = pdf

    pdf = price_cache.get(symbol)
    if pdf is None:
        return None

    mask = pdf["date_str"] == signal_date
    if not mask.any():
        return None

    idx = mask.idxmax()
    close = float(pdf.loc[idx, "close"])
    if close <= 0:
        return None

    result = {"close": close}
    for d in FORWARD_DAYS:
        end_idx = min(idx + d, len(pdf) - 1)
        if end_idx <= idx:
            result[f"close_ret_{d}d"] = 0.0
            result[f"max_high_ret_{d}d"] = 0.0
            result[f"min_low_ret_{d}d"] = 0.0
            continue

        fwd = pdf.iloc[idx + 1 : end_idx + 1]
        if len(fwd) == 0:
            result[f"close_ret_{d}d"] = 0.0
            result[f"max_high_ret_{d}d"] = 0.0
            result[f"min_low_ret_{d}d"] = 0.0
            continue

        close_d = float(fwd.iloc[-1]["close"])
        high_max = float(fwd["high"].max())
        low_min = float(fwd["low"].min())

        result[f"close_ret_{d}d"] = close_d / close - 1.0
        result[f"max_high_ret_{d}d"] = high_max / close - 1.0
        result[f"min_low_ret_{d}d"] = low_min / close - 1.0

    return result


def process_backtest(bt_dir: Path, year: int) -> pd.DataFrame | None:
    events_path = bt_dir / "events.csv"
    if not events_path.exists():
        print(f"  [skip] {events_path} not found")
        return None

    events = pd.read_csv(events_path, low_memory=False)
    events = events[events["side"] == "long"].copy()
    print(f"  [read] {bt_dir.name}/events.csv: {len(events)} long signals")

    price_cache: dict = {}
    rows = []
    skipped = 0

    for _, row in events.iterrows():
        fwd = compute_forward_returns(row["date"], str(row["symbol"]).zfill(6), price_cache)
        if fwd is None:
            skipped += 1
            continue

        out = {
            "date": row["date"],
            "symbol": row["symbol"],
            "event_type": row["event_type"],
            "confidence": row["confidence"],
            "side": row["side"],
            "entry_plan": row["entry_plan"],
            "invalidation": row["invalidation"],
            "exit_plan": row["exit_plan"],
            "context": row["context"],
            "close": fwd["close"],
        }
        for d in FORWARD_DAYS:
            out[f"close_ret_{d}d"] = round(fwd[f"close_ret_{d}d"], 6)
            out[f"max_high_ret_{d}d"] = round(fwd[f"max_high_ret_{d}d"], 6)
            out[f"min_low_ret_{d}d"] = round(fwd[f"min_low_ret_{d}d"], 6)
        out["year"] = year

        rows.append(out)

    if skipped:
        print(f"  [warn] Skipped {skipped}/{len(events)} signals (no price data)")
    print(f"  [done] {len(rows)} signals with forward returns")

    if not rows:
        return None
    return pd.DataFrame(rows)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--from-backtests", action="store_true", help="Auto-detect backtests")
    parser.add_argument("--years", type=int, nargs="*", default=None, help="Years to process (default: all 2019-2025)")
    parser.add_argument("--append", action="store_true", help="Append to existing CSV")
    parser.add_argument("--replace", action="store_true", help="Rebuild from scratch (default)")
    parser.add_argument("--pool-pattern", default="50-150cyc", help="Pool pattern to match backtests")
    parser.add_argument("--output", type=str, default=str(OUTPUT_CSV))
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()

    all_years = args.years or list(range(2019, 2026))

    if args.append and OUTPUT_CSV.exists():
        existing = pd.read_csv(str(OUTPUT_CSV), low_memory=False)
        existing_years = set(int(y) for y in existing["year"].unique())
        print(f"[existing] {len(existing)} signals, years: {sorted(existing_years)}")
        years_to_run = [y for y in all_years if y not in existing_years]
    else:
        existing = None
        existing_years = set()
        years_to_run = all_years

    if not years_to_run:
        print("[done] All requested years already in CSV")
        return

    frames = []
    for year in years_to_run:
        print(f"\n=== {year} ===")
        if args.from_backtests:
            bt_dir = find_best_backtest(year, args.pool_pattern)
            if bt_dir is None:
                print(f"  [skip] No matching backtest found for {year}")
                continue
            print(f"  [backtest] {bt_dir.name}")
        else:
            bt_dir = find_best_backtest(year, args.pool_pattern)
            if bt_dir is None:
                print(f"  [skip] No backtest found for {year}")
                continue
            print(f"  [auto] {bt_dir.name}")

        df = process_backtest(bt_dir, year)
        if df is not None:
            frames.append(df)

    if not frames:
        print("\n[done] No new data produced")
        return

    new_df = pd.concat(frames, ignore_index=True)

    if existing is not None and args.append:
        cols = existing.columns.tolist()
        for c in cols:
            if c not in new_df.columns:
                new_df[c] = np.nan
        combined = pd.concat([existing, new_df[cols]], ignore_index=True)
    else:
        combined = new_df

    combined = combined.sort_values(["year", "date", "symbol"]).reset_index(drop=True)

    print(f"\n[result] {len(combined)} signals total")
    for y in sorted(combined["year"].unique()):
        print(f"  {int(y)}: {len(combined[combined['year'] == y])} signals")

    if args.dry_run:
        print("\n[dry-run] Not writing output")
    else:
        Path(args.output).parent.mkdir(parents=True, exist_ok=True)
        combined.to_csv(args.output, index=False)
        print(f"\n[wrote] {args.output}")


if __name__ == "__main__":
    main()
