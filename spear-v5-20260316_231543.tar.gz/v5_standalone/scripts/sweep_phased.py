"""Phased position sweep: 4 sequential phases, ~40 runs total, zero redundancy.

Usage:
    python scripts/sweep_phased.py 0                    # Phase 0: equity vs cash (6 runs)
    python scripts/sweep_phased.py 1 --mode equity      # Phase 1: effective position size (12 runs)
    python scripts/sweep_phased.py 2 --mode equity --eff-pct 0.50  # Phase 2: base×mult interaction (12 runs)
    python scripts/sweep_phased.py 3 --mode equity --base-pct 0.25 --trend-mult 2.0 --sec off  # Phase 3: mp sweep (10 runs)

Each phase prints results; you pick the winner and feed it to the next phase.
Results are saved to outputs/sweeps/phase{N}_{timestamp}.csv
"""
from __future__ import annotations

import argparse
import csv
import json
import sys
import time
from collections import defaultdict
from dataclasses import dataclass, asdict, fields
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from v5.config.defaults import load_default_config, apply_execution_profile
from v5.config.pools import resolve_named_pool
from v5.backtest.runner import run_backtest
from v5.backtest.prepare import prepare_bundle
from v5.data.store import MarketStore

DEFAULT_YEARS = ["2025", "2026"]
YEARS: list[str] = []  # set from CLI

SEC_PROFILES = {
    "off":  {"post_limit": 0.0, "failed_board": 0.0, "youzi": 0.0, "sector_spear": 0.0, "attack": 0.0, "arb": 0.0},
    "low":  {"post_limit": 0.4, "failed_board": 0.3, "youzi": 0.3, "sector_spear": 0.3, "attack": 0.3, "arb": 0.2},
    "full": {"post_limit": 0.9, "failed_board": 0.85, "youzi": 0.75, "sector_spear": 0.7, "attack": 0.55, "arb": 0.35},
}

MULT_KEYS = ["trend_spear", "post_limit", "failed_board", "youzi", "sector_spear", "attack", "arb"]


SWEEP_DIR = Path("outputs/sweeps")


@dataclass
class R:
    phase: int
    year: str
    label: str
    mode: str
    base_pct: float
    trend_mult: float
    eff_pct: float
    sec: str
    mp: int
    ret: float
    trades: int
    open_pos: int
    equity_final: float
    fees: float


def _set_mults(cfg, trend_mult: float, sec: dict) -> None:
    cfg.execution.trend_spear_pos_mult = trend_mult
    cfg.execution.post_limit_pos_mult = sec.get("post_limit", 0.0)
    cfg.execution.failed_board_pos_mult = sec.get("failed_board", 0.0)
    cfg.execution.youzi_pos_mult = sec.get("youzi", 0.0)
    cfg.execution.sector_spear_pos_mult = sec.get("sector_spear", 0.0)
    cfg.execution.attack_pos_mult = sec.get("attack", 0.0)
    cfg.execution.arb_pos_mult = sec.get("arb", 0.0)


def _run(cfg, year, symbols, bundle, store) -> dict:
    arts = run_backtest(
        cfg=cfg, start=f"{year}-01-01", end=f"{year}-12-31",
        pool_size=len(symbols), initial_cash=1_000_000.0,
        symbols=symbols, bundle=bundle, store=store,
    )
    return arts.result.summary


def _save(results: list[R], phase: int | str) -> Path:
    SWEEP_DIR.mkdir(parents=True, exist_ok=True)
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    csv_path = SWEEP_DIR / f"phase{phase}_{ts}.csv"
    field_names = [f.name for f in fields(R)]
    with open(csv_path, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=field_names)
        w.writeheader()
        for r in results:
            w.writerow(asdict(r))
    print(f"💾 Results saved to {csv_path}")
    return csv_path


def _base_cfg():
    cfg = load_default_config()
    apply_execution_profile(cfg, "delayed_limit_hunt")
    cfg.data.disable_env_mapping = True
    return cfg


def _prepare(cfg, year, symbols, store):
    return prepare_bundle(
        cfg, start=f"{year}-01-01", end=f"{year}-12-31",
        pool_size=len(symbols), symbols=symbols, store=store,
    )


def _print_table(results: list[R], group_key="label"):
    groups: dict[str, dict[str, R]] = defaultdict(dict)
    for r in results:
        groups[r.label][r.year] = r
    labels = list(dict.fromkeys(r.label for r in results))
    years_seen = list(dict.fromkeys(r.year for r in results))

    header = f"\n{'label':<45}"
    for y in years_seen:
        header += f" | {y:>8} {'tr':>5}"
    header += f" | {'avg':>8}"
    print(header)
    print("-" * (50 + 17 * len(years_seen) + 12))
    for label in labels:
        yr = groups[label]
        vals = []
        parts = []
        for y in years_seen:
            if y in yr:
                vals.append(yr[y].ret)
                parts.append(f"{yr[y].ret:>+7.1f}% {yr[y].trades:>5d}")
            else:
                parts.append(f"{'':>8} {'':>5}")
        avg = sum(vals) / len(vals) if vals else 0
        print(f"{label:<45} | {' | '.join(parts)} | {avg:>+7.1f}%")
    print()


# ── Phase 0: equity vs cash ──────────────────────────────────────────────────

def phase0(store, symbols) -> list[R]:
    """3 representative configs × 2 modes × 2 years."""
    configs = [
        ("小仓集中 bp=15% mp=4 trend_only", 0.15, 4, 1.5, "off"),
        ("中仓均衡 bp=25% mp=10 full",       0.25, 10, 1.2, "full"),
        ("大仓趋势 bp=50% mp=4 trend_only",  0.50, 4, 1.5, "off"),
    ]
    results: list[R] = []
    total = len(YEARS) * len(configs) * 2
    done = 0

    for year in YEARS:
        cfg = _base_cfg()
        bundle = _prepare(cfg, year, symbols, store)
        for mode in ["cash", "equity"]:
            for desc, bp, mp, tm, sec_name in configs:
                cfg.execution.position_sizing_base = mode
                cfg.execution.base_pos_pct = bp
                cfg.execution.max_positions = mp
                _set_mults(cfg, tm, SEC_PROFILES[sec_name])
                s = _run(cfg, year, symbols, bundle, store)
                done += 1
                label = f"{mode:6s} | {desc}"
                r = R(phase=0, year=year, label=label, mode=mode, base_pct=bp,
                      trend_mult=tm, eff_pct=round(bp * tm, 4), sec=sec_name, mp=mp,
                      ret=s["equity_return_pct"], trades=s["trade_count"],
                      open_pos=s["open_count"], equity_final=s["equity_final"], fees=s["total_fees"])
                results.append(r)
                print(f"  [{done}/{total}] {year} {label} → {r.ret:>+7.1f}%  ({r.trades} trades)")

    print("\n" + "=" * 95)
    print("  PHASE 0: equity vs cash")
    print("=" * 95)
    _print_table(results)
    print("→ Pick the winning mode and run:  python scripts/sweep_phased.py 1 --mode <cash|equity>")
    return results


# ── Phase 1: effective position size ──────────────────────────────────────────

def phase1(store, symbols, mode: str) -> list[R]:
    """trend_only, mp=20, fixed base=50%, sweep trend_mult for effective %."""
    eff_targets = [
        (0.15, 0.30), (0.25, 0.50), (0.33, 0.66), (0.50, 1.00), (0.66, 1.32), (0.75, 1.50),
    ]
    results: list[R] = []
    total = len(YEARS) * len(eff_targets)
    done = 0

    for year in YEARS:
        cfg = _base_cfg()
        bundle = _prepare(cfg, year, symbols, store)
        for eff_pct, trend_mult in eff_targets:
            cfg.execution.position_sizing_base = mode
            cfg.execution.base_pos_pct = 0.50
            cfg.execution.max_positions = 20
            _set_mults(cfg, trend_mult, SEC_PROFILES["off"])
            s = _run(cfg, year, symbols, bundle, store)
            done += 1
            label = f"eff={eff_pct:.0%}  (base=50% × mult={trend_mult:.2f})"
            r = R(phase=1, year=year, label=label, mode=mode, base_pct=0.50,
                  trend_mult=trend_mult, eff_pct=eff_pct, sec="off", mp=20,
                  ret=s["equity_return_pct"], trades=s["trade_count"],
                  open_pos=s["open_count"], equity_final=s["equity_final"], fees=s["total_fees"])
            results.append(r)
            print(f"  [{done}/{total}] {year} {label} → {r.ret:>+7.1f}%  ({r.trades} trades)")

    print("\n" + "=" * 95)
    print(f"  PHASE 1: effective position size ({mode} mode, trend_only, mp=20)")
    print("=" * 95)
    _print_table(results)
    print(f"→ Pick best eff%, then run:  python scripts/sweep_phased.py 2 --mode {mode} --eff-pct <value>")
    return results


# ── Phase 2: base×mult interaction + secondary signals ───────────────────────

def phase2(store, symbols, mode: str, eff_pct: float) -> list[R]:
    """Same effective trend %, different base_pos_pct → different secondary signal sizes."""
    base_options = []
    for base in [0.25, 0.33, 0.50]:
        mult = eff_pct / base
        if mult < 0.1 or mult > 2.0:
            continue
        base_options.append((base, round(mult, 3)))

    if not base_options:
        print(f"ERROR: no valid base_pos_pct can achieve eff={eff_pct:.0%} with mult in [0.1, 2.0]")
        return []

    combos = []
    for base, mult in base_options:
        for sec_name in SEC_PROFILES:
            combos.append((base, mult, sec_name))

    results: list[R] = []
    total = len(YEARS) * len(combos)
    done = 0

    for year in YEARS:
        cfg = _base_cfg()
        bundle = _prepare(cfg, year, symbols, store)
        for base, mult, sec_name in combos:
            cfg.execution.position_sizing_base = mode
            cfg.execution.base_pos_pct = base
            cfg.execution.max_positions = 20
            _set_mults(cfg, mult, SEC_PROFILES[sec_name])
            s = _run(cfg, year, symbols, bundle, store)
            done += 1
            label = f"base={base:.0%} mult={mult:.2f} sec={sec_name:<4s}  (eff_trend={eff_pct:.0%})"
            r = R(phase=2, year=year, label=label, mode=mode, base_pct=base,
                  trend_mult=mult, eff_pct=eff_pct, sec=sec_name, mp=20,
                  ret=s["equity_return_pct"], trades=s["trade_count"],
                  open_pos=s["open_count"], equity_final=s["equity_final"], fees=s["total_fees"])
            results.append(r)
            print(f"  [{done}/{total}] {year} {label} → {r.ret:>+7.1f}%  ({r.trades} trades)")

    print("\n" + "=" * 95)
    print(f"  PHASE 2: base×mult interaction ({mode}, eff_trend={eff_pct:.0%}, mp=20)")
    print("=" * 95)
    _print_table(results)
    print(f"→ Pick best base/mult/sec combo, then run:")
    print(f"   python scripts/sweep_phased.py 3 --mode {mode} --base-pct <bp> --trend-mult <tm> --sec <off|low|full>")
    return results


# ── Phase 3: max positions ───────────────────────────────────────────────────

def phase3(store, symbols, mode: str, base_pct: float, trend_mult: float, sec_name: str) -> list[R]:
    """Sweep mp with the optimal config from Phase 2."""
    mp_values = [1, 2, 4, 10, 20]
    results: list[R] = []
    total = len(YEARS) * len(mp_values)
    done = 0
    eff_pct = round(base_pct * trend_mult, 4)

    for year in YEARS:
        cfg = _base_cfg()
        bundle = _prepare(cfg, year, symbols, store)
        for mp in mp_values:
            cfg.execution.position_sizing_base = mode
            cfg.execution.base_pos_pct = base_pct
            cfg.execution.max_positions = mp
            _set_mults(cfg, trend_mult, SEC_PROFILES[sec_name])
            s = _run(cfg, year, symbols, bundle, store)
            done += 1
            label = f"mp={mp:<2d}  (base={base_pct:.0%} mult={trend_mult:.2f} sec={sec_name})"
            r = R(phase=3, year=year, label=label, mode=mode, base_pct=base_pct,
                  trend_mult=trend_mult, eff_pct=eff_pct, sec=sec_name, mp=mp,
                  ret=s["equity_return_pct"], trades=s["trade_count"],
                  open_pos=s["open_count"], equity_final=s["equity_final"], fees=s["total_fees"])
            results.append(r)
            print(f"  [{done}/{total}] {year} {label} → {r.ret:>+7.1f}%  ({r.trades} trades)")

    print("\n" + "=" * 95)
    print(f"  PHASE 3: max positions ({mode}, base={base_pct:.0%}, mult={trend_mult:.2f}, sec={sec_name})")
    print("=" * 95)
    _print_table(results)
    print(f"\n✓ Final optimal config:")
    print(f"  mode={mode}  base_pos_pct={base_pct}  trend_mult={trend_mult}  eff_trend={eff_pct:.0%}  sec={sec_name}  mp=<your pick>")
    return results


# ── Auto-select best from phase results ──────────────────────────────────────

def _avg_ret(results: list[R], key_fn) -> dict:
    """Group by key_fn, return {key: avg_ret} across years."""
    groups: dict[str, list[float]] = defaultdict(list)
    for r in results:
        groups[key_fn(r)].append(r.ret)
    return {k: sum(v) / len(v) for k, v in groups.items()}


def _pick_phase0(results: list[R]) -> str:
    avg = _avg_ret(results, lambda r: r.mode)
    best = max(avg, key=avg.get)  # type: ignore[arg-type]
    print(f"\n  ★ Phase 0 auto-pick: {best} (avg {avg[best]:+.1f}% vs {[f'{k} {v:+.1f}%' for k, v in avg.items()]})")
    return best


def _pick_phase1(results: list[R]) -> float:
    avg = _avg_ret(results, lambda r: str(r.eff_pct))
    best_key = max(avg, key=avg.get)  # type: ignore[arg-type]
    best_eff = float(best_key)
    print(f"\n  ★ Phase 1 auto-pick: eff={best_eff:.0%} (avg {avg[best_key]:+.1f}%)")
    return best_eff


def _pick_phase2(results: list[R]) -> tuple[float, float, str]:
    avg = _avg_ret(results, lambda r: f"{r.base_pct}|{r.trend_mult}|{r.sec}")
    best_key = max(avg, key=avg.get)  # type: ignore[arg-type]
    parts = best_key.split("|")
    bp, tm, sec = float(parts[0]), float(parts[1]), parts[2]
    print(f"\n  ★ Phase 2 auto-pick: base={bp:.0%} mult={tm:.2f} sec={sec} (avg {avg[best_key]:+.1f}%)")
    return bp, tm, sec


def _pick_phase3(results: list[R]) -> int:
    avg = _avg_ret(results, lambda r: str(r.mp))
    best_key = max(avg, key=avg.get)  # type: ignore[arg-type]
    best_mp = int(best_key)
    print(f"\n  ★ Phase 3 auto-pick: mp={best_mp} (avg {avg[best_key]:+.1f}%)")
    return best_mp


# ── Full auto mode ───────────────────────────────────────────────────────────

def run_auto(store, symbols):
    """Run all 4 phases sequentially, auto-picking winners."""
    all_results: list[R] = []

    print("━" * 95)
    print("  AUTO MODE: running Phase 0 → 1 → 2 → 3")
    print("━" * 95)

    # Phase 0
    r0 = phase0(store, symbols)
    all_results.extend(r0)
    _save(r0, 0)
    mode = _pick_phase0(r0)

    # Phase 1
    print()
    r1 = phase1(store, symbols, mode)
    all_results.extend(r1)
    _save(r1, 1)
    eff_pct = _pick_phase1(r1)

    # Phase 2
    print()
    r2 = phase2(store, symbols, mode, eff_pct)
    all_results.extend(r2)
    _save(r2, 2)
    if not r2:
        print("Phase 2 returned no results, stopping.")
        return all_results
    bp, tm, sec = _pick_phase2(r2)

    # Phase 3
    print()
    r3 = phase3(store, symbols, mode, bp, tm, sec)
    all_results.extend(r3)
    _save(r3, 3)
    best_mp = _pick_phase3(r3)

    eff = bp * tm
    print("\n" + "━" * 95)
    print("  AUTO MODE COMPLETE — FINAL OPTIMAL CONFIG")
    print("━" * 95)
    print(f"  mode             = {mode}")
    print(f"  base_pos_pct     = {bp}")
    print(f"  trend_spear_mult = {tm}")
    print(f"  eff_trend_pos    = {eff:.0%}")
    print(f"  secondary        = {sec}")
    print(f"  max_positions    = {best_mp}")
    print("━" * 95)

    _save(all_results, phase="all")
    return all_results


# ── CLI ──────────────────────────────────────────────────────────────────────

def main():
    p = argparse.ArgumentParser(prog="sweep_phased", description="Phased position sweep")
    p.add_argument("phase", type=str, help="phase number (0-3) or 'auto' for full run")
    p.add_argument("--years", nargs="+", default=DEFAULT_YEARS, help="years to test (default: 2025 2026)")
    p.add_argument("--mode", choices=["cash", "equity"], help="sizing mode (Phase 1+)")
    p.add_argument("--eff-pct", type=float, help="target effective trend position (Phase 2)")
    p.add_argument("--base-pct", type=float, help="base_pos_pct (Phase 3)")
    p.add_argument("--trend-mult", type=float, help="trend_spear_pos_mult (Phase 3)")
    p.add_argument("--sec", choices=["off", "low", "full"], default="off", help="secondary signal profile (Phase 3)")
    args = p.parse_args()

    if args.phase not in ("0", "1", "2", "3", "auto"):
        p.error("phase must be 0, 1, 2, 3, or 'auto'")

    global YEARS
    YEARS = sorted(args.years)

    store = MarketStore("cache/market.duckdb")
    symbols = resolve_named_pool("50-150cyc")
    print(f"Pool: {len(symbols)} symbols | Phase: {args.phase} | Years: {', '.join(YEARS)}\n")

    t0 = time.monotonic()

    if args.phase == "auto":
        run_auto(store, symbols)
    else:
        phase_num = int(args.phase)
        results: list[R] = []
        if phase_num == 0:
            results = phase0(store, symbols)
        elif phase_num == 1:
            if not args.mode:
                p.error("Phase 1 requires --mode")
            results = phase1(store, symbols, args.mode)
        elif phase_num == 2:
            if not args.mode or args.eff_pct is None:
                p.error("Phase 2 requires --mode and --eff-pct")
            results = phase2(store, symbols, args.mode, args.eff_pct)
        elif phase_num == 3:
            if not all([args.mode, args.base_pct, args.trend_mult]):
                p.error("Phase 3 requires --mode, --base-pct, --trend-mult, --sec")
            results = phase3(store, symbols, args.mode, args.base_pct, args.trend_mult, args.sec)
        if results:
            _save(results, phase_num)

    elapsed = time.monotonic() - t0
    print(f"\nDone in {elapsed:.0f}s")


if __name__ == "__main__":
    main()
