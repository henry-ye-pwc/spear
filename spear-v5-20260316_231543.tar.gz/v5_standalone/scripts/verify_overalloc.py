"""Check for over-allocation: does total position value ever exceed equity?"""
from __future__ import annotations

import json
import sys
from collections import defaultdict

from v5.config.defaults import load_default_config, apply_execution_profile
from v5.config.pools import resolve_named_pool
from v5.backtest.runner import run_backtest
from v5.backtest.prepare import prepare_bundle
from v5.data.store import MarketStore


CONFIGS = [
    # (name, sizing, bp, mp, mults)
    ("equity 50% mp1 trend_only", "equity", 0.50, 1,
     {"trend_spear": 1.5, "post_limit": 0, "failed_board": 0, "youzi": 0, "sector_spear": 0, "attack": 0, "arb": 0}),
    ("equity 50% mp2 trend_only", "equity", 0.50, 2,
     {"trend_spear": 1.5, "post_limit": 0, "failed_board": 0, "youzi": 0, "sector_spear": 0, "attack": 0, "arb": 0}),
    ("equity 50% mp4 trend_only", "equity", 0.50, 4,
     {"trend_spear": 1.5, "post_limit": 0, "failed_board": 0, "youzi": 0, "sector_spear": 0, "attack": 0, "arb": 0}),
    ("equity 25% mp4 current", "equity", 0.25, 4,
     {"trend_spear": 1.2, "post_limit": 0.9, "failed_board": 0.85, "youzi": 0.75, "sector_spear": 0.7, "attack": 0.55, "arb": 0.35}),
    ("equity 25% mp10 current", "equity", 0.25, 10,
     {"trend_spear": 1.2, "post_limit": 0.9, "failed_board": 0.85, "youzi": 0.75, "sector_spear": 0.7, "attack": 0.55, "arb": 0.35}),
    ("equity 33% mp4 trend_heavy", "equity", 0.33, 4,
     {"trend_spear": 1.5, "post_limit": 0.5, "failed_board": 0.3, "youzi": 0.75, "sector_spear": 0.7, "attack": 0.55, "arb": 0.25}),
    ("equity 33% mp10 trend_heavy", "equity", 0.33, 10,
     {"trend_spear": 1.5, "post_limit": 0.5, "failed_board": 0.3, "youzi": 0.75, "sector_spear": 0.7, "attack": 0.55, "arb": 0.25}),
]


def analyze(name: str, arts, init_cash: float) -> None:
    trades = arts.result.trades
    summary = arts.result.summary

    # Reconstruct daily positions
    holdings: dict[str, dict] = {}  # sym -> {qty, entry_price, buy_cost}
    cash = init_cash
    daily_snapshots: list[dict] = []

    cur_date = ""
    for t in trades:
        date = t["date"]
        sym = str(t["symbol"]).zfill(6)
        meta = json.loads(t.get("meta", "{}")) if isinstance(t.get("meta"), str) else (t.get("meta") or {})
        cash_delta = float(meta.get("net_cash_delta", 0))

        if date != cur_date and cur_date:
            # snapshot at end of previous date
            total_cost = sum(h["qty"] * h["entry_price"] for h in holdings.values())
            daily_snapshots.append({
                "date": cur_date,
                "n_pos": len(holdings),
                "cash": cash,
                "total_cost_basis": total_cost,
            })
        cur_date = date

        if t["action"] == "buy":
            holdings[sym] = {"qty": float(t["qty"]), "entry_price": float(t["price"])}
        elif t["action"] == "sell":
            holdings.pop(sym, None)
        cash += cash_delta

    # final snapshot
    if cur_date:
        total_cost = sum(h["qty"] * h["entry_price"] for h in holdings.values())
        daily_snapshots.append({
            "date": cur_date,
            "n_pos": len(holdings),
            "cash": cash,
            "total_cost_basis": total_cost,
        })

    peak_pos = max((s["n_pos"] for s in daily_snapshots), default=0)
    peak_alloc_pct = max((s["total_cost_basis"] / (s["total_cost_basis"] + s["cash"]) * 100 for s in daily_snapshots if s["total_cost_basis"] + s["cash"] > 0), default=0)
    min_cash = min((s["cash"] for s in daily_snapshots), default=0)
    over_alloc_days = sum(1 for s in daily_snapshots if s["total_cost_basis"] > (s["total_cost_basis"] + s["cash"]) * 1.0)

    # Per-buy allocation as % of equity at time of buy
    buy_allocs: list[dict] = []
    cash_track = init_cash
    holdings_track: dict[str, dict] = {}
    for t in trades:
        meta = json.loads(t.get("meta", "{}")) if isinstance(t.get("meta"), str) else (t.get("meta") or {})
        cash_delta = float(meta.get("net_cash_delta", 0))
        sym = str(t["symbol"]).zfill(6)
        if t["action"] == "buy":
            buy_cost = float(t["price"]) * float(t["qty"])
            # estimate equity at buy time
            pos_value = sum(h["qty"] * h["entry_price"] for h in holdings_track.values())
            equity_at_buy = cash_track + pos_value
            alloc_pct = buy_cost / equity_at_buy * 100 if equity_at_buy > 0 else 0
            buy_allocs.append({
                "date": t["date"], "symbol": sym,
                "buy_cost": buy_cost, "equity": equity_at_buy,
                "alloc_pct": alloc_pct, "cash_before": cash_track,
                "n_pos_before": len(holdings_track),
            })
            holdings_track[sym] = {"qty": float(t["qty"]), "entry_price": float(t["price"])}
        elif t["action"] == "sell":
            holdings_track.pop(sym, None)
        cash_track += cash_delta

    print(f"\n  {name}")
    print(f"  {'─'*70}")
    print(f"  Return: {summary['equity_return_pct']:>+.1f}%  |  Buys: {summary['buy_count']}  |  Peak positions: {peak_pos}  |  Peak alloc: {peak_alloc_pct:.1f}%  |  Min cash: ¥{min_cash:,.0f}")

    if buy_allocs:
        max_alloc = max(buy_allocs, key=lambda x: x["alloc_pct"])
        print(f"  Largest single buy: {max_alloc['symbol']} on {max_alloc['date']} — ¥{max_alloc['buy_cost']:,.0f} = {max_alloc['alloc_pct']:.1f}% of equity (equity=¥{max_alloc['equity']:,.0f}, cash=¥{max_alloc['cash_before']:,.0f}, {max_alloc['n_pos_before']} pos)")

        # show all buys
        print(f"\n  All buys (alloc % of equity at time):")
        for b in buy_allocs:
            marker = " ⚠" if b["alloc_pct"] > 80 else ""
            print(f"    {b['date']} {b['symbol']} ¥{b['buy_cost']:>10,.0f}  {b['alloc_pct']:>5.1f}% of ¥{b['equity']:>12,.0f}  (cash=¥{b['cash_before']:>10,.0f}, {b['n_pos_before']} pos){marker}")

    if over_alloc_days > 0:
        print(f"\n  ⚠ {over_alloc_days} days where position cost > equity (over-leveraged!)")
    else:
        print(f"\n  ✓ No over-allocation detected")


def main() -> None:
    cfg = load_default_config()
    apply_execution_profile(cfg, "delayed_limit_hunt")
    cfg.data.disable_env_mapping = True

    year = sys.argv[1] if len(sys.argv) > 1 else "2026"
    init_cash = 1_000_000.0

    store = MarketStore("cache/market.duckdb")
    symbols = resolve_named_pool("50-150cyc")

    bundle = prepare_bundle(
        cfg, start=f"{year}-01-01", end=f"{year}-12-31",
        pool_size=len(symbols), symbols=symbols, store=store,
    )

    print(f"Pool: {len(symbols)} | Year: {year}\n")

    for name, sizing, bp, mp, mults in CONFIGS:
        cfg.execution.position_sizing_base = sizing
        cfg.execution.base_pos_pct = bp
        cfg.execution.max_positions = mp
        cfg.execution.trend_spear_pos_mult = mults["trend_spear"]
        cfg.execution.post_limit_pos_mult = mults["post_limit"]
        cfg.execution.failed_board_pos_mult = mults["failed_board"]
        cfg.execution.youzi_pos_mult = mults["youzi"]
        cfg.execution.sector_spear_pos_mult = mults["sector_spear"]
        cfg.execution.attack_pos_mult = mults["attack"]
        cfg.execution.arb_pos_mult = mults["arb"]

        arts = run_backtest(
            cfg=cfg, start=f"{year}-01-01", end=f"{year}-12-31",
            pool_size=len(symbols), initial_cash=init_cash,
            symbols=symbols, bundle=bundle, store=store,
        )
        analyze(name, arts, init_cash)


if __name__ == "__main__":
    main()
