"""
Independent verdict: analyze raw backtest trade data to assess signal value.
No reference to prior analysis files - fresh aggregation from trade CSVs.
"""
import pandas as pd
import numpy as np
import json
from pathlib import Path

BASE = Path("/Users/yhanlin001/spear-strategy/v5_standalone/outputs/backtests")

RUNS = {
    "2022": BASE / "ts_obs_20260313_2022_dlh_intraday",
    "2024": BASE / "ts_obs_20260313_2024_dlh_intraday",
    "2025": BASE / "ts_obs_20260313_2025_dlh_intraday",
}

def load_trades(run_dir: Path) -> pd.DataFrame:
    df = pd.read_csv(run_dir / "closed_trades_flat.csv", low_memory=False)
    return df

def basic_stats(df: pd.DataFrame, label: str):
    n = len(df)
    win = (df["ret"] > 0).sum()
    lose = (df["ret"] <= 0).sum()
    wr = win / n if n > 0 else 0
    avg_ret = df["ret"].mean()
    med_ret = df["ret"].median()
    avg_win = df.loc[df["ret"] > 0, "ret"].mean() if win > 0 else 0
    avg_lose = df.loc[df["ret"] <= 0, "ret"].mean() if lose > 0 else 0
    pf = abs(df.loc[df["ret"] > 0, "ret"].sum() / df.loc[df["ret"] <= 0, "ret"].sum()) if lose > 0 else float("inf")
    total_pnl = df["pnl"].sum()
    avg_hold = df["hold_days"].mean()
    print(f"\n{'='*60}")
    print(f"  {label}  (n={n})")
    print(f"{'='*60}")
    print(f"  胜率:       {wr:.1%}  ({win}W / {lose}L)")
    print(f"  平均收益:   {avg_ret:.2%}")
    print(f"  中位收益:   {med_ret:.2%}")
    print(f"  平均赢:     {avg_win:.2%}")
    print(f"  平均亏:     {avg_lose:.2%}")
    print(f"  盈亏比:     {pf:.2f}")
    print(f"  总 PnL:     {total_pnl:,.0f}")
    print(f"  平均持仓天: {avg_hold:.1f}")

def mfe_mae_analysis(df: pd.DataFrame, label: str):
    """Core question: do signals pick stocks that move up?"""
    print(f"\n--- MFE / MAE 分析: {label} ---")
    mfe = df["mfe"]
    mae = df["mae"]
    print(f"  MFE 均值:    {mfe.mean():.2%}   中位: {mfe.median():.2%}")
    print(f"  MAE 均值:    {mae.mean():.2%}   中位: {mae.median():.2%}")
    print(f"  MFE > 5%:    {(mfe > 0.05).mean():.1%}")
    print(f"  MFE > 10%:   {(mfe > 0.10).mean():.1%}")
    print(f"  MFE > 20%:   {(mfe > 0.20).mean():.1%}")
    print(f"  MAE < -5%:   {(mae < -0.05).mean():.1%}")
    print(f"  MAE < -10%:  {(mae < -0.10).mean():.1%}")
    mfe_capture = df["mfe_capture"]
    print(f"  MFE 兑现率均值: {mfe_capture.mean():.2%}  中位: {mfe_capture.median():.2%}")
    big_mfe = df[mfe > 0.10]
    if len(big_mfe) > 0:
        print(f"  大肉票(MFE>10%) MFE 兑现率: {big_mfe['mfe_capture'].mean():.2%}  实际 ret: {big_mfe['ret'].mean():.2%}")

def exit_reason_breakdown(df: pd.DataFrame, label: str):
    print(f"\n--- 出场原因分布: {label} ---")
    reasons = df["exit_reason"].value_counts()
    for reason, cnt in reasons.items():
        sub = df[df["exit_reason"] == reason]
        wr = (sub["ret"] > 0).mean()
        avg = sub["ret"].mean()
        avg_mfe = sub["mfe"].mean()
        avg_cap = sub["mfe_capture"].mean()
        print(f"  {reason:25s}  n={cnt:4d}  WR={wr:.0%}  ret={avg:+.2%}  MFE={avg_mfe:.2%}  cap={avg_cap:.1%}")

def signal_type_breakdown(df: pd.DataFrame, label: str):
    print(f"\n--- 信号类型分拆: {label} ---")
    col = "entry_meta.signal_event_type" if "entry_meta.signal_event_type" in df.columns else "entry_reason"
    if col not in df.columns:
        for c in df.columns:
            if "event_type" in c.lower():
                col = c
                break
    groups = df.groupby(col)
    for name, sub in sorted(groups, key=lambda x: -len(x[1])):
        n = len(sub)
        if n < 10:
            continue
        wr = (sub["ret"] > 0).mean()
        avg_ret = sub["ret"].mean()
        avg_mfe = sub["mfe"].mean()
        avg_mae = sub["mae"].mean()
        avg_cap = sub["mfe_capture"].mean()
        pct_big_mfe = (sub["mfe"] > 0.10).mean()
        print(f"  {name:20s}  n={n:4d}  WR={wr:.0%}  ret={avg_ret:+.2%}  MFE={avg_mfe:.2%}  MAE={avg_mae:.2%}  cap={avg_cap:.1%}  MFE>10%={pct_big_mfe:.0%}")

def leakage_analysis(df: pd.DataFrame, label: str):
    """How much money is left on the table? Post-exit analysis."""
    print(f"\n--- 出场后路径（钱桌上留了多少）: {label} ---")
    cols_20d = ["post_exit_20d_rebound", "post_exit_20d_entry_ret"]
    for c in cols_20d:
        if c in df.columns:
            vals = pd.to_numeric(df[c], errors="coerce")
            print(f"  {c}: 均值={vals.mean():.2%}  中位={vals.median():.2%}")

    if "post_exit_20d_high" in df.columns:
        pe20h = pd.to_numeric(df["post_exit_20d_high"], errors="coerce")
        print(f"  post_exit_20d_high(相对exit_price): 均值={pe20h.mean():.2%}  中位={pe20h.median():.2%}")
        print(f"    exit后20d最高 > +10%: {(pe20h > 0.10).mean():.1%}")
        print(f"    exit后20d最高 > +20%: {(pe20h > 0.20).mean():.1%}")

    losers = df[df["ret"] <= 0]
    if len(losers) > 0 and "post_exit_20d_high" in df.columns:
        pe20h_losers = pd.to_numeric(losers["post_exit_20d_high"], errors="coerce")
        print(f"  亏损交易 exit后20d最高: 均值={pe20h_losers.mean():.2%}  >+10%={( pe20h_losers > 0.10).mean():.1%}")

    stops = df[df["exit_reason"] == "stop_loss"]
    if len(stops) > 0 and "post_exit_20d_high" in df.columns:
        pe20h_stops = pd.to_numeric(stops["post_exit_20d_high"], errors="coerce")
        print(f"  止损交易(n={len(stops)}) exit后20d最高: 均值={pe20h_stops.mean():.2%}  >+10%={( pe20h_stops > 0.10).mean():.1%}  >+20%={( pe20h_stops > 0.20).mean():.1%}")

    time_exits = df[df["exit_reason"] == "time_exit"]
    if len(time_exits) > 0 and "post_exit_20d_high" in df.columns:
        pe20h_te = pd.to_numeric(time_exits["post_exit_20d_high"], errors="coerce")
        print(f"  超时交易(n={len(time_exits)}) exit后20d最高: 均值={pe20h_te.mean():.2%}  >+10%={( pe20h_te > 0.10).mean():.1%}  >+20%={( pe20h_te > 0.20).mean():.1%}")

def mfe_vs_realized(df: pd.DataFrame, label: str):
    """The big question: how much MFE is actually captured in realized returns?"""
    print(f"\n--- MFE 到 实际收益 的转化: {label} ---")
    bins = [0, 0.03, 0.05, 0.10, 0.15, 0.20, 0.30, 1.0]
    labels_b = ["0-3%", "3-5%", "5-10%", "10-15%", "15-20%", "20-30%", "30%+"]
    df2 = df.copy()
    df2["mfe_bin"] = pd.cut(df2["mfe"], bins=bins, labels=labels_b, right=True)
    for b in labels_b:
        sub = df2[df2["mfe_bin"] == b]
        if len(sub) < 5:
            continue
        n = len(sub)
        avg_mfe = sub["mfe"].mean()
        avg_ret = sub["ret"].mean()
        avg_cap = sub["mfe_capture"].mean()
        wr = (sub["ret"] > 0).mean()
        pct = n / len(df2)
        leaked = avg_mfe - max(avg_ret, 0)
        print(f"  MFE {b:8s}  n={n:4d} ({pct:.0%})  avg_MFE={avg_mfe:.2%}  avg_ret={avg_ret:+.2%}  cap={avg_cap:.0%}  WR={wr:.0%}  leaked={leaked:.2%}")

def holding_period_analysis(df: pd.DataFrame, label: str):
    print(f"\n--- 持仓天数 vs 收益: {label} ---")
    bins = [0, 1, 2, 3, 5, 8, 15, 100]
    labels_b = ["1d", "2d", "3d", "4-5d", "6-8d", "9-15d", "15d+"]
    df2 = df.copy()
    df2["hold_bin"] = pd.cut(df2["hold_days"], bins=bins, labels=labels_b, right=True)
    for b in labels_b:
        sub = df2[df2["hold_bin"] == b]
        if len(sub) < 3:
            continue
        n = len(sub)
        wr = (sub["ret"] > 0).mean()
        avg_ret = sub["ret"].mean()
        avg_mfe = sub["mfe"].mean()
        print(f"  Hold {b:6s}  n={n:4d}  WR={wr:.0%}  ret={avg_ret:+.2%}  MFE={avg_mfe:.2%}")

def diagnosis_breakdown(df: pd.DataFrame, label: str):
    if "diagnosis" not in df.columns:
        return
    print(f"\n--- 诊断分类: {label} ---")
    diag = df["diagnosis"].value_counts()
    for d, cnt in diag.items():
        sub = df[df["diagnosis"] == d]
        pct = cnt / len(df)
        avg_ret = sub["ret"].mean()
        avg_mfe = sub["mfe"].mean()
        print(f"  {d:25s}  n={cnt:4d} ({pct:.0%})  ret={avg_ret:+.2%}  MFE={avg_mfe:.2%}")

def reentry_value(df: pd.DataFrame, label: str):
    """After stop_loss, does the stock recover? Quantify false stop rate."""
    stops = df[df["exit_reason"] == "stop_loss"].copy()
    if len(stops) == 0:
        return
    print(f"\n--- 止损后反弹分析（假摔率）: {label}  (n_stops={len(stops)}) ---")
    for col_name, col_label in [
        ("post_exit_reclaim_stop_close_3d", "3d内收复止损价"),
        ("post_exit_reclaim_entry_close_3d", "3d内收复入场价"),
        ("post_exit_reclaim_stop_close_5d", "5d内收复止损价"),
        ("post_exit_reclaim_entry_close_5d", "5d内收复入场价"),
    ]:
        if col_name in stops.columns:
            vals = stops[col_name].astype(str).str.lower().map({"true": True, "false": False, "1": True, "0": False, "1.0": True, "0.0": False})
            rate = vals.mean()
            print(f"  {col_label}: {rate:.1%}")

def summary_json(run_dir: Path, label: str):
    p = run_dir / "summary.json"
    if not p.exists():
        return
    s = json.loads(p.read_text())
    print(f"\n--- Summary JSON: {label} ---")
    for k in ["total_return", "final_equity", "max_drawdown", "sharpe", "calmar", "total_trades", "win_rate", "profit_factor", "avg_trade_return"]:
        if k in s:
            v = s[k]
            if isinstance(v, float):
                if abs(v) < 1:
                    print(f"  {k:25s}: {v:.4f}")
                else:
                    print(f"  {k:25s}: {v:,.2f}")
            else:
                print(f"  {k:25s}: {v}")

# ============================================================
# MAIN
# ============================================================
if __name__ == "__main__":
    all_trades = []
    for year, run_dir in sorted(RUNS.items()):
        print(f"\n{'#'*70}")
        print(f"#  YEAR: {year}")
        print(f"{'#'*70}")
        df = load_trades(run_dir)
        all_trades.append(df.assign(year=year))
        summary_json(run_dir, year)
        basic_stats(df, year)
        mfe_mae_analysis(df, year)
        mfe_vs_realized(df, year)
        exit_reason_breakdown(df, year)
        signal_type_breakdown(df, year)
        holding_period_analysis(df, year)
        leakage_analysis(df, year)
        reentry_value(df, year)
        diagnosis_breakdown(df, year)

    combined = pd.concat(all_trades, ignore_index=True)
    print(f"\n{'#'*70}")
    print(f"#  ALL YEARS COMBINED")
    print(f"{'#'*70}")
    basic_stats(combined, "ALL")
    mfe_mae_analysis(combined, "ALL")
    mfe_vs_realized(combined, "ALL")
    exit_reason_breakdown(combined, "ALL")
    signal_type_breakdown(combined, "ALL")
    holding_period_analysis(combined, "ALL")
    leakage_analysis(combined, "ALL")
    reentry_value(combined, "ALL")
    diagnosis_breakdown(combined, "ALL")

    # Final verdict
    print(f"\n{'='*70}")
    print(f"  VERDICT SUMMARY")
    print(f"{'='*70}")
    for year, sub_df in combined.groupby("year"):
        n = len(sub_df)
        avg_mfe = sub_df["mfe"].mean()
        avg_ret = sub_df["ret"].mean()
        avg_cap = sub_df["mfe_capture"].mean()
        wr = (sub_df["ret"] > 0).mean()
        big_mfe = (sub_df["mfe"] > 0.10).mean()
        leaked = avg_mfe - max(avg_ret, 0)
        stops = sub_df[sub_df["exit_reason"] == "stop_loss"]
        stop_pct = len(stops) / n
        stop_pe20 = pd.to_numeric(stops["post_exit_20d_high"], errors="coerce").mean() if len(stops) > 0 else 0
        te = sub_df[sub_df["exit_reason"] == "time_exit"]
        te_pct = len(te) / n
        te_pe20 = pd.to_numeric(te["post_exit_20d_high"], errors="coerce").mean() if len(te) > 0 else 0
        print(f"\n  {year}: n={n}  WR={wr:.0%}  avg_ret={avg_ret:+.2%}  avg_MFE={avg_mfe:.2%}  cap={avg_cap:.0%}  MFE>10%={big_mfe:.0%}")
        print(f"    leaked={leaked:.2%}  stop%={stop_pct:.0%}(post20d_high={stop_pe20:.2%})  time_exit%={te_pct:.0%}(post20d_high={te_pe20:.2%})")
