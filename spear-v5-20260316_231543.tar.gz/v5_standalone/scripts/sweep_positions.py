"""Full grid sweep: sizing_base × base_pos_pct × max_positions × mult_profile."""
from __future__ import annotations

import sys
import time
from dataclasses import dataclass
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from v5.config.defaults import load_default_config, apply_execution_profile
from v5.config.pools import resolve_named_pool
from v5.backtest.runner import run_backtest
from v5.backtest.prepare import prepare_bundle
from v5.data.store import MarketStore


PROFILES = {
    "current": {
        "trend_spear": 1.2, "post_limit": 0.9, "failed_board": 0.85,
        "youzi": 0.75, "sector_spear": 0.7, "attack": 0.55, "arb": 0.35,
    },
    "trend_heavy": {
        "trend_spear": 1.5, "post_limit": 0.5, "failed_board": 0.3,
        "youzi": 0.75, "sector_spear": 0.7, "attack": 0.55, "arb": 0.25,
    },
    "trend_max": {
        "trend_spear": 2.0, "post_limit": 0.3, "failed_board": 0.2,
        "youzi": 0.5, "sector_spear": 0.5, "attack": 0.4, "arb": 0.2,
    },
    "balanced_cut": {
        "trend_spear": 1.3, "post_limit": 0.5, "failed_board": 0.3,
        "youzi": 0.75, "sector_spear": 0.7, "attack": 0.55, "arb": 0.25,
    },
    "conservative": {
        "trend_spear": 1.0, "post_limit": 0.4, "failed_board": 0.2,
        "youzi": 0.5, "sector_spear": 0.5, "attack": 0.3, "arb": 0.2,
    },
    "trend_only": {
        "trend_spear": 1.5, "post_limit": 0.0, "failed_board": 0.0,
        "youzi": 0.0, "sector_spear": 0.0, "attack": 0.0, "arb": 0.0,
    },
    "top2_only": {
        "trend_spear": 1.5, "post_limit": 0.0, "failed_board": 0.0,
        "youzi": 0.0, "sector_spear": 0.0, "attack": 0.6, "arb": 0.0,
    },
    "uniform": {
        "trend_spear": 1.0, "post_limit": 1.0, "failed_board": 1.0,
        "youzi": 1.0, "sector_spear": 1.0, "attack": 1.0, "arb": 1.0,
    },
}

MULT_KEYS = ["trend_spear", "post_limit", "failed_board", "youzi", "sector_spear", "attack", "arb"]


@dataclass
class RunResult:
    year: str
    sizing: str
    base_pct: float
    max_pos: int
    profile: str
    ret: float
    equity: float
    trades: int
    open_pos: int
    fees: float
    ts_eff: str  # effective trend_spear position size


def _apply_mults(cfg, mults: dict) -> None:
    cfg.execution.trend_spear_pos_mult = mults["trend_spear"]
    cfg.execution.post_limit_pos_mult = mults["post_limit"]
    cfg.execution.failed_board_pos_mult = mults["failed_board"]
    cfg.execution.youzi_pos_mult = mults["youzi"]
    cfg.execution.sector_spear_pos_mult = mults["sector_spear"]
    cfg.execution.attack_pos_mult = mults["attack"]
    cfg.execution.arb_pos_mult = mults["arb"]


def main() -> None:
    cfg = load_default_config()
    apply_execution_profile(cfg, "delayed_limit_hunt")
    cfg.data.disable_env_mapping = True

    years = []
    for arg in sys.argv[1:]:
        years.append(arg)
    if not years:
        years = ["2025", "2026"]

    SIZING_BASES = ["cash", "equity"]
    BASE_PCTS = [0.15, 0.25, 0.33, 0.50]
    MAX_POSITIONS = [4, 10, 20]

    store = MarketStore("cache/market.duckdb")
    symbols = resolve_named_pool("50-150cyc")

    total_combos = len(years) * len(SIZING_BASES) * len(BASE_PCTS) * len(MAX_POSITIONS) * len(PROFILES)
    print(f"Pool: {len(symbols)} symbols")
    print(f"Grid: {len(years)} years × {len(SIZING_BASES)} sizing × {len(BASE_PCTS)} base_pct × {len(MAX_POSITIONS)} max_pos × {len(PROFILES)} profiles = {total_combos} runs\n")

    all_results: list[RunResult] = []
    t_start = time.monotonic()

    for year in years:
        bundle = prepare_bundle(
            cfg, start=f"{year}-01-01", end=f"{year}-12-31",
            pool_size=len(symbols), symbols=symbols, store=store,
        )

        for sizing in SIZING_BASES:
            for bp in BASE_PCTS:
                for mp in MAX_POSITIONS:
                    cfg.execution.position_sizing_base = sizing
                    cfg.execution.base_pos_pct = bp
                    cfg.execution.max_positions = mp
                    label = f"{year} | {sizing:6s} | bp={bp:.0%} | mp={mp:2d}"

                    for prof_name, mults in PROFILES.items():
                        _apply_mults(cfg, mults)
                        arts = run_backtest(
                            cfg=cfg, start=f"{year}-01-01", end=f"{year}-12-31",
                            pool_size=len(symbols), initial_cash=1_000_000.0,
                            symbols=symbols, bundle=bundle, store=store,
                        )
                        s = arts.result.summary
                        ts_eff = f"{bp * mults['trend_spear'] * 100:.0f}%"
                        r = RunResult(
                            year=year, sizing=sizing, base_pct=bp, max_pos=mp,
                            profile=prof_name, ret=s["equity_return_pct"],
                            equity=s["equity_final"], trades=s["trade_count"],
                            open_pos=s["open_count"], fees=s["total_fees"],
                            ts_eff=ts_eff,
                        )
                        all_results.append(r)

                    best = max(all_results[-len(PROFILES):], key=lambda x: x.ret)
                    worst = min(all_results[-len(PROFILES):], key=lambda x: x.ret)
                    print(f"  {label} | best: {best.profile:<14s} {best.ret:>+6.1f}% | worst: {worst.profile:<14s} {worst.ret:>+6.1f}%")

    elapsed = time.monotonic() - t_start
    print(f"\n{'='*130}")
    print(f"  COMPLETED {len(all_results)} runs in {elapsed:.0f}s")
    print(f"{'='*130}\n")

    # ── Grand summary: group by (sizing, base_pct, max_pos) and show cross-year consistency ──
    from collections import defaultdict
    grid: dict[tuple, dict[str, list[RunResult]]] = defaultdict(lambda: defaultdict(list))
    for r in all_results:
        grid[(r.sizing, r.base_pct, r.max_pos)][r.year].append(r)

    print(f"{'sizing':>6} {'bp':>4} {'mp':>3} | ", end="")
    for year in years:
        print(f"{'best_' + year:<14s} {'ret':>7} {'worst_' + year:<14s} {'ret':>7} {'spread':>7} | ", end="")
    print("cross-year best")
    print("-" * 140)

    for (sizing, bp, mp), year_data in sorted(grid.items()):
        print(f"{sizing:>6} {bp:>3.0%} {mp:>3d} | ", end="")

        year_bests = {}
        for year in years:
            runs = year_data.get(year, [])
            if not runs:
                print(f"{'':>14} {'':>7} {'':>14} {'':>7} {'':>7} | ", end="")
                continue
            best = max(runs, key=lambda x: x.ret)
            worst = min(runs, key=lambda x: x.ret)
            spread = best.ret - worst.ret
            year_bests[year] = best
            print(f"{best.profile:<14s} {best.ret:>+6.1f}% {worst.profile:<14s} {worst.ret:>+6.1f}% {spread:>6.1f}pp | ", end="")

        # Cross-year: average return of each profile
        if len(year_bests) == len(years):
            prof_avg: dict[str, float] = {}
            for prof in PROFILES:
                rets = []
                for year in years:
                    for r in year_data[year]:
                        if r.profile == prof:
                            rets.append(r.ret)
                if rets:
                    prof_avg[prof] = sum(rets) / len(rets)
            if prof_avg:
                cross_best = max(prof_avg, key=prof_avg.get)
                print(f"{cross_best} avg {prof_avg[cross_best]:>+.1f}%", end="")
        print()

    # ── Top 20 overall configs (averaged across years) ──
    print(f"\n{'='*130}")
    print("  TOP 20 CONFIGS (averaged across years)")
    print(f"{'='*130}")

    combo_avg: dict[tuple, float] = {}
    combo_details: dict[tuple, list[RunResult]] = defaultdict(list)
    for r in all_results:
        key = (r.sizing, r.base_pct, r.max_pos, r.profile)
        combo_details[key].append(r)

    for key, runs in combo_details.items():
        combo_avg[key] = sum(r.ret for r in runs) / len(runs)

    ranked = sorted(combo_avg.items(), key=lambda x: -x[1])[:20]
    print(f"\n{'#':>3} {'sizing':>6} {'bp':>4} {'mp':>3} {'profile':<14s} {'avg_ret':>8} {'ts_eff':>6}", end="")
    for year in years:
        print(f" | {year + '_ret':>9} {'trades':>6} {'open':>4}", end="")
    print()
    print("-" * 130)

    for rank, (key, avg) in enumerate(ranked, 1):
        sizing, bp, mp, prof = key
        mults = PROFILES[prof]
        ts_eff = f"{bp * mults['trend_spear'] * 100:.0f}%"
        print(f"{rank:>3} {sizing:>6} {bp:>3.0%} {mp:>3d} {prof:<14s} {avg:>+7.1f}% {ts_eff:>6}", end="")
        for year in years:
            runs = [r for r in combo_details[key] if r.year == year]
            if runs:
                r = runs[0]
                print(f" | {r.ret:>+8.1f}% {r.trades:>6d} {r.open_pos:>4d}", end="")
            else:
                print(f" | {'':>9} {'':>6} {'':>4}", end="")
        print()


if __name__ == "__main__":
    main()
