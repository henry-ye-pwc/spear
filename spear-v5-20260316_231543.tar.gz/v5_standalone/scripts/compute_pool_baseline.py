#!/usr/bin/env python3
"""
Compute pool baseline: on each signal date, compare signal stocks vs
non-signal stocks from the same pool. This is the correct A/B comparison.

Method:
  For each unique signal date:
    - Signal group: stocks that triggered a signal that day
    - Control group: all OTHER stocks in the pool on that day (no signal)
    - Compute 20d max_high_ret for both groups from cache
  Aggregate across all dates to get baseline hit10 for the control group.

Usage:
  python scripts/compute_pool_baseline.py
"""
from __future__ import annotations

import pickle
import sys
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

CACHE_DIR = ROOT / "cache"
SIGNAL_CSV = ROOT / "outputs" / "analysis" / "signal_value_status_20260313" / "selected_stock_picks.csv"


def load_price_df(symbol: str) -> pd.DataFrame | None:
    pkl = CACHE_DIR / f"{symbol}_full.pkl"
    if not pkl.exists():
        return None
    try:
        df = pickle.loads(pkl.read_bytes())
        if "date" not in df.columns and df.index.name == "date":
            df = df.reset_index()
        df["date_str"] = pd.to_datetime(df["date"]).dt.strftime("%Y-%m-%d")
        df = df.sort_values("date_str").reset_index(drop=True)
        return df
    except Exception:
        return None


def compute_mfe20_on_date(pdf: pd.DataFrame, target_date: str) -> float | None:
    """Compute 20-day forward max_high_ret for a stock on a specific date."""
    mask = pdf["date_str"] == target_date
    if not mask.any():
        return None
    idx = mask.idxmax()
    close = float(pdf.loc[idx, "close"])
    if close <= 0:
        return None
    end_idx = min(idx + 20, len(pdf) - 1)
    if end_idx <= idx:
        return None
    fwd = pdf.iloc[idx + 1 : end_idx + 1]
    if len(fwd) == 0:
        return None
    return float(fwd["high"].max() / close - 1.0)


def main():
    from v5.config.pools import resolve_named_pool

    pool_name = "50-150cyc"
    pool_symbols = set(resolve_named_pool(pool_name))
    print(f"Pool: {pool_name} ({len(pool_symbols)} symbols)")

    signals = pd.read_csv(str(SIGNAL_CSV), low_memory=False)
    signals = signals[signals["side"] == "long"]
    print(f"Signals: {len(signals)} long signals")

    signal_dates = sorted(signals["date"].unique())
    print(f"Unique signal dates: {len(signal_dates)}")

    signal_pairs = set()
    for _, row in signals.iterrows():
        signal_pairs.add((row["date"], str(row["symbol"]).zfill(6)))

    print(f"Loading price data for pool symbols...")
    price_cache: dict[str, pd.DataFrame | None] = {}
    loaded = 0
    for i, sym in enumerate(pool_symbols):
        pdf = load_price_df(sym)
        price_cache[sym] = pdf
        if pdf is not None:
            loaded += 1
        if (i + 1) % 200 == 0:
            print(f"  [{i+1}/{len(pool_symbols)}] loaded={loaded}")
    print(f"  Loaded: {loaded} symbols")

    available_symbols = [s for s in pool_symbols if price_cache[s] is not None]

    # Sample signal dates to keep runtime reasonable (~200 dates)
    if len(signal_dates) > 200:
        rng = np.random.RandomState(42)
        sampled_dates = sorted(rng.choice(signal_dates, size=200, replace=False))
    else:
        sampled_dates = signal_dates

    print(f"\nComputing MFE20 for {len(sampled_dates)} signal dates x {len(available_symbols)} symbols...")

    signal_mfe = []
    control_mfe = []
    processed = 0

    for di, date in enumerate(sampled_dates):
        date_signal_syms = {sym for (d, sym) in signal_pairs if d == date}

        for sym in available_symbols:
            pdf = price_cache[sym]
            if pdf is None:
                continue
            mfe = compute_mfe20_on_date(pdf, date)
            if mfe is None:
                continue

            if sym in date_signal_syms:
                signal_mfe.append(mfe)
            else:
                control_mfe.append(mfe)

        processed += 1
        if (di + 1) % 50 == 0:
            print(f"  [{di+1}/{len(sampled_dates)}] signal={len(signal_mfe)}, control={len(control_mfe)}")

    signal_arr = np.array(signal_mfe)
    control_arr = np.array(control_mfe)

    print(f"\n{'='*60}")
    print(f"Signal group:  n={len(signal_arr):,}")
    print(f"  hit10: {(signal_arr >= 0.10).mean():.1%}")
    print(f"  hit5:  {(signal_arr >= 0.05).mean():.1%}")
    print(f"  hit20: {(signal_arr >= 0.20).mean():.1%}")
    print(f"  mfe20 mean:   {signal_arr.mean():.3f} ({signal_arr.mean()*100:.1f}%)")
    print(f"  mfe20 median: {np.median(signal_arr):.3f} ({np.median(signal_arr)*100:.1f}%)")

    print(f"\nControl group (same dates, non-signal stocks):  n={len(control_arr):,}")
    print(f"  hit10: {(control_arr >= 0.10).mean():.1%}")
    print(f"  hit5:  {(control_arr >= 0.05).mean():.1%}")
    print(f"  hit20: {(control_arr >= 0.20).mean():.1%}")
    print(f"  mfe20 mean:   {control_arr.mean():.3f} ({control_arr.mean()*100:.1f}%)")
    print(f"  mfe20 median: {np.median(control_arr):.3f} ({np.median(control_arr)*100:.1f}%)")

    lift = (signal_arr >= 0.10).mean() - (control_arr >= 0.10).mean()
    print(f"\nSignal lift (hit10): +{lift*100:.1f}pp")
    print(f"\n-> Update POOL_BASELINE in regenerate_oracle.py with:")
    print(f'    "hit10_20d": {(control_arr >= 0.10).mean():.3f},')
    print(f'    "mfe20_mean": {control_arr.mean():.3f},')
    print(f'    "mfe20_median": {np.median(control_arr):.3f},')


if __name__ == "__main__":
    main()
