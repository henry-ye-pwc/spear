"""
Signal-only verdict: pure signal quality assessment.
No execution, no backtesting, no stop loss, no exit rules.
Just: when a signal fires, what happens to the stock?
"""
import pandas as pd
import numpy as np
import json
import ast
from pathlib import Path

CSV = Path("/Users/yhanlin001/spear-strategy/v5_standalone/outputs/analysis/signal_value_status_20260313/selected_stock_picks.csv")

def parse_json_col(s):
    try:
        if pd.isna(s):
            return {}
        return json.loads(s.replace("'", '"'))
    except:
        try:
            return ast.literal_eval(s)
        except:
            return {}

df = pd.read_csv(CSV, low_memory=False)
print(f"Total signals: {len(df)}")

# Parse structured columns
df["_entry_plan"] = df["entry_plan"].apply(parse_json_col)
df["_invalidation"] = df["invalidation"].apply(parse_json_col)
df["_exit_plan"] = df["exit_plan"].apply(parse_json_col)
df["_context"] = df["context"].apply(parse_json_col)

df["gate_price"] = df["_entry_plan"].apply(lambda x: x.get("gate_price", 0.0))
df["gate_price"] = pd.to_numeric(df["gate_price"], errors="coerce").fillna(0.0)
df["stop_price"] = df["_invalidation"].apply(lambda x: x.get("price", 0.0))
df["stop_price"] = pd.to_numeric(df["stop_price"], errors="coerce").fillna(0.0)
df["hold_days"] = df["_exit_plan"].apply(lambda x: x.get("hold_days", 5))
df["take_profit_pct"] = df["_exit_plan"].apply(lambda x: x.get("take_profit_pct", 0.18))

# Entry-adjusted price
df["entry_ref"] = df[["close", "gate_price"]].max(axis=1)
df["entry_gap_pct"] = (df["entry_ref"] / df["close"] - 1.0).clip(lower=0)

# Adjusted forward metrics (from entry_ref, not close)
# max_high_ret_Xd is already from close. If gate_price > close, real MFE from entry is lower.
for d in [1, 3, 5, 10, 20]:
    # adj = (close * (1 + max_high_ret)) / entry_ref - 1
    df[f"adj_max_high_{d}d"] = (df["close"] * (1 + df[f"max_high_ret_{d}d"])) / df["entry_ref"] - 1.0
    df[f"adj_close_{d}d"] = (df["close"] * (1 + df[f"close_ret_{d}d"])) / df["entry_ref"] - 1.0

# Context features
df["peer_confirmation"] = df["_context"].apply(lambda x: int(x.get("peer_confirmation", 0) or 0))
df["leader_strength"] = df["_context"].apply(lambda x: int(x.get("leader_strength", 0) or 0))
df["sector_hot"] = df["_context"].apply(lambda x: bool(x.get("sector_hot", False)))
df["spear_role"] = df["_context"].apply(lambda x: str(x.get("spear_role", "")))
df["structure_mode"] = df["_context"].apply(lambda x: str(x.get("structure_mode", "")))
df["gate_source"] = df["_context"].apply(lambda x: str(x.get("gate_source", "")))
df["multi_spear_count"] = df["_context"].apply(lambda x: int(x.get("multi_spear_count", 0) or 0))

def section(title):
    print(f"\n{'='*70}")
    print(f"  {title}")
    print(f"{'='*70}")

def signal_profile(sub, label, baseline_mhr20=None):
    n = len(sub)
    if n < 10:
        return
    mhr = {d: sub[f"max_high_ret_{d}d"].mean() for d in [1,3,5,10,20]}
    cr = {d: sub[f"close_ret_{d}d"].mean() for d in [1,3,5,10,20]}
    adj_mhr = {d: sub[f"adj_max_high_{d}d"].mean() for d in [1,3,5,10,20]}
    adj_cr = {d: sub[f"adj_close_{d}d"].mean() for d in [1,3,5,10,20]}

    hit5_5d = (sub["max_high_ret_5d"] >= 0.05).mean()
    hit10_10d = (sub["max_high_ret_10d"] >= 0.10).mean()
    hit20_20d = (sub["max_high_ret_20d"] >= 0.20).mean()
    hit10_20d = (sub["max_high_ret_20d"] >= 0.10).mean()

    adj_hit10_10d = (sub["adj_max_high_10d"] >= 0.10).mean()
    adj_hit20_20d = (sub["adj_max_high_20d"] >= 0.20).mean()
    adj_hit10_20d = (sub["adj_max_high_20d"] >= 0.10).mean()

    # Path shape: how early does the potential appear?
    early_ratio = mhr[5] / mhr[20] if mhr[20] > 0 else 0

    # "Oracle profit": if you could sell at the 20d high
    oracle_ret_20d = sub["max_high_ret_20d"].mean()
    # Naive hold 20d
    hold_20d = sub["close_ret_20d"].mean()
    # Gap between oracle and reality
    oracle_gap = oracle_ret_20d - hold_20d

    # Drawdown: how much pain on the path?
    # close_ret_1d as proxy for immediate next-day path
    next_day_pain = (sub["close_ret_1d"] < -0.03).mean()
    next_day_positive = (sub["close_ret_1d"] > 0).mean()

    # 20d high but 20d close negative?
    big_potential_bad_close = ((sub["max_high_ret_20d"] >= 0.10) & (sub["close_ret_20d"] < 0)).mean()

    entry_gap = sub["entry_gap_pct"].mean()

    print(f"\n  [{label}]  n={n}")
    print(f"  入场差价: 信号收盘→gate_price 均值={entry_gap:.2%}")
    print(f"")
    print(f"  ---- 路径峰值 (从信号日收盘算, oracle视角) ----")
    print(f"  {'':20s}  {'1d':>8s}  {'3d':>8s}  {'5d':>8s}  {'10d':>8s}  {'20d':>8s}")
    print(f"  {'max_high_ret':20s}  {mhr[1]:>7.2%}  {mhr[3]:>7.2%}  {mhr[5]:>7.2%}  {mhr[10]:>7.2%}  {mhr[20]:>7.2%}")
    print(f"  {'close_ret':20s}  {cr[1]:>7.2%}  {cr[3]:>7.2%}  {cr[5]:>7.2%}  {cr[10]:>7.2%}  {cr[20]:>7.2%}")
    print(f"")
    print(f"  ---- 路径峰值 (入场调整后, gate_price视角) ----")
    print(f"  {'adj_max_high':20s}  {adj_mhr[1]:>7.2%}  {adj_mhr[3]:>7.2%}  {adj_mhr[5]:>7.2%}  {adj_mhr[10]:>7.2%}  {adj_mhr[20]:>7.2%}")
    print(f"  {'adj_close':20s}  {adj_cr[1]:>7.2%}  {adj_cr[3]:>7.2%}  {adj_cr[5]:>7.2%}  {adj_cr[10]:>7.2%}  {adj_cr[20]:>7.2%}")
    print(f"")
    print(f"  ---- 命中率 (从收盘价算) ----")
    print(f"  5d内曾到+5%:   {hit5_5d:.1%}")
    print(f"  10d内曾到+10%: {hit10_10d:.1%}")
    print(f"  20d内曾到+10%: {hit10_20d:.1%}")
    print(f"  20d内曾到+20%: {hit20_20d:.1%}")
    print(f"")
    print(f"  ---- 命中率 (从gate_price调整后) ----")
    print(f"  adj 10d内曾到+10%: {adj_hit10_10d:.1%}")
    print(f"  adj 20d内曾到+10%: {adj_hit10_20d:.1%}")
    print(f"  adj 20d内曾到+20%: {adj_hit20_20d:.1%}")
    print(f"")
    print(f"  ---- 路径形态 ----")
    print(f"  oracle_20d (20d MFE均值):      {oracle_ret_20d:.2%}")
    print(f"  hold_20d (20d 收盘均值):       {hold_20d:.2%}")
    print(f"  oracle gap (知道卖顶 vs 持有): {oracle_gap:.2%}")
    print(f"  5d MFE / 20d MFE 比值:         {early_ratio:.1%}  (越高=潜力越早出现)")
    print(f"  次日收阳比例:                  {next_day_positive:.1%}")
    print(f"  次日跌>3%比例:                 {next_day_pain:.1%}")
    print(f"  20d曾+10%但20d收盘为负:        {big_potential_bad_close:.1%}  (有肉但拿不住的比例)")
    if baseline_mhr20 is not None:
        delta = oracle_ret_20d - baseline_mhr20
        print(f"  vs 基线 20d MFE 提升:          {delta:+.2%}")

    # Distribution
    print(f"\n  ---- 20d MFE 分布 ----")
    bins = [float("-inf"), 0, 0.03, 0.05, 0.10, 0.15, 0.20, 0.30, float("inf")]
    labels_b = ["<=0%", "0-3%", "3-5%", "5-10%", "10-15%", "15-20%", "20-30%", "30%+"]
    cut = pd.cut(sub["max_high_ret_20d"], bins=bins, labels=labels_b)
    for b in labels_b:
        cnt = (cut == b).sum()
        pct = cnt / n
        if cnt > 0:
            avg_cr20 = sub.loc[cut == b, "close_ret_20d"].mean()
            print(f"    {b:8s}  {cnt:5d} ({pct:5.1%})  20d_close_ret={avg_cr20:+.2%}")


# ============================================================
section("全体信号概览")
signal_profile(df, "ALL SIGNALS")

section("按年份")
BASELINES = {"2022": 0.10759, "2024": 0.11797, "2025": 0.12343, "all": 0.11642}
for year in sorted(df["year"].unique()):
    signal_profile(df[df["year"] == year], f"YEAR {year}", baseline_mhr20=BASELINES.get(str(year)))

section("按信号类型")
for et in df["event_type"].value_counts().index:
    signal_profile(df[df["event_type"] == et], f"TYPE: {et}", baseline_mhr20=BASELINES["all"])

section("按信号类型 × 年份")
for et in ["trend_spear", "attack", "arb", "post_limit"]:
    for year in sorted(df["year"].unique()):
        sub = df[(df["event_type"] == et) & (df["year"] == year)]
        if len(sub) >= 10:
            signal_profile(sub, f"{et} / {year}", baseline_mhr20=BASELINES.get(str(year)))

section("路径形态深层分析：信号后的典型走势")
print("\n--- 信号后 1d/3d/5d 路径的条件概率 ---")
# What fraction of signals that have big 20d potential are ALREADY visible at 5d?
big_20d = df["max_high_ret_20d"] >= 0.10
print(f"  20d MFE>=10% 的信号 (n={big_20d.sum()}):")
sub_big = df[big_20d]
print(f"    其中 5d MFE已>=5%:  {(sub_big['max_high_ret_5d'] >= 0.05).mean():.1%}")
print(f"    其中 5d MFE已>=10%: {(sub_big['max_high_ret_5d'] >= 0.10).mean():.1%}")
print(f"    其中 5d close >0%:  {(sub_big['close_ret_5d'] > 0).mean():.1%}")
print(f"    其中 5d close <-3%: {(sub_big['close_ret_5d'] < -0.03).mean():.1%}")
print(f"    其中 1d close <0:   {(sub_big['close_ret_1d'] < 0).mean():.1%}")

small_20d = df["max_high_ret_20d"] < 0.05
print(f"\n  20d MFE<5% 的信号 (n={small_20d.sum()}, 废票):")
sub_small = df[small_20d]
print(f"    其中 1d close <0:   {(sub_small['close_ret_1d'] < 0).mean():.1%}")
print(f"    其中 5d close <-3%: {(sub_small['close_ret_5d'] < -0.03).mean():.1%}")

# Washout analysis: signals where 5d close is bad but 20d MFE is good
print(f"\n--- 洗盘/假摔现象量化 ---")
washout = (df["close_ret_5d"] < -0.03) & (df["max_high_ret_20d"] >= 0.10)
print(f"  '5d 跌>3% 但 20d MFE>=10%' (洗盘型): n={washout.sum()} ({washout.mean():.1%})")
if washout.sum() > 0:
    sub_w = df[washout]
    print(f"    avg 5d close:    {sub_w['close_ret_5d'].mean():.2%}")
    print(f"    avg 20d MFE:     {sub_w['max_high_ret_20d'].mean():.2%}")
    print(f"    avg 20d close:   {sub_w['close_ret_20d'].mean():.2%}")
    print(f"    hit 20d +20%:    {(sub_w['max_high_ret_20d'] >= 0.20).mean():.1%}")

deep_washout = (df["close_ret_5d"] < -0.05) & (df["max_high_ret_20d"] >= 0.15)
print(f"\n  '5d 跌>5% 但 20d MFE>=15%' (深度洗盘): n={deep_washout.sum()} ({deep_washout.mean():.1%})")
if deep_washout.sum() > 0:
    sub_dw = df[deep_washout]
    print(f"    avg 5d close:    {sub_dw['close_ret_5d'].mean():.2%}")
    print(f"    avg 20d MFE:     {sub_dw['max_high_ret_20d'].mean():.2%}")
    print(f"    avg 20d close:   {sub_dw['close_ret_20d'].mean():.2%}")

early_peak = (df["max_high_ret_5d"] >= 0.10) & (df["close_ret_20d"] < 0)
print(f"\n  '5d MFE>=10% 但 20d 收盘为负' (早冲晚退): n={early_peak.sum()} ({early_peak.mean():.1%})")
if early_peak.sum() > 0:
    sub_ep = df[early_peak]
    print(f"    avg 5d MFE:      {sub_ep['max_high_ret_5d'].mean():.2%}")
    print(f"    avg 20d close:   {sub_ep['close_ret_20d'].mean():.2%}")
    print(f"    avg 20d MFE:     {sub_ep['max_high_ret_20d'].mean():.2%}")

section("confidence 与前向表现")
for lo, hi, label in [(0.5, 0.65, "low"), (0.65, 0.78, "mid"), (0.78, 1.01, "high")]:
    sub = df[(df["confidence"] >= lo) & (df["confidence"] < hi)]
    if len(sub) >= 20:
        print(f"\n  confidence [{lo:.2f}, {hi:.2f})  n={len(sub)}")
        print(f"    20d MFE: {sub['max_high_ret_20d'].mean():.2%}   hit+10%: {(sub['max_high_ret_20d']>=0.10).mean():.1%}   hit+20%: {(sub['max_high_ret_20d']>=0.20).mean():.1%}")
        print(f"    20d close: {sub['close_ret_20d'].mean():.2%}")
        print(f"    adj 20d MFE: {sub['adj_max_high_20d'].mean():.2%}")

section("peer_confirmation 与前向表现")
for lo, hi, label in [(0, 3, "low 0-2"), (3, 7, "mid 3-6"), (7, 100, "high 7+")]:
    sub = df[(df["peer_confirmation"] >= lo) & (df["peer_confirmation"] < hi)]
    if len(sub) >= 20:
        print(f"\n  peer_confirmation [{lo}, {hi})  n={len(sub)}")
        print(f"    20d MFE: {sub['max_high_ret_20d'].mean():.2%}   hit+10%: {(sub['max_high_ret_20d']>=0.10).mean():.1%}")
        print(f"    20d close: {sub['close_ret_20d'].mean():.2%}")

section("sector_hot 与前向表现")
for val, label in [(True, "热门板块"), (False, "非热门板块")]:
    sub = df[df["sector_hot"] == val]
    if len(sub) >= 20:
        print(f"\n  sector_hot={val} ({label})  n={len(sub)}")
        print(f"    20d MFE: {sub['max_high_ret_20d'].mean():.2%}   hit+10%: {(sub['max_high_ret_20d']>=0.10).mean():.1%}")
        print(f"    20d close: {sub['close_ret_20d'].mean():.2%}")
        print(f"    5d MFE: {sub['max_high_ret_5d'].mean():.2%}")

section("spear_role (仅 trend_spear)")
ts = df[df["event_type"] == "trend_spear"]
for role in ts["spear_role"].value_counts().index:
    sub = ts[ts["spear_role"] == role]
    if len(sub) >= 15:
        print(f"\n  spear_role={role}  n={len(sub)}")
        print(f"    20d MFE: {sub['max_high_ret_20d'].mean():.2%}   hit+10%: {(sub['max_high_ret_20d']>=0.10).mean():.1%}   hit+20%: {(sub['max_high_ret_20d']>=0.20).mean():.1%}")
        print(f"    adj 20d MFE: {sub['adj_max_high_20d'].mean():.2%}")
        print(f"    5d close: {sub['close_ret_5d'].mean():.2%}")
        print(f"    20d close: {sub['close_ret_20d'].mean():.2%}")

section("gate_source (仅 trend_spear)")
for gs in ts["gate_source"].value_counts().index:
    sub = ts[ts["gate_source"] == gs]
    if len(sub) >= 15:
        print(f"\n  gate_source={gs}  n={len(sub)}")
        print(f"    20d MFE: {sub['max_high_ret_20d'].mean():.2%}   hit+10%: {(sub['max_high_ret_20d']>=0.10).mean():.1%}")
        print(f"    adj 20d MFE: {sub['adj_max_high_20d'].mean():.2%}")
        print(f"    entry gap: {sub['entry_gap_pct'].mean():.2%}")

section("FINAL: 信号层核心指标汇总")
print(f"\n  ALL {len(df)} signals:")
print(f"    20d MFE 均值:     {df['max_high_ret_20d'].mean():.2%}")
print(f"    20d MFE 中位:     {df['max_high_ret_20d'].median():.2%}")
print(f"    20d close 均值:   {df['close_ret_20d'].mean():.2%}")
print(f"    20d close 中位:   {df['close_ret_20d'].median():.2%}")
print(f"    adj 20d MFE:      {df['adj_max_high_20d'].mean():.2%}")
print(f"    20d MFE < 0 (真废票):  {(df['max_high_ret_20d'] <= 0).mean():.1%}")
print(f"    20d MFE < 3%:          {(df['max_high_ret_20d'] < 0.03).mean():.1%}")
print(f"    20d MFE 5-10%:         {((df['max_high_ret_20d']>=0.05)&(df['max_high_ret_20d']<0.10)).mean():.1%}")
print(f"    20d MFE 10-20%:        {((df['max_high_ret_20d']>=0.10)&(df['max_high_ret_20d']<0.20)).mean():.1%}")
print(f"    20d MFE 20%+:          {(df['max_high_ret_20d']>=0.20).mean():.1%}")
print(f"    oracle_gap (MFE - close): {df['max_high_ret_20d'].mean() - df['close_ret_20d'].mean():.2%}")
