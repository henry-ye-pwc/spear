"""
Per-signal oracle: for any given signal, find its "neighborhood" in historical
data and show what the outcome distribution actually looks like.

The question: can we tell GOOD signals from BAD ones at signal time?
"""
import pandas as pd
import numpy as np
import json, ast
from pathlib import Path

CSV = Path("/Users/yhanlin001/spear-strategy/v5_standalone/outputs/analysis/signal_value_status_20260313/selected_stock_picks.csv")
df = pd.read_csv(CSV, low_memory=False)

def pj(s):
    try:
        if pd.isna(s): return {}
        return json.loads(s.replace("'", '"'))
    except:
        try: return ast.literal_eval(s)
        except: return {}

df["_ctx"] = df["context"].apply(pj)
df["_ep"] = df["entry_plan"].apply(pj)
df["_inv"] = df["invalidation"].apply(pj)

df["gate_price"] = df["_ep"].apply(lambda x: float(x.get("gate_price", 0) or 0))
df["gate_gap"] = np.where(df["close"] > 0, (df["gate_price"] / df["close"] - 1).clip(lower=0), 0)
df["stop_price"] = df["_inv"].apply(lambda x: float(x.get("price", 0) or 0))
df["stop_gap"] = np.where(df["close"] > 0, df["stop_price"] / df["close"] - 1, 0)
df["peer"] = df["_ctx"].apply(lambda x: int(x.get("peer_confirmation", 0) or 0))
df["leader"] = df["_ctx"].apply(lambda x: int(x.get("leader_strength", 0) or 0))
df["sector_hot"] = df["_ctx"].apply(lambda x: bool(x.get("sector_hot", False))).astype(int)
df["conf"] = df["confidence"]
df["mfe20"] = df["max_high_ret_20d"]
df["cr20"] = df["close_ret_20d"]
df["mfe10"] = df["max_high_ret_10d"]
df["cr5"] = df["close_ret_5d"]
df["mfe5"] = df["max_high_ret_5d"]

# Binary outcomes
df["hit10_20d"] = (df["mfe20"] >= 0.10).astype(int)
df["hit20_20d"] = (df["mfe20"] >= 0.20).astype(int)
df["dud"] = (df["mfe20"] < 0.03).astype(int)

print(f"Total: {len(df)} signals\n")

# ============================================================
# PART 1: Which features actually predict outcomes?
# ============================================================
print("=" * 70)
print("  PART 1: 哪些信号日特征真的能区分好票和废票？")
print("=" * 70)

# Rank-biserial correlation of each feature with binary outcomes
features = ["conf", "peer", "leader", "gate_gap", "stop_gap", "sector_hot"]
for outcome_name, outcome_col in [("hit10_20d", "hit10_20d"), ("dud", "dud"), ("mfe20", "mfe20")]:
    print(f"\n--- {outcome_name} 的 Spearman 相关 ---")
    for feat in features:
        corr = df[[feat, outcome_col]].dropna().corr(method="spearman").iloc[0, 1]
        print(f"  {feat:15s}  rho={corr:+.4f}")

# ============================================================
# PART 2: Cross-tabulation - which COMBINATIONS matter?
# ============================================================
print(f"\n{'=' * 70}")
print("  PART 2: 特征组合的结局分布")
print("=" * 70)

# type x peer bucket
print("\n--- event_type × peer_confirmation ---")
df["peer_bin"] = pd.cut(df["peer"], bins=[-1, 4, 8, 100], labels=["low≤4", "mid5-8", "high9+"])
for et in ["trend_spear", "attack", "arb", "post_limit"]:
    for pb in ["low≤4", "mid5-8", "high9+"]:
        sub = df[(df["event_type"] == et) & (df["peer_bin"] == pb)]
        if len(sub) >= 30:
            print(f"  {et:15s} peer={pb:8s}  n={len(sub):4d}  mfe20={sub.mfe20.mean():.1%}  hit10={sub.hit10_20d.mean():.0%}  hit20={sub.hit20_20d.mean():.0%}  dud={sub.dud.mean():.0%}  cr20={sub.cr20.mean():+.1%}")

# type x gate_gap bucket
print("\n--- event_type × gate_gap ---")
df["gg_bin"] = pd.cut(df["gate_gap"], bins=[-0.001, 0.001, 0.02, 0.04, 1.0], labels=["none", "0-2%", "2-4%", "4%+"])
for et in ["trend_spear", "attack", "arb", "post_limit"]:
    for gg in ["none", "0-2%", "2-4%", "4%+"]:
        sub = df[(df["event_type"] == et) & (df["gg_bin"] == gg)]
        if len(sub) >= 25:
            adj_mfe = (sub.mfe20 - sub.gate_gap).mean()
            print(f"  {et:15s} gate={gg:6s}  n={len(sub):4d}  mfe20={sub.mfe20.mean():.1%}  adj_mfe={adj_mfe:.1%}  hit10={sub.hit10_20d.mean():.0%}  dud={sub.dud.mean():.0%}")

# type x stop_gap bucket (risk profile)
print("\n--- event_type × stop_gap (下行风险) ---")
df["sg_bin"] = pd.cut(df["stop_gap"], bins=[-1.0, -0.08, -0.05, -0.03, 0.0], labels=["deep<-8%", "med-8~-5%", "tight-5~-3%", "tiny>-3%"])
for et in ["trend_spear", "post_limit"]:
    for sg in ["deep<-8%", "med-8~-5%", "tight-5~-3%", "tiny>-3%"]:
        sub = df[(df["event_type"] == et) & (df["sg_bin"] == sg)]
        if len(sub) >= 20:
            print(f"  {et:15s} stop={sg:12s}  n={len(sub):4d}  mfe20={sub.mfe20.mean():.1%}  hit10={sub.hit10_20d.mean():.0%}  dud={sub.dud.mean():.0%}  cr20={sub.cr20.mean():+.1%}")

# ============================================================
# PART 3: Simple scoring - can we rank signals?
# ============================================================
print(f"\n{'=' * 70}")
print("  PART 3: 简单评分 → 能把信号分成好坏几档吗？")
print("=" * 70)

# A dead-simple score: peer_rank + conf_rank + (1 - gate_gap_rank) + (neg stop_gap = wider stop = more risk)
df["score_peer"] = df["peer"].rank(pct=True)
df["score_conf"] = df["conf"].rank(pct=True)
df["score_gate"] = 1 - df["gate_gap"].rank(pct=True)  # lower gate gap is better
df["score_stop"] = (-df["stop_gap"]).rank(pct=True)  # more negative stop = wider = more risk = lower score
df["composite_score"] = (df["score_peer"] + df["score_conf"] + df["score_gate"]) / 3

# Score quintiles
df["score_q"] = pd.qcut(df["composite_score"], 5, labels=["Q1(worst)", "Q2", "Q3", "Q4", "Q5(best)"])
print("\n--- composite_score 五等分 ---")
for q in ["Q1(worst)", "Q2", "Q3", "Q4", "Q5(best)"]:
    sub = df[df["score_q"] == q]
    print(f"  {q:12s}  n={len(sub):4d}  mfe20={sub.mfe20.mean():.2%}  hit10={sub.hit10_20d.mean():.0%}  hit20={sub.hit20_20d.mean():.0%}  dud={sub.dud.mean():.0%}  cr20={sub.cr20.mean():+.2%}")

# Same but within each event_type
for et in ["trend_spear", "attack", "arb"]:
    sub_et = df[df["event_type"] == et].copy()
    if len(sub_et) < 100:
        continue
    sub_et["et_score_q"] = pd.qcut(sub_et["composite_score"], 5, labels=["Q1", "Q2", "Q3", "Q4", "Q5"], duplicates="drop")
    print(f"\n--- {et} 内部五等分 ---")
    for q in ["Q1", "Q2", "Q3", "Q4", "Q5"]:
        s = sub_et[sub_et["et_score_q"] == q]
        if len(s) >= 10:
            print(f"  {q:4s}  n={len(s):4d}  mfe20={s.mfe20.mean():.2%}  hit10={s.hit10_20d.mean():.0%}  hit20={s.hit20_20d.mean():.0%}  dud={s.dud.mean():.0%}  cr20={s.cr20.mean():+.2%}")

# ============================================================
# PART 4: Marginal value of each feature beyond event_type
# ============================================================
print(f"\n{'=' * 70}")
print("  PART 4: 每个特征的边际区分力 (高 vs 低分组)")
print("=" * 70)

for feat, lo_cond, hi_cond, lo_label, hi_label in [
    ("peer", lambda x: x < 5, lambda x: x >= 9, "peer<5", "peer≥9"),
    ("conf", lambda x: x < 0.68, lambda x: x >= 0.80, "conf<0.68", "conf≥0.80"),
    ("gate_gap", lambda x: x < 0.01, lambda x: x >= 0.03, "gap<1%", "gap≥3%"),
    ("leader", lambda x: x < 3, lambda x: x >= 8, "leader<3", "leader≥8"),
]:
    lo = df[lo_cond(df[feat])]
    hi = df[hi_cond(df[feat])]
    if len(lo) >= 30 and len(hi) >= 30:
        d_mfe = hi.mfe20.mean() - lo.mfe20.mean()
        d_hit = hi.hit10_20d.mean() - lo.hit10_20d.mean()
        d_dud = hi.dud.mean() - lo.dud.mean()
        print(f"\n  {hi_label:12s} (n={len(hi):4d})  mfe20={hi.mfe20.mean():.2%}  hit10={hi.hit10_20d.mean():.0%}  dud={hi.dud.mean():.0%}")
        print(f"  {lo_label:12s} (n={len(lo):4d})  mfe20={lo.mfe20.mean():.2%}  hit10={lo.hit10_20d.mean():.0%}  dud={lo.dud.mean():.0%}")
        print(f"  delta:  mfe20={d_mfe:+.2%}  hit10={d_hit:+.0%}  dud={d_dud:+.0%}")

# ============================================================
# PART 5: The honest question - is ANY feature actually strong?
# ============================================================
print(f"\n{'=' * 70}")
print("  PART 5: 诚实回答 — 有没有任何特征能强力区分单个信号的好坏？")
print("=" * 70)

# Best possible: top quartile vs bottom quartile of composite score
top = df[df["score_q"] == "Q5(best)"]
bot = df[df["score_q"] == "Q1(worst)"]
print(f"\n  最好五分位 vs 最差五分位:")
print(f"  Q5(best):  n={len(top):4d}  mfe20={top.mfe20.mean():.2%}  hit10={top.hit10_20d.mean():.0%}  hit20={top.hit20_20d.mean():.0%}  dud={top.dud.mean():.0%}  cr20={top.cr20.mean():+.2%}")
print(f"  Q1(worst): n={len(bot):4d}  mfe20={bot.mfe20.mean():.2%}  hit10={bot.hit10_20d.mean():.0%}  hit20={bot.hit20_20d.mean():.0%}  dud={bot.dud.mean():.0%}  cr20={bot.cr20.mean():+.2%}")
delta_mfe = top.mfe20.mean() - bot.mfe20.mean()
delta_hit = top.hit10_20d.mean() - bot.hit10_20d.mean()
delta_dud = top.dud.mean() - bot.dud.mean()
print(f"  gap:       mfe20={delta_mfe:+.2%}  hit10={delta_hit:+.0%}  dud={delta_dud:+.0%}")

print(f"\n  MFE 20d 分布对比:")
for bucket, lo, hi in [("<=0%", -999, 0), ("0-5%", 0, 0.05), ("5-10%", 0.05, 0.10), ("10-20%", 0.10, 0.20), ("20%+", 0.20, 999)]:
    top_pct = ((top.mfe20 >= lo) & (top.mfe20 < hi)).mean()
    bot_pct = ((bot.mfe20 >= lo) & (bot.mfe20 < hi)).mean()
    print(f"    {bucket:8s}  Q5={top_pct:.0%}  Q1={bot_pct:.0%}  diff={top_pct - bot_pct:+.0%}")
