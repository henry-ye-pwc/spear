"""
Analyze limit-up timing, duration, and volume-price patterns for trend_spear trades.
Uses bar-level data from cached parquet files to trace daily holding behavior.
"""
import sys, os, json, glob
import numpy as np
import pandas as pd
from collections import defaultdict

VENV = "/Users/yhanlin001/spear-strategy/.venv/bin/python"
BASE = "/Users/yhanlin001/spear-strategy/v5_standalone"
OUT_DIR = os.path.join(BASE, "outputs/backtests")

BACKTEST_DIRS = sorted(glob.glob(os.path.join(OUT_DIR, "20260312_*")))
CACHE_DIR = os.path.join(BASE, "cache")

def load_cached_bars(symbol: str) -> pd.DataFrame | None:
    sym6 = str(symbol).zfill(6)
    for pattern in [
        os.path.join(CACHE_DIR, f"*/{sym6}.parquet"),
        os.path.join(CACHE_DIR, f"**/{sym6}.parquet"),
    ]:
        files = glob.glob(pattern, recursive=True)
        if files:
            df = pd.read_parquet(files[0])
            if "date" in df.columns:
                df["date"] = pd.to_datetime(df["date"]).dt.strftime("%Y-%m-%d")
            return df
    return None

def find_bar_data_dir():
    candidates = [
        os.path.join(CACHE_DIR, "bars"),
        os.path.join(CACHE_DIR, "daily"),
        CACHE_DIR,
        os.path.join(BASE, "data"),
    ]
    for c in candidates:
        if os.path.isdir(c):
            parquets = glob.glob(os.path.join(c, "**/*.parquet"), recursive=True)
            if parquets:
                return c
    return None

def load_all_bars_for_symbol(symbol: str, bar_dir: str) -> pd.DataFrame | None:
    sym6 = str(symbol).zfill(6)
    for subdir in ["features", ""]:
        search_dir = os.path.join(bar_dir, subdir) if subdir else bar_dir
        if not os.path.isdir(search_dir):
            continue
        for pattern in [
            os.path.join(search_dir, f"{sym6}_*.parquet"),
            os.path.join(search_dir, f"{sym6}.parquet"),
        ]:
            files = glob.glob(pattern)
            if files:
                df = pd.read_parquet(files[0])
                if "date" in df.index.names:
                    df = df.reset_index()
                if "date" not in df.columns:
                    if {"year", "month", "day"}.issubset(df.columns):
                        df["date"] = pd.to_datetime(
                            df[["year", "month", "day"]].astype(int).astype(str).agg("-".join, axis=1)
                        ).dt.strftime("%Y-%m-%d")
                else:
                    df["date"] = pd.to_datetime(df["date"]).dt.strftime("%Y-%m-%d")
                df = df.sort_values("date").reset_index(drop=True)
                return df
    return None

def is_limit_up(row, tol=0.005):
    if "limit_up" in row.index and pd.notna(row.get("limit_up")):
        return abs(row["close"] - row["limit_up"]) / row["limit_up"] < tol
    pct = row.get("pct_chg") or row.get("change_pct")
    if pct is not None and pd.notna(pct):
        return pct >= 9.8
    if row.get("high") == row.get("close") and row.get("open") == row.get("close"):
        prev_close = row.get("pre_close")
        if prev_close and prev_close > 0:
            gain = (row["close"] - prev_close) / prev_close * 100
            return gain >= 9.5
    return False

def analyze():
    bar_dir = find_bar_data_dir()
    print(f"Bar data directory: {bar_dir}")
    if bar_dir:
        sample = glob.glob(os.path.join(bar_dir, "**/*.parquet"), recursive=True)[:3]
        for s in sample:
            print(f"  Sample: {s}")
            df = pd.read_parquet(s)
            print(f"    Columns: {list(df.columns)}")
            print(f"    Shape: {df.shape}")
            break

    all_records = []
    for bt_dir in BACKTEST_DIRS:
        ct_path = os.path.join(bt_dir, "closed_trades.csv")
        if not os.path.exists(ct_path):
            continue
        ct = pd.read_csv(ct_path, dtype={"symbol": str})
        ct["symbol"] = ct["symbol"].astype(str).str.zfill(6)
        spear = ct[ct["entry_reason"].str.contains("trend_spear", na=False)].copy()
        if spear.empty:
            continue

        bt_name = os.path.basename(bt_dir)
        meta_path = os.path.join(bt_dir, "meta.json")
        year_range = ""
        if os.path.exists(meta_path):
            with open(meta_path) as f:
                meta = json.load(f)
                year_range = meta.get("settings", {}).get("year_range", "")

        for _, trade in spear.iterrows():
            all_records.append({
                "backtest": bt_name,
                "year_range": year_range,
                "symbol": trade["symbol"],
                "entry_date": trade["entry_date"],
                "exit_date": trade["exit_date"],
                "exit_reason": trade["exit_reason"],
                "ret": trade["ret"],
                "hold_days": trade["hold_days"],
                "mfe": trade.get("mfe", np.nan),
                "mae": trade.get("mae", np.nan),
                "mfe_capture": trade.get("mfe_capture", np.nan),
            })

    print(f"\nTotal trend_spear trades across all backtests: {len(all_records)}")
    if not all_records:
        return

    df_trades = pd.DataFrame(all_records)
    unique_symbols = df_trades["symbol"].unique()
    print(f"Unique symbols: {len(unique_symbols)}")

    # Try to load bar data and compute daily metrics during holding
    bar_cache = {}
    loaded_count = 0
    for sym in unique_symbols:
        bars = None
        if bar_dir:
            bars = load_all_bars_for_symbol(sym, bar_dir)
        if bars is None:
            bars = load_cached_bars(sym)
        if bars is not None:
            bar_cache[sym] = bars
            loaded_count += 1
    print(f"Loaded bar data for {loaded_count}/{len(unique_symbols)} symbols")

    if loaded_count == 0:
        print("No bar data found. Listing cache structure...")
        if os.path.isdir(CACHE_DIR):
            for root, dirs, files in os.walk(CACHE_DIR):
                level = root.replace(CACHE_DIR, '').count(os.sep)
                indent = ' ' * 2 * level
                print(f'{indent}{os.path.basename(root)}/')
                if level < 2:
                    subindent = ' ' * 2 * (level + 1)
                    for f in files[:5]:
                        print(f'{subindent}{f}')
                    if len(files) > 5:
                        print(f'{subindent}... and {len(files)-5} more')
                if level >= 2:
                    break
        return

    # Analyze each trade's holding period
    holding_analyses = []
    for _, trade in df_trades.iterrows():
        sym = trade["symbol"]
        bars = bar_cache.get(sym)
        if bars is None:
            continue

        entry_date = trade["entry_date"]
        exit_date = trade["exit_date"]

        date_col = "date"
        mask = (bars[date_col] >= entry_date) & (bars[date_col] <= exit_date)
        hold_bars = bars[mask].copy()
        if hold_bars.empty:
            continue

        # Pre-entry bars for context (last 60 days before entry)
        pre_mask = bars[date_col] < entry_date
        pre_bars = bars[pre_mask].tail(60)

        # Volume stats from pre-entry period
        if len(pre_bars) > 0 and "volume" in pre_bars.columns:
            pre_vol = pre_bars["volume"]
            vol_median_pre = pre_vol.median()
            vol_p75_pre = pre_vol.quantile(0.75)
            vol_p90_pre = pre_vol.quantile(0.90)
            vol_max_pre = pre_vol.max()
        else:
            vol_median_pre = vol_p75_pre = vol_p90_pre = vol_max_pre = np.nan

        # Analyze each holding day
        limit_up_days = []
        daily_vol_ratios = []
        daily_returns = []
        for i, (idx, bar) in enumerate(hold_bars.iterrows()):
            day_num = i  # 0 = entry day
            lu = is_limit_up(bar)
            if lu:
                limit_up_days.append(day_num)

            if "volume" in bar.index and pd.notna(bar["volume"]) and vol_median_pre > 0:
                daily_vol_ratios.append(bar["volume"] / vol_median_pre)
            if "close" in bar.index and "open" in bar.index:
                daily_returns.append((bar["close"] - bar["open"]) / bar["open"] if bar["open"] > 0 else 0)

        # Compute consecutive limit-up streaks
        max_consecutive = 0
        current_streak = 0
        for i in range(len(hold_bars)):
            if i in limit_up_days:
                current_streak += 1
                max_consecutive = max(max_consecutive, current_streak)
            else:
                current_streak = 0

        first_lu_day = limit_up_days[0] if limit_up_days else -1
        n_lu = len(limit_up_days)

        # Volume behavior analysis
        up_day_vols = []
        down_day_vols = []
        for i, (idx, bar) in enumerate(hold_bars.iterrows()):
            if "volume" not in bar.index or pd.isna(bar["volume"]):
                continue
            ret = (bar["close"] - bar["open"]) / bar["open"] if bar["open"] > 0 else 0
            if ret > 0:
                up_day_vols.append(bar["volume"])
            elif ret < 0:
                down_day_vols.append(bar["volume"])

        # Zhang-yang-han-xu metrics
        mean_up_vol = np.mean(up_day_vols) if up_day_vols else np.nan
        mean_down_vol = np.mean(down_day_vols) if down_day_vols else np.nan
        median_up_vol = np.median(up_day_vols) if up_day_vols else np.nan
        median_down_vol = np.median(down_day_vols) if down_day_vols else np.nan

        vol_ratio_up_down_mean = mean_up_vol / mean_down_vol if mean_down_vol and mean_down_vol > 0 else np.nan
        vol_ratio_up_down_median = median_up_vol / median_down_vol if median_down_vol and median_down_vol > 0 else np.nan

        max_hold_vol = hold_bars["volume"].max() if "volume" in hold_bars.columns else np.nan
        vol_ratio_max_vs_pre = max_hold_vol / vol_max_pre if vol_max_pre and vol_max_pre > 0 else np.nan

        holding_analyses.append({
            "backtest": trade["backtest"],
            "symbol": sym,
            "entry_date": entry_date,
            "exit_date": exit_date,
            "exit_reason": trade["exit_reason"],
            "ret": trade["ret"],
            "mfe": trade.get("mfe", np.nan),
            "hold_days": trade["hold_days"],
            "n_limit_up": n_lu,
            "first_lu_day": first_lu_day,
            "max_consecutive_lu": max_consecutive,
            "vol_ratio_up_down_mean": vol_ratio_up_down_mean,
            "vol_ratio_up_down_median": vol_ratio_up_down_median,
            "vol_ratio_max_vs_pre": vol_ratio_max_vs_pre,
            "vol_median_pre60": vol_median_pre,
            "mean_daily_vol_ratio": np.mean(daily_vol_ratios) if daily_vol_ratios else np.nan,
            "daily_vol_ratios": daily_vol_ratios,
            "daily_returns": daily_returns,
            "limit_up_days": limit_up_days,
        })

    ha = pd.DataFrame(holding_analyses)
    print(f"\nAnalyzed {len(ha)} trades with bar data")
    print(f"  With limit-up: {(ha['n_limit_up'] > 0).sum()} ({(ha['n_limit_up'] > 0).mean()*100:.1f}%)")
    print(f"  Without limit-up: {(ha['n_limit_up'] == 0).sum()} ({(ha['n_limit_up'] == 0).mean()*100:.1f}%)")

    # Q1: When do limit-ups start?
    lu_trades = ha[ha["n_limit_up"] > 0]
    print("\n" + "="*60)
    print("Q1: WHEN DO LIMIT-UPS START? (first_lu_day distribution)")
    print("="*60)
    if len(lu_trades) > 0:
        print(f"\nFirst limit-up day distribution (0=entry day):")
        print(lu_trades["first_lu_day"].describe())
        print(f"\nHistogram:")
        for d in range(-1, 12):
            count = (lu_trades["first_lu_day"] == d).sum()
            if count > 0:
                bar = "#" * count
                print(f"  Day {d:2d}: {bar} ({count})")

    # Q2: How long do consecutive limit-up waves last?
    print("\n" + "="*60)
    print("Q2: CONSECUTIVE LIMIT-UP DURATION")
    print("="*60)
    if len(lu_trades) > 0:
        print(f"\nMax consecutive limit-ups distribution:")
        print(lu_trades["max_consecutive_lu"].describe())
        print(f"\nHistogram:")
        for d in range(1, 8):
            count = (lu_trades["max_consecutive_lu"] == d).sum()
            if count > 0:
                bar = "#" * count
                print(f"  {d} consecutive: {bar} ({count})")

    # Q3: Volume-price pattern differences: board vs no-board
    print("\n" + "="*60)
    print("Q3: VOLUME-PRICE PATTERNS - BOARD vs NO-BOARD")
    print("="*60)
    no_lu = ha[ha["n_limit_up"] == 0]

    for label, group in [("WITH BOARD", lu_trades), ("NO BOARD", no_lu)]:
        print(f"\n--- {label} (n={len(group)}) ---")
        print(f"  Avg return: {group['ret'].mean()*100:.2f}%")
        print(f"  Avg MFE: {group['mfe'].mean()*100:.2f}%")
        print(f"  Avg hold days: {group['hold_days'].mean():.1f}")
        print(f"  Vol ratio up/down (mean): {group['vol_ratio_up_down_mean'].median():.3f}")
        print(f"  Vol ratio up/down (median): {group['vol_ratio_up_down_median'].median():.3f}")
        print(f"  Max vol vs pre-60d max: {group['vol_ratio_max_vs_pre'].median():.3f}")
        print(f"  Mean daily vol ratio (vs pre median): {group['mean_daily_vol_ratio'].median():.3f}")

    # Q3b: Day-by-day volume pattern comparison for first 10 days
    print("\n" + "="*60)
    print("Q3b: DAY-BY-DAY VOLUME PATTERN (first 10 holding days)")
    print("="*60)
    for label, group in [("WITH BOARD", lu_trades), ("NO BOARD", no_lu)]:
        print(f"\n--- {label} ---")
        print(f"{'Day':>4s} | {'Med Vol Ratio':>14s} | {'Med Return':>11s} | {'N':>4s}")
        print("-" * 45)
        for day in range(10):
            vols = []
            rets = []
            for _, row in group.iterrows():
                if day < len(row["daily_vol_ratios"]):
                    vols.append(row["daily_vol_ratios"][day])
                if day < len(row["daily_returns"]):
                    rets.append(row["daily_returns"][day])
            if vols:
                med_vol = np.median(vols)
                med_ret = np.median(rets) * 100 if rets else 0
                print(f"  {day:2d}  | {med_vol:14.3f} | {med_ret:10.2f}% | {len(vols):4d}")

    # Q4: Discriminating features - what predicts limit-up potential early?
    print("\n" + "="*60)
    print("Q4: EARLY DISCRIMINATORS (Day 0-2 patterns)")
    print("="*60)

    for label, group in [("WITH BOARD", lu_trades), ("NO BOARD", no_lu)]:
        day0_vols = [r["daily_vol_ratios"][0] for _, r in group.iterrows() if len(r["daily_vol_ratios"]) > 0]
        day0_rets = [r["daily_returns"][0] for _, r in group.iterrows() if len(r["daily_returns"]) > 0]
        day1_vols = [r["daily_vol_ratios"][1] for _, r in group.iterrows() if len(r["daily_vol_ratios"]) > 1]
        day1_rets = [r["daily_returns"][1] for _, r in group.iterrows() if len(r["daily_returns"]) > 1]

        print(f"\n--- {label} ---")
        if day0_vols:
            print(f"  Day 0: Vol ratio median={np.median(day0_vols):.3f}, p25={np.percentile(day0_vols, 25):.3f}, p75={np.percentile(day0_vols, 75):.3f}")
            print(f"         Return  median={np.median(day0_rets)*100:.2f}%, p25={np.percentile(day0_rets, 25)*100:.2f}%, p75={np.percentile(day0_rets, 75)*100:.2f}%")
        if day1_vols:
            print(f"  Day 1: Vol ratio median={np.median(day1_vols):.3f}, p25={np.percentile(day1_vols, 25):.3f}, p75={np.percentile(day1_vols, 75):.3f}")
            print(f"         Return  median={np.median(day1_rets)*100:.2f}%, p25={np.percentile(day1_rets, 25)*100:.2f}%, p75={np.percentile(day1_rets, 75)*100:.2f}%")

    # Q5: P&L by first_lu_day to understand urgency
    print("\n" + "="*60)
    print("Q5: P&L BY FIRST LIMIT-UP DAY")
    print("="*60)
    if len(lu_trades) > 0:
        for d in range(10):
            sub = lu_trades[lu_trades["first_lu_day"] == d]
            if len(sub) > 0:
                print(f"  First LU on Day {d}: n={len(sub)}, avg ret={sub['ret'].mean()*100:.2f}%, avg mfe={sub['mfe'].mean()*100:.2f}%")

    # Final: exit reason breakdown for board vs no-board
    print("\n" + "="*60)
    print("EXIT REASON BREAKDOWN")
    print("="*60)
    for label, group in [("WITH BOARD", lu_trades), ("NO BOARD", no_lu)]:
        print(f"\n--- {label} ---")
        if len(group) > 0:
            for reason, cnt in group["exit_reason"].value_counts().items():
                avg_ret = group[group["exit_reason"] == reason]["ret"].mean() * 100
                print(f"  {reason}: {cnt} ({cnt/len(group)*100:.1f}%) avg ret={avg_ret:.2f}%")


if __name__ == "__main__":
    analyze()
