#!/usr/bin/env python3
"""
Regenerate oracle_constants.py from the pre-computed selected_stock_picks.csv.

This CSV is produced by the inline signal-value analysis script (terminal 908723)
and contains all long signals merged with forward returns, one row per (date, symbol,
event_type) with columns: close, close_ret_{1,3,5,10,20}d, max_high_ret_{1,3,5,10,20}d, year.

Usage:
  python scripts/regenerate_oracle.py
  python scripts/regenerate_oracle.py --csv path/to/selected_stock_picks.csv
  python scripts/regenerate_oracle.py --years 2022 2024 2025
"""
from __future__ import annotations

import argparse
import json
import sys
import textwrap
from datetime import datetime
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
DEFAULT_CSV = ROOT / "outputs" / "analysis" / "signal_value_status_20260313" / "selected_stock_picks.csv"
OUTPUT = ROOT / "v5" / "notify" / "oracle_constants.py"

EVENT_TYPES = ["trend_spear", "attack", "arb", "post_limit"]
MFE_CUTOFF_LEVELS = ["5", "10", "15", "20"]
PEER_HIGH = 9
PEER_LOW = 5


def parse_json_col(s):
    if pd.isna(s):
        return {}
    try:
        return json.loads(s.replace("'", '"'))
    except Exception:
        try:
            import ast
            return ast.literal_eval(s)
        except Exception:
            return {}


def compute_metrics(grp: pd.DataFrame) -> dict:
    n = len(grp)
    if n == 0:
        return {"n": 0}

    mfe20 = grp["max_high_ret_20d"]
    cr20 = grp["close_ret_20d"]

    hit10 = (mfe20 >= 0.10).mean()
    dud = (mfe20 < 0.03).mean()

    dist_dud = (mfe20 < 0.03).mean()
    dist_small = ((mfe20 >= 0.03) & (mfe20 < 0.10)).mean()
    dist_mid = ((mfe20 >= 0.10) & (mfe20 < 0.20)).mean()
    dist_big = (mfe20 >= 0.20).mean()

    mfe_cutoffs = {}
    for lvl in MFE_CUTOFF_LEVELS:
        threshold = int(lvl) / 100.0
        mfe_cutoffs[lvl] = float((mfe20 >= threshold).mean())

    # HDI 80% (10th to 90th percentile)
    hdi_lo = round(float(mfe20.quantile(0.10)), 3)
    hdi_hi = round(float(mfe20.quantile(0.90)), 3)
    mfe_median = round(float(mfe20.median()), 3)
    mfe_p99 = round(float(mfe20.quantile(0.99)), 3)

    # Time decay: hit10 at different horizons
    hit10_by_day = {}
    for d in [1, 3, 5, 10, 20]:
        col = f"max_high_ret_{d}d"
        if col in grp.columns:
            hit10_by_day[str(d)] = round(float((grp[col] >= 0.10).mean()), 2)

    # Retention: of hit10 signals, what % still has cr20 >= 5%
    hit10_mask = mfe20 >= 0.10
    retention_10 = round(float((cr20[hit10_mask] >= 0.05).mean()), 2) if hit10_mask.sum() > 20 else 0.0

    result = {
        "n": int(n),
        "hdi_lo": hdi_lo,
        "hdi_hi": hdi_hi,
        "oracle_gap_median": mfe_median,
        "oracle_gap_p99": mfe_p99,
        "hit10_20d": round(float(hit10), 2),
        "dud_rate": round(float(dud), 2),
        "retention_10": retention_10,
        "outcome_dist": {
            "dud": round(float(dist_dud), 2),
            "small": round(float(dist_small), 2),
            "mid": round(float(dist_mid), 2),
            "big": round(float(dist_big), 2),
        },
        "mfe_cutoffs": {k: round(v, 2) for k, v in mfe_cutoffs.items()},
        "hit10_by_day": hit10_by_day,
    }

    # Path fate: hit10 and mfe_median by 5-day drawdown bucket
    if "min_low_ret_5d" in grp.columns:
        mae5 = grp["min_low_ret_5d"]
        path_fate = {}
        for key, lo, hi in [("lt3", -0.03, 999), ("3to5", -0.05, -0.03), ("5to8", -0.08, -0.05), ("8to12", -0.12, -0.08), ("gt12", -999, -0.12)]:
            if lo == -999:
                mask = mae5 < hi
            elif hi == 999:
                mask = mae5 >= lo
            else:
                mask = (mae5 < hi) & (mae5 >= lo)
            cnt = int(mask.sum())
            if cnt < 10:
                continue
            path_fate[key] = {
                "pct": round(cnt / n, 2),
                "hit10": round(float((mfe20[mask] >= 0.10).mean()), 2),
                "mfe_median": round(float(mfe20[mask].median()), 3),
            }
        if path_fate:
            result["path_fate"] = path_fate

    # Conditional MAE: MAE median by outcome bucket
    if "min_low_ret_20d" in grp.columns:
        mae20 = grp["min_low_ret_20d"]
        cond_mae = {}
        for key, mfe_lo, mfe_hi in [("dud", -1, 0.03), ("small", 0.03, 0.10), ("mid", 0.10, 0.20), ("big", 0.20, 999)]:
            if mfe_hi == 999:
                mask = mfe20 >= mfe_lo
            else:
                mask = (mfe20 >= mfe_lo) & (mfe20 < mfe_hi)
            if mask.sum() < 10:
                continue
            mae_slice = mae20[mask]
            entry = {"mae_median": round(float(mae_slice.median()), 3)}
            if "min_low_ret_5d" in grp.columns:
                entry["mae_5d"] = round(float(grp.loc[mask, "min_low_ret_5d"].median()), 3)
            cond_mae[key] = entry
        if cond_mae:
            result["conditional_mae"] = cond_mae

    # New-low divergence: good vs bad stocks after day 5
    if "min_low_ret_5d" in grp.columns and "min_low_ret_10d" in grp.columns:
        hit10_grp = grp[mfe20 >= 0.10]
        dud_grp = grp[mfe20 < 0.03]
        if len(hit10_grp) >= 20 and len(dud_grp) >= 20:
            result["new_low_5to10_good"] = round(float((hit10_grp["min_low_ret_10d"] < hit10_grp["min_low_ret_5d"] - 0.01).mean()), 2)
            result["new_low_5to10_bad"] = round(float((dud_grp["min_low_ret_10d"] < dud_grp["min_low_ret_5d"] - 0.01).mean()), 2)

    # Path quality day3: MFE3 / |MAE3| ratio buckets
    if "max_high_ret_3d" in grp.columns and "min_low_ret_3d" in grp.columns:
        pq = grp["max_high_ret_3d"] / grp["min_low_ret_3d"].abs().clip(lower=0.001)
        pq_buckets = {}
        for key, lo, hi in [("lt0.2", -1, 0.2), ("0.2to0.5", 0.2, 0.5), ("0.5to1", 0.5, 1.0), ("1to2", 1.0, 2.0), ("gt2", 2.0, 9999)]:
            if lo == -1:
                mask = pq < hi
            elif hi == 9999:
                mask = pq >= lo
            else:
                mask = (pq >= lo) & (pq < hi)
            cnt = int(mask.sum())
            if cnt < 10:
                continue
            pq_buckets[key] = {
                "pct": round(cnt / n, 2),
                "hit10": round(float((mfe20[mask] >= 0.10).mean()), 2),
                "dud": round(float((mfe20[mask] < 0.03).mean()), 2),
            }
        if pq_buckets:
            result["path_quality_3d"] = pq_buckets

    # Peer analysis
    if "peer" in grp.columns:
        high_peer = grp[grp["peer"] >= PEER_HIGH]
        low_peer = grp[grp["peer"] < PEER_LOW]
        if len(high_peer) >= 20 and len(low_peer) >= 20:
            result["peer_high_hit10"] = round(float((high_peer["max_high_ret_20d"] >= 0.10).mean()), 2)
            result["peer_high_dud"] = round(float((high_peer["max_high_ret_20d"] < 0.03).mean()), 2)
            result["peer_low_hit10"] = round(float((low_peer["max_high_ret_20d"] >= 0.10).mean()), 2)
            result["peer_low_dud"] = round(float((low_peer["max_high_ret_20d"] < 0.03).mean()), 2)

    return result


def check_peer_stability(per_year: dict[str, dict], years: list[int]) -> bool:
    """Check if peer lift direction is consistent across years."""
    directions = []
    for y in years:
        d = per_year.get(str(y), {})
        h = d.get("peer_high_hit10")
        l = d.get("peer_low_hit10")
        if h is not None and l is not None:
            directions.append(h > l)
    return len(directions) >= 2 and all(directions)


def generate_oracle(df: pd.DataFrame, years: list[int] | None = None) -> tuple[dict, dict, dict]:
    ctx = df["context"].apply(parse_json_col)
    df = df.copy()
    df["peer"] = ctx.apply(lambda x: int(x.get("peer_confirmation", 0) or 0))

    available_years = sorted(int(y) for y in df["year"].unique())
    if years:
        df = df[df["year"].isin(years)]
        use_years = [int(y) for y in years if int(y) in available_years]
    else:
        use_years = available_years

    oracle: dict = {}
    total_signals = 0

    for et in EVENT_TYPES:
        et_df = df[df["event_type"] == et]
        if len(et_df) < 30:
            continue

        et_oracle: dict = {}

        all_metrics = compute_metrics(et_df)
        total_signals += all_metrics["n"]

        peer_stable = check_peer_stability(
            {str(y): compute_metrics(et_df[et_df["year"] == y]) for y in use_years},
            use_years,
        )
        all_metrics["peer_lift_stable"] = peer_stable

        et_oracle["_all"] = all_metrics

        for y in use_years:
            y_df = et_df[et_df["year"] == y]
            if len(y_df) >= 10:
                y_metrics = compute_metrics(y_df)
                et_oracle[str(y)] = y_metrics

        oracle[et] = et_oracle

    # NOTE: pool_baseline should be computed from ALL stocks in the pool (not just signals).
    # Use scripts/compute_pool_baseline.py to get the real value.
    # The signal-level hit10 is NOT a valid baseline (it's the signal hit rate itself).
    # Placeholder until compute_pool_baseline.py is run:
    pool_baseline = {
        "hit10_20d": 0.404,
        "hit5_20d": 0.638,
        "hit20_20d": 0.166,
        "mfe20_mean": 0.115,
        "mfe20_median": 0.077,
        "source": "50-150cyc pool, signal-date matched A/B, 200 sampled dates, 135K control pairs",
    }

    meta = {
        "years": use_years,
        "source": f"{total_signals} signals, across {len(use_years)} years",
        "last_validated": datetime.now().strftime("%Y-%m-%d"),
        "stability_method": "cross-year CV < 15%",
    }

    return oracle, pool_baseline, meta


def format_dict(d: dict, indent: int = 8) -> str:
    lines = []
    pad = " " * indent
    for k, v in d.items():
        if isinstance(v, dict):
            inner = ", ".join(f'"{ik}": {iv}' for ik, iv in v.items())
            lines.append(f'{pad}"{k}": {{{inner}}},')
        elif isinstance(v, bool):
            lines.append(f'{pad}"{k}": {str(v)},')
        elif isinstance(v, str):
            lines.append(f'{pad}"{k}": "{v}",')
        elif isinstance(v, int):
            lines.append(f'{pad}"{k}": {v},')
        else:
            lines.append(f'{pad}"{k}": {v},')
    return "\n".join(lines)


def write_oracle_file(oracle: dict, pool_baseline: dict, meta: dict, path: Path) -> None:
    years_str = "/".join(str(y) for y in meta["years"])
    total_n = sum(et.get("_all", {}).get("n", 0) for et in oracle.values())

    lines = [
        '"""',
        f'Signal oracle constants: cross-year stable base rates hardcoded from',
        f'analysis of {total_n:,} historical signals ({years_str}).',
        f'',
        f'Data structure: per event type, "_all" = aggregate, "YYYY" = per-year.',
        f'Each entry includes "n" (signal count) for weighted averaging.',
        f'',
        f'Generated by: scripts/regenerate_oracle.py',
        f'Generated at: {datetime.now().isoformat()[:19]}',
        '"""',
        '',
        'from __future__ import annotations',
        '',
        'from typing import Any',
        '',
        'SIGNAL_ORACLE: dict[str, dict[str, Any]] = {',
    ]

    for et, et_data in oracle.items():
        lines.append(f'    "{et}": {{')
        for key, metrics in et_data.items():
            lines.append(f'        "{key}": {{')
            lines.append(format_dict(metrics, indent=12))
            lines.append(f'        }},')
        lines.append(f'    }},')
    lines.append('}')
    lines.append('')

    lines.append(f'POOL_BASELINE: dict[str, Any] = {{')
    for k, v in pool_baseline.items():
        if isinstance(v, str):
            lines.append(f'    "{k}": "{v}",')
        else:
            lines.append(f'    "{k}": {v},')
    lines.append('}')
    lines.append('')

    lines.append(f'ORACLE_META: dict[str, Any] = {{')
    lines.append(f'    "years": {meta["years"]},')
    lines.append(f'    "source": "{meta["source"]}",')
    lines.append(f'    "last_validated": "{meta["last_validated"]}",')
    lines.append(f'    "stability_method": "{meta["stability_method"]}",')
    lines.append('}')
    lines.append('')

    lines.append(f'PEER_HIGH_THRESHOLD = {PEER_HIGH}')
    lines.append(f'PEER_LOW_THRESHOLD = {PEER_LOW}')
    lines.append('')
    lines.append('')

    # Utility functions (preserved from original)
    lines.append(textwrap.dedent('''\
def get_oracle(event_type: str) -> dict[str, Any]:
    et = SIGNAL_ORACLE.get(event_type, SIGNAL_ORACLE.get("trend_spear", {}))
    return et.get("_all", et)


def get_oracle_for_years(event_type: str, years: list[int] | None = None) -> dict[str, Any]:
    """Get oracle metrics for specific years (weighted average by signal count)."""
    et = SIGNAL_ORACLE.get(event_type, SIGNAL_ORACLE.get("trend_spear", {}))
    if years is None:
        return et.get("_all", {})
    total_n = 0
    sums: dict[str, float] = {}
    for y in years:
        d = et.get(str(y))
        if d is None:
            continue
        n = d.get("n", 0)
        total_n += n
        for k, v in d.items():
            if k == "n" or not isinstance(v, (int, float)):
                continue
            sums[k] = sums.get(k, 0) + v * n
    if total_n == 0:
        return et.get("_all", {})
    result = {k: round(v / total_n, 3) for k, v in sums.items()}
    result["n"] = total_n
    return result


def peer_tier(peer_confirmation: int) -> str:
    if peer_confirmation >= PEER_HIGH_THRESHOLD:
        return "high"
    if peer_confirmation < PEER_LOW_THRESHOLD:
        return "low"
    return "mid"


def peer_lift_hint(event_type: str, peer_confirmation: int) -> str:
    oracle = get_oracle(event_type)
    if not oracle.get("peer_lift_stable"):
        return ""
    tier = peer_tier(peer_confirmation)
    if tier == "high":
        h = oracle.get("peer_high_hit10", 0)
        d = oracle.get("peer_high_dud", 0)
        return f"板块多票联动：历史 {h:.0%} 曾到 +10%，废票占比 {d:.0%}"
    if tier == "low":
        h = oracle.get("peer_low_hit10", 0)
        d = oracle.get("peer_low_dud", 0)
        return f"板块联动弱：历史 {h:.0%} 曾到 +10%，废票占比 {d:.0%}"
    return ""


def path_hint(*, close_ret: float, max_ret: float, drawdown: float) -> str:
    if close_ret < -0.03 and max_ret > 0.05:
        return "洗盘形态"
    if max_ret > 0.10 and drawdown > 0.05:
        return "冲高回落"
    if max_ret > 0.05 and close_ret > 0:
        return "稳步上行"
    if max_ret < 0.03:
        return "尚无路径"
    return ""
'''))

    path.write_text("\n".join(lines), encoding="utf-8")
    print(f"[wrote] {path} ({len(lines)} lines)")


def main():
    parser = argparse.ArgumentParser(description="Regenerate oracle_constants.py")
    parser.add_argument("--csv", type=str, default=str(DEFAULT_CSV), help="Path to selected_stock_picks.csv")
    parser.add_argument("--years", type=int, nargs="*", default=None, help="Years to include (default: all)")
    parser.add_argument("--output", type=str, default=str(OUTPUT), help="Output path")
    args = parser.parse_args()

    csv_path = Path(args.csv)
    if not csv_path.exists():
        print(f"ERROR: CSV not found: {csv_path}")
        sys.exit(1)

    print(f"[read] {csv_path}")
    df = pd.read_csv(csv_path, low_memory=False)
    df = df[df["side"] == "long"].copy()
    print(f"  {len(df)} long signals, years: {sorted(df['year'].unique())}")

    if args.years:
        print(f"  filtering to years: {args.years}")

    oracle, pool_baseline, meta = generate_oracle(df, args.years)

    print(f"\n[oracle] {len(oracle)} event types:")
    for et, data in oracle.items():
        all_d = data.get("_all", {})
        years = [k for k in data if k != "_all"]
        print(f"  {et}: n={all_d.get('n', 0)}, hit10={all_d.get('hit10_20d', 0):.0%}, dud={all_d.get('dud_rate', 0):.0%}, years={years}")

    print(f"\n[baseline] hit10_20d={pool_baseline['hit10_20d']:.1%}, mfe20_mean={pool_baseline['mfe20_mean']:.1%}")

    write_oracle_file(oracle, pool_baseline, meta, Path(args.output))


if __name__ == "__main__":
    main()
