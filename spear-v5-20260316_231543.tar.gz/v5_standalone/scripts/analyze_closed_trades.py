#!/usr/bin/env python3
"""Analyze closed_trades.csv for backtest report."""
import csv
from collections import defaultdict
from pathlib import Path

CSV_PATH = Path(__file__).resolve().parents[1] / "outputs/backtests/20260312_2024-2024_50-150cyc_dli_9ecfc0/closed_trades.csv"


def main():
    rows = []
    with open(CSV_PATH, encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for r in reader:
            r["pnl"] = float(r["pnl"])
            r["ret"] = float(r["ret"])
            r["hold_days"] = int(r["hold_days"])
            r["entry_reason"] = r["entry_reason"].replace("entry:", "").strip()
            r["exit_reason"] = r["exit_reason"].strip()
            rows.append(r)

    n = len(rows)
    print(f"Total closed trades: {n}\n")

    # 1. By entry_reason breakdown
    by_entry = defaultdict(lambda: {"count": 0, "pnl_sum": 0, "ret_sum": 0, "wins": 0})
    for r in rows:
        k = r["entry_reason"]
        by_entry[k]["count"] += 1
        by_entry[k]["pnl_sum"] += r["pnl"]
        by_entry[k]["ret_sum"] += r["ret"]
        if r["pnl"] > 0:
            by_entry[k]["wins"] += 1

    print("=" * 80)
    print("1. BY ENTRY_REASON BREAKDOWN")
    print("=" * 80)
    for k in sorted(by_entry.keys()):
        d = by_entry[k]
        avg_ret = d["ret_sum"] / d["count"] if d["count"] else 0
        wr = 100 * d["wins"] / d["count"] if d["count"] else 0
        print(f"  {k:20s}  count={d['count']:4d}  avg_ret={avg_ret:8.4%}  total_pnl={d['pnl_sum']:12,.2f}  win_rate={wr:5.2f}%")
    print()

    # 2. Top 10 most profitable
    sorted_pnl = sorted(rows, key=lambda x: x["pnl"], reverse=True)
    print("=" * 80)
    print("2. TOP 10 MOST PROFITABLE TRADES (by pnl)")
    print("=" * 80)
    for r in sorted_pnl[:10]:
        print(f"  {r['symbol']:8s}  {r['entry_date']}  {r['exit_date']}  {r['entry_reason']:15s}  {r['exit_reason']:12s}  pnl={r['pnl']:12,.2f}  ret={r['ret']:8.4%}")
    print()

    # 3. Top 10 most losing
    print("=" * 80)
    print("3. TOP 10 MOST LOSING TRADES (by pnl)")
    print("=" * 80)
    for r in sorted_pnl[-10:][::-1]:
        print(f"  {r['symbol']:8s}  {r['entry_date']}  {r['exit_date']}  {r['entry_reason']:15s}  {r['exit_reason']:12s}  pnl={r['pnl']:12,.2f}  ret={r['ret']:8.4%}")
    print()

    # 4. Total PnL verification
    total_pnl = sum(r["pnl"] for r in rows)
    print("=" * 80)
    print("4. TOTAL PNL VERIFICATION")
    print("=" * 80)
    print(f"  Sum of closed_trades pnl:     {total_pnl:,.2f}")
    print(f"  Open positions unrealized:     ~23,467.77 (from summary)")
    print(f"  Total (closed + unrealized):   {total_pnl + 23467.77:,.2f}")
    print(f"  Init cash:                     1,000,000.00")
    print(f"  Equity final (from summary):   2,421,052.94")
    print(f"  Implied total gain:            {2421052.94 - 1000000:,.2f}")
    print(f"  Equity return:                 142.11%")
    print()

    # 5. Monthly PnL distribution
    by_month = defaultdict(float)
    for r in rows:
        exit_date = r["exit_date"]
        month = exit_date[:7]  # YYYY-MM
        by_month[month] += r["pnl"]

    print("=" * 80)
    print("5. MONTHLY PNL DISTRIBUTION (by exit_date month)")
    print("=" * 80)
    for m in sorted(by_month.keys()):
        print(f"  {m}  total_pnl={by_month[m]:12,.2f}")
    print()

    # 6. Hold days by entry_reason and exit_reason
    hold_by_entry = defaultdict(list)
    hold_by_exit = defaultdict(list)
    hold_by_both = defaultdict(list)
    for r in rows:
        hold_by_entry[r["entry_reason"]].append(r["hold_days"])
        hold_by_exit[r["exit_reason"]].append(r["hold_days"])
        hold_by_both[(r["entry_reason"], r["exit_reason"])].append(r["hold_days"])

    print("=" * 80)
    print("6. HOLD DAYS DISTRIBUTION")
    print("=" * 80)
    print("  By entry_reason:")
    for k in sorted(hold_by_entry.keys()):
        vals = hold_by_entry[k]
        avg = sum(vals) / len(vals)
        print(f"    {k:20s}  avg_hold_days={avg:.2f}  (n={len(vals)})")
    print("  By exit_reason:")
    for k in sorted(hold_by_exit.keys()):
        vals = hold_by_exit[k]
        avg = sum(vals) / len(vals)
        print(f"    {k:20s}  avg_hold_days={avg:.2f}  (n={len(vals)})")
    print("  By (entry_reason, exit_reason):")
    for (er, ex) in sorted(hold_by_both.keys()):
        vals = hold_by_both[(er, ex)]
        avg = sum(vals) / len(vals)
        print(f"    ({er}, {ex})  avg_hold_days={avg:.2f}  (n={len(vals)})")
    print()

    # 7. Concentration by symbol
    by_symbol = defaultdict(float)
    for r in rows:
        by_symbol[r["symbol"]] += r["pnl"]

    sorted_symbols = sorted(by_symbol.items(), key=lambda x: x[1], reverse=True)
    print("=" * 80)
    print("7. TOP 10 SYMBOLS BY TOTAL PNL (concentration)")
    print("=" * 80)
    for sym, pnl in sorted_symbols[:10]:
        print(f"  {sym:8s}  total_pnl={pnl:12,.2f}")
    print()
    print("  Bottom 5 symbols (most negative):")
    for sym, pnl in sorted_symbols[-5:]:
        print(f"  {sym:8s}  total_pnl={pnl:12,.2f}")


if __name__ == "__main__":
    main()
