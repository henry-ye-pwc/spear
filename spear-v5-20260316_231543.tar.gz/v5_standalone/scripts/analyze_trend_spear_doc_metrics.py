from __future__ import annotations

import json
import sys
from datetime import datetime
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from v4.data.adapter import V4DataAdapter
from v4.features import add_robust_volume_features, add_sequence_features, add_structure_features


BACKTEST_ROOT = ROOT / "outputs" / "backtests"
STAMP = datetime.now().strftime("%Y%m%d")
OUT_DIR = ROOT / "outputs" / "analysis" / f"trend_spear_doc_metrics_{STAMP}"
YEARS = [2022, 2024, 2025]

RUN_DIRS = {
    year: BACKTEST_ROOT / f"ts_obs_20260313_{year}_dlh_intraday"
    for year in YEARS
}

BOOL_METRICS = [
    "zhangyang_zhang_ok",
    "zhangyang_xu_ok",
    "zhangyang_han_ok",
    "zhangyang_explosive_recent",
    "zhangyang_vol_price_divergence",
    "zhangyang_hanshu_score",
    "chengshangqixia_chip_loosen",
    "chengshangqixia_position_ok",
    "chengshangqixia_score",
]

CONT_METRICS = [
    "zhang_ratio_10",
    "xu_ratio_10",
    "han_ratio_10",
    "zhangyang_recent_vol_ratio_10",
    "zhangyang_recent_price_gain_10",
    "chengshangqixia_pressure_touch_pct",
    "chengshangqixia_release_touch_pct",
]

RETURN_TARGETS = [
    "adj_max_high_ret_20d",
    "adj_max_high_ret_30d",
    "adj_close_ret_10d",
    "adj_close_ret_30d",
]


def parse_plan(value: str) -> dict:
    try:
        return json.loads(value) if isinstance(value, str) and value else {}
    except Exception:
        return {}


def prepare_symbol_frame(adapter: V4DataAdapter, symbol: str, end: str) -> pd.DataFrame:
    bars = adapter.load_symbol(symbol, start="", end=end)
    if bars.empty or len(bars) < 140:
        return pd.DataFrame()
    bars = add_robust_volume_features(bars)
    bars = add_sequence_features(bars)
    bars = add_structure_features(bars)
    bars = bars.copy()
    bars["date"] = pd.to_datetime(bars.index).strftime("%Y-%m-%d")
    return bars


def build_forward_metrics(frame: pd.DataFrame) -> pd.DataFrame:
    cols = [
        "date",
        "symbol",
        "close",
        "high",
        "vol60_iqr_norm",
        "vol_elevation",
        *BOOL_METRICS,
        *CONT_METRICS,
    ]
    out = frame[cols].copy()
    out["close"] = out["close"].astype(float)
    out["high"] = out["high"].astype(float)
    for horizon in [10, 20, 30]:
        out[f"close_ret_{horizon}d"] = out["close"].shift(-horizon) / out["close"] - 1.0
        fut_high = pd.concat([out["high"].shift(-i) for i in range(1, horizon + 1)], axis=1)
        out[f"max_high_ret_{horizon}d"] = fut_high.max(axis=1) / out["close"] - 1.0
    return out


def summarize_boolean_metric(year: str | int, metric: str, frame: pd.DataFrame) -> list[dict]:
    rows: list[dict] = []
    for flag, label in [(True, "true"), (False, "false")]:
        grp = frame[frame[metric].fillna(False) == flag]
        rows.append(
            {
                "year": year,
                "metric": metric,
                "group": label,
                "n": int(len(grp)),
                "share": float(len(grp) / len(frame)) if len(frame) else None,
                "adj_max_high_ret_30d_mean": float(grp["adj_max_high_ret_30d"].mean()) if len(grp) else None,
                "adj_close_ret_30d_mean": float(grp["adj_close_ret_30d"].mean()) if len(grp) else None,
                "big_meat_30d_rate": float(grp["big_meat_30d"].mean()) if len(grp) else None,
                "junk_30d_rate": float(grp["junk_30d"].mean()) if len(grp) else None,
                "washout_10d_rate": float(grp["washout_10d"].mean()) if len(grp) else None,
            }
        )
    return rows


def summarize_quantiles(year: str | int, metric: str, frame: pd.DataFrame) -> list[dict]:
    valid = frame[[metric, "adj_max_high_ret_30d", "adj_close_ret_30d", "big_meat_30d", "junk_30d", "washout_10d"]].dropna(subset=[metric])
    if len(valid) < 20:
        return []
    labels = ["Q1_low", "Q2", "Q3", "Q4_high"]
    buckets = pd.qcut(valid[metric], 4, labels=labels, duplicates="drop")
    rows: list[dict] = []
    for bucket, grp in valid.groupby(buckets):
        rows.append(
            {
                "year": year,
                "metric": metric,
                "bucket": str(bucket),
                "n": int(len(grp)),
                "adj_max_high_ret_30d_mean": float(grp["adj_max_high_ret_30d"].mean()),
                "adj_close_ret_30d_mean": float(grp["adj_close_ret_30d"].mean()),
                "big_meat_30d_rate": float(grp["big_meat_30d"].mean()),
                "junk_30d_rate": float(grp["junk_30d"].mean()),
                "washout_10d_rate": float(grp["washout_10d"].mean()),
            }
        )
    return rows


def correlation_rows(year: str | int, frame: pd.DataFrame) -> list[dict]:
    rows: list[dict] = []
    for metric in [*BOOL_METRICS, *CONT_METRICS]:
        metric_series = pd.to_numeric(frame[metric], errors="coerce")
        for target in RETURN_TARGETS:
            data = pd.DataFrame({"metric": metric_series, "target": pd.to_numeric(frame[target], errors="coerce")}).dropna()
            if len(data) < 20:
                continue
            rows.append(
                {
                    "year": year,
                    "metric": metric,
                    "target": target,
                    "n": int(len(data)),
                    "pearson": float(data["metric"].corr(data["target"], method="pearson")),
                    "spearman": float(data["metric"].corr(data["target"], method="spearman")),
                }
            )
    return rows


def load_signals(year: int) -> pd.DataFrame:
    events = pd.read_csv(RUN_DIRS[year] / "events.csv", dtype={"symbol": str})
    events["symbol"] = events["symbol"].astype(str).str.zfill(6)
    events = events[(events["side"] == "long") & (events["event_type"] == "trend_spear")].copy()
    plans = events["entry_plan"].map(parse_plan)
    events["gate_price"] = plans.map(lambda x: float(x.get("gate_price", 0.0) or 0.0))
    return events


def score_signal_frame(year: int, signals: pd.DataFrame, metrics: pd.DataFrame) -> tuple[pd.DataFrame, list[dict], list[dict], list[dict]]:
    if signals.empty:
        return pd.DataFrame(), [], [], []
    merged = signals.merge(metrics, on=["date", "symbol"], how="inner")
    merged["entry_ref_price"] = merged[["close", "gate_price"]].max(axis=1)

    for horizon in [10, 20, 30]:
        future_close = merged["close"] * (1.0 + merged[f"close_ret_{horizon}d"])
        future_high = merged["close"] * (1.0 + merged[f"max_high_ret_{horizon}d"])
        merged[f"adj_close_ret_{horizon}d"] = future_close / merged["entry_ref_price"] - 1.0
        merged[f"adj_max_high_ret_{horizon}d"] = future_high / merged["entry_ref_price"] - 1.0

    merged["big_meat_30d"] = merged["adj_max_high_ret_30d"] >= 0.20
    merged["junk_30d"] = merged["adj_max_high_ret_30d"] < 0.08
    merged["washout_10d"] = merged["adj_close_ret_10d"] <= -0.08
    merged["year"] = year

    group_rows: list[dict] = []
    for metric in BOOL_METRICS:
        group_rows.extend(summarize_boolean_metric(year, metric, merged))

    quantile_rows: list[dict] = []
    for metric in CONT_METRICS:
        quantile_rows.extend(summarize_quantiles(year, metric, merged))

    corr_rows = correlation_rows(year, merged)
    return merged, corr_rows, group_rows, quantile_rows


def summarize_top_findings(corr_df: pd.DataFrame, group_df: pd.DataFrame) -> str:
    lines = [
        "# Trend Spear 01/03 Metrics",
        "",
        "## Strongest Spearman Links",
    ]
    if corr_df.empty:
        lines.append("- no correlation rows generated")
    else:
        all_corr = corr_df[corr_df["year"].astype(str) == "all"] if "all" in set(corr_df["year"].astype(str)) else corr_df
        top_corr = all_corr.reindex(all_corr["spearman"].abs().sort_values(ascending=False).index).head(8)
        for _, row in top_corr.iterrows():
            lines.append(
                f"- `{row['metric']}` vs `{row['target']}`: spearman={row['spearman']:.4f}, pearson={row['pearson']:.4f}, n={int(row['n'])}"
            )

    lines.extend(["", "## Boolean Metric Lift"])
    if group_df.empty:
        lines.append("- no boolean group rows generated")
    else:
        all_groups = group_df[group_df["year"].astype(str) == "all"] if "all" in set(group_df["year"].astype(str)) else group_df
        pivot = (
            all_groups[all_groups["group"].isin(["true", "false"])]
            .pivot(index="metric", columns="group", values=["adj_max_high_ret_30d_mean", "big_meat_30d_rate", "junk_30d_rate", "washout_10d_rate"])
        )
        if not pivot.empty:
            for metric in pivot.index:
                try:
                    true_mfe = pivot.loc[metric, ("adj_max_high_ret_30d_mean", "true")]
                    false_mfe = pivot.loc[metric, ("adj_max_high_ret_30d_mean", "false")]
                    true_big = pivot.loc[metric, ("big_meat_30d_rate", "true")]
                    false_big = pivot.loc[metric, ("big_meat_30d_rate", "false")]
                    true_junk = pivot.loc[metric, ("junk_30d_rate", "true")]
                    false_junk = pivot.loc[metric, ("junk_30d_rate", "false")]
                    lines.append(
                        f"- `{metric}`: max_high_30d {true_mfe:.4f} vs {false_mfe:.4f}, big_meat {true_big:.4f} vs {false_big:.4f}, junk {true_junk:.4f} vs {false_junk:.4f}"
                    )
                except Exception:
                    continue
    return "\n".join(lines) + "\n"


def main() -> None:
    OUT_DIR.mkdir(parents=True, exist_ok=True)

    signals_by_year = {year: load_signals(year) for year in YEARS}
    all_signal_symbols = sorted({sym for df in signals_by_year.values() for sym in df["symbol"].unique()})

    adapter = V4DataAdapter(cache_dir="./cache", count=1400, cache_only=False)
    metric_frames: list[pd.DataFrame] = []
    for idx, symbol in enumerate(all_signal_symbols, start=1):
        frame = prepare_symbol_frame(adapter, symbol, end="2026-03-31")
        if frame.empty:
            continue
        metric_frames.append(build_forward_metrics(frame))
        if idx % 50 == 0:
            print(f"[doc-metrics] prepared {idx}/{len(all_signal_symbols)} symbols", flush=True)

    metrics = pd.concat(metric_frames, ignore_index=True) if metric_frames else pd.DataFrame()
    metrics = metrics[metrics["date"] >= "2022-01-01"].copy() if not metrics.empty else metrics

    raw_frames: list[pd.DataFrame] = []
    corr_rows: list[dict] = []
    group_rows: list[dict] = []
    quantile_rows: list[dict] = []

    for year in YEARS:
        year_metrics = metrics[metrics["date"].str.startswith(str(year))].copy() if not metrics.empty else pd.DataFrame()
        merged, year_corr, year_groups, year_quantiles = score_signal_frame(year, signals_by_year[year], year_metrics)
        if not merged.empty:
            raw_frames.append(merged)
        corr_rows.extend(year_corr)
        group_rows.extend(year_groups)
        quantile_rows.extend(year_quantiles)

    all_signals = pd.concat(raw_frames, ignore_index=True) if raw_frames else pd.DataFrame()
    if not all_signals.empty:
        corr_rows.extend(correlation_rows("all", all_signals))
        for metric in BOOL_METRICS:
            group_rows.extend(summarize_boolean_metric("all", metric, all_signals))
        for metric in CONT_METRICS:
            quantile_rows.extend(summarize_quantiles("all", metric, all_signals))

    corr_df = pd.DataFrame(corr_rows)
    group_df = pd.DataFrame(group_rows)
    quant_df = pd.DataFrame(quantile_rows)

    all_signals.to_csv(OUT_DIR / "trend_spear_doc_metrics_signal_potential.csv", index=False)
    corr_df.to_csv(OUT_DIR / "metric_correlations.csv", index=False)
    group_df.to_csv(OUT_DIR / "metric_group_summary.csv", index=False)
    quant_df.to_csv(OUT_DIR / "metric_quantiles.csv", index=False)
    (OUT_DIR / "summary.md").write_text(summarize_top_findings(corr_df, group_df), encoding="utf-8")

    print(f"wrote analysis to {OUT_DIR}")
    print(f"signals={len(all_signals)} corr_rows={len(corr_df)} group_rows={len(group_df)} quant_rows={len(quant_df)}")


if __name__ == "__main__":
    main()
