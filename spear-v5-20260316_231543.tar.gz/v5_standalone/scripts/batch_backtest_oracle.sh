#!/usr/bin/env bash
#
# Batch backtest for oracle regeneration: 7 years × 50-150cyc pool
# Run from v5_standalone/: bash scripts/batch_backtest_oracle.sh
#
# After completion, run:
#   python scripts/extend_signal_csv.py --from-backtests
#   python scripts/regenerate_oracle.py
#
set -euo pipefail
cd "$(dirname "$0")/.."

# Activate virtualenv
VENV_DIR="$(cd .. && pwd)/.venv"
if [ -f "$VENV_DIR/bin/activate" ]; then
    source "$VENV_DIR/bin/activate"
    echo "Using Python: $(which python3)"
fi

POOL_NAME="50-150cyc"
POOL_SIZE=832
WARMUP=600
PROFILE="delayed_limit_hunt"

YEARS=(2019 2020 2021 2022 2023 2024 2025)

echo "=== Oracle Batch Backtest ==="
echo "Pool: $POOL_NAME ($POOL_SIZE symbols)"
echo "Years: ${YEARS[*]}"
echo "Config: warmup=$WARMUP, profile=$PROFILE, disable_env=True"
echo ""

for YEAR in "${YEARS[@]}"; do
    OUTDIR="$(pwd)/outputs/backtests/oracle_${YEAR}_50-150cyc_dlh"
    echo "────────────────────────────────────────"
    echo "[$(date +%H:%M:%S)] Starting $YEAR -> $OUTDIR"
    echo "────────────────────────────────────────"

    python3 v5/run.py \
        --start "${YEAR}-01-01" \
        --end "${YEAR}-12-31" \
        --pool-name "$POOL_NAME" \
        --pool "$POOL_SIZE" \
        --pool-sampling head \
        --pool-seed 42 \
        --execution-profile "$PROFILE" \
        --warmup-bars "$WARMUP" \
        --disable-env-mapping \
        --max-positions 8 \
        --base-pos-pct 0.25 \
        --output-dir "$OUTDIR"

    echo "[$(date +%H:%M:%S)] $YEAR done."
    echo ""
done

echo "=== All backtests complete ==="
echo ""
echo "Next steps:"
echo "  1. Update YEAR_BACKTEST_MAP in scripts/extend_signal_csv.py with the new directories"
echo "  2. python scripts/extend_signal_csv.py"
echo "  3. python scripts/regenerate_oracle.py"
