"""
Multi-axis config sweep: TP, stop/grace, hunt window, cooldown, trend mgmt, pos sizing.
Shares one prepare_bundle across all runs for efficiency.
Usage: python -m scripts.sweep_configs [year]
"""
from __future__ import annotations

import copy
import itertools
import sys
import time
from dataclasses import dataclass
from typing import Any

from v5.backtest.prepare import prepare_bundle
from v5.backtest.runner import run_backtest
from v5.config.defaults import V5Config, load_default_config, apply_execution_profile
from v5.config.pools import resolve_named_pool
from v5.data.store import MarketStore


@dataclass
class Axis:
    name: str
    param_path: str          # dot-separated: "execution.default_take_profit_pct"
    values: list[Any]
    label_fn: Any = None     # optional formatter


AXES: list[Axis] = [
    Axis("take_profit", "execution.default_take_profit_pct",
         [0.10, 0.15, 0.18, 0.22, 0.30, 999.0],
         lambda v: "no_tp" if v > 1 else f"tp{int(v*100)}"),
    Axis("stop_grace", "execution.trend_spear_stop_grace_days",
         [0, 2, 3, 5],
         lambda v: f"grace{v}d"),
    Axis("hunt_window", "execution.hunt_window_days",
         [1, 3, 5],
         lambda v: f"hunt{v}d"),
    Axis("cooldown", "execution.cooldown_days",
         [0, 2, 3, 5],
         lambda v: f"cd{v}d"),
    Axis("trend_mgmt", "execution.trend_spear_trend_management_enabled",
         [False, True],
         lambda v: "tmON" if v else "tmOFF"),
    Axis("max_pos", "execution.max_positions",
         [10, 20, 30],
         lambda v: f"mp{v}"),
    Axis("base_pct", "execution.base_pos_pct",
         [0.15, 0.25, 0.33],
         lambda v: f"bp{int(v*100)}"),
]


BEST_MULTIPLIERS = {
    "trend_spear": 1.5, "post_limit": 0.0, "failed_board": 0.0,
    "youzi": 0.0, "sector_spear": 0.0, "attack": 0.6, "arb": 0.0,
}

BASELINE_CFG: dict[str, Any] = {
    "execution.max_positions": 20,
    "execution.base_pos_pct": 0.25,
    "execution.default_take_profit_pct": 0.18,
    "execution.cooldown_days": 3,
    "execution.hunt_window_days": 3,
    "execution.hunt_price_buffer_pct": 0.005,
    "execution.exit_hunt_buffer_pct": 0.005,
    "execution.exit_hunt_window_days": 3,
    "execution.trend_spear_stop_grace_days": 3,
    "execution.trend_spear_stop_mode": "intraday",
    "execution.trend_spear_trend_management_enabled": False,
    "execution.trend_spear_trend_activation_ret": 0.20,
    "execution.trend_spear_trend_drawdown_exit": 0.12,
    "execution.trend_spear_trend_stale_days": 3,
    "execution.trend_spear_trend_max_extension_days": 10,
}


def _set_param(cfg: V5Config, path: str, value: Any) -> None:
    parts = path.split(".")
    obj: Any = cfg
    for p in parts[:-1]:
        obj = getattr(obj, p)
    setattr(obj, parts[-1], value)


def _apply_multipliers(cfg: V5Config, mults: dict[str, float]) -> None:
    cfg.execution.trend_spear_pos_mult = mults["trend_spear"]
    cfg.execution.post_limit_pos_mult = mults["post_limit"]
    cfg.execution.failed_board_pos_mult = mults["failed_board"]
    cfg.execution.youzi_pos_mult = mults["youzi"]
    cfg.execution.sector_spear_pos_mult = mults["sector_spear"]
    cfg.execution.attack_pos_mult = mults["attack"]
    cfg.execution.arb_pos_mult = mults["arb"]


def _make_cfg() -> V5Config:
    cfg = load_default_config()
    apply_execution_profile(cfg, "delayed_limit_hunt")
    cfg.data.disable_env_mapping = True
    for path, val in BASELINE_CFG.items():
        _set_param(cfg, path, val)
    _apply_multipliers(cfg, BEST_MULTIPLIERS)
    return cfg


def _run_one(cfg: V5Config, year: str, symbols: list[str], bundle, store) -> dict:
    arts = run_backtest(
        cfg=cfg, start=f"{year}-01-01", end=f"{year}-12-31",
        pool_size=len(symbols), initial_cash=1_000_000.0,
        symbols=symbols, bundle=bundle, store=store,
    )
    return arts.result.summary


def main() -> None:
    year = sys.argv[1] if len(sys.argv) > 1 else "2025"

    cfg = _make_cfg()
    store = MarketStore("cache/market.duckdb")
    symbols = resolve_named_pool("50-150cyc")
    print(f"Pool: {len(symbols)} | Year: {year}\n")

    bundle = prepare_bundle(
        cfg, start=f"{year}-01-01", end=f"{year}-12-31",
        pool_size=len(symbols), symbols=symbols, store=store,
    )

    # --- Phase 1: one-axis-at-a-time sweeps (each axis vs baseline) ---
    print("=" * 100)
    print("PHASE 1: One-axis sweeps (varying one param, others at baseline)")
    print("=" * 100)

    baseline_s = _run_one(_make_cfg(), year, symbols, bundle, store)
    baseline_ret = baseline_s["equity_return_pct"]
    print(f"\n  BASELINE: ret={baseline_ret:>+7.1f}%  equity={baseline_s['equity_final']:>12,.0f}  trades={baseline_s['trade_count']}")
    print()

    axis_results: dict[str, list[tuple[str, float, dict]]] = {}
    best_per_axis: dict[str, tuple[Any, float]] = {}

    for axis in AXES:
        print(f"--- {axis.name} ---")
        results: list[tuple[str, float, dict]] = []
        for val in axis.values:
            cfg_i = _make_cfg()
            _set_param(cfg_i, axis.param_path, val)
            s = _run_one(cfg_i, year, symbols, bundle, store)
            label = axis.label_fn(val) if axis.label_fn else str(val)
            ret = s["equity_return_pct"]
            delta = ret - baseline_ret
            marker = " <-- baseline" if abs(delta) < 0.05 else ""
            print(f"  {label:<12} ret={ret:>+7.1f}%  Δ={delta:>+6.1f}%  equity={s['equity_final']:>12,.0f}  trades={s['trade_count']}{marker}")
            results.append((label, ret, s))
        best = max(results, key=lambda x: x[1])
        best_per_axis[axis.name] = (
            axis.values[next(i for i, r in enumerate(results) if r[0] == best[0])],
            best[1],
        )
        axis_results[axis.name] = results
        print(f"  >> best: {best[0]} ({best[1]:+.1f}%)\n")

    # --- Phase 2: combine best settings from each axis ---
    print("=" * 100)
    print("PHASE 2: Combined best from each axis")
    print("=" * 100)

    cfg_combined = _make_cfg()
    combo_desc = []
    for axis in AXES:
        best_val, best_ret = best_per_axis[axis.name]
        _set_param(cfg_combined, axis.param_path, best_val)
        label = axis.label_fn(best_val) if axis.label_fn else str(best_val)
        combo_desc.append(f"{axis.name}={label}")

    s_combined = _run_one(cfg_combined, year, symbols, bundle, store)
    print(f"\n  Combined: {' | '.join(combo_desc)}")
    print(f"  ret={s_combined['equity_return_pct']:>+7.1f}%  equity={s_combined['equity_final']:>12,.0f}  trades={s_combined['trade_count']}")
    print(f"  vs baseline: Δ={s_combined['equity_return_pct'] - baseline_ret:>+6.1f}%")

    # --- Phase 3: test a few hand-crafted combos ---
    print(f"\n{'=' * 100}")
    print("PHASE 3: Hand-crafted combo configs")
    print("=" * 100)

    COMBOS: dict[str, dict[str, Any]] = {
        "aggressive": {
            "execution.default_take_profit_pct": 999.0,
            "execution.max_positions": 20,
            "execution.base_pos_pct": 0.25,
            "execution.cooldown_days": 0,
            "execution.hunt_window_days": 3,
            "execution.trend_spear_stop_grace_days": 5,
            "execution.trend_spear_trend_management_enabled": True,
            "execution.trend_spear_trend_activation_ret": 0.15,
            "execution.trend_spear_trend_drawdown_exit": 0.10,
            "execution.trend_spear_trend_max_extension_days": 15,
        },
        "let_winners_run": {
            "execution.default_take_profit_pct": 0.30,
            "execution.max_positions": 20,
            "execution.base_pos_pct": 0.25,
            "execution.cooldown_days": 2,
            "execution.hunt_window_days": 3,
            "execution.trend_spear_stop_grace_days": 3,
            "execution.trend_spear_trend_management_enabled": True,
            "execution.trend_spear_trend_activation_ret": 0.20,
            "execution.trend_spear_trend_drawdown_exit": 0.12,
            "execution.trend_spear_trend_max_extension_days": 10,
        },
        "tight_tp_fast": {
            "execution.default_take_profit_pct": 0.10,
            "execution.max_positions": 30,
            "execution.base_pos_pct": 0.15,
            "execution.cooldown_days": 0,
            "execution.hunt_window_days": 1,
            "execution.trend_spear_stop_grace_days": 2,
            "execution.trend_spear_trend_management_enabled": False,
        },
        "concentrated_patient": {
            "execution.default_take_profit_pct": 0.22,
            "execution.max_positions": 10,
            "execution.base_pos_pct": 0.33,
            "execution.cooldown_days": 5,
            "execution.hunt_window_days": 5,
            "execution.trend_spear_stop_grace_days": 5,
            "execution.trend_spear_trend_management_enabled": True,
            "execution.trend_spear_trend_activation_ret": 0.20,
            "execution.trend_spear_trend_drawdown_exit": 0.10,
            "execution.trend_spear_trend_max_extension_days": 15,
        },
        "no_tp_trend_ride": {
            "execution.default_take_profit_pct": 999.0,
            "execution.max_positions": 20,
            "execution.base_pos_pct": 0.25,
            "execution.cooldown_days": 2,
            "execution.hunt_window_days": 3,
            "execution.trend_spear_stop_grace_days": 3,
            "execution.trend_spear_trend_management_enabled": True,
            "execution.trend_spear_trend_activation_ret": 0.15,
            "execution.trend_spear_trend_drawdown_exit": 0.08,
            "execution.trend_spear_trend_max_extension_days": 20,
        },
        "wide_tp_conservative": {
            "execution.default_take_profit_pct": 0.30,
            "execution.max_positions": 15,
            "execution.base_pos_pct": 0.20,
            "execution.cooldown_days": 3,
            "execution.hunt_window_days": 3,
            "execution.trend_spear_stop_grace_days": 5,
            "execution.trend_spear_trend_management_enabled": False,
        },
    }

    combo_results = [("baseline", baseline_ret, baseline_s)]
    for name, overrides in COMBOS.items():
        cfg_c = _make_cfg()
        for path, val in overrides.items():
            _set_param(cfg_c, path, val)
        s = _run_one(cfg_c, year, symbols, bundle, store)
        ret = s["equity_return_pct"]
        delta = ret - baseline_ret
        combo_results.append((name, ret, s))
        print(f"  {name:<28} ret={ret:>+7.1f}%  Δ={delta:>+6.1f}%  equity={s['equity_final']:>12,.0f}  trades={s['trade_count']}")

    combo_results.append(("combined_best", s_combined["equity_return_pct"], s_combined))

    print(f"\n{'=' * 100}")
    print("FINAL RANKING")
    print("=" * 100)
    for name, ret, s in sorted(combo_results, key=lambda x: -x[1]):
        print(f"  {name:<28} {ret:>+7.1f}%   equity={s['equity_final']:>12,.0f}   trades={s['trade_count']}   fees={s['total_fees']:>8,.0f}")


if __name__ == "__main__":
    main()
