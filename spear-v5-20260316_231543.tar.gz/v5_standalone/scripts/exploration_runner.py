#!/usr/bin/env python3
"""Broad permutation scanner for trend_spear exit and recovery research.

This runner is intentionally research-oriented:
1. Load multiple backtest runs into one wide table.
2. Build exit-time features from closed trades plus holding-path aggregates.
3. Define multiple post-exit targets.
4. Scan variable-arity predicate combinations across regimes/segments.
5. Separate stable facts, LEGO-style combos, and regime-specific patterns.
"""
from __future__ import annotations

import argparse
import itertools
import json
import math
import os
import re
import sys
from collections import defaultdict
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
os.chdir(ROOT)
sys.path.insert(0, str(ROOT))


DEFAULT_RUN_GLOB = "ts_obs_20260313_*"
DEFAULT_ENTRY_REASON = "entry:trend_spear"
DEFAULT_SEGMENT_LEVELS = (
    (),
    ("exit_reason",),
    ("year",),
    ("stop_mode",),
    ("exit_reason", "year"),
    ("exit_reason", "stop_mode"),
)


@dataclass(frozen=True)
class SegmentSpec:
    cols: tuple[str, ...]
    values: tuple[str, ...]

    @property
    def name(self) -> str:
        if not self.cols:
            return "all"
        return "|".join(f"{col}={value}" for col, value in zip(self.cols, self.values))


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Explore exit/recovery permutations from wide observability tables.")
    parser.add_argument("--run-glob", default=DEFAULT_RUN_GLOB, help="Glob under outputs/backtests used to discover runs.")
    parser.add_argument("--entry-reason", default=DEFAULT_ENTRY_REASON, help="Only keep trades with this entry reason.")
    parser.add_argument("--exit-reasons", nargs="*", default=["time_exit", "stop_loss"], help="Optional exit reason filter.")
    parser.add_argument("--max-arity", type=int, default=4, help="Maximum predicate combination order to scan.")
    parser.add_argument("--min-support", type=int, default=15, help="Minimum rows required for a combo.")
    parser.add_argument("--min-segment-rows", type=int, default=60, help="Skip combo scans for smaller segments.")
    parser.add_argument("--top-k", type=int, default=20, help="Top rows to keep per segment/target/arity summary.")
    parser.add_argument("--max-features", type=int, default=42, help="Keep at most this many predicate legs after univariate prescreen.")
    parser.add_argument("--with-path-features", action="store_true", default=True, help="Aggregate holding-path features from position_marks.")
    parser.add_argument("--without-path-features", dest="with_path_features", action="store_false")
    parser.add_argument("--out-dir", default="", help="Optional output directory. Defaults to a timestamped research folder.")
    return parser.parse_args()


def safe_num(frame: pd.DataFrame, column: str, default: float = np.nan) -> pd.Series:
    if column not in frame.columns:
        return pd.Series(default, index=frame.index, dtype="float64")
    return pd.to_numeric(frame[column], errors="coerce")


def safe_bool(frame: pd.DataFrame, column: str) -> pd.Series:
    if column not in frame.columns:
        return pd.Series(False, index=frame.index, dtype=bool)
    series = frame[column]
    if pd.api.types.is_bool_dtype(series):
        return series.fillna(False).astype(bool)
    normalized = series.fillna("").astype(str).str.strip().str.lower()
    return normalized.isin({"1", "true", "t", "yes", "y"})


def safe_text(frame: pd.DataFrame, column: str, default: str = "") -> pd.Series:
    if column not in frame.columns:
        return pd.Series(default, index=frame.index, dtype="object")
    return frame[column].fillna(default).astype(str)


def coalesce_num(frame: pd.DataFrame, columns: list[str], default: float = np.nan) -> pd.Series:
    out = pd.Series(default, index=frame.index, dtype="float64")
    for column in columns:
        values = safe_num(frame, column, default=np.nan)
        out = out.where(out.notna(), values)
    return out


def coalesce_bool(frame: pd.DataFrame, columns: list[str]) -> pd.Series:
    out = pd.Series(False, index=frame.index, dtype=bool)
    for column in columns:
        out = out | safe_bool(frame, column)
    return out


def coalesce_text(frame: pd.DataFrame, columns: list[str], default: str = "") -> pd.Series:
    out = pd.Series(default, index=frame.index, dtype="object")
    for column in columns:
        values = safe_text(frame, column, default=default)
        mask = out.eq(default) & values.ne(default)
        out.loc[mask] = values.loc[mask]
    return out


def parse_run_name(run_name: str) -> dict[str, str]:
    parts = run_name.split("_")
    meta: dict[str, str] = {"run_name": run_name, "year": "", "stop_mode": "", "profile": ""}
    for token in parts:
        if re.fullmatch(r"20\d{2}", token):
            meta["year"] = token
    if len(parts) >= 2:
        meta["stop_mode"] = parts[-1]
    for token in parts:
        if token in {"dlh", "dli", "delayed", "ideal"}:
            meta["profile"] = token
    return meta


def load_run_metadata(run_dir: Path) -> dict[str, str]:
    meta = parse_run_name(run_dir.name)
    meta_file = run_dir / "meta.json"
    if meta_file.exists():
        try:
            payload = json.loads(meta_file.read_text(encoding="utf-8"))
            cfg = payload.get("config", {})
            meta["profile"] = str(cfg.get("execution_profile") or meta.get("profile") or "")
            stop_mode = cfg.get("trend_spear_stop_mode")
            if stop_mode:
                grace_days = int(cfg.get("trend_spear_stop_grace_days", 0) or 0)
                meta["stop_mode"] = f"grace{grace_days}" if stop_mode == "grace_close" else str(stop_mode).replace("_confirm", "")
            start = str(cfg.get("start", ""))
            if re.match(r"20\d{2}-", start):
                meta["year"] = start[:4]
        except Exception:
            pass
    if meta["stop_mode"] == "close":
        meta["stop_mode"] = "close"
    if meta["stop_mode"] == "intraday":
        meta["stop_mode"] = "intraday"
    return meta


def summarize_path(group: pd.DataFrame) -> pd.Series:
    ordered = group.sort_values(["date", "holding_days"]).reset_index(drop=True)
    peak_idx = int(ordered["peak_ret"].astype(float).fillna(-np.inf).idxmax()) if not ordered.empty else 0
    return pd.Series(
        {
            "path_obs_days": int(len(ordered)),
            "path_peak_ret_max": float(safe_num(ordered, "peak_ret").max()),
            "path_high_ret_max": float(safe_num(ordered, "high_ret").max()),
            "path_close_ret_max": float(safe_num(ordered, "close_ret").max()),
            "path_low_ret_min": float(safe_num(ordered, "low_ret").min()),
            "path_drawdown_from_peak_max": float(safe_num(ordered, "drawdown_from_peak").max()),
            "path_intraday_drawdown_from_peak_max": float(safe_num(ordered, "intraday_drawdown_from_peak").max()),
            "path_close_vs_stop_min": float(safe_num(ordered, "close_vs_stop_pct").min()),
            "path_limit_up_days": int(safe_bool(ordered, "day_is_limit_up_close").sum()),
            "path_touch_limit_up_days": int(safe_bool(ordered, "day_touch_limit_up").sum()),
            "path_amount_explosive_days": int(safe_bool(ordered, "day_is_amount_explosive").sum()),
            "path_amount_confirm_days": int(safe_bool(ordered, "day_is_amount_confirm").sum()),
            "path_near_support_days": int(safe_bool(ordered, "day_near_release_support").sum()),
            "path_near_pressure_days": int(safe_bool(ordered, "day_near_peak_pressure").sum()),
            "path_above_ma20_days": int((safe_num(ordered, "day_close_vs_ma20_pct") > 0).sum()),
            "path_above_vwap_days": int((safe_num(ordered, "day_close_vs_anchored_vwap_pct") > 0).sum()),
            "path_close_pos_high_days": int((safe_num(ordered, "day_close_pos") >= 0.7).sum()),
            "path_peak_reached_day": int(safe_num(ordered, "holding_days").iloc[peak_idx]) if not ordered.empty else 0,
        }
    )


def aggregate_path_features(run_dir: Path) -> pd.DataFrame:
    position_marks_path = run_dir / "position_marks.csv"
    if not position_marks_path.exists():
        return pd.DataFrame()
    marks = pd.read_csv(position_marks_path)
    if marks.empty:
        return pd.DataFrame()
    marks["source_event"] = coalesce_text(
        marks,
        ["source_event", "signal_event_type"],
        default="",
    )
    group_cols = ["symbol", "entry_date", "signal_date", "source_event"]
    grouped = marks.groupby(group_cols, dropna=False, sort=False)
    return grouped.apply(summarize_path).reset_index()


def enrich_trade_features(frame: pd.DataFrame) -> pd.DataFrame:
    out = frame.copy()
    derived: dict[str, pd.Series] = {}
    derived["source_event"] = safe_text(out, "entry_reason").str.replace("entry:", "", regex=False)
    derived["signal_confidence"] = coalesce_num(out, ["entry_meta.signal_confidence", "exit_meta.signal_confidence"])
    derived["signal_peer_confirmation"] = coalesce_num(out, ["entry_meta.signal_peer_confirmation", "exit_meta.signal_peer_confirmation"], default=0.0)
    derived["signal_leader_strength"] = coalesce_num(out, ["entry_meta.signal_leader_strength", "exit_meta.signal_leader_strength"], default=0.0)
    derived["signal_multi_spear_count"] = coalesce_num(out, ["entry_meta.signal_multi_spear_count", "exit_meta.signal_multi_spear_count"], default=0.0)
    derived["signal_limit_gap"] = coalesce_num(out, ["entry_meta.signal_limit_gap", "exit_meta.signal_limit_gap"], default=0.0)
    derived["signal_dense_gate"] = coalesce_num(out, ["entry_meta.signal_dense_gate", "exit_meta.signal_dense_gate"])
    derived["signal_entry_gate_price"] = coalesce_num(out, ["entry_meta.signal_entry_gate_price", "exit_meta.signal_entry_gate_price"])
    derived["signal_invalidation_price"] = coalesce_num(out, ["entry_meta.signal_invalidation_price", "exit_meta.signal_invalidation_price"])
    derived["signal_prior_limit_amount"] = coalesce_num(out, ["entry_meta.signal_prior_limit_amount", "exit_meta.signal_prior_limit_amount"])
    derived["signal_atr_at_entry"] = coalesce_num(out, ["entry_meta.signal_context.atr_at_entry", "exit_meta.signal_context.atr_at_entry"])
    derived["signal_sector_hot"] = coalesce_bool(out, ["entry_meta.signal_sector_hot", "exit_meta.signal_sector_hot"])
    derived["signal_lhb_net_sell"] = coalesce_bool(out, ["entry_meta.signal_lhb_net_sell", "exit_meta.signal_lhb_net_sell"])
    derived["signal_relative_limit_volume_ok"] = coalesce_bool(out, ["entry_meta.signal_relative_limit_volume_ok", "exit_meta.signal_relative_limit_volume_ok"])
    derived["signal_three_gun_pattern"] = coalesce_text(out, ["entry_meta.signal_three_gun_pattern", "exit_meta.signal_three_gun_pattern"])
    derived["signal_spear_role"] = coalesce_text(out, ["entry_meta.signal_spear_role", "exit_meta.signal_spear_role"])
    derived["signal_structure_mode"] = coalesce_text(out, ["entry_meta.signal_structure_mode", "exit_meta.signal_structure_mode"])
    derived["signal_stop_gap_pct"] = (
        (derived["signal_entry_gate_price"] - derived["signal_invalidation_price"]) / derived["signal_entry_gate_price"]
    ).replace([np.inf, -np.inf], np.nan)

    derived["exit_drawdown_from_peak"] = coalesce_num(out, ["exit_meta.drawdown_from_peak"], default=0.0)
    derived["exit_intraday_drawdown_from_peak"] = coalesce_num(out, ["exit_meta.intraday_drawdown_from_peak"], default=0.0)
    derived["exit_peak_ret"] = coalesce_num(out, ["exit_meta.peak_ret", "mfe"], default=0.0)
    derived["exit_peak_gap"] = (safe_num(out, "mfe", default=np.nan) - safe_num(out, "ret", default=np.nan)).replace([np.inf, -np.inf], np.nan)
    derived["exit_had_limit_up_close"] = coalesce_bool(out, ["exit_meta.had_limit_up_close"])
    derived["exit_limit_up_close_days"] = coalesce_num(out, ["exit_meta.limit_up_close_days"], default=0.0)
    derived["exit_close_vs_stop_pct"] = coalesce_num(out, ["exit_meta.close_vs_stop_pct", "exit_stop_buffer_close_pct"])
    derived["exit_low_vs_stop_pct"] = coalesce_num(out, ["exit_meta.low_vs_stop_pct", "exit_stop_buffer_low_pct"])
    derived["exit_hold_days"] = coalesce_num(out, ["hold_days", "exit_meta.holding_days"], default=0.0)
    derived["exit_close_pos_norm"] = coalesce_num(out, ["exit_close_pos", "exit_meta.day_close_pos"])
    derived["exit_upper_shadow_pct_norm"] = coalesce_num(out, ["exit_upper_shadow_pct", "exit_meta.day_upper_shadow_pct"])
    derived["exit_amount_vs_prev20_med_norm"] = coalesce_num(out, ["exit_amount_vs_prev20_med"])
    derived["exit_volume_vs_prev20_med_norm"] = coalesce_num(out, ["exit_volume_vs_prev20_med"])
    derived["exit_amount_vs_hsm_norm"] = coalesce_num(out, ["exit_amount_vs_hsm", "exit_meta.day_amount_vs_hsm"])
    derived["exit_amount_vs_q95_norm"] = coalesce_num(out, ["exit_amount_vs_q95", "exit_meta.day_amount_vs_q95"])
    derived["exit_trend_up_norm"] = coalesce_bool(out, ["exit_trend_up", "exit_meta.day_trend_up"])
    derived["exit_near_support_norm"] = coalesce_bool(out, ["exit_near_release_support", "exit_meta.day_near_release_support"])
    derived["exit_near_pressure_norm"] = coalesce_bool(out, ["exit_near_peak_pressure", "exit_meta.day_near_peak_pressure"])
    derived["exit_touch_limit_up_norm"] = coalesce_bool(out, ["exit_touch_limit_up", "exit_meta.day_touch_limit_up"])
    derived["exit_failed_board_norm"] = coalesce_bool(out, ["exit_is_failed_board", "exit_meta.day_is_failed_board"])
    derived["exit_amount_explosive_norm"] = coalesce_bool(out, ["exit_meta.day_is_amount_explosive"])
    derived["exit_amount_confirm_norm"] = coalesce_bool(out, ["exit_meta.day_is_amount_confirm"])
    derived["exit_close_vs_ma20_pct_norm"] = coalesce_num(out, ["exit_close_vs_ma20_pct", "exit_meta.day_close_vs_ma20_pct"])
    derived["exit_close_vs_pressure_pct_norm"] = coalesce_num(out, ["exit_close_vs_pressure_pct", "exit_meta.day_close_vs_pressure_pct"])
    derived["exit_close_vs_release_pct_norm"] = coalesce_num(out, ["exit_close_vs_release_pct", "exit_meta.day_close_vs_release_pct"])
    derived["exit_days_since_peak_norm"] = coalesce_num(out, ["exit_days_since_peak"], default=np.nan)
    derived["exit_days_since_trough_norm"] = coalesce_num(out, ["exit_days_since_trough"], default=np.nan)
    derived["mfe_capture_norm"] = coalesce_num(out, ["mfe_capture"], default=np.nan)
    derived["mae_norm"] = coalesce_num(out, ["mae"], default=np.nan)
    derived["mfe_norm"] = coalesce_num(out, ["mfe"], default=np.nan)
    derived["ret_norm"] = coalesce_num(out, ["ret"], default=np.nan)

    if "path_obs_days" in out.columns:
        derived["path_above_ma20_ratio"] = safe_num(out, "path_above_ma20_days") / safe_num(out, "path_obs_days")
        derived["path_above_vwap_ratio"] = safe_num(out, "path_above_vwap_days") / safe_num(out, "path_obs_days")
        derived["path_close_pos_high_ratio"] = safe_num(out, "path_close_pos_high_days") / safe_num(out, "path_obs_days")
        derived["path_days_from_peak_to_exit"] = safe_num(out, "path_obs_days") - 1.0 - safe_num(out, "path_peak_reached_day")
    else:
        derived["path_above_ma20_ratio"] = pd.Series(np.nan, index=out.index)
        derived["path_above_vwap_ratio"] = pd.Series(np.nan, index=out.index)
        derived["path_close_pos_high_ratio"] = pd.Series(np.nan, index=out.index)
        derived["path_days_from_peak_to_exit"] = pd.Series(np.nan, index=out.index)

    derived_df = pd.DataFrame(derived, index=out.index)
    return pd.concat([out, derived_df], axis=1).copy()


def load_runs(args: argparse.Namespace) -> pd.DataFrame:
    root = ROOT / "outputs" / "backtests"
    run_dirs = sorted([p for p in root.glob(args.run_glob) if p.is_dir()])
    if not run_dirs:
        raise FileNotFoundError(f"No run directories matched {args.run_glob!r} under {root}")

    merged: list[pd.DataFrame] = []
    for run_dir in run_dirs:
        closed_path = run_dir / "closed_trades_flat.csv"
        if not closed_path.exists():
            continue
        trades = pd.read_csv(closed_path).copy()
        if trades.empty:
            continue
        meta = load_run_metadata(run_dir)
        trades = pd.concat(
            [
                trades,
                pd.DataFrame(
                    {
                        "run_name": run_dir.name,
                        "year": meta.get("year", ""),
                        "stop_mode": meta.get("stop_mode", ""),
                        "execution_profile": meta.get("profile", ""),
                        "source_event": safe_text(trades, "entry_reason").str.replace("entry:", "", regex=False),
                    },
                    index=trades.index,
                ),
            ],
            axis=1,
        ).copy()
        if args.with_path_features:
            path_df = aggregate_path_features(run_dir)
            if not path_df.empty:
                trades = trades.merge(
                    path_df,
                    on=["symbol", "entry_date", "signal_date", "source_event"],
                    how="left",
                )
        merged.append(trades)

    if not merged:
        raise RuntimeError("No closed_trades_flat.csv files could be loaded.")

    frame = pd.concat(merged, ignore_index=True)
    if args.entry_reason:
        frame = frame[frame["entry_reason"] == args.entry_reason].copy()
    if args.exit_reasons:
        frame = frame[frame["exit_reason"].isin(args.exit_reasons)].copy()
    frame["year"] = safe_text(frame, "year")
    frame["stop_mode"] = safe_text(frame, "stop_mode")
    return enrich_trade_features(frame.reset_index(drop=True))


def define_targets(frame: pd.DataFrame) -> dict[str, pd.Series]:
    targets: dict[str, pd.Series] = {
        "reclaim_entry_close_3d": safe_bool(frame, "post_exit_reclaim_entry_close_3d"),
        "reclaim_entry_high_5d": safe_bool(frame, "post_exit_reclaim_entry_high_5d"),
        "reclaim_gate_close_3d": safe_bool(frame, "post_exit_reclaim_gate_close_3d"),
        "reclaim_stop_close_3d": safe_bool(frame, "post_exit_reclaim_stop_close_3d"),
        "post5_high_ge_8": safe_num(frame, "post_exit_5d_high") >= 0.08,
        "post20_high_ge_15": safe_num(frame, "post_exit_20d_high") >= 0.15,
        "post20_high_ge_20": safe_num(frame, "post_exit_20d_high") >= 0.20,
        "post20_close_ge_5": safe_num(frame, "post_exit_20d_close") >= 0.05,
        "compound_fast_reclaim": safe_bool(frame, "post_exit_reclaim_entry_close_3d") & (safe_num(frame, "post_exit_20d_high") >= 0.15),
        "compound_stop_fakeout": safe_bool(frame, "post_exit_reclaim_stop_close_3d") & (safe_num(frame, "post_exit_10d_high") >= 0.10),
    }
    return {name: values.fillna(False).astype(bool) for name, values in targets.items()}


def define_predicates(frame: pd.DataFrame) -> dict[str, pd.Series]:
    predicates: dict[str, pd.Series] = {
        "regime_intraday": frame["stop_mode"].eq("intraday"),
        "regime_close": frame["stop_mode"].eq("close"),
        "regime_grace3": frame["stop_mode"].eq("grace3"),
        "year_2022": frame["year"].eq("2022"),
        "year_2024": frame["year"].eq("2024"),
        "year_2025": frame["year"].eq("2025"),
        "sig_conf_ge_078": safe_num(frame, "signal_confidence") >= 0.78,
        "sig_conf_ge_082": safe_num(frame, "signal_confidence") >= 0.82,
        "sig_conf_lt_074": safe_num(frame, "signal_confidence") < 0.74,
        "peer_ge_5": safe_num(frame, "signal_peer_confirmation") >= 5,
        "peer_ge_9": safe_num(frame, "signal_peer_confirmation") >= 9,
        "leader_ge_2": safe_num(frame, "signal_leader_strength") >= 2,
        "multi_spear_ge_3": safe_num(frame, "signal_multi_spear_count") >= 3,
        "signal_sector_hot": safe_bool(frame, "signal_sector_hot"),
        "signal_no_lhb_sell": ~safe_bool(frame, "signal_lhb_net_sell"),
        "signal_rel_limit_vol_ok": safe_bool(frame, "signal_relative_limit_volume_ok"),
        "signal_last_shrink": safe_text(frame, "signal_three_gun_pattern").eq("last_shrink"),
        "signal_progressive_expand": safe_text(frame, "signal_three_gun_pattern").eq("progressive_expand"),
        "signal_role_leader": safe_text(frame, "signal_spear_role").eq("leader"),
        "signal_structure_trend": safe_text(frame, "signal_structure_mode").eq("trend"),
        "signal_stop_gap_le_8": safe_num(frame, "signal_stop_gap_pct") <= 0.08,
        "signal_stop_gap_ge_12": safe_num(frame, "signal_stop_gap_pct") >= 0.12,
        "mfe_ge_20": safe_num(frame, "mfe_norm") >= 0.20,
        "mfe_ge_30": safe_num(frame, "mfe_norm") >= 0.30,
        "peak_gap_ge_10": safe_num(frame, "exit_peak_gap") >= 0.10,
        "peak_gap_le_5": safe_num(frame, "exit_peak_gap") <= 0.05,
        "mfe_capture_ge_70": safe_num(frame, "mfe_capture_norm") >= 0.70,
        "mfe_capture_lt_45": safe_num(frame, "mfe_capture_norm") < 0.45,
        "close_pos_high": safe_num(frame, "exit_close_pos_norm") >= 0.70,
        "close_pos_low": safe_num(frame, "exit_close_pos_norm") <= 0.35,
        "upper_shadow_ge_35": safe_num(frame, "exit_upper_shadow_pct_norm") >= 0.35,
        "amount_shrink_prev20": safe_num(frame, "exit_amount_vs_prev20_med_norm") <= 0.85,
        "amount_expand_prev20": safe_num(frame, "exit_amount_vs_prev20_med_norm") >= 1.50,
        "volume_shrink_prev20": safe_num(frame, "exit_volume_vs_prev20_med_norm") <= 0.85,
        "amount_vs_hsm_ge_15": safe_num(frame, "exit_amount_vs_hsm_norm") >= 1.50,
        "trend_up_exit": safe_bool(frame, "exit_trend_up_norm"),
        "near_support_exit": safe_bool(frame, "exit_near_support_norm"),
        "near_pressure_exit": safe_bool(frame, "exit_near_pressure_norm"),
        "touch_limit_up_exit": safe_bool(frame, "exit_touch_limit_up_norm"),
        "failed_board_exit": safe_bool(frame, "exit_failed_board_norm"),
        "amount_explosive_exit": safe_bool(frame, "exit_amount_explosive_norm"),
        "amount_confirm_exit": safe_bool(frame, "exit_amount_confirm_norm"),
        "close_above_ma20_exit": safe_num(frame, "exit_close_vs_ma20_pct_norm") > 0,
        "close_above_release_exit": safe_num(frame, "exit_close_vs_release_pct_norm") > 0,
        "close_below_pressure_exit": safe_num(frame, "exit_close_vs_pressure_pct_norm") < 0,
        "drawdown_from_peak_le_8": safe_num(frame, "exit_drawdown_from_peak") <= 0.08,
        "drawdown_from_peak_ge_15": safe_num(frame, "exit_drawdown_from_peak") >= 0.15,
        "intraday_drawdown_ge_18": safe_num(frame, "exit_intraday_drawdown_from_peak") >= 0.18,
        "days_since_peak_le_2": safe_num(frame, "exit_days_since_peak_norm") <= 2,
        "days_since_peak_ge_5": safe_num(frame, "exit_days_since_peak_norm") >= 5,
        "had_limit_up_close": safe_bool(frame, "exit_had_limit_up_close"),
        "limit_up_close_days_ge_2": safe_num(frame, "exit_limit_up_close_days") >= 2,
        "close_vs_stop_le_2": safe_num(frame, "exit_close_vs_stop_pct") <= 0.02,
        "low_vs_stop_lt_0": safe_num(frame, "exit_low_vs_stop_pct") < 0,
        "path_peak_ge_20": safe_num(frame, "path_peak_ret_max") >= 0.20,
        "path_peak_ge_30": safe_num(frame, "path_peak_ret_max") >= 0.30,
        "path_dd_peak_ge_15": safe_num(frame, "path_drawdown_from_peak_max") >= 0.15,
        "path_limit_up_ge_1": safe_num(frame, "path_limit_up_days") >= 1,
        "path_amount_explosive_ge_1": safe_num(frame, "path_amount_explosive_days") >= 1,
        "path_near_support_ge_2": safe_num(frame, "path_near_support_days") >= 2,
        "path_near_pressure_ge_2": safe_num(frame, "path_near_pressure_days") >= 2,
        "path_above_ma20_ratio_ge_70": safe_num(frame, "path_above_ma20_ratio") >= 0.70,
        "path_above_vwap_ratio_ge_70": safe_num(frame, "path_above_vwap_ratio") >= 0.70,
        "path_close_pos_high_ratio_ge_60": safe_num(frame, "path_close_pos_high_ratio") >= 0.60,
        "path_days_from_peak_to_exit_le_2": safe_num(frame, "path_days_from_peak_to_exit") <= 2,
        "path_days_from_peak_to_exit_ge_5": safe_num(frame, "path_days_from_peak_to_exit") >= 5,
    }
    return {name: series.fillna(False).astype(bool) for name, series in predicates.items()}


def prescreen_predicates(
    frame: pd.DataFrame,
    predicates: dict[str, pd.Series],
    targets: dict[str, pd.Series],
    min_support: int,
    max_features: int,
) -> tuple[dict[str, pd.Series], pd.DataFrame]:
    rows: list[dict[str, float | int | str]] = []
    for name, predicate in predicates.items():
        n = int(predicate.sum())
        if n < min_support:
            continue
        best_target = ""
        best_rate = 0.0
        best_lift = -np.inf
        lift_sum = 0.0
        for target_name, target_values in targets.items():
            base = float(target_values.mean())
            rate = float(target_values[predicate].mean()) if n else 0.0
            lift = rate - base
            lift_sum += max(lift, 0.0)
            if lift > best_lift:
                best_target = target_name
                best_rate = rate
                best_lift = lift
        rows.append(
            {
                "feature": name,
                "support_n": n,
                "support_pct": n / len(frame) if len(frame) else 0.0,
                "target": best_target,
                "target_rate": best_rate,
                "lift_abs": best_lift,
                "score": lift_sum * math.sqrt(max(n, 1)),
            }
        )
    prescreen = pd.DataFrame(rows).sort_values(["score", "support_n"], ascending=[False, False]).reset_index(drop=True)
    keep = prescreen.head(max_features)["feature"].tolist()
    return {name: predicates[name] for name in keep}, prescreen


def build_segments(frame: pd.DataFrame, min_rows: int) -> list[SegmentSpec]:
    segments: list[SegmentSpec] = []
    for cols in DEFAULT_SEGMENT_LEVELS:
        if not cols:
            segments.append(SegmentSpec(cols=(), values=()))
            continue
        grouped = frame.groupby(list(cols), dropna=False, sort=True)
        for values, part in grouped:
            values_tuple = values if isinstance(values, tuple) else (values,)
            values_str = tuple(str(v) for v in values_tuple)
            if len(part) >= min_rows:
                segments.append(SegmentSpec(cols=cols, values=values_str))
    return segments


def slice_segment(frame: pd.DataFrame, segment: SegmentSpec) -> pd.DataFrame:
    if not segment.cols:
        return frame
    mask = pd.Series(True, index=frame.index)
    for col, value in zip(segment.cols, segment.values):
        mask &= safe_text(frame, col).eq(value)
    return frame[mask].copy()


def subgroup_lifts(
    subset: pd.DataFrame,
    combo_mask: pd.Series,
    target_mask: pd.Series,
    group_col: str,
) -> tuple[int, float]:
    if group_col not in subset.columns:
        return 0, 0.0
    lifts: list[float] = []
    for _, group in subset.groupby(group_col, sort=True):
        if len(group) < 8:
            continue
        local_mask = combo_mask.loc[group.index]
        n = int(local_mask.sum())
        if n < max(4, min(12, len(group) // 4)):
            continue
        base = float(target_mask.loc[group.index].mean())
        rate = float(target_mask.loc[group.index][local_mask].mean())
        lifts.append(rate - base)
    if not lifts:
        return 0, 0.0
    pos_ratio = sum(1 for x in lifts if x > 0) / len(lifts)
    return len(lifts), pos_ratio


def scan_combinations(
    frame: pd.DataFrame,
    predicates: dict[str, pd.Series],
    targets: dict[str, pd.Series],
    segment: SegmentSpec,
    min_support: int,
    max_arity: int,
    top_k: int,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    subset = slice_segment(frame, segment)
    if subset.empty:
        return pd.DataFrame(), pd.DataFrame()

    subset_predicates: dict[str, pd.Series] = {}
    for name, predicate in predicates.items():
        values = predicate.loc[subset.index].fillna(False).astype(bool)
        if int(values.sum()) >= min_support:
            subset_predicates[name] = values

    target_arrays = {name: values.loc[subset.index].fillna(False).astype(bool) for name, values in targets.items()}
    baselines = {name: float(mask.mean()) for name, mask in target_arrays.items()}
    combo_rows: list[dict[str, float | int | str]] = []

    feature_names = list(subset_predicates)
    if not feature_names:
        return pd.DataFrame(), pd.DataFrame()

    for arity in range(1, max_arity + 1):
        for combo in itertools.combinations(feature_names, arity):
            combo_mask = pd.Series(True, index=subset.index)
            for feature in combo:
                combo_mask &= subset_predicates[feature]
            support_n = int(combo_mask.sum())
            if support_n < min_support:
                continue
            support_pct = support_n / len(subset)
            combo_str = " & ".join(combo)
            post3_close = float(safe_num(subset.loc[combo_mask], "post_exit_3d_close").mean())
            post20_high = float(safe_num(subset.loc[combo_mask], "post_exit_20d_high").mean())
            post20_close = float(safe_num(subset.loc[combo_mask], "post_exit_20d_close").mean())
            realized_ret = float(safe_num(subset.loc[combo_mask], "ret_norm").mean())

            for target_name, target_mask in target_arrays.items():
                hits = int((combo_mask & target_mask).sum())
                if hits == 0:
                    rate = 0.0
                else:
                    rate = hits / support_n
                baseline = baselines[target_name]
                abs_lift = rate - baseline
                rel_lift = rate / baseline if baseline > 0 else np.nan
                year_groups, pos_year_ratio = subgroup_lifts(subset, combo_mask, target_mask, "year")
                stop_groups, pos_stop_ratio = subgroup_lifts(subset, combo_mask, target_mask, "stop_mode")
                stability = np.mean([x for x in [pos_year_ratio, pos_stop_ratio] if not np.isnan(x)]) if (year_groups or stop_groups) else 0.0
                score = abs_lift * math.sqrt(support_n) * max(0.20, stability)
                combo_rows.append(
                    {
                        "segment": segment.name,
                        "segment_cols": ",".join(segment.cols),
                        "arity": arity,
                        "combo": combo_str,
                        "features": ",".join(combo),
                        "target": target_name,
                        "support_n": support_n,
                        "support_pct": support_pct,
                        "hits": hits,
                        "target_rate": rate,
                        "baseline_rate": baseline,
                        "lift_abs": abs_lift,
                        "lift_rel": rel_lift,
                        "pos_year_groups": year_groups,
                        "pos_year_ratio": pos_year_ratio,
                        "pos_stop_groups": stop_groups,
                        "pos_stop_ratio": pos_stop_ratio,
                        "stability": stability,
                        "score": score,
                        "mean_post3_close": post3_close,
                        "mean_post20_high": post20_high,
                        "mean_post20_close": post20_close,
                        "mean_realized_ret": realized_ret,
                    }
                )

    combo_df = pd.DataFrame(combo_rows)
    if combo_df.empty:
        return combo_df, combo_df
    summary_df = (
        combo_df.sort_values(["segment", "target", "arity", "score", "support_n"], ascending=[True, True, True, False, False])
        .groupby(["segment", "target", "arity"], sort=False)
        .head(top_k)
        .reset_index(drop=True)
    )
    return combo_df, summary_df


def numeric_screen(
    frame: pd.DataFrame,
    targets: dict[str, pd.Series],
    segments: list[SegmentSpec],
    min_rows: int,
) -> pd.DataFrame:
    numeric_cols = [
        "signal_confidence",
        "signal_peer_confirmation",
        "signal_leader_strength",
        "signal_multi_spear_count",
        "signal_stop_gap_pct",
        "mfe_norm",
        "mfe_capture_norm",
        "exit_peak_gap",
        "exit_drawdown_from_peak",
        "exit_intraday_drawdown_from_peak",
        "exit_close_pos_norm",
        "exit_upper_shadow_pct_norm",
        "exit_amount_vs_prev20_med_norm",
        "exit_volume_vs_prev20_med_norm",
        "exit_days_since_peak_norm",
        "exit_close_vs_stop_pct",
        "path_peak_ret_max",
        "path_drawdown_from_peak_max",
        "path_limit_up_days",
        "path_above_ma20_ratio",
        "path_days_from_peak_to_exit",
    ]
    rows: list[dict[str, float | int | str]] = []
    for segment in segments:
        subset = slice_segment(frame, segment)
        if len(subset) < min_rows:
            continue
        for feature in numeric_cols:
            feature_values = safe_num(subset, feature)
            if feature_values.notna().sum() < min_rows or feature_values.nunique(dropna=True) < 4:
                continue
            try:
                bins = pd.qcut(feature_values, q=min(5, feature_values.nunique(dropna=True)), duplicates="drop")
            except ValueError:
                continue
            for target_name, target_mask in targets.items():
                tmp = pd.DataFrame({"feature": feature_values, "target": target_mask.loc[subset.index], "bucket": bins}).dropna()
                if tmp.empty or tmp["bucket"].nunique() < 3:
                    continue
                grouped = tmp.groupby("bucket", observed=True)["target"].agg(["mean", "count"])
                grouped = grouped.reset_index(drop=True)
                top_rate = float(grouped["mean"].iloc[-1])
                bottom_rate = float(grouped["mean"].iloc[0])
                overall = float(tmp["target"].mean())
                rho = float(tmp["feature"].corr(tmp["target"].astype(float), method="spearman"))
                rows.append(
                    {
                        "segment": segment.name,
                        "feature": feature,
                        "target": target_name,
                        "rows": int(len(tmp)),
                        "overall_rate": overall,
                        "top_bucket_rate": top_rate,
                        "bottom_bucket_rate": bottom_rate,
                        "spread": top_rate - bottom_rate,
                        "spearman_rho": rho,
                        "direction": "higher_better" if top_rate >= bottom_rate else "lower_better",
                        "score": abs(top_rate - bottom_rate) * math.sqrt(len(tmp)),
                    }
                )
    if not rows:
        return pd.DataFrame()
    return pd.DataFrame(rows).sort_values(["segment", "score"], ascending=[True, False]).reset_index(drop=True)


def baseline_summary(frame: pd.DataFrame, targets: dict[str, pd.Series]) -> pd.DataFrame:
    rows: list[dict[str, float | int | str]] = []
    group_cols = [(), ("exit_reason",), ("year",), ("stop_mode",), ("exit_reason", "year"), ("exit_reason", "stop_mode")]
    for cols in group_cols:
        if cols:
            grouped = frame.groupby(list(cols), dropna=False, sort=True)
            iterator = grouped
        else:
            iterator = [((), frame)]
        for values, part in iterator:
            values_tuple = values if isinstance(values, tuple) else (values,)
            segment = "all" if not cols else "|".join(f"{col}={val}" for col, val in zip(cols, values_tuple))
            for target_name, target_mask in targets.items():
                local = target_mask.loc[part.index]
                rows.append(
                    {
                        "segment": segment,
                        "segment_cols": ",".join(cols),
                        "target": target_name,
                        "rows": int(len(part)),
                        "rate": float(local.mean()) if len(local) else 0.0,
                    }
                )
    return pd.DataFrame(rows).sort_values(["target", "segment"]).reset_index(drop=True)


def classify_results(combo_df: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    if combo_df.empty:
        empty = pd.DataFrame()
        return empty, empty, empty
    stable_facts = combo_df[
        (combo_df["arity"] == 1)
        & (combo_df["support_n"] >= 20)
        & (combo_df["stability"] >= 0.55)
        & (combo_df["lift_abs"] > 0)
    ].sort_values(["score", "support_n"], ascending=[False, False]).reset_index(drop=True)
    lego = combo_df[
        (combo_df["arity"] >= 2)
        & (combo_df["support_n"] >= 15)
        & (combo_df["stability"] >= 0.35)
        & (combo_df["lift_abs"] > 0)
    ].sort_values(["score", "support_n"], ascending=[False, False]).reset_index(drop=True)
    regime_patterns = combo_df[
        (combo_df["support_n"] >= 12)
        & (combo_df["lift_abs"] > 0)
        & (combo_df["stability"] < 0.35)
    ].sort_values(["score", "support_n"], ascending=[False, False]).reset_index(drop=True)
    return stable_facts, lego, regime_patterns


def render_brief_report(
    frame: pd.DataFrame,
    baseline: pd.DataFrame,
    prescreen: pd.DataFrame,
    stable_facts: pd.DataFrame,
    lego: pd.DataFrame,
    regime_patterns: pd.DataFrame,
    numeric_df: pd.DataFrame,
) -> str:
    lines = [
        "# Trend Spear Exploration Runner",
        "",
        f"- rows: {len(frame)}",
        f"- runs: {frame['run_name'].nunique()}",
        f"- years: {', '.join(sorted(frame['year'].dropna().astype(str).unique()))}",
        f"- stop modes: {', '.join(sorted(frame['stop_mode'].dropna().astype(str).unique()))}",
        f"- exit reasons: {', '.join(sorted(frame['exit_reason'].dropna().astype(str).unique()))}",
        "",
        "## Target Baselines",
    ]
    for row in baseline[baseline["segment"] == "all"].sort_values("target").itertuples():
        lines.append(f"- {row.target}: {row.rate:.2%} on n={row.rows}")

    lines.extend(["", "## Predicate Prescreen"])
    for row in prescreen.head(12).itertuples():
        lines.append(f"- {row.feature}: lift={row.lift_abs:+.2%}, support={row.support_n}")

    lines.extend(["", "## Stable Facts"])
    if stable_facts.empty:
        lines.append("- none")
    else:
        for row in stable_facts.head(12).itertuples():
            lines.append(
                f"- [{row.segment}] {row.combo} -> {row.target} rate {row.target_rate:.2%} "
                f"(base {row.baseline_rate:.2%}, lift {row.lift_abs:+.2%}, n={row.support_n})"
            )

    lines.extend(["", "## LEGO Combos"])
    if lego.empty:
        lines.append("- none")
    else:
        for row in lego.head(15).itertuples():
            lines.append(
                f"- [{row.segment}] {row.combo} -> {row.target} rate {row.target_rate:.2%} "
                f"(lift {row.lift_abs:+.2%}, stability {row.stability:.2f}, n={row.support_n})"
            )

    lines.extend(["", "## Regime Patterns"])
    if regime_patterns.empty:
        lines.append("- none")
    else:
        for row in regime_patterns.head(10).itertuples():
            lines.append(
                f"- [{row.segment}] {row.combo} -> {row.target} rate {row.target_rate:.2%} "
                f"(lift {row.lift_abs:+.2%}, stability {row.stability:.2f}, n={row.support_n})"
            )

    lines.extend(["", "## Numeric Screens"])
    if numeric_df.empty:
        lines.append("- none")
    else:
        for row in numeric_df.head(12).itertuples():
            lines.append(
                f"- [{row.segment}] {row.feature} -> {row.target}: {row.direction}, "
                f"spread {row.spread:+.2%}, rho {row.spearman_rho:+.3f}, rows={row.rows}"
            )
    lines.append("")
    return "\n".join(lines)


def main() -> None:
    args = parse_args()
    out_dir = Path(args.out_dir) if args.out_dir else ROOT / "outputs" / "research" / f"exploration_runner_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
    out_dir.mkdir(parents=True, exist_ok=True)

    frame = load_runs(args)
    targets = define_targets(frame)
    predicates, prescreen = prescreen_predicates(frame, define_predicates(frame), targets, args.min_support, args.max_features)
    segments = build_segments(frame, args.min_segment_rows)

    combo_frames: list[pd.DataFrame] = []
    combo_summary_frames: list[pd.DataFrame] = []
    for segment in segments:
        combo_df, summary_df = scan_combinations(
            frame=frame,
            predicates=predicates,
            targets=targets,
            segment=segment,
            min_support=args.min_support,
            max_arity=args.max_arity,
            top_k=args.top_k,
        )
        if not combo_df.empty:
            combo_frames.append(combo_df)
            combo_summary_frames.append(summary_df)

    combo_all = pd.concat(combo_frames, ignore_index=True) if combo_frames else pd.DataFrame()
    combo_summary = pd.concat(combo_summary_frames, ignore_index=True) if combo_summary_frames else pd.DataFrame()
    baseline = baseline_summary(frame, targets)
    numeric_df = numeric_screen(frame, targets, segments, args.min_segment_rows)
    stable_facts, lego, regime_patterns = classify_results(combo_summary)

    frame.to_csv(out_dir / "dataset.csv", index=False, encoding="utf-8")
    baseline.to_csv(out_dir / "baseline_summary.csv", index=False, encoding="utf-8")
    prescreen.to_csv(out_dir / "predicate_prescreen.csv", index=False, encoding="utf-8")
    combo_all.to_csv(out_dir / "combo_results_full.csv", index=False, encoding="utf-8")
    combo_summary.to_csv(out_dir / "combo_results_top.csv", index=False, encoding="utf-8")
    stable_facts.to_csv(out_dir / "stable_facts.csv", index=False, encoding="utf-8")
    lego.to_csv(out_dir / "lego_combos.csv", index=False, encoding="utf-8")
    regime_patterns.to_csv(out_dir / "regime_patterns.csv", index=False, encoding="utf-8")
    numeric_df.to_csv(out_dir / "numeric_screen.csv", index=False, encoding="utf-8")

    manifest = {
        "run_glob": args.run_glob,
        "entry_reason": args.entry_reason,
        "exit_reasons": args.exit_reasons,
        "rows": int(len(frame)),
        "runs": sorted(frame["run_name"].dropna().astype(str).unique().tolist()),
        "targets": sorted(targets),
        "predicate_count": len(predicates),
        "segments": [segment.name for segment in segments],
        "max_arity": args.max_arity,
        "min_support": args.min_support,
        "min_segment_rows": args.min_segment_rows,
        "top_k": args.top_k,
    }
    (out_dir / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")

    report = render_brief_report(frame, baseline, prescreen, stable_facts, lego, regime_patterns, numeric_df)
    (out_dir / "summary.md").write_text(report, encoding="utf-8")
    print(report)
    print(f"[written] {out_dir}")


if __name__ == "__main__":
    main()
