#!/usr/bin/env python3
"""
Audit script: Collect detailed comparison data from backtest results for audit document.
Working directory: v5_standalone
Run: python scripts/audit_backtest_comparison.py
"""
import json
import pickle
from collections import defaultdict
from datetime import datetime
from pathlib import Path

import pandas as pd

WORKSPACE = Path(__file__).resolve().parent.parent
BACKTESTS_DIR = WORKSPACE / "outputs" / "backtests"
SIGNALS_DIR = WORKSPACE / "outputs" / "signals"
CACHE_DIR = WORKSPACE / "cache"
QFQ_CUTOFF = datetime(2026, 3, 10, 15, 6, 0)


def main():
    print("=" * 80)
    print("AUDIT: Backtest & Signal Comparison Data")
    print("=" * 80)

    # 1. List ALL directories under outputs/backtests/ sorted by name
    backtest_dirs = sorted([d for d in BACKTESTS_DIR.iterdir() if d.is_dir()])
    print(f"\n## 1. BACKTEST DIRECTORIES ({len(backtest_dirs)} total)")
    print("-" * 60)
    for d in backtest_dirs:
        print(f"  {d.name}")

    # 2. For each backtest dir: read meta.json and summary.json
    print(f"\n## 2. BACKTEST META + SUMMARY (per directory)")
    print("-" * 60)
    for d in backtest_dirs:
        print(f"\n### {d.name}")
        meta_path = d / "meta.json"
        summary_path = d / "summary.json"
        if meta_path.exists():
            with open(meta_path) as f:
                meta = json.load(f)
            print(f"  Config: {json.dumps(meta.get('config', {}), indent=4)}")
            for k, v in meta.items():
                if k != "config":
                    print(f"  {k}: {v}")
        else:
            print("  [meta.json not found]")
        if summary_path.exists():
            with open(summary_path) as f:
                summary = json.load(f)
            print(f"  Summary stats: {json.dumps(summary, indent=4)}")
        else:
            print("  [summary.json not found]")

    # 3. List ALL directories under outputs/signals/ sorted by name, read meta.json
    signal_dirs = sorted([d for d in SIGNALS_DIR.iterdir() if d.is_dir()])
    print(f"\n## 3. SIGNAL DIRECTORIES ({len(signal_dirs)} total)")
    print("-" * 60)
    for d in signal_dirs:
        print(f"\n### {d.name}")
        meta_path = d / "meta.json"
        if meta_path.exists():
            with open(meta_path) as f:
                meta = json.load(f)
            print(f"  {json.dumps(meta, indent=4)}")
        else:
            print("  [meta.json not found]")

    # 4. Count cache files by modification date (grouped by hour)
    print(f"\n## 4. CACHE FILES BY MODIFICATION HOUR")
    print("-" * 60)
    cache_by_hour = defaultdict(int)
    cache_files = list(CACHE_DIR.glob("*.pkl"))
    for p in cache_files:
        mtime = datetime.fromtimestamp(p.stat().st_mtime)
        hour_key = mtime.strftime("%Y-%m-%d %H:00")
        cache_by_hour[hour_key] += 1
    for hour in sorted(cache_by_hour.keys()):
        print(f"  {hour}: {cache_by_hour[hour]} files")

    # 5. Sample 5 pre-QFQ and 5 post-QFQ stocks
    pre_qfq = []
    post_qfq = []
    for p in cache_files:
        mtime = datetime.fromtimestamp(p.stat().st_mtime)
        code = p.stem.replace("_full", "")
        if mtime < QFQ_CUTOFF:
            pre_qfq.append((code, p, mtime))
        else:
            post_qfq.append((code, p, mtime))
    pre_qfq.sort(key=lambda x: x[0])
    post_qfq.sort(key=lambda x: x[0])
    pre_sample = pre_qfq[:5]
    post_sample = post_qfq[:5]

    print(f"\n## 5. PRE-QFQ vs POST-QFQ SAMPLE (5 stocks each)")
    print("-" * 60)
    print(f"Cutoff: {QFQ_CUTOFF} (before = raw, after = QFQ adjusted)")
    print()

    def print_pkl_sample(label, samples):
        print(f"### {label}")
        for code, path, mtime in samples:
            with open(path, "rb") as f:
                df = pickle.load(f)
            if isinstance(df, pd.DataFrame) and "close" in df.columns:
                bars = len(df)
                date_min = df.index.min()
                date_max = df.index.max()
                first_3 = df["close"].head(3).tolist()
                last_3 = df["close"].tail(3).tolist()
                print(f"  Code: {code} | mtime: {mtime}")
                print(f"    bars: {bars} | date range: {date_min} to {date_max}")
                print(f"    first 3 closes: {first_3}")
                print(f"    last 3 closes: {last_3}")
                print()
            else:
                print(f"  Code: {code} | [unexpected pkl structure]")
                print()

    print_pkl_sample("PRE-QFQ (raw, cache modified before 2026-03-10 15:06)", pre_sample)
    print_pkl_sample("POST-QFQ (QFQ adjusted, cache modified after cutoff)", post_sample)

    print("=" * 80)
    print("AUDIT COMPLETE")
    print("=" * 80)


if __name__ == "__main__":
    main()
