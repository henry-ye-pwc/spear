#!/usr/bin/env bash
set -euo pipefail

PROJ_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJ_NAME="spear-strategy-v5"
TIMESTAMP="$(date +%Y%m%d_%H%M%S)"
OUT_TAR="${PROJ_DIR}/${PROJ_NAME}-${TIMESTAMP}.tar.gz"
OUT_ZIP="${PROJ_DIR}/${PROJ_NAME}-${TIMESTAMP}.zip"

# Common excludes (used for both tar and zip)
EXCLUDES=(
  '__pycache__' '*.pyc' '.pytest_cache'
  '.DS_Store' '.git' '.env'
  'cache' 'v5/cache'
  'outputs' 'output'
  'v5/results' 'v5/output_*'
  'v4/output_*' 'v4/stability_*'
  '.studio'
  'studio_frontend/node_modules' 'studio_frontend/dist'
  '*.pkl' '*.tar.gz' '*.zip'
  'scripts' 'package.sh'
)

cd "$PROJ_DIR"

echo "==> Building frontend..."
(cd studio_frontend && npm install --silent && npm run build --silent)

# Strip macOS extended attributes (com.apple.provenance etc.) to avoid ._* files on Windows
xattr -cr "$PROJ_DIR"

# --- tar.gz ---
echo "==> Packaging ${PROJ_NAME} (tar.gz)..."
TAR_EXCLUDES=()
for e in "${EXCLUDES[@]}"; do TAR_EXCLUDES+=(--exclude="$e"); done
COPYFILE_DISABLE=1 tar czf "$OUT_TAR" \
  "${TAR_EXCLUDES[@]}" \
  -C "$(dirname "$PROJ_DIR")" \
  "$(basename "$PROJ_DIR")"
SIZE=$(du -sh "$OUT_TAR" | cut -f1)
echo "==> Done: ${OUT_TAR} (${SIZE})"

# --- zip (Windows-friendly: no ._* macOS metadata) ---
echo "==> Packaging ${PROJ_NAME} (zip, Windows-friendly)..."
ZIP_EXCLUDES=()
for e in "${EXCLUDES[@]}"; do ZIP_EXCLUDES+=(-x "*/${e}" -x "${e}"); done
# COPYFILE_DISABLE prevents macOS from adding ._* resource forks
COPYFILE_DISABLE=1 zip -r "$OUT_ZIP" "$(basename "$PROJ_DIR")" \
  "${ZIP_EXCLUDES[@]}" \
  -x "*/.DS_Store" \
  -x "*/__MACOSX/*" \
  -x "*/._*" \
  2>/dev/null
SIZE=$(du -sh "$OUT_ZIP" | cut -f1)
echo "==> Done: ${OUT_ZIP} (${SIZE})"

echo ""
echo "To use (Linux/macOS):  tar xzf $(basename "$OUT_TAR")"
echo "To use (Windows):      unzip   $(basename "$OUT_ZIP")"
echo ""
echo "  cd $(basename "$PROJ_DIR")"
echo "  pip install -r requirements.txt"
echo "  cd studio_frontend && npm install && cd .."
echo "  python start_studio_backend.py      # backend on :8000"
echo "  cd studio_frontend && npm run dev    # frontend on :5173"
