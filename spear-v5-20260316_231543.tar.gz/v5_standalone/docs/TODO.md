# Trend Spear 策略待办事项

> 最后更新：2026-03-12
> 来源：因子验证 (06)、持仓分析 (07)、入场分析 (08)、止损分析 (09)

---

## 已完成（2026-03-12 策略升级 + 消融测试）

- [x] **ATR 自适应止损**：`entry - 2.0×ATR_20d`（有板 2.5x，无板 >5日 1.5x，底线 -8%）
  - 实现：`v4/features/robust.py`（atr_20d_pct）, `v4/models/trend_spear.py`（invalidation）, `v4/execution/state_machine.py`（动态调整）
  - **消融测试结论：三年跨度唯一稳定正向因素（+6.97pp 平均），保留**

- [x] ~~**入场过滤器**：`vol60_iqr_norm ≤ 1.2` + `vol_elevation ≤ 1.3`~~
  - 实现：`v4/models/trend_spear.py`（过滤逻辑）
  - **消融测试结论：效果不稳定（-1.17~-11.56pp，2024 反转 +3.28pp），待移除**

- [x] ~~**持仓分流 + 爆量退出**：有板延长 15 天，无板缩短 5 天，vol_exhaustion~~
  - 实现：`v4/execution/state_machine.py`
  - **消融测试结论：三年全负（-2.07~-16.06pp），待移除**

- [x] **消融测试（三年全量）**
  - 方法：2^3 = 8 配置 × 3 年份（2022/2024/2025），dlh 模式
  - 详见：[10_ablation_test.md](strategy/trend_spear/10_ablation_test.md)
  - 脚本：`scripts/ablation_test.py`

## 紧急 Bug / UX（信号扫描页面）

- [ ] **信号扫描 prefetch 静默失败**：confirm 模式下 `prefetch_symbols()` 跑了但通达信没有返回新日期的数据（可能是盘后未更新、网络问题、或通达信服务未启动），系统静默降级到缓存最后日期，用户无感知。
  - 现象：用户选 3-12 跑信号，log 显示 process 只到 3-10，结果标题写 3-11 但实际数据截止 3-10。
  - 应修：(a) prefetch 后检查实际最新日期，如果 < 用户请求日期则在 log 和 meta.json 里明确标注 warning；(b) 前端在结果页显示 `实际数据截止: 2026-03-10`（如果 != 请求日期）并标红。
  - 涉及：`v5/daily_signal_job.py`（检查 effective_date vs requested_date）、`ResultsExplorer.tsx`（显示 warning）

- [ ] **Results 页面缺少扫描目标日期标注**：signal scan 结果列表和详情页都没有清晰显示"扫描目标日期"，只显示 effective_date（实际数据截止日），容易误导。
  - 应修：(a) `SignalRow` 显示 `目标: 2026-03-12 | 实际: 2026-03-10`；(b) 详情页顶部 banner 标注。
  - 涉及：`ResultsExplorer.tsx`（SignalRow + detail header）、`meta.json`（已有 `date` 和 `effective_date` 字段）

- [ ] **股票池包含 ETF/指数标的**：结果中出现科创50等非个股标的，应在 pool 解析或信号检测阶段过滤。
  - 应修：在 `prepare_bundle()` 或 pool 解析时排除 symbol prefix 为 `51`/`56`/`15`/`16` 的 ETF 和 `000001`~`000030` 中的指数。
  - 涉及：`v5/backtest/prepare.py` 或 `v5/config/pools.py`

## 高优先级（有数据支撑，可直接实现）

- [ ] **持仓状态机升级与假说验证 (代替死板的 time_exit)**
  - 触发条件：持仓期间 `MFE > 20%`（或曾有涨停表现）。
  - 动作：从“倒计时模式（time_exit）”切换到“趋势管理模式” **（注意：需先做实验，不能直接上默认规则，先补在线状态）**
  - 在线状态增补（待开发）：`running_peak_ret`，`drawdown_from_peak`，`stop_day_volume_vs_recent`，`stop_after_3d_reclaim`。
  - 退出判定候选：改看峰值回撤（如 drawdown_from_peak > 10%~15%）、高位量价见顶、或跟踪均线。

- [ ] **假摔后的二进宫机制验证与设计**
  - 当前状态：优秀假说待验证。
  - 验证逻辑：基于补充的在线状态（`stop_day_volume_vs_recent`, `stop_after_3d_reclaim`），统计止损当日的量能（是否缩量）以及止损后 3 日内是否放量收复关键位。
  - 如果被数据坐实：设计 `stop_loss -> 观察名单 -> 二次触发入场` 的逻辑闭环。

- [ ] **止损后二次观察池的因子增强**
  - 虽然 `peer_confirmation` 不能单独判断假摔，但可作为观察池加分项（注意是信号日特征）。
  - 测试：`高 peer_confirmation` + `止损日缩量` -> 优先加入反包重入观察池。

- [ ] **`vol_elevation` 正式验证**：对其进行与 vol60_iqr_norm 同等的 7 项因子检验
  - 涉及文件：`scripts/factor_method_validation.py`
  - 详见：[06_factor_validation.md](strategy/trend_spear/06_factor_validation.md)

## 中优先级（需要额外数据或较大改动）

- [ ] **Day 1-3 量比早期分流**：确定精确阈值（目前参考值 2.0x / 1.5x）
  - 详见：[02_board_analysis.md](strategy/trend_spear/02_board_analysis.md)

- [ ] **2025 年信号失效调查**：市场环境变化？池子结构差异？
  - 详见：[06_factor_validation.md](strategy/trend_spear/06_factor_validation.md) §6.5

- [ ] **持仓期动态张扬含蓄评估验证**：统计"持仓中量价变质"与后续收益的关系
  - 详见：[01_zhangyang_hanshu.md](strategy/trend_spear/01_zhangyang_hanshu.md)

- [ ] **F-Score ≥ 5 池子过滤**（需接入财务数据）
  - 详见：[08_entry_multidim.md](strategy/trend_spear/08_entry_multidim.md) §8.4

## 低优先级（长期探索）

- [ ] 张扬含蓄 v0 量化公式阈值调参（α, β, 爆量倍数）
- [ ] 连板追踪模式的 state_machine.py 实现
- [ ] 分时数据接入（封板质量判断）
- [ ] 分类模型（logistic / RF）探索
- [ ] 承上启下 + 张扬含蓄联合过滤条件的回测验证
