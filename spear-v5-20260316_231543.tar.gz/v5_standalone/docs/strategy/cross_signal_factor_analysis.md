# 跨信号类型因子分析

> 最后更新：2026-03-14
> 数据：2,612 笔已执行交易（7 年 × 50-150cyc 池），覆盖 trend_spear(861), attack(573), arb(930), post_limit(178)
> 脚本：`scripts/factor_method_validation.py`（已指向 oracle 回测数据）
> 完整输出：`outputs/analysis/factor_validation_861trades_7years.txt`

---

## 1. 核心发现

### 真正跨类型有效的不是量能特征，而是动量和波动率

| 特征 | 显著类型数 | 方向 | 含义 |
|:--|:-:|:-:|:--|
| `mom_20d` | **3/4** | 负 | 信号前 20 天涨幅越大，后续收益越差 |
| `mom_5d` | **3/4** | 负 | 信号前 5 天涨幅越大，后续越差 |
| `price_vol_5d` | 2/4 | 负 | 近 5 天价格波动率越高越差 |
| `atr_20d_pct` | 2/4 | 负 | ATR 越高越差 |

**均值回归效应**：前期涨得越多、波动越大的票，信号后表现越差。这在 trend_spear、attack、arb 三种信号上一致成立。

### 量能离散度特征只对趋势类有效

之前认为 `vol60_iqr_norm` 等量能收敛性指标具有普适性，**实际上只在 trend_spear 上显著**（p≈0.05），在 attack/arb/post_limit 上不显著。

更关键的是，**post_limit 的方向完全相反**——量越发散反而越好（iqr_norm 高半 +1.6% vs 低半 -2.0%）。涨停板后放量说明换手充分，量缩说明接盘不够。

---

## 2. 各信号类型 Top 特征

### trend_spear（n=861）— 安静 + 低波动 = 好

| 特征 | rho | p | 解读 |
|:--|:--:|:--:|:--|
| `atr_20d_pct` | -0.159 | <0.0001 | **最强因子**。波动率越低越好 |
| `price_vol_20d` | -0.144 | <0.0001 | 价格越平稳越好 |
| `mom_20d` | -0.131 | 0.0001 | 前期越没涨过越好 |
| `price_vol_5d` | -0.115 | 0.0007 | 近期价格波动越小越好 |
| `vol60_iqr_norm` | -0.065 | 0.056 | 量能越收敛越好（边缘显著） |

**画像**：好的趋势长枪信号来自"安静酝酿"的票——价格波动低、量能收敛、前期没怎么涨过。

### attack（n=573）— 低动量 + 阳线不需要堆量

| 特征 | rho | p | 解读 |
|:--|:--:|:--:|:--|
| `mom_20d` | -0.204 | <0.0001 | **最强因子**。前期涨幅越小越好 |
| `mom_5d` | -0.116 | 0.006 | 近期同理 |
| `upper_shadow_ratio_5d` | +0.114 | 0.006 | 上影线越长反而越好（有人卖但买盘能接） |
| `zhang_ratio` | -0.100 | 0.017 | 阳线量/阴线量比越高反而越差（量能已消耗） |

**画像**：好的 attack 信号来自"还没怎么涨过"的票。如果信号前 20 天已经涨了很多，后续大概率是冲高回落。

### arb（n=930）— 弱信号，因子整体不显著

| 特征 | rho | p | 解读 |
|:--|:--:|:--:|:--|
| `mom_20d` | -0.078 | 0.017 | 方向同上但效果弱 |
| `mom_5d` | -0.073 | 0.026 | 同上 |
| `zhang_ratio` | -0.057 | 0.081 | 边缘显著 |

**画像**：arb 对入场因子不敏感。主要区分因子是**板块联动**（peer_ratio），不是个股特征。

### post_limit（n=178）— 样本偏小，波动率是唯一因子

| 特征 | rho | p | 解读 |
|:--|:--:|:--:|:--|
| `atr_20d_pct` | -0.171 | 0.022 | 波动率越低越好 |
| `vol60_iqr_norm` | +0.115 | 0.125 | 方向反转（量越发散越好），但不显著 |

**注意**：post_limit 只有 178 笔，统计检验力不足。iqr_norm 方向反转需要更多数据验证。

---

## 3. 量能特征的跨类型表现

| 量能特征 | trend_spear | attack | arb | post_limit |
|:--|:-:|:-:|:-:|:-:|
| `vol60_iqr_norm` | **LOW 好** (p=0.056) | LOW 好 (ns) | LOW 好 (ns) | **HIGH 好** (反转!) |
| `vol_ratio_10_60` | **LOW 好** (p=0.057) | LOW 好 (ns) | 无差 | HIGH 好 (反转) |
| `hdi_width` | **LOW 好** (p=0.051) | 无差 | HIGH 好 | HIGH 好 (反转) |
| `vol60_cv` | LOW 好 (ns) | 无差 | HIGH 好 | HIGH 好 |

ns = not significant

**结论**：量能收敛性只是 trend_spear 的特征，不能作为通用过滤器。post_limit 需要相反的逻辑。

---

## 4. 策略启示

1. **通用过滤器**：`mom_20d` 和 `atr_20d_pct` 可以跨信号类型使用。前期涨幅过大 or ATR 过高的票，不论哪种信号都应该降权。

2. **按类型定制**：
   - trend_spear：加上量能收敛过滤（iqr_norm）
   - attack：加上动量过滤（mom_20d）和上影线信号
   - arb：入场因子弱，重点放在板块联动（peer_ratio）上
   - post_limit：不能用量能收敛过滤（方向相反）

3. **不应使用的特征**：`zhang_ratio`（张扬含蓄比）在 7 年 861 笔 trend_spear 上 0/7 gates passed，在 attack 和 arb 上方向为负。文档 01 的"张扬含蓄"叙事在统计上不成立。

---

## 5. 数据质量说明

- 交易数据来自 oracle 回测（`oracle_YYYY_50-150cyc_dlh`），`--disable-env-mapping` 模式
- 特征计算使用缓存 PKL 的日线数据（前复权）
- 持仓期收益取自 `closed_trades.csv` 的 `ret` 字段（含手续费）
- post_limit 样本量（178）偏小，结论需保守看待
- youzi（51）和 failed_board（19）样本太少，未纳入分析

## 6. 复现

```bash
# 确保 oracle 回测已完成
ls outputs/backtests/oracle_*_50-150cyc_dlh/closed_trades.csv

# 运行因子验证（约 15 秒）
python scripts/factor_method_validation.py

# 输出在终端，可重定向保存
python scripts/factor_method_validation.py > outputs/analysis/factor_validation_latest.txt
```
