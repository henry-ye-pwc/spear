# 信号能力概览（Oracle Analysis）

> 最后更新：2026-03-13
> 数据来源：15,470 个 long 信号，2019-2025 跨 7 年，50-150cyc 池（832 只精选票）

---

## 1. 数据管线

### 生成流程

```
batch_backtest_oracle.sh        # 7年回测（每年独立目录）
    ↓
extend_signal_csv.py            # 从 events.csv + cache PKL 计算前瞻收益
    ↓
selected_stock_picks.csv        # 15,470 行，含 MFE/MAE/close_ret 各时间窗口
    ↓
regenerate_oracle.py            # 计算所有统计指标，写入 oracle_constants.py
compute_pool_baseline.py        # A/B 对比：信号票 vs 同日非信号票
    ↓
oracle_constants.py             # 前端 Dashboard 通过 /api/signal-oracle 读取
```

### 关键文件

| 文件 | 作用 |
|------|------|
| `scripts/batch_backtest_oracle.sh` | 跑 7 年回测，输出到 `outputs/backtests/oracle_YYYY_50-150cyc_dlh/` |
| `scripts/extend_signal_csv.py` | 从回测 `events.csv` + 缓存 PKL 算前瞻收益（MFE/MAE/close_ret，1/3/5/10/20 天） |
| `scripts/regenerate_oracle.py` | 读 CSV，算所有 oracle 指标，写 `v5/notify/oracle_constants.py` |
| `scripts/compute_pool_baseline.py` | 信号日匹配 A/B 对比，算真实 pool baseline |
| `v5/notify/oracle_constants.py` | 最终产出，被后端 API serve 到前端 |
| `outputs/analysis/signal_value_status_20260313/selected_stock_picks.csv` | 中间数据，15,470 行 |

### 重新生成

```bash
cd v5_standalone

# 1. 跑 7 年回测（约 15 分钟，需要通达信连接）
bash scripts/batch_backtest_oracle.sh

# 2. 从回测结果生成 CSV（含 MFE + MAE）
python scripts/extend_signal_csv.py --from-backtests --replace

# 3. 计算 oracle 指标
python scripts/regenerate_oracle.py

# 4. 计算 pool baseline（可选，约 20 秒）
python scripts/compute_pool_baseline.py
```

---

## 2. 数据结构

### selected_stock_picks.csv 列

| 列 | 含义 |
|----|------|
| date, symbol, event_type | 信号基本信息 |
| confidence, side | 信号置信度，方向（long） |
| entry_plan, invalidation, exit_plan, context | JSON 字段，含 gate_price, stop_price, peer_confirmation, theme_label 等 |
| close | 信号日收盘价 |
| close_ret_{1,3,5,10,20}d | 信号后 N 天收盘价相对信号日收盘的收益率 |
| max_high_ret_{1,3,5,10,20}d | 信号后 N 天内盘中最高价相对信号日收盘的最大收益（MFE） |
| min_low_ret_{1,3,5,10,20}d | 信号后 N 天内盘中最低价相对信号日收盘的最大回撤（MAE） |
| year | 年份 |

### oracle_constants.py 结构

```python
SIGNAL_ORACLE = {
    "attack": {
        "_all": { ... },       # 全年份聚合
        "2019": { ... },       # 单年
        ...
    },
    ...
}
POOL_BASELINE = { ... }        # 非信号票的 baseline
ORACLE_META = { ... }          # 元信息
```

---

## 3. Oracle 指标清单

### 每个 event_type 的 `_all` 和 per-year 包含：

| 字段 | 含义 | 示例（attack _all） |
|------|------|-----|
| `n` | 信号样本数 | 4288 |
| `hdi_lo` | MFE20 第 10 百分位 | 0.016 |
| `hdi_hi` | MFE20 第 90 百分位 | 0.358 |
| `oracle_gap_median` | MFE20 中位数 | 0.114 |
| `oracle_gap_p99` | MFE20 第 99 百分位 | 0.818 |
| `hit10_20d` | 20 天内曾涨超 10% 的占比 | 0.55 |
| `dud_rate` | 废票率（MFE20 < 3%） | 0.17 |
| `retention_10` | 曾涨 10% 的票中，20 天后仍盈利 5%+ 的占比 | 0.54 |
| `outcome_dist` | 结局分布 {dud, small, mid, big} | |
| `mfe_cutoffs` | 各 cutoff 到达率 {"5": 0.73, "10": 0.55, ...} | |
| `hit10_by_day` | 时间衰减 {"1": 0.06, "3": 0.21, "5": 0.31, "10": 0.44, "20": 0.55} | |
| `path_fate` | 前 5 天回撤分桶 → hit10 + MFE 中位数 | 见下 |
| `path_quality_3d` | 前 3 天攻守比分桶 → hit10 + 废票率 | 见下 |
| `conditional_mae` | 按结局分桶的 MAE 中位数 | 见下 |
| `new_low_5to10_good` | 好票（hit10）5-10 天还创新低的比例 | 0.26 |
| `new_low_5to10_bad` | 废票 5-10 天还创新低的比例 | 0.72 |
| `peer_high_hit10/dud` | peer >= 9 时的 hit10 和废票率 | |
| `peer_low_hit10/dud` | peer < 5 时的 hit10 和废票率 | |
| `peer_lift_stable` | peer 区分力是否跨年稳定（bool） | |

### path_fate 结构

按信号后 5 天内盘中最深回撤分 5 个桶：

```python
"path_fate": {
    "lt3":   {"pct": 0.24, "hit10": 0.88, "mfe_median": 0.21},   # 回撤 ≤3%
    "3to5":  {"pct": 0.16, "hit10": 0.69, "mfe_median": 0.153},  # 回撤 3-5%
    "5to8":  {"pct": 0.21, "hit10": 0.51, "mfe_median": 0.10},   # 回撤 5-8%
    "8to12": {"pct": 0.20, "hit10": 0.40, "mfe_median": 0.072},  # 回撤 8-12%
    "gt12":  {"pct": 0.18, "hit10": 0.21, "mfe_median": 0.033},  # 回撤 >12%
}
```

### path_quality_3d 结构

按信号后 3 天 MFE/|MAE| 比值（攻守比）分桶：

```python
"path_quality_3d": {
    "lt0.2":   {"pct": 0.22, "hit10": 0.25, "dud": 0.52},  # 跌幅超涨幅 5 倍，过半废票
    "0.2to0.5": {"pct": 0.16, "hit10": 0.35, "dud": 0.27},
    "0.5to1":  {"pct": 0.13, "hit10": 0.47, "dud": 0.08},
    "1to2":    {"pct": 0.14, "hit10": 0.59, "dud": 0.02},
    "gt2":     {"pct": 0.35, "hit10": 0.85, "dud": 0.00},  # 涨幅超跌幅 2 倍，几乎不会废
}
```

### conditional_mae 结构

按 MFE20 结局分桶看过程中的 MAE：

```python
"conditional_mae": {
    "dud":   {"mae_median": -0.196, "mae_5d": -0.114},  # 废票过程中也深跌
    "small": {"mae_median": -0.159, "mae_5d": -0.075},
    "mid":   {"mae_median": -0.100, "mae_5d": -0.049},
    "big":   {"mae_median": -0.052, "mae_5d": -0.034},  # 大肉路径干净
}
```

---

## 4. Pool Baseline（A/B 对比）

方法：在每个信号日，对比触发信号的票 vs 同日同池未触发信号的票。200 个采样日 × 757 只池内股票。

| 窗口 | 信号票 hit5 | 非信号票 hit5 | 信号票 hit10 | 非信号票 hit10 |
|:--:|:-:|:-:|:-:|:-:|
| 5 天 | 58% | 38% | 34% | 16% |
| 10 天 | 66% | 52% | 45% | 27% |
| 20 天 | 75% | 65% | 56% | 42% |

信号超额在 5 天窗口最大（hit10 +18pp），到 20 天收窄至 +14pp。

当前 `POOL_BASELINE` 硬编码值（20 天窗口）：
- `hit10_20d`: 0.404
- `hit5_20d`: 0.638
- `mfe20_mean`: 0.115

---

## 5. 关键发现

### 最有区分力的维度（按 hit10 spread 排序）

1. **MFE Day1**（spread 59pp）：次日盘中冲高 10%+ 的票，100% 最终涨过 10%；不到 2% 的，1/3 是废票
2. **攻守比 Day3**（spread 55pp）：MFE3/|MAE3| > 2 的票，84% hit10，废票 0%；< 0.2 的，52% 废票
3. **前 5 天回撤深度**（spread 63pp）：回撤 ≤3% 的 85% hit10；>12% 的只有 22%
4. **收益集中度**（spread 52pp）：MFE3/MFE20 > 90%（涨幅全在前 3 天）的票，23% hit10，cr20 中位 -12%——全吐回去
5. **前 5 天波动幅度**（spread 50pp）：MFE5-MAE5 > 20% 的票（剧烈波动），77% hit10

### 信号类型间差异小

四种主要信号类型（trend_spear, attack, arb, post_limit）在大部分指标上差异只有 2-5pp。真正有区分力的是**路径形态**（前 3-5 天的涨跌走势），不是信号类型。

### Peer 联动

**绝对 peer（当前实现）的问题**：`peer_confirmation` 是同板块同日触发信号的绝对数量。但一个 500 只票的大板块有 10 只联动（2%）和一个 20 只票的小板块有 10 只联动（50%）含义完全不同。

**注意**：oracle backtest 用 `--disable-env-mapping` 跑的数据中，所有票的 `theme_label` 都是"其他"，peer 实际衡量的是**全池信号密度**而非板块联动。需要用 enable env mapping 的回测数据（`oracle_YYYY_50-150cyc_dlh_env/`）才能正确分析板块联动。

**peer_ratio（归一化版本）验证结果**（基于 env mapping 数据，12,552 信号，163 个板块）：

- 绝对 peer spread：3.1pp（几乎没用）
- peer_ratio spread：8.4pp（好一些但不大）
- **唯一有显著区分力的信号类型是 arb**：ratio<5% hit10=36%（比 baseline 还低！），ratio>5% 约 52-53%，spread 17pp
- attack/trend_spear/post_limit 的 peer_ratio spread 都在 3-5pp

**arb peer_ratio 跨年稳定性**（ratio>15% vs ratio<5%）：

| 年 | ratio>15% | ratio<5% | 差值 | 方向 |
|:--:|:--:|:--:|:--:|:--|
| 2019 | 46% | 17% | +29pp | HIGH |
| 2020 | 47% | 26% | +21pp | HIGH |
| 2021 | 45% | 48% | -3pp | 反转 |
| 2022 | 59% | 39% | +19pp | HIGH |
| 2024 | 64% | 44% | +20pp | HIGH |
| 2025 | 53% | 46% | +7pp | HIGH |

6 年中 5 年方向一致。arb peer_ratio 5% 是自然分界线：低于此的 arb 信号质量不如随机选票。

### 逃命信号

631 个 escape（risk_off）信号：触发后次日 57% 收跌，5 天 62% 收跌（MAE 中位 -7.7%），20 天 65% 收跌（MAE 中位 -12.8%）。84% 在 20 天内至少跌过 5%。

### 止损误杀率

| 止损线 | 误杀好票（曾涨 10%+）的比例 |
|:--:|:--:|
| -3% | 80% |
| -5% | 65% |
| -8% | 45% |
| -10% | 35% |
| -15% | 17% |

---

## 6. Dashboard 展示

每张 oracle 卡片包含：
- 标题行：信号类型 + 样本量 + hit10 率
- 描述：行动指导文案
- 攻守比段落（path_quality_3d）：文字描述，84% 绿色加粗，"超过一半废票"红色加粗
- 废票率 + 留存率
- 板块联动（仅 peer_lift_stable 时显示）
- Path Fate：5 行渐变条（回撤分桶 → hit10 概率）+ 新低段落
- MFE Cutoff Bar：曾涨 +5/10/15/20%
- Outcome Distribution Bar：废票/小肉/中肉/大肉

顶部描述：信号数 + hit10 率 + 逃命信号统计

年份选择器允许动态聚合不同年份的 oracle 数据（加权平均 by 样本数）。
