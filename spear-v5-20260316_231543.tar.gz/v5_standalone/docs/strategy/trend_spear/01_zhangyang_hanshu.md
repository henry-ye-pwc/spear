# "张扬含蓄" —— 量价形态的核心判别

> 数据基础：3930 笔 trend_spear 交易（多年份、多批次）

---

## 1.1 定义

"张扬含蓄"是一种量价哲学，用于判断当前放量行为是"进攻蓄力"还是"出货逃跑"。

核心含义：

> **承上启下的位置，上方在大刀阔斧地运行，而它下面对应的量，则是上涨放量，但相对之前的高量又是缩量（张扬），表明吃货态度；下跌相对当前又是缩量（含蓄），表明目前价格没有出货。**

## 1.2 三层结构

| 层 | 名称 | 价格行为 | 量能行为 | 含义 |
|---|---|---|---|---|
| 1 | **张（扬）** | 价格在上涨/冲击高点 | 有量，是放量的 | 有资金在推动 |
| 2 | **蓄（含蓄）** | — | 但量没超过历史峰值 | 不是出货式爆量 |
| 3 | **含（含蓄）** | 回调/下跌时 | 量明显萎缩 | 没人在逃跑 |

**直觉**：有人在用力推门，但推得很从容，没有使出吃奶的力气。

## 1.3 场景表现

| 场景 | "张扬"表现 | "含蓄"表现 |
|---|---|---|
| 二板 | 封板放量 = 进攻确认 | 量不是天量/发烧的量 |
| 三板位置放量 | 放量 = 进攻明确 | 没有出货迹象 |
| 四板炸板后回封 | 坚决回封 | 回封时量没有超过之前的量 |
| 趋势枪 | 上涨有量 = 有资金推 | 比前高量小 + 回调无量 |
| 套利枪多次测试 | 长枪试探高位 | 量表现的非常含蓄 |
| 分时级别 | 分时活跃 | 日线对应缩量或微放量 |

## 1.4 反面（失败模式）

| 失败模式 | 特征 | 结果 |
|---|---|---|
| **只张扬不含蓄** | 量到了近2倍，但价顾废（不涨或收阴） | 出货 |
| **爆量 > 2x** | 日线量达历史最大量 | 逃命信号 |
| **双爆量** | 分时爆量 + 日线也爆量 | 逃跑的前兆 |
| **高位横盘后砸** | 高位横盘近两小时后直接尾盘砸 | 出货完成 |

## 1.5 量化建模

### 为什么不能用均值？

量（volume/amount）的分布特性：
- **有下界**：最小为 0
- **无上界**：极端情况可以是正常水平的 10x-100x
- **右偏分布**：典型的对数正态分布，outlier 出现在右侧
- **均值被 outlier 严重拉高**，不能代表"大多数时候的量"

**统计学上反映"占比最多的区间"的正确指标**：

| 方法 | 公式 | 含义 | 适合场景 |
|---|---|---|---|
| **中位数 (median)** | P50 | 一半天数在此之上，一半在此之下 | 最稳健的"典型量"代理 |
| **IQR (四分位距)** | P75 - P25 | 中间 50% 数据的范围 | 衡量正常波动范围 |
| **百分位 (percentile)** | P75, P90 | 高位分界线 | 定义"放量"的阈值 |
| **对数变换后的均值** | exp(mean(log(vol))) | 几何平均数 | 消除右偏的稳健中心 |

**结论：用 median 作为基准线，用 P90 / P95 作为"放量"判定，用 2x P90 作为"爆量"判定。**

### 观察窗口设定

| 窗口 | 用途 | 长度 |
|---|---|---|
| **近期窗口 N** | 当前量价状态 | 10 个交易日 |
| **历史基准窗口 M** | 历史量的 baseline | 60 个交易日 |
| **极端参考窗口 L** | 检测历史爆量 | 120 个交易日 |

### Pseudo-code：张扬含蓄判定

```python
def zhangyang_hanshu(bars, N=10, M=60, L=120):
    """
    输入: 日线 bars，包含 OHLCV
    输出: score (bool), details (dict)
    """
    recent = bars[-N:]       # 最近 N 天
    hist = bars[-M:]         # 历史 M 天
    long_hist = bars[-L:]    # 长历史 L 天

    # --- 分离涨日/跌日 ---
    up_days = [b for b in recent if b.close > b.open]
    down_days = [b for b in recent if b.close < b.open]

    # --- 核心量用 median，不用 mean ---
    vol_up_median = median([b.volume for b in up_days])
    vol_down_median = median([b.volume for b in down_days])
    vol_hist_median = median([b.volume for b in hist])
    vol_hist_p90 = percentile([b.volume for b in hist], 90)
    vol_long_p95 = percentile([b.volume for b in long_hist], 95)

    # ============================
    # 层1: 张（上涨有量）
    # ============================
    # 涨日的中位量 > 跌日的中位量 × 1.2
    # 含义: 上涨时有资金在推动
    zhang = vol_up_median > vol_down_median * 1.2

    # ============================
    # 层2: 蓄（量不爆）
    # ============================
    # 近期最大量 < 历史 P90 × α (α=1.5~2.0)
    # 含义: 放量但没有失控，不是出货
    max_recent_vol = max([b.volume for b in recent])
    xu = max_recent_vol < vol_hist_p90 * 1.8

    # 极端爆量排除: 任何单日 > 长期 P95 × 2.0 → 立即失败
    any_explosive = any(b.volume > vol_long_p95 * 2.0 for b in recent)
    xu = xu and not any_explosive

    # ============================
    # 层3: 含（回调缩量）
    # ============================
    # 跌日中位量 < 涨日中位量 × β (β=0.5~0.7)
    # 含义: 跌时没人逃跑
    han = vol_down_median < vol_up_median * 0.6

    # ============================
    # 额外排除: 量价背离
    # ============================
    # 如果量暴增但价格不涨 → "张扬但价顾废"
    recent_vol_ratio = vol_up_median / vol_hist_median
    recent_price_gain = (recent[-1].close - recent[0].open) / recent[0].open
    vol_price_divergence = (recent_vol_ratio > 2.0) and (recent_price_gain < 0.02)

    score = zhang and xu and han and not vol_price_divergence

    return score, {
        "zhang_ratio": vol_up_median / vol_down_median,
        "xu_ratio": max_recent_vol / vol_hist_p90,
        "han_ratio": vol_down_median / vol_up_median,
        "explosive": any_explosive,
        "vol_price_divergence": vol_price_divergence,
    }
```

### 为什么用 median + percentile 而不是 mean？

回测数据实证（3930 笔 trend_spear 交易）：

- 有板交易的持仓期中位日量比 = 入场前60天 median 的 **2.26x**
- 无板交易的持仓期中位日量比 = 入场前60天 median 的 **1.45x**
- 差异在 median 口径下**清晰可分**（2.26 vs 1.45）

如果用 mean，这个差异会被少数爆量天拉平，区分度变差。
