# 可优化项（IO 重构后）

在完成 DuckDB + Parquet 报告 + Feather 特征缓存 + 并行预加载后，以下方向仍可继续优化。

---

## 1. 计算热点（优先）

### 1.1 Phase C 线程数

- **现状**：`n_threads = min(4, os.cpu_count())`，Phase C 约 10s，占 prepare 大部分时间。
- **建议**：改为 `min(n_threads, len(feature_symbols))` 且 `n_threads = os.cpu_count() or 4`（或 `cpu_count() - 1`），在 8+ 核机器上可缩短 Phase C。
- **位置**：`v5/backtest/prepare.py` 中 `_run_phase_c_parallel` 的调用处（约 441 行）。

### 1.2 Phase A+B 的 ProcessPool chunksize

- **现状**：`chunksize=4`，755 个 symbol 约 189 个 chunk，进程间通信有一定开销。
- **建议**：可尝试 `chunksize=8` 或 `max(4, len(symbols_list) // (n_workers * 4))`，在减少 IPC 次数的同时保持负载均衡。
- **位置**：`v5/backtest/prepare.py` 第 355 行 `pool.map(..., chunksize=4)`。

### 1.3 LHB 缓存构建

- **现状**：在 Phase C 前于主进程对「有信号或主题活跃」的 (symbol, date) 逐个算 `env.recent_lhb_net_sell`，可能较慢。
- **建议**：若 LHB 数据可向量化，改为按 symbol 或 date 批量查询；或把 LHB 预计算放入 Phase C 的 thread batch，避免主进程单线程扫。
- **位置**：`v5/backtest/prepare.py` 约 414–426 行。

---

## 2. I/O 与内存

### 2.1 报告写入并行化

- **现状**：`write_reports` 中多个 `to_parquet` 串行执行（trades, events, closed_trades, event_summary 等）。
- **建议**：用 `ThreadPoolExecutor` 并行写互不依赖的 Parquet（例如 trades / events / closed_trades / event_summary / exit_summary / diagnosis_summary），最后再写 summary.json / overview。写盘为 I/O 型，并行通常有收益。
- **位置**：`v5/reports/writer.py` 第 85–92 行。

### 2.2 特征预加载线程数

- **现状**：`ThreadPoolExecutor(max_workers=8)` 固定。
- **建议**：改为 `min(16, (os.cpu_count() or 4) * 2)` 或由配置/环境变量控制，SSD/NVMe 上可适当提高。
- **位置**：`v5/backtest/prepare.py` 第 326 行。

### 2.3 DuckDB 大批量读取

- **现状**：`read_bars_multi(symbols)` 一次查全部 symbol，755 个约 0.9s，可接受。
- **建议**：若 pool 常达到 2000+，可考虑按批（如 500 一批）查询并合并，避免单次结果过大；当前规模可不改。

---

## 3. 数值与精度（需谨慎）

### 3.1 保守的 float32

- **现状**：全量 float32 已回退（信号/收益差异过大）。
- **建议**：仅对「仅用于展示或非关键比较」的列用 float32，例如：
  - 在 `store.read_bars` 仅把 `volume`、`amount` 转为 float32，OHLC 保持 float64；或
  - 仅在报告层对部分统计列 downcast，回测与特征路径保持 float64。
- **前提**：每次改动后做小范围回测对比，确认交易数/收益一致。

---

## 4. 可观测与调优

### 4.1 分段计时

- **建议**：在 prepare 各阶段（DuckDB 读、预加载、Phase A+B、Phase C）和 backtest 循环打点计时，通过环境变量（如 `V5_TIMING=1`）或配置开关输出，便于定位瓶颈。
- **位置**：`v5/backtest/prepare.py` 的 `prepare_bundle`、`v5/backtest/runner.py` 的 `run_backtest`。

### 4.2 特征缓存命中率

- **建议**：在预加载或 Phase A 中统计「从 cache 加载 / 本次计算」的 symbol 数，打 log 或写入 meta，便于判断缓存效果与 invalidation 策略。

---

## 5. 其他

### 5.1 报告层只传必要 bars

- **现状**：`enrich_closed_trades_with_path_stats`、`build_trade_master_table` 接收完整 `bundle.feature_data`（所有 symbol）。
- **建议**：若 closed 数量远小于 symbol 数，可只传入 `closed["symbol"].unique()` 对应的 feature 子集，减少扫描和内存。
- **位置**：`v5/reports/writer.py` 第 71、75–81 行；需检查这两个函数是否依赖「全量 feature_data」的索引或结构。

### 5.2 Backtest 主循环

- **现状**：`for date, symbols_today in schedule.items(): for symbol in symbols_today:` 纯 Python 循环，内部为 dict 查找与 state machine 更新。
- **建议**：中长期可考虑对「按 date 的 OHLC 数组访问」和「仓位/权益更新」用 Numba 或 Cython 写热路径；当前 6s 量级，优先级低于 Phase C 与报告 I/O。

---

## 建议实施顺序

| 优先级 | 项 | 预期收益 | 风险/工作量 |
|--------|----|----------|-------------|
| 高 | Phase C 线程数调大 | 2–4s（约 20–40%） | 低 |
| 高 | 报告 Parquet 并行写 | 0.2–0.5s | 低 |
| 中 | Phase A chunksize 调优 | 0.5–1s | 低 |
| 中 | 特征预加载 workers 可配置 | 小幅 | 低 |
| 中 | LHB 缓存向量化/并行 | 视数据量 | 中 |
| 低 | 保守 float32（仅 volume/amount 或报告） | 内存/带宽 | 需验证 |
| 低 | 分段计时 + 缓存命中率 | 可观测性 | 低 |
