# 用 Rust/C 重写计算的热点与收益评估

基于当前 v5 回测与 prepare 管线，对「将计算热点用 Rust 或 C 重写」的**性能收益**与**实施成本**做简要评估。

---

## 1. 当前计算热点与耗时（概览）

| 阶段 | 位置 | 典型耗时 | 主要操作 |
|------|------|----------|----------|
| **Prepare Phase A+B** | `v5/backtest/prepare.py` | 视 symbol 数/缓存 | 每 symbol：DuckDB/缓存读 → 预处理 → 特征（volume/sequence/structure）→ `count_signals` |
| **Prepare Phase C** | 同上 | **~10s**（文档与注释） | 多线程对 (symbol, date) 跑 `detect_signals`，含 8 种模型 + env 组装 |
| **Backtest 主循环** | `v5/backtest/runner.py` | **~6s**（OPTIMIZATION_OPPORTUNITIES） | 按 date → symbol 循环：数组索引 + `sm.on_day()` + 买卖决策与资金更新 |

- **Phase A** 单 symbol 最重的是特征计算（尤其是 structure/sequence）；**Phase C** 是 prepare 里最突出的单块耗时；**Backtest 主循环** 是纯 Python 的「日期 × 股票」双层循环 + 状态机。

---

## 2. 已做的加速（Numba）

- **`v4/features/structure.py`**  
  - 原纯 Python 循环约 **1500ms/symbol**（约 3200 根 bar），改为 Numba kernel 后约 **15–30ms/symbol**，已是数量级提升。  
  - 注释中明确标注为 Phase A 的最大瓶颈，且已用 Numba 解决。

- **`v4/features/sequence.py`**  
  - 原约 **142ms/symbol**，Numba 后约 **3–8ms/symbol**。

- **`cq_backtest/shared/feature_primitives.py`**  
  - 部分指标使用 `@njit`。

因此，**特征管线里最耗时的数值循环已经用 Numba 推到接近 C 的速度**；再把这些 kernel 单独用 Rust/C 重写，**单阶段收益有限**（大致在 0–20% 量级，且要维护两套实现）。

---

## 3. Rust/C 重写可能带来收益的地方

### 3.1 Prepare Phase C（`detect_signals` 及 8 个模型）

- **现状**：  
  - 对每个 (symbol, date) 调用 `detect_signals()`，内部再调 8 个 `detect_*`（escape, post_limit, failed_board, trend_spear, attack, arb, youzi, sector_spear）。  
  - 每次都是 **pandas**：`frame.iloc[:max_idx+1]`、`frame.iloc[idx].to_dict()`、各模型内 again 的 `frame.iloc[-multi_days:]`、`recent["is_spear"]` 等。  
  - 大量小 DataFrame 切片 + Python 对象创建，GIL 下多线程只能掩盖一部分开销。

- **若用 Rust/C 重写**：  
  - 输入：按 (symbol, date) 预提取的**连续数组**（OHLC、is_spear、amount、ma20 等），而不是 DataFrame。  
  - 输出：结构化事件列表（event_type, confidence, entry_plan, ...）再在 Python 侧封装成现有 `SignalEventV2`。  
  - **预期**：Phase C 从 ~10s 降到 **~2–5s**（约 **2–5x**），主要来自：  
    - 去掉 per-call 的 pandas 索引与 Python 调用；  
    - 更好的缓存局部性；  
    - 无 GIL 的并行（若用 Rust 多线程或 C+OpenMP）。

- **成本**：  
  - 需要把 8 个模型的**业务逻辑**完整 port 到 Rust/C（条件、阈值、lookback 等），并保持与 Python 一致；  
  - 与现有 `PreparedBundle` / `env_ctx` 的接口设计（传数组、收事件）和测试/回归都要做。

### 3.2 Backtest 主循环 + 状态机

- **现状**：  
  - `runner.py` 中已对 OHLC 等做了 `_preextract_ohlc`，内循环是 `arr["open"][idx]` 这类数组访问，**数据层已不是瓶颈**。  
  - 瓶颈在 **`sm.on_day()`**：纯 Python 的状态机（仓位、挂单、止损、再入、trace 等），大量 dict 查找、分支、临时对象。

- **若用 Rust/C 重写**：  
  - 把「按 date 遍历 → 按 symbol 遍历 → 读 bar → 更新状态机 → 写交易/权益」整条热路径放到 Rust/C，用数组 in/out 与 Python 只做一次交换。  
  - **预期**：主循环从 ~6s 降到 **~1.5–3s**（约 **2–4x**）。

- **成本**：  
  - 状态机逻辑复杂（`v4/execution/state_machine.py` 体量很大），分支与策略细节多，port 容易出错且难与现有 Python 行为逐点一致；  
  - 若保留 trace/observability，需要设计好事件回传协议。

### 3.3 特征管线（structure / sequence / volume）

- **现状**：Numba 已把最重循环压到 15–30ms（structure）和 3–8ms（sequence）量级。  
- **用 Rust/C 重写**：  
  - 理论上可再省一点（避免 Numba 的装箱/类型推断），但**边际收益有限**（大致 0–20% 的 Phase A 时间），且要维护 C/Rust 与 Numba 两套实现或全面替换 Numba。  
- **结论**：**不优先**；除非目标是「去 Numba 依赖、单一二进制」，否则性价比低。

---

## 4. 收益与成本汇总（数量级）

| 目标 | 预期加速 | 实施成本 | 建议 |
|------|----------|----------|------|
| Phase C（detect_signals + 8 模型） | **2–5x**（10s → 2–5s） | 高（逻辑 port + 接口 + 回归） | 若 prepare 总时间仍是瓶颈，可做；优先保证接口清晰、可测 |
| Backtest 主循环 + 状态机 | **2–4x**（6s → 1.5–3s） | 很高（状态机复杂、行为一致性与 trace） | 仅当回测循环是主要痛点且愿意长期维护 C/Rust 状态机时考虑 |
| 特征 structure/sequence | **0–20%**（已 Numba） | 中（重写 + 双实现或替换） | 不优先 |

---

## 5. 替代方案与实施顺序

在动 Rust/C 之前，更划算的做法是：

1. **先做文档里已列出的低成本优化**（`docs/architecture/OPTIMIZATION_OPPORTUNITIES.md`）：  
   - 提高 Phase C 线程数（例如 `n_threads = min(n_threads, len(feature_symbols))` 且 `n_threads = os.cpu_count() or 4`），预期可省 2–4s。  
   - 报告 Parquet 并行写、Phase A chunksize 调优等。

2. **若仍要「类 C 性能」且希望尽量少改接口**：  
   - **Cython**：  
     - 把 Phase C 的「单次 (symbol, date) 检测」做成 Cython 函数，输入为 memoryview 的数组，输出为 C 结构体再由 Python 转成 `SignalEventV2`；  
     - 或把 backtest 内循环「读 bar → 更新仓位/现金 → 写一条 trade」做成 Cython 扩展，状态机仍保留在 Python（只把最内层算术与写结果下放到 C）。  
   - **更多 Numba**：  
     - 在 `detect_*` 中把「仅依赖数组、无复杂 Python 对象」的判定（如 trend_spear 的 gate、atr_stop）抽成 `@njit` 函数，由 Python 侧传 `frame.xxx.values` 调用；收益小于完整 Rust Phase C，但工作量也小很多。

3. **只有在**「prepare 或 backtest 仍明显是整体链路瓶颈」且「愿意承担长期维护」时，再考虑：  
   - **Rust**：Phase C 的 detect 管线（pyo3 暴露一个函数，传入预提取数组，返回事件列表）；  
   - **C**：同上，用 C extension 或 ctypes/cffi；  
   - Backtest 状态机用 Rust/C 重写仅作**远期选项**，且建议从「最小可测单元」（例如单日、单 symbol 的决策与资金更新）开始，再逐步扩大。

---

## 6. 其他优化手段：JIT（Numba 扩展）与 Cython

除「整块用 Rust/C 重写」外，用 **JIT（主要是 Numba）** 和 **Cython** 做增量优化，通常性价比更高。

### 6.1 Numba（JIT）— 在现有基础上的扩展

**已用 Numba 的**：`v4/features/structure.py`、`sequence.py`、`cq_backtest/shared/feature_primitives.py`（rolling_rank_pct、rolling_mad 等）。

**可继续用 Numba 的热点**：

| 位置 | 内容 | 做法 | 预期收益 |
|------|------|------|----------|
| **v4/models/helpers.py** | `trend_city_gate`、`recent_spear_indices`、`recent_event_gate`、`board_after_gate`、`prior_limit_event` 等 | 将「输入为一组 numpy 数组 + 当前下标，输出为标量（gate 价格等）」的逻辑抽成 `@njit` 函数；Python 侧在 `detect_*` 里先取 `frame.xxx.values` 再调该函数 | Phase C 单次调用减少 pandas 索引与 Python 层循环；整体约 **10–30%** Phase C 时间，工作量小 |
| **v4/features/robust.py** | `add_robust_volume_features` 中的 `rolling(...).apply(half_sample_mode, raw=False)` | 在 `feature_primitives.py` 里为 `half_sample_mode` 写 `@njit` 版本，并实现「对整列做 rolling + 逐窗调用」的 Numba 一维循环，替代 pandas `apply` | Phase A 每 symbol 省掉大量 Python 回调；**数十 ms/symbol** 量级（视 bar 数），整体 Phase A 可再降 **5–15%** |
| **v4/models/*.py（各 detect_*）** | 仅依赖「当前行 + 过去 N 行数组」的判定（如 trend_spear 的 gate、atr_stop、median(prev_amounts)） | 把「给定数组 + idx」的纯数值判断写成 `@njit`，返回 bool/float；`detect_*` 仍保留 Python 控制流与 `SignalEventV2` 构造 | 减少 Phase C 内 pandas 切片与 Python 调用次数，约 **10–25%** Phase C |

**注意**：Numba 不支持 DataFrame / dict / 复杂 Python 对象，只适合「数组 in → 标量或小数组 out」的纯数值逻辑；gate、阈值、lookback 计算都符合这一模式。

### 6.2 Cython — 热路径编译为 C 扩展

**特点**：可继续用 Python 类型与 API，只把最内层循环或「整段热路径」用 Cython 写，编译后少掉 Python 解释器与 GIL 开销。

| 目标 | 做法 | 预期收益 | 工作量 |
|------|------|----------|--------|
| **Phase C 单 (symbol, date)** | 新建 Cython 模块：输入为 memoryview 的 OHLC/amount/is_spear 等数组 + `max_idx`，内部用 C 循环实现 8 个模型的「判定 + gate 计算」，输出为 C 结构体或 Python list of dict；Python 侧只做「从 bundle 取数组 → 调 Cython → 把结果转成 SignalEventV2」 | Phase C **约 1.5–3x**（10s → 3–6s），比全 Rust 略小但接口与现有 Python 一致，易做 A/B 对比 | 中高（需把 8 个模型逻辑迁到 Cython，但不必动 runner/prepare 的调用方式） |
| **Backtest 内循环（单日）** | Cython 函数：对「当日所有 symbol」的数组按 index 取 o/h/l/c，顺序调用「仓位/现金更新」的 C 逻辑（状态用 C struct 或 Cython 类），只把「产生交易、写 trace」回传给 Python；或更保守：仅「读 bar + 应用一笔 decision 更新 cash/positions」用 Cython，状态机分支仍留 Python | 主循环 **约 1.5–2.5x**（6s → 2.5–4s） | 高（状态机复杂，需拆出「纯算术+写结果」部分） |

**与 Numba 的取舍**：  
- Numba 适合「小函数、数组进数组出」、无复杂状态；**零构建成本**，改几行加 `@njit` 即可。  
- Cython 适合「整段热路径、需要复杂状态或与现有 C 库交互」；需要写 `.pyx`、配 build，但可逐步把 Phase C / backtest 的一整块搬进去。

### 6.3 其他 JIT / 编译选项（简要）

- **PyPy**：全解释器 JIT，对纯 Python 有加速，但 **numpy/pandas 等 C 扩展** 与 PyPy 的兼容性差，当前科学计算栈一般不推荐用 PyPy 跑本仓库。  
- **JAX**：JIT + 自动微分 + 向量化，需把逻辑写成「纯函数 + 数组运算」，**无 pandas**；适合从零重写一整套因子/信号管线，属于架构级改动，不推荐作为「在现有 pandas 管线上的小改」。  
- **Pythran**：可对部分 Python 子集做编译到 C++，与 Numba 类似但语法限制不同；若团队已有 Pythran 经验可尝试对个别 kernel 做替换，否则优先 Numba/Cython 更稳妥。

### 6.4 建议顺序（JIT + Cython 与 Rust 的搭配）

1. **低成本**：先做 `OPTIMIZATION_OPPORTUNITIES.md` 中的 Phase C 线程数、报告并行写、chunksize 等。  
2. **Numba 扩展**（已实施）：  
   - `cq_backtest/shared/feature_primitives.py`：`half_sample_mode` 的 `@njit` 版本 + `rolling_half_sample_mode`，`v4/features/robust.py` 已改用该函数。  
   - `v4/models/helpers.py`：gate/indices 的 Numba 内核（`_trend_city_gate_nb`、`_board_after_gate_nb`、`_recent_event_gate_nb`、`_prior_limit_event_nb` 等），当 `_HAS_NUMBA` 且 frame 含所需列时自动走 Numba 路径。  
   - 单元测试：`v4/tests/test_numba_optimizations.py`；E2E：`v5/tests/test_e2e_backtest.py`。  
3. **Cython**：若 Phase C 仍是瓶颈，再考虑 Cython 模块封装「单次 (symbol, date) 的 8 模型检测」，保持 Python 侧 API 不变。  
4. **Rust/C**：仅在 Cython 仍不满足或希望单一二进制/无 GIL 时，再上 Rust/C 的 Phase C 或 backtest 重写。

---

## 7. 结论

- **用 Rust/C 重写计算**，能带来明显收益的主要是：  
  - **Prepare Phase C**（~10s → 2–5s），  
  - **Backtest 主循环 + 状态机**（~6s → 1.5–3s）。  
- 特征管线已由 Numba 覆盖，Rust/C 重写收益有限（0–20%），不建议优先。  
- **JIT（Numba）**：在 helpers 的 gate/indices、robust 的 rolling、以及各 detect_* 的纯数值判定上扩展 Numba，可再带来约 **10–30% Phase C**、**5–15% Phase A**，工作量小。  
- **Cython**：把 Phase C 单次检测或 backtest 内循环整段写成 Cython，可获得约 **1.5–3x** 对应阶段加速，且与现有 Python API 兼容，适合作为「不直接上 Rust 前的折中」。  
- 实施前应先做**分段计时**（prepare 各阶段、backtest 主循环）确认当前瓶颈，并完成文档中的**低成本优化**；若仍不足，按 **Numba 扩展 → Cython Phase C → Rust/C（可选）** 的顺序推进。
