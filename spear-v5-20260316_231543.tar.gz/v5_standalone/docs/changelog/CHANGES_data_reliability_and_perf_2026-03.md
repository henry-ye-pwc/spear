# Changes: Data Reliability & Performance Improvements

**Date**: 2026-03-11  
**Scope**: `cq_backtest/data/feed.py`, `v5/backtest/prepare.py`, `v5/data/prefetch_features.py`, `v5/data/providers/mootdx_provider.py`, `v5/daily_signal_job.py`, `v5/run.py`, `package.sh`, `requirements.txt`  
**Status**: Implemented (uncommitted)

---

## 1. Overview

This document covers all non-bug-fix, non-feature changes in the current working copy. These changes fall into three categories:

1. **Data reliability** — hardened mootdx connection, placeholder bar detection, universe fallback
2. **Performance** — feature computation caching (parquet-based)
3. **Infrastructure** — packaging improvements, dependency updates

---

## 2. Data Reliability

### 2.1 Mootdx Connection Fallback Servers

**File**: `cq_backtest/data/feed.py` — `DataFeed._connect()`

**Problem**: `Quotes.factory(market='std')` performs auto-discovery of the "best" 通达信 server (`best_ip`). This occasionally fails entirely (DNS timeout, all tested IPs unreachable), leaving `self.client = None` and forcing the system to use local cache only — which may be stale or empty.

**Fix**: Added a retry loop with 3 hardcoded fallback servers after auto-discovery fails:

```python
_FALLBACK_SERVERS = [
    ('119.147.212.81', 7709),   # 广州
    ('221.194.181.176', 7709),  # 北京
    ('120.76.152.87',  7709),   # 阿里云
]
for attempt, (host, port) in enumerate([('__auto__', 0)] + _FALLBACK_SERVERS):
    try:
        if attempt == 0:
            self.client = Quotes.factory(market='std', timeout=10)
        else:
            self.client = Quotes.factory(market='std', host=host, port=port, timeout=10)
        return
    except Exception as e:
        last_err = e
        continue
```

**Design decisions**:
- Auto-discovery is still attempted first (attempt 0) for optimal server selection.
- Fallback IPs are from the `mootdx` project's known server list. These are stable 通达信 行情 servers.
- Port 7709 is the standard 通达信 TCP market data port.
- Log message now includes which server was used (`自动` vs specific IP).

**Tech debt**:
- Hardcoded IPs may become stale if servers are decommissioned. Consider periodically updating from `mootdx.config.BEST_IP`.
- No health-check ping before connecting — the TCP handshake in `factory()` serves as an implicit health check.

### 2.2 Placeholder Bar Rejection

**File**: `cq_backtest/data/feed.py` — `_cache_exactly_covers_end_date()` and `_cache_covers_end_date()`

**Problem**: Mootdx (通达信) pre-generates daily bars for trading days **before market close**. These "placeholder" bars have:
- `volume = 0` (or very low, < 100)
- `open = high = low = close = previous day's close`

If a signal scan runs during trading hours, these placeholder bars get cached. The cache freshness check sees the bar exists for today's date and returns `True`, preventing a re-fetch when real data becomes available after market close.

**Consequence**: Feature computation uses stale OHLCV data (yesterday's close repeated as today's OHLC, zero volume) → incorrect signals and P&L calculations.

**Fix**: Both cache coverage functions now reject bars with `volume < 100`:

```python
# _cache_exactly_covers_end_date (used for historical backtests)
if last_ts.normalize() == end_ts.normalize():
    last_row = df.iloc[-1]
    if float(last_row.get('volume', 1)) < 100:
        return False  # Placeholder bar — needs re-fetch

# _cache_covers_end_date (used for signal scans)
if last_ts == end_ts and float(last_row.get('volume', 1)) < 100:
    return False
```

**Why volume < 100 and not volume == 0**:
- Most placeholder bars have exactly 0 volume, but some have tiny volumes (1-99 shares) from pre-market matching or auction data.
- Legitimate trading days always have volume >> 100 for stocks in the pool.
- The threshold 100 is conservative enough to catch all placeholders without false positives.

**Design decisions**:
- Only check the **last bar** (the one matching `end_date`). Historical bars are assumed valid.
- The `.get('volume', 1)` default ensures no crash if the DataFrame lacks a `volume` column (defensive).

### 2.3 adj_break Placeholder Filter

**File**: `cq_backtest/data/feed.py` — incremental cache update section (around line 309)

**Problem**: The `adj_break` detection compares overlapping bars between disk cache and freshly-fetched data. If a placeholder bar (V=0, close = prev close) exists in the disk cache, its close price differs from the real close → the comparison detects a "factor change" (`max_dev > 0.005`) → triggers a full refresh even though no actual QFQ factor change occurred.

**Fix**: Exclude placeholder bars from the overlap comparison:

```python
old_vol = disk_df.loc[overlap_idx, 'volume'].astype(float)
valid_mask = old_vol >= 100
valid_overlap = overlap_idx[valid_mask]
if len(valid_overlap) >= 2:
    old_close = disk_df.loc[valid_overlap, 'close'].astype(float)
    new_close = latest.loc[valid_overlap, 'close'].astype(float)
    deviation = ((new_close - old_close) / old_close.replace(0, float('nan'))).abs()
    # ... adj_break detection as before
```

**Impact**: Prevents unnecessary full refreshes when placeholder bars are later replaced with real data. Previously, every first-fetch-after-close for stocks with cached placeholders would trigger a full refresh (~3-5 seconds per stock, ~1500 stocks = hours of wasted I/O).

### 2.4 Universe Fallback to code.txt

**File**: `v5/data/providers/mootdx_provider.py` — `MootdxProvider.load_universe()`

**Problem**: When `self.feed.get_stock_list()` returns `None` or empty (mootdx connection fully failed), the universe is empty → no symbols to process → backtest/scan produces nothing.

**Fix**: Fallback to parsing `code.txt` (the built-in pool file at project root):

```python
if df is None or df.empty:
    from v5.config.pools import ROOT, _extract_symbols
    code_txt = ROOT / "code.txt"
    if code_txt.exists():
        symbols = _extract_symbols(code_txt.read_text(encoding="utf-8", errors="ignore"))
        df = pd.DataFrame({"symbol": symbols, "name": [""] * len(symbols)})
    else:
        return pd.DataFrame(columns=["symbol", "name"])
```

**Limitation**: The fallback universe has no `name` column (all empty strings). Stock names are used for display only, so this is acceptable for backtest/scan execution.

---

## 3. Performance: Feature Computation Cache

### 3.1 Architecture

Feature computation (`preprocess_daily` → `add_robust_volume` → `add_sequence_features` → `add_structure_features`) is the most expensive step in `prepare_bundle()`, taking ~9 minutes for 300 symbols on a 2-core machine. Most of the cost is in `add_sequence_features` and `add_structure_features` (Numba JIT kernels operating on the full bar history).

The feature cache stores computed feature DataFrames as **parquet files** in `{cache_dir}/features/`. Cache key is `{symbol}_{config_hash}.parquet` where `config_hash` is an 8-character MD5 of the feature configuration parameters.

### 3.2 Cache Key Design

**File**: `v5/backtest/prepare.py` — `_feature_config_hash()`

```python
def _feature_config_hash(cfg):
    fc = cfg.features
    key = (f"{fc.vol_window}:{fc.sequence_window}:{fc.peak_window}:"
           f"{fc.drawdown_min}:{fc.peak_touch_eps}:{fc.consolidation_window}")
    return hashlib.md5(key.encode()).hexdigest()[:8]
```

The hash includes all `FeatureConfig` parameters that affect the output of `_prepare_frame()`. If any parameter changes, the hash changes, and the cache misses → recomputation.

**What's NOT in the hash**:
- Raw data content (captured by PKL mtime comparison instead)
- Model parameters (those only affect signal detection, not features)
- Execution parameters (don't affect features)

### 3.3 Cache Hit/Miss Logic

**File**: `v5/backtest/prepare.py` — `_load_cached_features()`, `_save_features_cache()`

**Hit conditions** (all must be true):
1. Parquet file exists at `{cache_dir}/features/{symbol}_{hash}.parquet`
2. Parquet mtime >= PKL mtime (features are at least as fresh as raw data)
3. Cached DataFrame covers the full date range of the raw data (`cached.index.max() >= raw.index.max()`)
4. After date-range filtering, at least 120 rows remain (minimum for feature computation)

**Miss → compute + save**:
- Run `_prepare_frame()` as normal
- Save result as parquet (atomic write via `.tmp` + `os.replace`)

**Never cached**:
- Symbols with intraday overlay data (`has_intraday=True`). Intraday data is volatile (changes during trading hours) and would invalidate the cache immediately.

### 3.4 Batch Prefetch

**File**: `v5/data/prefetch_features.py` — `prefetch_features()`

A standalone batch job that pre-computes features for ALL symbols in the PKL cache. Called after `prefetch_symbols()` in both `daily_signal_job.py` and `run.py`.

**Worker model**: Uses `ProcessPoolExecutor` with batched symbols (round-robin distribution). Each worker:
1. Loads PKL data
2. Runs `preprocess_daily` + 3 feature functions
3. Saves parquet to `{cache_dir}/features/`
4. Skips if cache is already fresh (mtime check)

**Config pickling workaround**: Full `V5Config` objects are hard to pickle across process boundaries. The prefetch worker receives a plain `dict` of feature config values and wraps it in a `_FakeCfg` class to satisfy the `_feature_config_hash()` and `_feature_cache_path()` functions.

### 3.5 Integration Points

| File | Change |
|------|--------|
| `v5/backtest/prepare.py` | `_phase_a_worker`: try cached features before `_prepare_frame()`; save after compute. Return tuple includes `cache_hit` flag. `prepare_bundle`: log cache hit stats. |
| `v5/data/prefetch_features.py` | New file: `prefetch_features()` batch worker |
| `v5/daily_signal_job.py` | Calls `prefetch_features()` after `prefetch_symbols()` when `--prefetch` is used |
| `v5/run.py` | Calls `prefetch_features()` after `prefetch_symbols()` when `--prefetch` is used |

### 3.6 Performance Impact

| Metric | Without Cache | With Cache (warm) |
|--------|---------------|-------------------|
| prepare_bundle (300 symbols) | ~9 min (2-core) | ~10-15 sec |
| prefetch_features (first run) | N/A | ~9 min |
| prefetch_features (warm) | N/A | ~5 sec (skip all) |
| Parquet size (per symbol) | N/A | ~100-300 KB |
| Total cache size (1500 symbols) | N/A | ~200-400 MB |

### 3.7 Tech Debt

| ID | Description |
|----|-------------|
| CACHE-001 | Feature cache doesn't include code version in hash. If `preprocess_daily` or feature functions change (e.g., new column, different calculation), cached features are stale but hash matches. **Workaround**: delete `cache/features/` after code changes to feature computation. |
| CACHE-002 | `_FakeCfg` in `prefetch_features.py` duplicates the `FeatureConfig` structure. If a new feature parameter is added to `FeatureConfig`, it must also be added to `_FakeCfg` and the `cfg_features` dict. |
| CACHE-003 | Parquet engine is hardcoded to `pyarrow`. If `pyarrow` is not installed, cache read/write silently fails (caught by except) and falls back to recomputation. No explicit error message. |
| CACHE-004 | Cache invalidation is PKL-mtime-based only. If the PKL file is touched (mtime changes) without content change, the cache is invalidated unnecessarily. |

---

## 4. Infrastructure

### 4.1 Package Script Improvements

**File**: `package.sh`

Changes:
1. **Added ZIP output**: Generates both `.tar.gz` (Linux/macOS) and `.zip` (Windows-friendly)
2. **Common excludes array**: DRY refactor — excludes defined once, used for both tar and zip
3. **macOS metadata stripping**: `xattr -cr` removes extended attributes (com.apple.provenance etc.) before packaging; `COPYFILE_DISABLE=1` prevents `._*` resource fork files from being included
4. **Updated usage instructions**: Shows both tar and zip extraction commands

**Why ZIP was added**: The package is deployed to a Windows server. `.tar.gz` requires third-party tools on Windows; `.zip` is natively supported.

### 4.2 Requirements Update

**File**: `requirements.txt`

| Package | Before | After | Reason |
|---------|--------|-------|--------|
| `numpy` | `>=1.24.0` | `>=2.0.0` | Required by numba 0.59+; also used for array protocol improvements |
| `numba` | not listed | `>=0.59.0` (optional) | JIT-optimized feature kernels in `sequence.py` and `structure.py` |
| `akquant` | required | optional | Not needed for signal scans or feature-only runs |
| `akshare` | optional | optional (unchanged) | — |
| `tqdm` | optional | required | Used in prefetch progress bars |

**Note**: `numba` is marked "optional" in the comment but IS required for the Numba-optimized `_sequence_kernel` and `_structure_kernel`. Without numba, these fall back to the original pure-Python implementations (`_add_sequence_features_original` etc.) which are ~10x slower. The fallback is handled by try/except in the feature modules.

---

## 5. Files Changed Summary

| File | Category | Description |
|------|----------|-------------|
| `cq_backtest/data/feed.py` | Data reliability | Connection fallback servers; placeholder bar rejection; adj_break placeholder filter |
| `v5/backtest/prepare.py` | Performance | Feature cache: load/save helpers; cache-aware `_phase_a_worker`; hit stats logging |
| `v5/data/prefetch_features.py` | Performance | **New file**: batch feature pre-computation worker |
| `v5/daily_signal_job.py` | Performance | Calls `prefetch_features()` after data prefetch |
| `v5/run.py` | Performance | Calls `prefetch_features()` after data prefetch |
| `v5/data/providers/mootdx_provider.py` | Data reliability | Universe fallback to `code.txt` when mootdx stock list unavailable |
| `package.sh` | Infrastructure | Added ZIP output; macOS metadata stripping; common excludes |
| `requirements.txt` | Infrastructure | numpy >=2.0, numba >=0.59, reordered optional deps |
| `v5/backtest/runner.py` | Trivial | Blank line formatting only |

---

## 6. Interaction with Other Changes

- **Feature cache + QFQ fix** (Audit doc): If the PKL cache is rebuilt (cache cleared for QFQ consistency), the feature cache is also invalidated (mtime check: PKL is newer). The next `prepare_bundle` or `prefetch_features` run will recompute all features. This is correct behavior.

- **Feature cache + placeholder fix**: If a placeholder bar was cached in a PKL and later replaced with real data, the PKL mtime updates → feature cache invalidated → features recomputed with real data. No stale features leak through.

- **Connection fallback + universe fallback**: These are independent fallback layers. Even if the connection fallback succeeds (client connected), `get_stock_list()` might still fail (API timeout). The universe fallback handles this separately.
