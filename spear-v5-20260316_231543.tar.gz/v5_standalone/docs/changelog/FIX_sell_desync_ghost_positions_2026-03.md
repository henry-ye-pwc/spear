# Fix: Sell Order Desync & Ghost Positions → 5 Configurable Sell Execution Modes

**Date**: 2026-03-11 (initial), 2026-03-12 (modes implementation)  
**Scope**: `v4/execution/state_machine.py`, `v5/backtest/strategy_host.py`, `v5/config/defaults.py`, `v5/run.py`, `studio_backend/`, `studio_frontend/`  
**Status**: Resolved — 5 configurable sell execution modes  
**Related**: `docs/AUDIT_backtest_inconsistency_2026-03.md`

---

## 1. The Bug

**Symptom**: Backtest produces 5 open positions despite `max_positions=4`.

**Root cause**: In non-realistic execution mode (`_is_realistic() == False`, i.e. `execution_profile=day_level_ideal` with `exit_mode=ideal`), the state machine submits sell orders as **limit orders** at `pos.stop_price` or `pos.take_price`. In akquant's `CurrentClose` execution mode, orders can only fill at the bar's close price. When `close < stop_price` (or `close < take_price`), the limit sell cannot fill. But the state machine has already **popped** the position. Result: a "ghost position" held in akquant but invisible to the state machine.

### Detailed Mechanism

```
Day N: state machine processes symbol A
  1. low <= stop_price → stop_loss triggered
  2. Decision("sell", A, stop_price=368.66, qty, "stop_loss")
  3. self.positions.pop(A)                    ← position gone from state machine
  4. self.cooldowns[A] = d_idx + 3
  5. _submit_decision → self.sell(A, qty, price=368.66)   ← limit sell at 368.66

Day N (same bar): akquant processes the limit sell
  - CurrentClose mode: only fills at close
  - close = 341.50
  - Limit sell means "sell at >= 368.66"
  - 341.50 < 368.66 → ORDER CANNOT FILL
  - Position A still held in akquant

Day N (same bar loop): state machine processes symbol B
  - _can_open: len(positions)=3 (A was popped) → 3 < 4 → allowed
  - Buys B → positions = {B, C, D, E} = 4

Net result:
  - State machine: {B, C, D, E} = 4 positions ✓
  - akquant: {A, B, C, D, E} = 5 positions ✗
  - A is a "ghost position" — held in akquant, invisible to state machine
  - No exit management for A: no stop, no take, no time_exit — pure buy-and-hold
```

### Why Ghost Positions Inflate Returns

In a bull market, ghost positions accidentally become "diamond hands":
- No stop-loss → rides through dips
- No take-profit → no premature exit
- No time-exit → holds indefinitely
- Effectively buy-and-hold → can outperform active management

This explains the ~99% backtest return which dropped to ~35-50% when early fix iterations eliminated ghost behavior.

### akquant CurrentClose Execution Semantics

From akquant docs: "CurrentClose: Signals are matched immediately at the Close of the current Bar."

| Sell Type | Limit Price | Close vs Limit | Result |
|-----------|-------------|----------------|--------|
| Limit sell | P | close >= P | **Filled** at P |
| Limit sell | P | close < P | **Cannot fill** — ghost |
| Market sell | None | any | **Filled** at close |

### Which Sell Paths Are Affected

Only non-realistic sells with `price != close` can produce ghosts:

| Reason | Price Used | Ghost Possible? |
|--------|-----------|-----------------|
| `stop_loss` | `pos.stop_price` | YES — close may recover above stop intraday |
| `take_profit` | `pos.take_price` | YES — close may drop below take intraday |
| `no_premium` | `close` | No |
| `failed_continuation` | `close` | No |
| `theme_collapse` | `close` | No |
| `rebreak` | `close` | No |
| `time_exit` | `close` | No |
| `escape_risk_off` | `close` | No |

---

## 2. Fix History (Iterations 1-3, all reverted or superseded)

### Iteration 1: Deferred Sell (REVERTED)

**Approach**: Don't pop positions on sell trigger. Mark as "deferred", pop on next trading day.

**Why reverted**: Too aggressive — deferred positions block same-day sell+buy, changed trade sequence, returns dropped beyond ghost-removal explanation. Wrong layer — bug is in execution semantics, not state machine logic.

### Iteration 2: Market Order for All Sells (REVERTED)

**Approach**: Submit all sell orders as market orders in `strategy_host._submit_decision`.

**Why reverted**: Changed all sell fill prices to close. Eliminated ghost phenomenon entirely, which was an overcorrection. Returns changed dramatically because ALL sells (not just ghost-producing ones) now filled at different prices.

### Iteration 3: on_order Rejection Handling (SUPERSEDED)

**Approach**: When akquant's `on_order` callback reports a non-filled sell, restore the position to state machine from a saved snapshot.

**Why superseded**:
1. **akquant may not call `on_order` for unfilled orders at all** — the callback is not guaranteed for rejected/expired orders
2. **Infinite loop**: Even if the position is restored, next day `low <= stop_price` re-triggers, submitting the same unfillable limit sell. This repeats forever because stop_loss evaluation precedes time_exit in the code. The position never reaches time_exit.

---

## 3. Final Solution: 5 Configurable Sell Execution Modes

Instead of a single fix, the sell execution behavior is now a **configurable parameter** (`sell_execution_mode`). This lets the user choose the trade-off between execution realism, ghost prevention, and returns.

**Config field**: `V5Config.execution.sell_execution_mode`  
**Default**: `close_price`  
**CLI**: `--sell-execution-mode {ghost_allow,close_price,market_at_host,deferred_pop,hybrid}`

### Mode 1: `ghost_allow` — Original Behavior

```
State machine: Decision("sell", sym, pos.stop_price) → pop + cooldown
Strategy host: self.sell(sym, qty, price=stop_price)  # limit sell
akquant: close < stop_price → cannot fill → GHOST
```

- **Changes**: None (current code path when mode is ghost_allow)
- **Ghost possible**: YES
- **Use case**: Reproduce pre-fix behavior, compare with other modes

### Mode 2: `close_price` — Fix at State Machine (DEFAULT)

```
State machine: Decision("sell", sym, close) → pop + cooldown
                                      ^^^^^ changed from stop_price/take_price
Strategy host: self.sell(sym, qty, price=close)  # limit sell at close
akquant: close == close → ALWAYS FILLS
```

- **Changes**: `v4/execution/state_machine.py` — `_sell_price()` helper returns `close` instead of original price
- **Ghost possible**: NO
- **Trade-off**: Sell price is always `close`, not `stop_price`/`take_price`. For stop_loss this means selling at a potentially lower price (close < stop when low dipped below stop intraday). For take_profit, selling at a potentially higher price (close > take when close continued rising after hitting take).
- **Semantic**: "Trigger condition determines WHETHER to sell; close price determines AT WHAT PRICE"

### Mode 3: `market_at_host` — Fix at Execution Layer

```
State machine: Decision("sell", sym, pos.stop_price) → pop + cooldown  # unchanged
Strategy host: self.sell(sym, qty)  # NO price → market order
                              ^^^^^ price stripped
akquant: market order → fills at close → ALWAYS FILLS
```

- **Changes**: `v5/backtest/strategy_host.py` — `_submit_decision` strips price for sells
- **Ghost possible**: NO
- **Trade-off**: Same execution result as `close_price`. Difference: Decision still records `stop_price`/`take_price` as the "intended" price (visible in `submitted_orders` audit trail), but actual fill is at close.
- **Semantic**: "Strategy logic preserved in Decision, execution layer adapts to CurrentClose reality"

### Mode 4: `deferred_pop` — Wait for Fill Confirmation

```
State machine: Decision("sell", sym, stop_price) → NO pop, mark _sell_pending
Strategy host: self.sell(sym, qty, price=stop_price) + track order_id

Next day on_bar:
  FILL confirmed → strategy_host calls sm.confirm_sell() → pop + cooldown
  NO fill → strategy_host calls sm.cancel_pending_sell() → clear pending
            position stays → on_day re-evaluates:
              - stop triggers again → another limit sell attempt
              - holding_days increases → eventually time_exit (close, always fills)
              - close recovers → limit sell fills
```

- **Changes**: Both `state_machine.py` and `strategy_host.py`
  - State machine: `_sell_pending: set[str]`, `_do_sell_pop()`, `confirm_sell()`, `cancel_pending_sell()`
  - Strategy host: `_deferred_sell_orders: dict`, `_resolve_pending_sells()`
- **Ghost possible**: NO (temporary — position always held in state machine until confirmed)
- **Trade-off**: Limit sells at original prices (potentially better fills when close >= limit). When close < limit, position re-evaluated next day. Temporary max_positions+N for up to 1 day when multiple sells are pending. Eventually exits via time_exit if limit never fills.
- **Semantic**: "Optimistic limit sell, position tracked until confirmed"

### Mode 5: `hybrid` — Limit Try + Market Fallback

```
State machine: Decision("sell", sym, stop_price) → pop + cooldown (eager, like ghost_allow)
Strategy host: self.sell(sym, qty, price=stop_price) + save position + track attempt count

Next day on_bar (strategy_host._resolve_pending_sells):
  FILL confirmed → clean up, done
  NO fill → restore position to state machine + increment attempt_count
            if attempt_count >= 2 → next sell trigger forced to market (guaranteed fill)
            else → try limit again

Eventually: either limit fills, or market forced after 2 failed attempts
```

- **Changes**: `v5/backtest/strategy_host.py` — `_hybrid_pending`, `_hybrid_attempts`, `_resolve_pending_sells()`
- **Ghost possible**: NO (max 2-day temporary ghost before forced market)
- **Trade-off**: Gets limit price when possible (close >= limit). Falls back to market after 2 failed attempts. Temporary max_positions+N for up to 2 days.
- **Semantic**: "Best-effort limit price with guaranteed market fallback"

---

## 4. Implementation Architecture

### State Machine Changes (`v4/execution/state_machine.py`)

New `__init__` parameter: `sell_execution_mode: str = "close_price"`

Helper methods:

```python
def _sell_price(self, original: float, close: float) -> float:
    """For close_price mode, returns close; otherwise returns original."""
    if self.sell_execution_mode == "close_price":
        return close
    return original

def _do_sell_pop(self, symbol: str, d_idx: int) -> None:
    """Pop position + set cooldown, unless deferred_pop mode."""
    if self.sell_execution_mode == "deferred_pop":
        self._sell_pending.add(symbol)
        return
    self.positions.pop(symbol, None)
    self.cooldowns[symbol] = d_idx + self.cooldown_days

def confirm_sell(self, symbol: str, d_idx: int) -> None:
    """Called by strategy_host when deferred_pop sell is confirmed filled."""
    self._sell_pending.discard(symbol)
    self.positions.pop(symbol, None)
    self.cooldowns[symbol] = d_idx + self.cooldown_days

def cancel_pending_sell(self, symbol: str) -> None:
    """Called by strategy_host when deferred_pop sell expired unfilled."""
    self._sell_pending.discard(symbol)
```

All 8 non-realistic sell paths use `_sell_price()` for stop_loss/take_profit and `_do_sell_pop()` for position removal.

Guard in `on_day`: if symbol in `_sell_pending`, return empty decisions (skip sell evaluation for pending symbols in deferred_pop mode).

### Strategy Host Changes (`v5/backtest/strategy_host.py`)

Tracking state:
```python
self._sell_execution_mode = cfg.execution.sell_execution_mode
self._deferred_sell_orders: dict[str, str] = {}       # deferred_pop: sym → order_id
self._hybrid_pending: dict[str, tuple[str, PositionState]] = {}  # hybrid: sym → (order_id, saved_pos)
self._hybrid_attempts: dict[str, int] = {}             # hybrid: sym → fail count
```

`on_bar`: calls `_resolve_pending_sells(symbol, d_idx)` BEFORE `state_machine.on_day()` to resolve previous day's pending sells.

`_submit_decision`:
- `market_at_host` or `hybrid` (attempts >= 2): forces market order (no price)
- `deferred_pop`: tracks order_id in `_deferred_sell_orders`
- `hybrid`: tracks (order_id, saved_pos) in `_hybrid_pending`

Old `on_order` restore logic (from Iteration 3) **removed** — superseded by `_resolve_pending_sells` which checks `recorded_fills` set to determine fill status.

---

## 5. Pipeline (Full Data Flow)

```
Frontend (BacktestLauncher.tsx)
  sellMode state → payload.sell_execution_mode
    ↓
Backend API (studio_backend/models.py)
  BacktestRequest.sell_execution_mode: SellExecutionMode
    ↓
Task Builder (studio_backend/services/tasks.py)
  cmd.extend(["--sell-execution-mode", payload.sell_execution_mode])
    ↓
CLI (v5/run.py)
  argparse --sell-execution-mode → cfg.execution.sell_execution_mode
    ↓
Runner (v5/backtest/runner.py)
  AKQuantSpearStrategy(bundle, cfg, start) → reads cfg.execution.sell_execution_mode
    ↓
Strategy Host (v5/backtest/strategy_host.py)
  self._sell_execution_mode + passes to V4ExecutionStateMachine(sell_execution_mode=...)
    ↓
State Machine (v4/execution/state_machine.py)
  self.sell_execution_mode → _sell_price(), _do_sell_pop(), _sell_pending guard

Persistence:
  v5/reports/writer.py → meta.json["config"]["sell_execution_mode"]
    ↓
  Frontend applyConfig → restores sellMode from saved config
```

---

## 6. Files Changed (Final State)

| File | Change |
|------|--------|
| `v5/config/defaults.py` | Added `sell_execution_mode: str = "close_price"` to `ExecutionConfig` |
| `v4/execution/state_machine.py` | Added `sell_execution_mode` param, `_sell_pending`, `_sell_price()`, `_do_sell_pop()`, `confirm_sell()`, `cancel_pending_sell()`. All 8 non-realistic sell paths use `_sell_price()` and `_do_sell_pop()`. Guard for deferred pending sells. |
| `v5/backtest/strategy_host.py` | Added `_sell_execution_mode`, deferred/hybrid tracking dicts. `_resolve_pending_sells()`. Modified `_submit_decision()` for market_at_host/hybrid force-market. Removed old on_order restore. |
| `v5/run.py` | Added `--sell-execution-mode` CLI arg |
| `studio_backend/models.py` | Added `SellExecutionMode` type, `sell_execution_mode` field to `BacktestRequest` |
| `studio_backend/services/tasks.py` | Pass `--sell-execution-mode` in `_build_backtest_command` |
| `v5/reports/writer.py` | Added `sell_execution_mode` to `run_config` in `meta.json` |
| `studio_frontend/src/pages/BacktestLauncher.tsx` | `SELL_MODES` constant, `sellMode` state, payload, applyConfig, segmented button UI, CONFIG_LABELS, formatConfigValue, summary row |

---

## 7. Tech Debt

### TD-001: Temporary max_positions+N in deferred_pop and hybrid modes

When sells are pending/unfilled, the portfolio may temporarily exceed max_positions for 1-2 bars. This is inherent to the deferred confirmation approach.

### TD-002: `_deferred_sells` legacy field

The `_deferred_sells: dict[str, int]` from Iteration 1 is still in `__init__` with `# unused, kept for serialization compat`. Can be removed once no pickled state machine objects depend on it.

### TD-003: Sell hunt paths not covered

`_try_sell_hunt_fill` (lines 377, 391) produces limit sells at `open_price`/`target_price`. These are only active when `exit_mode == "hunt_exit"` (which implies `_is_realistic() == True`). The sell_execution_mode only affects the non-realistic path. If needed, sell_hunt paths can be extended later.

### TD-004: Hybrid threshold hardcoded

The hybrid mode forces market after 2 failed limit sell attempts. This threshold is hardcoded in `strategy_host.py` (`self._hybrid_attempts.get(dec.symbol, 0) >= 2`). Could be made configurable if needed.
