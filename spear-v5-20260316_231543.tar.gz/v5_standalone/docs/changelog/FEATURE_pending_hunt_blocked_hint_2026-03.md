# Feature: Pending Hunt Position-Blocked Hint

**Date**: 2026-03-11  
**Scope**: State machine, scanner, frontend  
**Status**: Implemented

---

## 1. Summary

When a pending buy hunt's price enters the trigger zone but can't execute because `max_positions` is full, the hunt is annotated with a **position-blocked hint**. This surfaces in the 挂单预购池 (pending hunt pool) UI as a distinct status badge showing when and why the hunt was blocked.

---

## 2. Motivation

In `delayed_limit_hunt` mode, hunts queue limit buy orders that wait for price to enter a target zone. When the price does enter the zone but all position slots are occupied, the hunt silently fails to fill. The user has no visibility into this — the hunt just shows "等待触发" even though the price was right. This feature makes blocked hunts visible so the user can:

1. Understand why a hunt didn't fill despite favorable price action
2. Gauge how often position limits constrain the strategy
3. Decide whether to increase `max_positions` based on missed opportunities

---

## 3. Implementation

### 3.1 State Machine: `PendingHunt.last_blocked_date`

**File**: `v4/execution/state_machine.py`

Added field to `PendingHunt` dataclass:
```python
@dataclass(slots=True)
class PendingHunt:
    ...
    last_blocked_date: str = ""
```

Modified `_try_hunt_fill` to check price range BEFORE the `_can_open` early return:

```python
def _try_hunt_fill(self, *, date, d_idx, symbol, high, low, cash):
    hunt = self.pending_hunts.get(symbol)
    ...
    # Price range computed BEFORE position check (moved up)
    lower = hunt.target_price * (1.0 - hunt.buffer_pct)
    upper = hunt.target_price * (1.0 + hunt.buffer_pct)

    if not self._can_open(symbol, d_idx):
        if high >= lower and low <= upper:
            hunt.last_blocked_date = date          # ← NEW: annotate
        self._trace(
            "hunt_blocked_max_positions",
            ...,
            in_trigger_zone=high >= lower and low <= upper,  # ← NEW: trace field
        )
        return None
    ...
```

**Key design decision**: The `lower`/`upper` computation was moved ABOVE the `_can_open` check (previously it was below). This reordering is necessary to know whether the price was in range when the position check fails. The computation is cheap (two multiplications) so there's no performance concern.

**`last_blocked_date` semantics**: Records the **most recent** date when the price was in the trigger zone but the buy was blocked. If the hunt triggers on multiple days (all blocked), only the latest date is stored. This is sufficient for the UI hint — the user sees "仓位已满，{date} 曾触发" with the most recent blocked date.

### 3.2 Scanner: Status Override

**File**: `v5/notify/scanner.py`

In the pending hunts loop that builds `PendingHuntItem` objects:

```python
blocked_date = str(getattr(hunt, "last_blocked_date", ""))
pos_blocked = bool(blocked_date)
if pos_blocked and not expired:
    status = f"仓位已满，{blocked_date} 曾触发"
```

**Precedence**: The blocked hint only applies if the hunt is NOT expired. If it's expired, the "已过期" status takes priority (an expired hunt is no longer actionable regardless of past blocking).

### 3.3 Notification Model: New Fields

**File**: `v5/notify/models.py`

```python
@dataclass(slots=True)
class PendingHuntItem:
    ...
    position_blocked: bool = False    # True if hunt was ever blocked by max_positions while in trigger zone
    blocked_date: str = ""            # Most recent date when blocked (YYYY-MM-DD format)
```

### 3.4 Frontend: TypeScript Type & UI

**File**: `studio_frontend/src/lib/api.ts`

```typescript
export interface PendingHuntItem {
  ...
  position_blocked: boolean;
  blocked_date: string;
}
```

**File**: `studio_frontend/src/pages/ResultsExplorer.tsx`

Status badge color coding:

| Condition | Badge Color | Text |
|-----------|-------------|------|
| `expired` | Red (`bg-destructive/15 text-destructive`) | "已过期" |
| `position_blocked && !expired` | Orange (`bg-orange-500/15 text-orange-600`) | "仓位已满，{date} 曾触发" |
| Default (waiting) | Amber (`bg-amber-500/15 text-amber-600`) | "等待触发" |

---

## 4. Files Changed

| File | Change |
|------|--------|
| `v4/execution/state_machine.py` | `PendingHunt.last_blocked_date` field; reordered price range check in `_try_hunt_fill`; added `in_trigger_zone` to trace |
| `v5/notify/models.py` | `PendingHuntItem.position_blocked` and `.blocked_date` fields |
| `v5/notify/scanner.py` | Read `last_blocked_date` from hunt, set status override and new fields |
| `studio_frontend/src/lib/api.ts` | Added `position_blocked` and `blocked_date` to `PendingHuntItem` interface |
| `studio_frontend/src/pages/ResultsExplorer.tsx` | 3-tier badge color logic (red/orange/amber) |

---

## 5. Tech Debt

### TD-001: Only tracks most recent blocked date

If a hunt is blocked on 3-08, then again on 3-09, only 3-09 is stored. A full history (list of blocked dates) would be more informative but adds complexity to the `PendingHunt` dataclass (slots=True, serialization). The single-date approach is sufficient for the current UI.

### TD-002: No blocked count

The hint doesn't track HOW MANY times the hunt was blocked. Adding a `blocked_count: int` field would let the UI show "仓位已满，已错过 3 次触发". Low priority — the blocked_date is informative enough.

### TD-003: Backend-only hint (no Feishu notification)

The hint only appears in the Studio UI. The Feishu webhook notification (`v5/notify/feishu.py`, `v5/notify/templates.py`) does not include pending hunt blocked hints. If the user wants Feishu alerts for blocked hunts, those templates would need updating.

### TD-004: No backtest-mode relevance

This feature is primarily useful for signal scans (forward-looking: "what hunts are pending right now?"). For historical backtests, pending hunts at the end of the backtest period are less actionable. The hint still works in backtest mode but has limited practical value there.
