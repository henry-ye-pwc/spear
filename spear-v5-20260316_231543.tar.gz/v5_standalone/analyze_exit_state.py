import pandas as pd
import json

trades = pd.read_csv("outputs/backtests/ts_stopexp_20260312_2025_dlh_intraday/closed_trades.csv")
trades = trades[trades['entry_reason'] == 'entry:trend_spear'].copy()

# Parse the entry_legs to get entry price, we already have entry_price and exit_price
# Let's check the return at exit
trades['exit_ret'] = trades['exit_price'] / trades['entry_price'] - 1

sold_early = trades[trades['diagnosis'] == '盈利但明显卖早']
sold_good = trades[trades['diagnosis'].isin(['盈利且兑现合理', '盈利且接近MFE高点'])]

print("=== 退出时的状态对比 ===")
print("\n[退出时的实际收益率]")
print(f"Sold early mean exit ret: {sold_early['exit_ret'].mean():.2%}")
print(f"Sold good mean exit ret: {sold_good['exit_ret'].mean():.2%}")

print("\n[退出时的 MFE (到退出那天为止看到的最大利润)]")
# MFE in trades is the post-facto MFE. Wait, is `mfe` the MFE *during the trade* or *overall*?
# In backtesting, `mfe` is usually the maximum excursion DURING the holding period.
print(f"Sold early MFE during hold: {sold_early['mfe'].mean():.2%}")
print(f"Sold good MFE during hold: {sold_good['mfe'].mean():.2%}")

# Let's check if they were close to their MFE when sold
sold_early['dist_from_mfe'] = sold_early['mfe'] - sold_early['exit_ret']
sold_good['dist_from_mfe'] = sold_good['mfe'] - sold_good['exit_ret']

print("\n[退出时距离期间最高点的回撤]")
print(f"Sold early dist from MFE: {sold_early['dist_from_mfe'].mean():.2%}")
print(f"Sold good dist from MFE: {sold_good['dist_from_mfe'].mean():.2%}")
