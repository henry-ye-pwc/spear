import {
  Activity,
  AlertTriangle,
  ArrowDown,
  ArrowUp,
  BarChart3,
  CheckCircle2,
  Crosshair,
  Database,
  Loader2,
  RefreshCcw,
  Search,
  TrendingUp,
} from "lucide-react";
import { useCallback, useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { useApi } from "../hooks/useApi";
import { api, type BacktestStat, type BacktestStatEntry, type ConsistencyCheckResult, type SignalOracleData, type TaskRecord } from "../lib/api";
import { cn, prettyDate } from "../lib/utils";

const PROFILE_SHORT: Record<string, string> = {
  day_level_ideal: "DLI",
  next_open_realistic: "NOR",
  delayed_limit_hunt: "DLH",
};

function hasStats(s: BacktestStat["stats"]): s is BacktestStatEntry {
  return "total_closed" in s && (s as BacktestStatEntry).total_closed > 0;
}

function pct(v: number | undefined, digits = 2): string {
  if (v === undefined || v === null) return "—";
  return `${v >= 0 ? "+" : ""}${v.toFixed(digits)}%`;
}

function money(v: number | undefined): string {
  if (v === undefined || v === null) return "—";
  const abs = Math.abs(v);
  if (abs >= 1e6) return `¥${(v / 1e6).toFixed(2)}M`;
  if (abs >= 1e3) return `¥${(v / 1e3).toFixed(1)}K`;
  return `¥${v.toLocaleString()}`;
}

function retColor(v: number | undefined | null): string {
  if (v === undefined || v === null || v === 0) return "text-muted-foreground";
  return v > 0 ? "text-up" : "text-down";
}

function parsePeriod(cfg: Record<string, unknown>): string {
  const s = String(cfg.start ?? "").slice(0, 4);
  const e = String(cfg.end ?? "").slice(0, 4);
  if (!s) return "—";
  return s === e ? s : `${s}-${e}`;
}


function KPI({
  label,
  value,
  sub,
  icon: Icon,
  color,
}: {
  label: string;
  value: string;
  sub?: string;
  icon: React.ElementType;
  color: string;
}) {
  return (
    <div className="rounded-xl border border-border bg-card p-4 flex items-start gap-3">
      <div className={cn("rounded-lg p-2", color)}>
        <Icon className="h-4 w-4" />
      </div>
      <div className="min-w-0">
        <p className="text-xs text-muted-foreground">{label}</p>
        <p className="text-xl font-bold tracking-tight mt-0.5 tabular-nums">{value}</p>
        {sub && <p className="text-[11px] text-muted-foreground mt-0.5 truncate">{sub}</p>}
      </div>
    </div>
  );
}

function ActiveTaskCard({ task: t, onCleanup }: { task: TaskRecord; onCleanup: () => void }) {
  const p = t.payload;
  const period = p.start && p.end ? `${String(p.start).slice(0, 10)} → ${String(p.end).slice(0, 10)}` : "";
  const profile = PROFILE_SHORT[String(p.execution_profile ?? "")] ?? String(p.execution_profile ?? "");
  const syms = Array.isArray(p.symbols) ? p.symbols as string[] : [];
  const pool = p.pool_name ? String(p.pool_name) : syms.length > 0 ? `${syms.length} symbols` : p.pool ? `Pool ${p.pool}` : "";
  const elapsed = Math.round((Date.now() - new Date(t.created_at).getTime()) / 1000);
  const mins = Math.floor(elapsed / 60);
  const secs = elapsed % 60;
  const isStale = elapsed > 3600;
  const linkTo = t.kind === "signal_scan" ? "/signals" : "/backtest";

  async function handleCancel(e: React.MouseEvent) {
    e.preventDefault();
    e.stopPropagation();
    await api.cancelTask(t.id);
    onCleanup();
  }

  async function handleDelete(e: React.MouseEvent) {
    e.preventDefault();
    e.stopPropagation();
    await api.deleteTask(t.id);
    onCleanup();
  }

  return (
    <div className={cn(
      "flex items-center gap-3 rounded-lg border px-4 py-3",
      isStale ? "border-destructive/30 bg-destructive/5" : "border-warning/30 bg-warning/5",
    )}>
      <div className="relative flex-shrink-0">
        {isStale
          ? <Activity className="h-5 w-5 text-destructive" />
          : <Loader2 className="h-5 w-5 animate-spin text-warning" />}
      </div>
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 text-sm">
          <span className="font-medium">{t.kind === "backtest" ? "回测" : "信号扫描"}</span>
          {period && <span className="text-muted-foreground">{period}</span>}
          {profile && <span className="rounded bg-muted px-1.5 py-0.5 text-[10px] font-medium">{profile}</span>}
          {isStale && <span className="rounded bg-destructive/10 text-destructive px-1.5 py-0.5 text-[10px] font-medium">疑似卡死</span>}
        </div>
        <div className="flex items-center gap-2 text-xs text-muted-foreground mt-0.5">
          <span>{pool}</span>
          <span>·</span>
          <span>{t.status === "running" ? "运行中" : "等待中"}</span>
          <span>·</span>
          <span>{mins > 0 ? `${mins}m ${secs}s` : `${secs}s`}</span>
        </div>
      </div>
      <div className="flex items-center gap-1.5 flex-shrink-0">
        {isStale && (
          <button onClick={handleDelete} className="text-[11px] text-destructive hover:text-destructive/80 font-medium px-2 py-1 rounded hover:bg-destructive/10 transition-colors">
            删除
          </button>
        )}
        <button onClick={handleCancel} className="text-[11px] text-muted-foreground hover:text-foreground font-medium px-2 py-1 rounded hover:bg-muted transition-colors">
          取消
        </button>
        <Link to={linkTo} className="text-[11px] text-primary font-medium px-2 py-1 rounded hover:bg-primary/10 transition-colors">
          查看 →
        </Link>
      </div>
    </div>
  );
}

function DataHealthCard() {
  const [checkResult, setCheckResult] = useState<ConsistencyCheckResult | null>(null);
  const [checking, setChecking] = useState(false);
  const [refreshTaskId, setRefreshTaskId] = useState<string | null>(null);
  const [refreshTask, setRefreshTask] = useState<TaskRecord | null>(null);

  const handleCheck = useCallback(async () => {
    setChecking(true);
    try {
      const result = await api.consistencyCheck({ sample_size: 30 });
      setCheckResult(result);
    } catch {
      /* ignore */
    } finally {
      setChecking(false);
    }
  }, []);

  const handleFullRefresh = useCallback(async () => {
    try {
      const res = await api.fullRefresh({});
      setRefreshTaskId(res.task_id);
      setRefreshTask({ id: res.task_id, kind: "backtest", status: "pending", created_at: new Date().toISOString(), updated_at: new Date().toISOString(), payload: {} } as TaskRecord);
    } catch {
      /* ignore */
    }
  }, []);

  // Poll refresh task status
  useEffect(() => {
    if (!refreshTaskId) return;
    const interval = setInterval(async () => {
      try {
        const t = await api.task(refreshTaskId);
        setRefreshTask(t as TaskRecord);
        if (t.status === "succeeded" || t.status === "failed") {
          clearInterval(interval);
        }
      } catch {
        clearInterval(interval);
      }
    }, 3000);
    return () => clearInterval(interval);
  }, [refreshTaskId]);

  const r = checkResult;
  const hasIssue = r && r.inconsistent > 0;
  const notMigrated = r && r.qfq_migrated === false;
  const isRefreshing = refreshTask && (refreshTask.status === "pending" || refreshTask.status === "running");
  const refreshDone = refreshTask && refreshTask.status === "succeeded";

  return (
    <div className={cn(
      "rounded-xl border bg-card p-5 space-y-3",
      hasIssue || notMigrated ? "border-warning/50" : "border-border",
    )}>
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Database className="h-4 w-4 text-muted-foreground" />
          <h3 className="font-semibold text-sm">数据健康</h3>
          {r && !hasIssue && !notMigrated && (
            <span className="inline-flex items-center gap-1 text-[11px] text-up font-medium">
              <CheckCircle2 className="h-3 w-3" />前复权一致
            </span>
          )}
          {hasIssue && (
            <span className="inline-flex items-center gap-1 text-[11px] text-warning font-medium">
              <AlertTriangle className="h-3 w-3" />{r.inconsistent}/{r.checked} 只标的历史价格偏差
            </span>
          )}
          {!hasIssue && notMigrated && (
            <span className="inline-flex items-center gap-1 text-[11px] text-warning font-medium">
              <AlertTriangle className="h-3 w-3" />未迁移至前复权
            </span>
          )}
        </div>
        <div className="flex items-center gap-1.5">
          <button
            onClick={handleCheck}
            disabled={checking || !!isRefreshing}
            className="inline-flex items-center gap-1 text-[11px] font-medium px-2.5 py-1 rounded-md border border-border hover:bg-muted transition-colors disabled:opacity-50"
          >
            {checking ? <Loader2 className="h-3 w-3 animate-spin" /> : <Search className="h-3 w-3" />}
            检查一致性
          </button>
          <button
            onClick={handleFullRefresh}
            disabled={!!isRefreshing}
            className="inline-flex items-center gap-1 text-[11px] font-medium px-2.5 py-1 rounded-md border border-border hover:bg-muted transition-colors disabled:opacity-50"
          >
            {isRefreshing ? <Loader2 className="h-3 w-3 animate-spin" /> : <RefreshCcw className="h-3 w-3" />}
            全量刷新
          </button>
        </div>
      </div>

      {/* Explanation when no check has been run */}
      {!r && !checking && !isRefreshing && (
        <div className="text-[11px] text-muted-foreground space-y-1">
          <p>
            缓存的 K 线数据必须使用一致的<b>前复权</b>（qfq）才能保证回测和信号扫描结果可复现。
          </p>
          <p>
            「检查一致性」会抽检缓存中的<b>历史价格</b>（非近期），与 mootdx 最新前复权数据对比。
            若偏差 &gt;0.5% 则判定为复权因子已变化或缓存包含不复权数据，需要全量刷新。
          </p>
        </div>
      )}

      {/* Check results */}
      {r && (
        <div className="space-y-2">
          <div className="flex flex-wrap gap-x-5 gap-y-1 text-[11px] text-muted-foreground">
            <span>缓存: {r.total_cached} 只标的</span>
            <span>抽检: {r.checked} 只（对比历史价格）</span>
            <span>一致: {r.consistent}</span>
            <span>偏差: {r.inconsistent}</span>
            {(r.errors ?? 0) > 0 && <span className="text-destructive">错误: {r.errors}</span>}
            {r.newest_update && <span>最新更新: {prettyDate(r.newest_update)}</span>}
          </div>

          {/* Migration warning */}
          {notMigrated && !hasIssue && (
            <div className="rounded-lg bg-amber-500/5 border border-amber-500/20 p-3 text-[11px] text-amber-700 dark:text-amber-400 space-y-1">
              <p className="font-medium flex items-center gap-1.5">
                <AlertTriangle className="h-3.5 w-3.5 shrink-0" />
                缓存尚未标记为前复权迁移完成
              </p>
              <p className="text-amber-600/80 dark:text-amber-400/70">
                即使抽检一致，建议执行一次「全量刷新」以确保所有标的的完整历史均为前复权数据，
                并写入迁移标记。刷新后新的增量更新会自动检测复权因子变化。
              </p>
            </div>
          )}

          {/* Inconsistent symbols */}
          {hasIssue && (
            <div className="rounded-lg bg-warning/5 border border-warning/20 p-3 space-y-1.5">
              <p className="text-[11px] text-warning font-medium">
                以下标的的缓存历史价格与最新前复权数据存在偏差 (&gt;0.5%)，表明缓存可能包含不复权或混合复权数据：
              </p>
              <div className="flex flex-wrap gap-1.5">
                {r.inconsistent_symbols.map((s) => (
                  <span
                    key={s.symbol}
                    className="inline-flex items-center gap-1 rounded bg-warning/10 px-2 py-0.5 text-[10px] font-mono text-warning"
                    title={`偏差 ${s.max_deviation_pct.toFixed(1)}%, 更新于 ${prettyDate(s.last_pkl_update)}`}
                  >
                    {s.symbol}
                    <span className="text-warning/70">{s.max_deviation_pct.toFixed(1)}%</span>
                  </span>
                ))}
              </div>
              <p className="text-[10px] text-warning/70 mt-1">
                建议点击「全量刷新」重新拉取所有标的的前复权数据，刷新后回测结果将可复现。
              </p>
            </div>
          )}

          {/* All consistent */}
          {!hasIssue && !notMigrated && (
            <p className="text-[11px] text-up/80">
              抽检 {r.checked} 只标的的历史价格均与最新前复权数据一致，缓存状态健康。
            </p>
          )}
        </div>
      )}

      {/* Refresh progress */}
      {isRefreshing && (
        <div className="flex items-center gap-2 rounded-md bg-primary/5 border border-primary/20 px-3 py-2 text-[11px]">
          <Loader2 className="h-3.5 w-3.5 animate-spin text-primary shrink-0" />
          <span className="text-primary font-medium">
            全量刷新进行中...
          </span>
          <span className="text-muted-foreground">
            任务 {refreshTaskId?.slice(0, 8)} · {refreshTask?.status === "running" ? "正在拉取数据" : "等待启动"}
          </span>
        </div>
      )}
      {refreshDone && (
        <div className="flex items-center gap-2 rounded-md bg-emerald-500/10 px-3 py-1.5 text-[11px] text-emerald-700 dark:text-emerald-400">
          <CheckCircle2 className="h-3.5 w-3.5 shrink-0" />
          全量刷新完成，缓存已更新为前复权数据。建议重新「检查一致性」确认。
        </div>
      )}
      {refreshTask?.status === "failed" && (
        <div className="flex items-center gap-2 rounded-md bg-destructive/10 px-3 py-1.5 text-[11px] text-destructive">
          <AlertTriangle className="h-3.5 w-3.5 shrink-0" />
          全量刷新失败，请检查日志 (任务 {refreshTaskId?.slice(0, 8)})
        </div>
      )}
    </div>
  );
}


type SortKey = "name" | "win_rate" | "total_return_pct" | "peak_equity" | "max_drawdown_pct" | "total_closed" | "updated_at";

const EVENT_DISPLAY: Record<string, string> = {
  attack: "进攻长枪",
  arb: "套利长枪",
  trend_spear: "趋势长枪",
  post_limit: "板后长枪",
};

const EVENT_BLURB: Record<string, string> = {
  attack: "放量攻击型信号。路径最干净，冲高后留得住。板块联动是关键区分因子——同板块多票同时异动时质量显著提升。",
  arb: "短节奏套利型机会。板块联动越强质量越高；联动弱时废票率明显上升，需要谨慎。",
  trend_spear: "趋势突破型信号，数量最多。路径空间大但波动剧烈，典型走势是先回踩再上行。不要期待次日就涨——收益在 5~20 天窗口内兑现。",
  post_limit: "涨停板后的延续型机会。有潜力但不确定性最高，样本量也最少。",
};

const DIST_COLORS: Record<string, string> = {
  dud: "bg-destructive/60",
  small: "bg-muted-foreground/40",
  mid: "bg-primary/50",
  big: "bg-success/60",
};

const DIST_LABELS: Record<string, string> = {
  dud: "废票",
  small: "小肉",
  mid: "中肉",
  big: "大肉",
};

function aggregateForYears(etOracle: Record<string, Record<string, unknown>>, years: number[]): Record<string, number> {
  let totalN = 0;
  const sums: Record<string, number> = {};
  for (const y of years) {
    const d = etOracle[String(y)] as Record<string, unknown> | undefined;
    if (!d) continue;
    const n = Number(d.n ?? 0);
    totalN += n;
    for (const [k, v] of Object.entries(d)) {
      if (k === "n") continue;
      if (typeof v === "number") {
        sums[k] = (sums[k] ?? 0) + v * n;
      } else if (typeof v === "boolean") {
        sums[k] = (sums[k] ?? 0) + (v ? 1 : 0) * n;
      } else if (typeof v === "object" && v !== null && !Array.isArray(v)) {
        for (const [sk, sv] of Object.entries(v as Record<string, unknown>)) {
          if (typeof sv === "number") {
            const flat = `${k}.${sk}`;
            sums[flat] = (sums[flat] ?? 0) + sv * n;
          }
        }
      }
    }
  }
  if (totalN === 0) return {};
  const result: Record<string, number> = { n: totalN };
  for (const [k, v] of Object.entries(sums)) result[k] = v / totalN;
  return result;
}

function SignalQualityPanel() {
  const { data: oracle } = useApi<SignalOracleData>(() => api.signalOracle(), []);
  const allYears: number[] = oracle?.meta?.years ?? [];
  const [selectedYears, setSelectedYears] = useState<number[]>([]);

  useEffect(() => {
    if (allYears.length > 0 && selectedYears.length === 0) setSelectedYears([...allYears]);
  }, [allYears]); // eslint-disable-line react-hooks/exhaustive-deps

  if (!oracle?.oracle) return null;

  const types = ["attack", "arb", "trend_spear", "post_limit"];
  const baseline = Number(oracle.pool_baseline?.hit10_20d ?? 0.25);
  const useAll = selectedYears.length === allYears.length;

  function getMetrics(et: string): Record<string, number> {
    const etData = oracle!.oracle[et];
    if (!etData) return {};
    if (useAll) {
      const all = etData._all as unknown as Record<string, unknown>;
      if (!all) return {};
      const result: Record<string, number> = {};
      for (const [k, v] of Object.entries(all)) {
        if (typeof v === "number") result[k] = v;
        else if (typeof v === "boolean") result[k] = v ? 1 : 0;
      }
      return result;
    }
    const agg = aggregateForYears(etData as unknown as Record<string, Record<string, unknown>>, selectedYears);
    const all = etData._all as unknown as Record<string, unknown>;
    if (all) {
      for (const [k, v] of Object.entries(all)) {
        if (typeof v === "boolean" && !(k in agg)) agg[k] = v ? 1 : 0;
      }
    }
    return agg;
  }

  const toggleYear = (y: number) => {
    setSelectedYears((prev) => {
      if (prev.includes(y)) {
        const next = prev.filter((x) => x !== y);
        return next.length > 0 ? next : prev;
      }
      return [...prev, y].sort();
    });
  };

  const totalSignals = types.reduce((s, et) => s + (getMetrics(et).n ?? 0), 0);

  return (
    <div className="rounded-xl border border-border bg-card p-6">
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center gap-2">
          <TrendingUp className="h-5 w-5 text-primary" />
          <h3 className="text-base font-semibold">信号能力概览</h3>
          <span className="text-[10px] text-muted-foreground tabular-nums">{totalSignals.toLocaleString()} 信号</span>
        </div>
        <div className="flex items-center gap-1">
          <span className="text-[10px] text-muted-foreground mr-1">年份</span>
          {allYears.map((y) => (
            <button key={y} onClick={() => toggleYear(y)}
              className={cn("rounded-full px-2.5 py-0.5 text-[10px] font-medium transition-all tabular-nums",
                selectedYears.includes(y) ? "bg-primary text-primary-foreground shadow-sm" : "bg-muted text-muted-foreground hover:bg-accent",
              )}>
              {y}
            </button>
          ))}
        </div>
      </div>
      <div className="text-sm text-muted-foreground mb-5 max-w-3xl leading-relaxed space-y-2">
        <p>
          基于 <span className="font-semibold text-foreground">{totalSignals.toLocaleString()}</span> 个历史信号（{allYears.length > 2 ? `${allYears[0]}-${allYears[allYears.length - 1]}` : allYears.join("/")} 跨牛熊验证）。
          信号选出的票 20 天内能涨到 +10% 的概率是 <span className="font-semibold text-up">{Math.round(types.reduce((s, et) => s + (getMetrics(et).hit10_20d ?? 0) * (getMetrics(et).n ?? 0), 0) / Math.max(totalSignals, 1) * 100)}%</span>。
        </p>
        <p>
          逃命长枪（回避信号）次日收跌概率 <span className="font-semibold text-down">57%</span>，5 天收跌 <span className="font-semibold text-down">62%</span>（最大回撤中位数 -7.7%），20 天收跌 <span className="font-semibold text-down">65%</span>（最大回撤中位数 -12.8%）。
        </p>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {types.map((et) => {
          const o = getMetrics(et);
          if (!o.n) return null;
          const dudRate = o.dud_rate ?? 0;
          const raw = (useAll ? oracle.oracle[et]?._all : oracle.oracle[et]?._all) as unknown as Record<string, unknown> | undefined;
          return (
            <div key={et} className="rounded-lg border border-border p-4">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <span className="text-sm font-semibold">{EVENT_DISPLAY[et] ?? et}</span>
                  <span className="text-[10px] text-muted-foreground tabular-nums">{(o.n ?? 0).toLocaleString()} 个样本</span>
                </div>
                <span className="text-[10px] font-medium text-primary tabular-nums">{((o.hit10_20d ?? 0) * 100).toFixed(0)}% 在 20 天内曾涨超 10%</span>
              </div>
              <p className="text-xs text-muted-foreground leading-relaxed mb-3">
                {EVENT_BLURB[et] ?? ""}
              </p>
              {/* Path Quality Insight */}
              {Boolean(raw?.path_quality_3d) && (() => {
                const pq = raw!.path_quality_3d as Record<string, {pct: number; hit10: number; dud: number}>;
                const bull = pq["gt2"];
                const bear = pq["lt0.2"];
                if (!bull || !bear) return null;
                return (
                  <p className="text-[11px] text-muted-foreground leading-relaxed mb-3">
                    <span className="font-semibold text-foreground">前 3 天攻守比</span>（盘中最高涨幅 ÷ 最深跌幅）是信号后最有预判力的早期指标。攻守比超过
                    2 的票（涨幅是跌幅的两倍以上），<span className="font-semibold text-up">{(bull.hit10 * 100).toFixed(0)}%</span> 最终涨过 10%，几乎不会是废票；攻守比低于
                    0.2 的票（跌幅超过涨幅 5 倍），<span className="font-semibold text-down">超过一半是废票</span>——路径越早走强，终局越好。
                  </p>
                );
              })()}

              {/* Core metrics */}
              <div className="space-y-1.5 text-xs">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">废票率（20 天内从未涨过 3%）</span>
                  <span className="font-medium">{(dudRate * 100).toFixed(0)}%{dudRate > 0 ? `（约每 ${Math.round(1 / dudRate)} 个中 1 个）` : ""}</span>
                </div>
                {(o.retention_10 ?? 0) > 0 && (
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">留存率（曾涨过 10% 的票中，20 天后仍盈利 5%+）</span>
                    <span className="font-medium">{((o.retention_10 ?? 0) * 100).toFixed(0)}%</span>
                  </div>
                )}
                {(o.peer_lift_stable ?? 0) > 0.5 && (
                  <>
                    <div className="mt-1.5 pt-1.5 border-t border-border/30 flex justify-between">
                      <span className="text-muted-foreground">板块联动强时（同板块多票同日异动）</span>
                      <span className="font-medium text-up">{((o.peer_high_hit10 ?? 0) * 100).toFixed(0)}% 曾+10%，废票仅 {((o.peer_high_dud ?? 0) * 100).toFixed(0)}%</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">板块联动弱时（仅个别触发）</span>
                      <span className="font-medium text-muted-foreground">{((o.peer_low_hit10 ?? 0) * 100).toFixed(0)}% 曾+10%，废票 {((o.peer_low_dud ?? 0) * 100).toFixed(0)}%</span>
                    </div>
                  </>
                )}
              </div>

              {/* Path Fate Decision Tree */}
              {Boolean(raw?.path_fate) && (() => {
                const pf = raw!.path_fate as Record<string, {pct: number; hit10: number; mfe_median: number}>;
                const FATE_LABELS: Record<string, string> = {
                  lt3: "回撤 ≤3%", "3to5": "回撤 3-5%", "5to8": "回撤 5-8%",
                  "8to12": "回撤 8-12%", gt12: "回撤 >12%",
                };
                const FATE_HINTS: Record<string, string> = {
                  lt3: "几乎稳了", "3to5": "多数能回来", "5to8": "五五开",
                  "8to12": "开始危险", gt12: "大概率废了",
                };
                const keys = ["lt3", "3to5", "5to8", "8to12", "gt12"].filter((k) => pf[k]);
                if (keys.length === 0) return null;
                return (
                  <div className="mt-2.5 pt-2 border-t border-border/50">
                    <div className="text-[10px] text-muted-foreground mb-1.5">信号后 5 天内盘中最深回撤 vs 20 天内涨过 10% 的概率</div>
                    <div className="space-y-1">
                      {keys.map((k) => {
                        const { pct, hit10: h10, mfe_median: mfm } = pf[k];
                        return (
                          <div key={k} className="flex items-center gap-1.5 text-[10px]" title={`占全部信号的 ${(pct * 100).toFixed(0)}%，该组盘中峰值中位数 +${(mfm * 100).toFixed(0)}%`}>
                            <span className="w-16 text-muted-foreground shrink-0 tabular-nums">{FATE_LABELS[k]}</span>
                            <div className="flex-1 h-2 rounded-full bg-muted/40 overflow-hidden">
                              <div
                                className={cn("h-full rounded-full", h10 >= 0.7 ? "bg-success" : h10 >= 0.5 ? "bg-primary/60" : h10 >= 0.35 ? "bg-warning/60" : "bg-destructive/50")}
                                style={{ width: `${h10 * 100}%` }}
                              />
                            </div>
                            <span className="w-24 text-right font-medium tabular-nums shrink-0">{(h10 * 100).toFixed(0)}% 涨过10%</span>
                          </div>
                        );
                      })}
                    </div>
                    {Boolean(raw?.new_low_5to10_good != null && raw?.new_low_5to10_bad != null) && (
                      <p className="mt-1.5 text-[10px] text-muted-foreground leading-relaxed">
                        如果到了第 5-10 天还在不断创新低，大概率是废票（废票中 <span className="font-medium text-down">{(Number(raw?.new_low_5to10_bad ?? 0) * 100).toFixed(0)}%</span> 仍在跌，而好票只有 <span className="font-medium text-foreground">{(Number(raw?.new_low_5to10_good ?? 0) * 100).toFixed(0)}%</span>）。前 5 天是洗盘还是趋势恶化，第二周的走势会给出答案。
                      </p>
                    )}
                  </div>
                );
              })()}
              {(o["mfe_cutoffs.5"] != null || (useAll && oracle.oracle[et]?._all?.mfe_cutoffs)) && (() => {
                const cuts = useAll
                  ? (oracle.oracle[et]?._all as unknown as Record<string, unknown>)?.mfe_cutoffs as Record<string, number> | undefined
                  : { "5": o["mfe_cutoffs.5"] ?? 0, "10": o["mfe_cutoffs.10"] ?? 0, "15": o["mfe_cutoffs.15"] ?? 0, "20": o["mfe_cutoffs.20"] ?? 0 };
                if (!cuts) return null;
                return (
                  <div className="mt-2.5 pt-2 border-t border-border/50">
                    <div className="text-[10px] text-muted-foreground mb-1">20天内路径曾达到该涨幅的信号占比（各项独立，非累加）</div>
                    <div className="flex gap-2">
                      {["5", "10", "15", "20"].map((pct) => {
                        const rate = cuts[pct] ?? 0;
                        return (
                          <div key={pct} className="flex-1 text-center">
                            <div className={cn("text-xs font-semibold tabular-nums", rate >= 0.5 ? "text-up" : rate >= 0.25 ? "text-foreground" : "text-muted-foreground")}>
                              {(rate * 100).toFixed(0)}%
                            </div>
                            <div className="text-[9px] text-muted-foreground">曾涨+{pct}%</div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                );
              })()}
              {(() => {
                const dist: Record<string, number> = useAll
                  ? ((oracle.oracle[et]?._all as unknown as Record<string, unknown>)?.outcome_dist ?? {}) as Record<string, number>
                  : { dud: o["outcome_dist.dud"] ?? 0, small: o["outcome_dist.small"] ?? 0, mid: o["outcome_dist.mid"] ?? 0, big: o["outcome_dist.big"] ?? 0 };
                const hasAny = ["dud", "small", "mid", "big"].some((k) => (dist[k] ?? 0) > 0);
                if (!hasAny) return null;
                return (
                  <div className="mt-3">
                    <div className="flex h-2.5 w-full rounded-full overflow-hidden">
                      {["dud", "small", "mid", "big"].map((k) => {
                        const v = dist[k] ?? 0;
                        return v > 0 ? (
                          <div key={k} className={cn("h-full", DIST_COLORS[k])} style={{ width: `${v * 100}%` }} title={`${DIST_LABELS[k]}: ${(v * 100).toFixed(0)}%`} />
                        ) : null;
                      })}
                    </div>
                    <div className="flex justify-between text-[9px] text-muted-foreground mt-1">
                      {["dud", "small", "mid", "big"].map((k) => (
                        <span key={k}>{DIST_LABELS[k]} {((dist[k] ?? 0) * 100).toFixed(0)}%</span>
                      ))}
                    </div>
                  </div>
                );
              })()}
            </div>
          );
        })}
      </div>
      <p className="text-[9px] text-muted-foreground/60 mt-3 text-right" title={oracle.meta?.source ?? ""}>
        数据来源: {oracle.meta?.source ?? ""} · 验证于 {oracle.meta?.last_validated ?? ""}
      </p>
    </div>
  );
}

const DASHBOARD_PAGE_SIZE = 20;

export function Dashboard() {
  const [sortKey, setSortKey] = useState<SortKey>("updated_at");
  const [sortDir, setSortDir] = useState<"asc" | "desc">("desc");
  const { data: batchStatsResp, loading: bsLoading } = useApi(
    () => api.batchStats("", 0, DASHBOARD_PAGE_SIZE, sortKey, sortDir),
    [sortKey, sortDir],
  );
  const { data: tasks, loading: tLoading, refetch: refetchTasks } = useApi(() => api.tasks(), []);

  const activeTasks = useMemo(
    () => (tasks ?? []).filter((t) => t.status === "running" || t.status === "pending"),
    [tasks],
  );

  const sorted = batchStatsResp?.items ?? [];

  function handleSort(key: SortKey) {
    if (sortKey === key) {
      setSortDir((d) => (d === "asc" ? "desc" : "asc"));
    } else {
      setSortKey(key);
      setSortDir(key === "name" || key === "updated_at" ? "desc" : "desc");
    }
  }

  function SortHeader({ label, col, className }: { label: string; col: SortKey; className?: string }) {
    const active = sortKey === col;
    return (
      <th
        className={cn("py-2 font-medium cursor-pointer select-none hover:text-foreground transition-colors", active && "text-foreground", className)}
        onClick={() => handleSort(col)}
      >
        <span className="inline-flex items-center gap-0.5">
          {label}
          {active && (sortDir === "asc" ? <ArrowUp className="h-3 w-3" /> : <ArrowDown className="h-3 w-3" />)}
        </span>
      </th>
    );
  }

  if ((bsLoading && !batchStatsResp) || tLoading) {
    return (
      <div className="flex items-center justify-center h-full">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  const isEmpty = !batchStatsResp || batchStatsResp.total === 0;

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">回测绩效总览</h1>
          <p className="text-muted-foreground text-sm mt-1">
            {isEmpty ? "暂无回测数据" : `${batchStatsResp!.total} 次回测 · ${batchStatsResp!.summary.total_trades} 笔交易`}
          </p>
        </div>
        <Link
          to="/backtest"
          className="flex items-center gap-1.5 rounded-lg px-4 py-2 text-sm font-medium bg-primary text-primary-foreground hover:bg-primary/90 transition-colors"
        >
          <BarChart3 className="h-4 w-4" />
          新建回测
        </Link>
      </div>

      {/* Active Tasks */}
      {activeTasks.length > 0 && (
        <div className="space-y-2">
          {activeTasks.map((t) => (
            <ActiveTaskCard key={t.id} task={t} onCleanup={refetchTasks} />
          ))}
        </div>
      )}

      {/* Data Health */}
      <DataHealthCard />

      {isEmpty ? (
        <div className="rounded-xl border border-dashed border-border bg-card p-12 text-center space-y-3">
          <BarChart3 className="h-10 w-10 text-muted-foreground mx-auto" />
          <p className="text-muted-foreground">还没有回测结果，开始你的第一次回测吧</p>
          <Link
            to="/backtest"
            className="inline-flex items-center gap-1.5 rounded-lg px-4 py-2 text-sm font-medium bg-primary text-primary-foreground hover:bg-primary/90 transition-colors"
          >
            启动回测
          </Link>
        </div>
      ) : (
        <>
          {/* Signal Quality Overview */}
          <SignalQualityPanel />

          {/* Quick Actions */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Link
              to="/backtest"
              className="rounded-xl border border-border bg-card p-5 hover:border-primary hover:shadow-md transition-all group"
            >
              <BarChart3 className="h-5 w-5 text-primary mb-2" />
              <p className="font-semibold group-hover:text-primary transition-colors text-sm">启动回测</p>
              <p className="text-xs text-muted-foreground mt-1">使用自定义参数运行新的回测</p>
            </Link>
            <Link
              to="/signals"
              className="rounded-xl border border-border bg-card p-5 hover:border-primary hover:shadow-md transition-all group"
            >
              <Crosshair className="h-5 w-5 text-success mb-2" />
              <p className="font-semibold group-hover:text-success transition-colors text-sm">信号扫描</p>
              <p className="text-xs text-muted-foreground mt-1">扫描今日交易信号</p>
            </Link>
          </div>

          {/* Performance Leaderboard */}
          <div className="rounded-xl border border-border bg-card overflow-hidden">
            <div className="flex items-center justify-between border-b border-border px-5 py-3">
              <h2 className="font-semibold text-sm">回测排行榜</h2>
              <Link to="/results" className="text-xs text-primary hover:underline">
                查看详细结果 →
              </Link>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-xs">
                <thead>
                  <tr className="text-muted-foreground text-left border-b border-border bg-muted/30">
                    <SortHeader label="名称" col="name" className="pl-5" />
                    <th className="py-2 font-medium">区间</th>
                    <th className="py-2 font-medium">模式</th>
                    <SortHeader label="交易数" col="total_closed" className="text-right" />
                    <SortHeader label="胜率" col="win_rate" className="text-right" />
                    <SortHeader label="总收益率" col="total_return_pct" className="text-right" />
                    <SortHeader label="最大净值" col="peak_equity" className="text-right" />
                    <SortHeader label="最大回撤" col="max_drawdown_pct" className="text-right" />
                    <SortHeader label="日期" col="updated_at" className="text-right pr-5" />
                  </tr>
                </thead>
                <tbody>
                  {sorted.map((item, idx) => {
                    const s = hasStats(item.stats) ? (item.stats as BacktestStatEntry) : null;
                    const profile = PROFILE_SHORT[String(item.config.execution_profile ?? "")] ?? "";
                    return (
                      <tr key={item.name} className={cn("border-b border-border/50 last:border-0 hover:bg-muted/20", idx < 3 && s && (s.total_return_pct ?? 0) > 0 && "bg-up/[0.03]")}>
                        <td className="py-2 pl-5 font-mono truncate max-w-[14rem]" title={item.name}>
                          <Link to="/results" className="text-primary hover:underline">{item.name}</Link>
                        </td>
                        <td className="py-2 tabular-nums">{parsePeriod(item.config)}</td>
                        <td className="py-2">
                          {profile && (
                            <span className="rounded-full px-1.5 py-0.5 text-[10px] font-medium bg-muted text-muted-foreground">
                              {profile}
                            </span>
                          )}
                        </td>
                        <td className="py-2 text-right tabular-nums">{s?.total_closed ?? "—"}</td>
                        <td className={cn("py-2 text-right tabular-nums", s && retColor(s.win_rate >= 0.5 ? 1 : -1))}>
                          {s ? `${(s.win_rate * 100).toFixed(1)}%` : "—"}
                        </td>
                        <td className={cn("py-2 text-right tabular-nums font-medium", retColor(s?.total_return_pct))}>
                          {s?.total_return_pct != null ? pct(s.total_return_pct) : "—"}
                        </td>
                        <td className="py-2 text-right tabular-nums">
                          {s?.peak_equity != null ? money(s.peak_equity) : "—"}
                        </td>
                        <td className="py-2 text-right tabular-nums text-down">
                          {s?.max_drawdown_pct != null ? pct(s.max_drawdown_pct) : "—"}
                        </td>
                        <td className="py-2 text-right text-muted-foreground pr-5">{prettyDate(item.updated_at)}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
