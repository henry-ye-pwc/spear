import {
  Activity,
  Bell,
  Check,
  ChevronDown,
  ChevronRight,
  Clock,
  Eye,
  FileText,
  Filter,
  Loader2,
  Play,
  RefreshCw,
  RotateCcw,
  Save,
  Send,
  Settings2,
  Trash2,
  X,
} from "lucide-react";
import React, { useCallback, useEffect, useRef, useState, useMemo } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { toast } from "sonner";
import { Pagination } from "../components/Pagination";
import { SavePoolDialog } from "../components/SavePoolDialog";
import { TaskLogPanel } from "../components/TaskLogPanel";
import { WatchStateTable } from "../components/WatchStateTable";
import { useApi } from "../hooks/useApi";
import { useTaskPoller } from "../hooks/useTaskPoller";
import {
  api,
  type PoolPreview,
  type SignalScanSummary,
  type TaskRecord,
  type TradeSummaryItem,
  type PositionSummaryItem,
} from "../lib/api";
import { cn, parseSymbols, prettyPct } from "../lib/utils";

const SAMPLINGS = ["random", "head"] as const;
type PoolMode = "named" | "random" | "custom";
type SignalMode = "auto" | "preview" | "confirm";
const MODE_LABELS: Record<SignalMode, string> = { auto: "自动", preview: "盘中预测", confirm: "盘后确认" };

const POS_MULT_FIELDS: { key: string; label: string; default_: number }[] = [
  { key: "trend_spear_pos_mult",  label: "趋势长枪", default_: 1.50 },
  { key: "post_limit_pos_mult",   label: "板后长枪", default_: 0.00 },
  { key: "failed_board_pos_mult", label: "烂板长枪", default_: 0.00 },
  { key: "youzi_pos_mult",        label: "游资长枪", default_: 0.00 },
  { key: "sector_spear_pos_mult", label: "板块长枪", default_: 0.00 },
  { key: "attack_pos_mult",       label: "进攻长枪", default_: 0.60 },
  { key: "arb_pos_mult",          label: "套利长枪", default_: 0.00 },
];

type PosPreset = { label: string; desc: string; bp: number; mp: number; sizing: "cash" | "equity"; mults: Record<string, number> };
const POS_PRESETS: PosPreset[] = [
  { label: "激进集中", desc: "equity 50% mp4 trend_only · 2025+116% 2026+39% · 高波动",
    bp: 0.50, mp: 4, sizing: "equity",
    mults: { trend_spear_pos_mult: 1.5, post_limit_pos_mult: 0, failed_board_pos_mult: 0, youzi_pos_mult: 0, sector_spear_pos_mult: 0, attack_pos_mult: 0, arb_pos_mult: 0 } },
  { label: "稳健趋势", desc: "equity 15% mp4 trend_only · 2025+98% 2026+49% · 年度差49pp",
    bp: 0.15, mp: 4, sizing: "equity",
    mults: { trend_spear_pos_mult: 1.5, post_limit_pos_mult: 0, failed_board_pos_mult: 0, youzi_pos_mult: 0, sector_spear_pos_mult: 0, attack_pos_mult: 0, arb_pos_mult: 0 } },
  { label: "均衡全类", desc: "equity 25% mp10 current · 2025+77% 2026+47% · 交易量553",
    bp: 0.25, mp: 10, sizing: "equity",
    mults: { trend_spear_pos_mult: 1.2, post_limit_pos_mult: 0.9, failed_board_pos_mult: 0.85, youzi_pos_mult: 0.75, sector_spear_pos_mult: 0.7, attack_pos_mult: 0.55, arb_pos_mult: 0.35 } },
  { label: "趋势重仓", desc: "equity 33% mp10 trend_heavy · 2025+61% 2026+45% · 最稳16pp差距",
    bp: 0.33, mp: 10, sizing: "equity",
    mults: { trend_spear_pos_mult: 1.5, post_limit_pos_mult: 0.5, failed_board_pos_mult: 0.3, youzi_pos_mult: 0.75, sector_spear_pos_mult: 0.7, attack_pos_mult: 0.55, arb_pos_mult: 0.25 } },
];

function isNearLimitUp(price: number, limitUp?: number): boolean {
  return limitUp != null && price >= limitUp * 0.998;
}
function isNearLimitDown(price: number, limitDown?: number): boolean {
  return limitDown != null && price <= limitDown * 1.002;
}

const EVENT_LABELS: Record<string, string> = {
  trend_spear: "趋势长枪", post_limit: "板后长枪", failed_board: "烂板长枪",
  youzi: "游资长枪", sector_spear: "板块长枪", attack: "进攻长枪",
  arb: "套利长枪", escape: "逃命长枪", tail_close: "尾盘入场",
  breakout: "突破入场", continuation: "趋势延续",
};
const ENTRY_STYLE_LABELS: Record<string, string> = {
  breakout: "突破入场", tail_close: "尾盘入场",
};
const REASON_LABELS: Record<string, string> = {
  stop_loss: "止损", take_profit: "止盈", time_exit: "到期",
  no_premium: "无溢价", failed_continuation: "趋势失败",
  theme_collapse: "主题退潮", rebreak: "跌破支撑",
  escape_risk_off: "风险逃离", sell_hunt_expired: "挂单到期",
};
function labelEvent(code: string): string {
  if (!code) return "—";
  const clean = code.replace(/^entry:/, "");
  return EVENT_LABELS[clean] ?? clean;
}
function labelEntryStyle(code: string): string {
  if (!code) return "—";
  return ENTRY_STYLE_LABELS[code] ?? code;
}
function labelReason(code: string): string {
  if (!code) return "—";
  const clean = code.replace(/_forced$/, "");
  return REASON_LABELS[clean] ?? code;
}
function formatEnv(s: { sector_hot: boolean; peer_confirmation: number; leader_strength: number }, envDisabled?: boolean): React.JSX.Element {
  if (envDisabled) {
    return <span className="text-muted-foreground/40 italic text-[10px]">行业映射已禁用</span>;
  }
  const peer = s.peer_confirmation;
  const leader = s.leader_strength;

  if (s.sector_hot) {
    return (
      <span className="inline-flex items-center gap-1">
        <span className="text-warning font-medium">热门</span>
        <span className="text-muted-foreground text-[10px]">{peer}只共振 {leader}只龙头</span>
      </span>
    );
  }
  if (peer > 0 || leader > 0) {
    return <span className="text-muted-foreground">{peer}只共振 {leader}只龙头</span>;
  }
  return <span className="text-muted-foreground/50">无</span>;
}

type Step = 1 | 2 | 3;
const STEPS: { num: Step; label: string }[] = [
  { num: 1, label: "配置" },
  { num: 2, label: "运行" },
  { num: 3, label: "结果" },
];

function StepperBar({ step, onStepClick }: { step: Step; onStepClick?: (s: Step) => void }) {
  return (
    <div className="flex items-center justify-center gap-0">
      {STEPS.map((s, i) => {
        const done = s.num < step;
        const active = s.num === step;
        return (
          <React.Fragment key={s.num}>
            {i > 0 && <div className={cn("h-px w-12 lg:w-20", done ? "bg-primary" : "bg-border")} />}
            <button
              onClick={() => onStepClick?.(s.num)}
              disabled={!onStepClick || (s.num > step)}
              className={cn(
                "flex items-center gap-2 rounded-full px-4 py-1.5 text-xs font-medium transition-all",
                active ? "bg-primary text-primary-foreground shadow-sm" :
                done ? "bg-primary/15 text-primary cursor-pointer hover:bg-primary/25" :
                "bg-muted text-muted-foreground",
              )}
            >
              {done ? <Check className="h-3 w-3" /> : <span className="text-[10px] font-bold">{s.num}</span>}
              {s.label}
            </button>
          </React.Fragment>
        );
      })}
    </div>
  );
}

export function SignalScanner() {
  const location = useLocation();
  const navigate = useNavigate();
  const { data: pools, refetch: refetchPools } = useApi(() => api.pools(), []);
  const { data: watchState, refetch: refetchWatch } = useApi(() => api.watchState(), []);
  const { data: feishuCfg } = useApi(() => api.feishuConfig(), []);

  const today = new Date().toISOString().slice(0, 10);
  const [date, setDate] = useState(today);
  const [latestBar, setLatestBar] = useState<{ date: string | null; loading: boolean; error?: string; hint?: string; dailyReady?: boolean }>({ date: null, loading: true });
  const probeLatestBar = useCallback(() => {
    setLatestBar((prev) => ({ ...prev, loading: true }));
    api.latestBar()
      .then((r) => setLatestBar({ date: r.latest_date, loading: false, error: r.error, hint: r.hint, dailyReady: r.daily_ready }))
      .catch(() => setLatestBar({ date: null, loading: false, error: "请求失败" }));
  }, []);
  useEffect(() => { probeLatestBar(); }, [probeLatestBar]);
  const [poolMode, setPoolMode] = useState<PoolMode>("named");
  const [poolSize, setPoolSize] = useState(300);
  const [poolSampling, setPoolSampling] = useState<string>("random");
  const [poolSeed, setPoolSeed] = useState(42);
  const [poolName, setPoolName] = useState("");
  const [symbolsRaw, setSymbolsRaw] = useState("");
  const [signalMode, setSignalMode] = useState<SignalMode>("auto");
  const [warmupBars, setWarmupBars] = useState(600);

  const [watchWindowDays, setWatchWindowDays] = useState(5);
  const [huntBufferPct, setHuntBufferPct] = useState(0.005);
  const [huntWindowDays, setHuntWindowDays] = useState(3);
  const [disableEnvMapping, setDisableEnvMapping] = useState(true);
  const [ytd, setYtd] = useState(true);
  const [showStrategyConfig, setShowStrategyConfig] = useState(true);

  const [maxPositions, setMaxPositions] = useState(20);
  const [basePosPct, setBasePosPct] = useState(0.25);
  const [positionSizingBase, setPositionSizingBase] = useState<"cash" | "equity">("equity");
  const [posMults, setPosMults] = useState<Record<string, number>>(
    () => Object.fromEntries(POS_MULT_FIELDS.map((f) => [f.key, f.default_])),
  );
  /** When true, row is "on" (打开); mult can be 0 (打开并=0). When false, row is off and mult is 0. */
  const [posMultEnabled, setPosMultEnabled] = useState<Record<string, boolean>>(
    () => Object.fromEntries(POS_MULT_FIELDS.map((f) => [f.key, true])),
  );
  const [showPosConfig, setShowPosConfig] = useState(false);

  const [tsDynamicHold, setTsDynamicHold] = useState(false);
  const [tsLimitupExtendDays, setTsLimitupExtendDays] = useState(15);
  const [tsLimitupWideAtrMult, setTsLimitupWideAtrMult] = useState(2.5);
  const [tsLimitupStopFloorPct, setTsLimitupStopFloorPct] = useState(0.92);
  const [tsNoboardTightenDays, setTsNoboardTightenDays] = useState(5);
  const [tsNoboardTightAtrMult, setTsNoboardTightAtrMult] = useState(1.5);
  const [tsNoboardMaxHold, setTsNoboardMaxHold] = useState(5);
  const [tsVolExhaustionExit, setTsVolExhaustionExit] = useState(false);
  const [tsAtrStop, setTsAtrStop] = useState(true);
  const [tsIqrFilter, setTsIqrFilter] = useState(false);
  const [tsIqrThreshold, setTsIqrThreshold] = useState(0.85);
  const [tsElevFilter, setTsElevFilter] = useState(false);
  const [tsElevThreshold, setTsElevThreshold] = useState(1.0);
  const [showTsConfig, setShowTsConfig] = useState(false);

  const [step, setStep] = useState<Step>(1);
  type ResultTab = "new" | "watch" | "dropped" | "positions" | "hunts" | "trades" | "closed";
  const [resultTab, setResultTab] = useState<ResultTab>("new");

  const [pushTopNew, setPushTopNew] = useState(3);
  const [pushTopWatch, setPushTopWatch] = useState(5);
  const [pushTopDrops, setPushTopDrops] = useState(5);
  const [minConfidence, setMinConfidence] = useState<"all" | "A">("all");
  const [autoPush, setAutoPush] = useState(false);
  const [showNotifyConfig, setShowNotifyConfig] = useState(false);

  const [feishuWebhook, setFeishuWebhook] = useState("");
  const [feishuSecret, setFeishuSecret] = useState("");
  const [feishuSaving, setFeishuSaving] = useState(false);
  const [feishuLoaded, setFeishuLoaded] = useState(false);

  const [showCronConfig, setShowCronConfig] = useState(false);
  const [cronHour, setCronHour] = useState("15");
  const [cronMinute, setCronMinute] = useState("5");
  const [cronWeekdays, setCronWeekdays] = useState("1-5");
  const [cronEnabled, setCronEnabled] = useState(false);
  const [cronSaving, setCronSaving] = useState(false);
  const { data: schedules, refetch: refetchSchedules } = useApi(() => api.schedules(), []);

  type ViewMode = "signals" | "strategy";
  const [viewMode, setViewMode] = useState<ViewMode>("signals");

  const hasFeishuConfig = Boolean(feishuCfg?.webhook);

  useEffect(() => {
    if (feishuCfg && !feishuLoaded) {
      setFeishuWebhook(feishuCfg.webhook || "");
      setFeishuSecret(feishuCfg.secret || "");
      setFeishuLoaded(true);
    }
  }, [feishuCfg, feishuLoaded]);

  // Apply config from ResultsExplorer "应用到信号页"
  const appliedFromResultsRef = useRef(false);
  useEffect(() => {
    const state = location.state as { applyConfig?: Record<string, unknown> } | null;
    if (!state?.applyConfig || appliedFromResultsRef.current) return;
    appliedFromResultsRef.current = true;
    const c = state.applyConfig;
    if (c.pool !== undefined) {
      const p = Number(c.pool);
      if (p < 9999) setPoolSize(p);
    }
    if (c.pool_sampling !== undefined) setPoolSampling(String(c.pool_sampling) as "random" | "head");
    if (c.pool_seed !== undefined) setPoolSeed(Number(c.pool_seed));
    if (c.pool_name !== undefined) {
      setPoolName(String(c.pool_name));
      setPoolMode("named");
    }
    if (c.mode !== undefined) setSignalMode(String(c.mode) as SignalMode);
    if (c.warmup_bars !== undefined) setWarmupBars(Number(c.warmup_bars));
    if (c.watch_window_days !== undefined) setWatchWindowDays(Number(c.watch_window_days));
    if (c.hunt_price_buffer_pct !== undefined) setHuntBufferPct(Number(c.hunt_price_buffer_pct));
    if (c.hunt_window_days !== undefined) setHuntWindowDays(Number(c.hunt_window_days));
    if (c.max_positions !== undefined) setMaxPositions(Number(c.max_positions));
    if (c.base_pos_pct !== undefined) setBasePosPct(Number(c.base_pos_pct));
    if (c.position_sizing_base !== undefined) setPositionSizingBase(String(c.position_sizing_base) as "cash" | "equity");
    if (c.disable_env_mapping !== undefined) setDisableEnvMapping(Boolean(c.disable_env_mapping));
    if (c.position_multipliers !== undefined && typeof c.position_multipliers === "object") {
      setPosMults((prev) => ({ ...prev, ...(c.position_multipliers as Record<string, number>) }));
    }
    POS_MULT_FIELDS.forEach((f) => {
      const v = c[f.key as keyof typeof c];
      if (v !== undefined) setPosMults((prev) => ({ ...prev, [f.key]: Number(v) }));
    });
    setPosMultEnabled((prev) => Object.fromEntries(POS_MULT_FIELDS.map((f) => [f.key, true]))); // mult=0 = 打开并=0
    if (c.trend_spear_dynamic_hold !== undefined) setTsDynamicHold(Boolean(c.trend_spear_dynamic_hold));
    if (c.push_top_new !== undefined) setPushTopNew(Number(c.push_top_new));
    if (c.push_top_watch !== undefined) setPushTopWatch(Number(c.push_top_watch));
    if (c.push_top_drops !== undefined) setPushTopDrops(Number(c.push_top_drops));
    if (c.min_confidence !== undefined) setMinConfidence(Number(c.min_confidence) >= 0.78 ? "A" : "all");
    if (c.ytd !== undefined) setYtd(Boolean(c.ytd));
    navigate(location.pathname, { replace: true, state: {} });
    toast.success("已应用该次扫描的配置");
  }, [location.state, location.pathname, navigate]);

  useEffect(() => {
    if (schedules && schedules.length > 0) {
      const sig = schedules.find((s) => s.kind === "signal_scan");
      if (sig) {
        setCronHour(String(sig.hour ?? "15"));
        setCronMinute(String(sig.minute ?? "5"));
        setCronWeekdays(String(sig.weekdays ?? "1-5"));
        setCronEnabled(Boolean(sig.enabled));
      }
    }
  }, [schedules]);

  const [taskId, setTaskId] = useState<string | null>(null);
  const { task, logLines, taskNotFound } = useTaskPoller(taskId);

  const [snapshot, setSnapshot] = useState<Record<string, unknown> | null>(null);
  const [scanSummary, setScanSummary] = useState<SignalScanSummary | null>(null);

  const [preview, setPreview] = useState<PoolPreview | null>(null);
  const [previewLoading, setPreviewLoading] = useState(false);
  const [pushing, setPushing] = useState(false);
  const [pushed, setPushed] = useState(false);

  const [showNewSignals, setShowNewSignals] = useState(true);
  const [showWatchUpdates, setShowWatchUpdates] = useState(false);
  const [showDropped, setShowDropped] = useState(false);
  const [showMessagePreview, setShowMessagePreview] = useState(true);
  const [showSavePool, setShowSavePool] = useState(false);

  const PAGE_SIZE = 20;
  const [newSigPage, setNewSigPage] = useState(0);
  const [watchUpPage, setWatchUpPage] = useState(0);
  const [droppedPage, setDroppedPage] = useState(0);

  const [watchFilter, setWatchFilter] = useState<{ status: string; type: string }>({ status: "", type: "" });

  const isRunning = task?.status === "running" || task?.status === "pending";

  useEffect(() => {
    if (taskNotFound && taskId) {
      setTaskId(null);
      setStep(1);
    }
  }, [taskNotFound]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    if (isRunning && step !== 2) setStep(2);
    if (task?.status === "succeeded" && snapshot && step === 2) setStep(3);
  }, [task?.status, snapshot, isRunning]); // eslint-disable-line react-hooks/exhaustive-deps

  async function handlePreview() {
    setPreviewLoading(true);
    try {
      setPreview(await api.poolPreview(poolSize, poolSampling, poolSeed, poolMode === "named" ? poolName : undefined));
    } catch (e: unknown) { toast.error(String(e)); }
    finally { setPreviewLoading(false); }
  }

  async function handleSubmit() {
    if (poolMode === "named" && !poolName) { toast.error("请选择一个标的池"); return; }
    if (poolMode === "custom" && !symbolsRaw.trim()) { toast.error("请输入至少一个股票代码"); return; }
    try {
      const payload: Record<string, unknown> = {
        date,
        pool: poolMode === "random" ? poolSize : 9999,
        pool_sampling: poolSampling,
        pool_seed: poolSeed,
        execution_profile: "delayed_limit_hunt",
        output_dir: "",
        mode: signalMode,
        warmup_bars: warmupBars,
        watch_window_days: watchWindowDays,
        hunt_price_buffer_pct: huntBufferPct,
        hunt_window_days: huntWindowDays,
        max_positions: maxPositions,
        base_pos_pct: basePosPct,
        position_sizing_base: positionSizingBase,
        ...posMults,
        push_top_new: pushTopNew,
        push_top_watch: pushTopWatch,
        push_top_drops: pushTopDrops,
        min_confidence: minConfidence === "A" ? 0.78 : 0.0,
        auto_push: autoPush,
        disable_env_mapping: disableEnvMapping,
        trend_spear_dynamic_hold: tsDynamicHold,
        ...(tsDynamicHold ? {
          trend_spear_limitup_extend_days: tsLimitupExtendDays,
          trend_spear_limitup_wide_atr_mult: tsLimitupWideAtrMult,
          trend_spear_limitup_stop_floor_pct: tsLimitupStopFloorPct,
          trend_spear_noboard_tighten_days: tsNoboardTightenDays,
          trend_spear_noboard_tight_atr_mult: tsNoboardTightAtrMult,
          trend_spear_noboard_max_hold: tsNoboardMaxHold,
        } : {}),
        trend_spear_vol_exhaustion_exit: tsVolExhaustionExit,
        ts_atr_stop: tsAtrStop,
        ts_iqr_filter: tsIqrFilter,
        ts_iqr_threshold: tsIqrThreshold,
        ts_elev_filter: tsElevFilter,
        ts_elev_threshold: tsElevThreshold,
        ytd,
      };
      if (poolMode === "named") payload.pool_name = poolName;
      if (poolMode === "custom") payload.symbols = parseSymbols(symbolsRaw);
      const t = await api.createSignalScan(payload);
      setTaskId(t.id); setSnapshot(null); setScanSummary(null); setPushed(false); resultLoadedRef.current = false;
      setNewSigPage(0); setWatchUpPage(0); setDroppedPage(0);
      setStep(2);
      toast.success("信号扫描已启动");
    } catch (e: unknown) { toast.error(String(e)); }
  }

  async function handlePush() {
    const effectiveDate = String(snapshot?.effective_date || snapshot?.date || date);
    const outputDir = task?.output_dir;
    setPushing(true);
    try { await api.feishuPush(effectiveDate, outputDir); setPushed(true); toast.success("已推送到飞书"); }
    catch (e: unknown) { toast.error(`推送失败: ${String(e)}`); }
    finally { setPushing(false); }
  }

  const resultLoadedRef = useRef(false);

  useEffect(() => {
    if (task?.status !== "succeeded" || resultLoadedRef.current) return;
    resultLoadedRef.current = true;
    const name = task.output_dir.split("/").pop() ?? "";
    if (!name) return;
    (async () => {
      try {
        const [meta, summary] = await Promise.allSettled([api.resultMeta(name), api.scanSummary(name)]);
        if (meta.status === "fulfilled") setSnapshot(meta.value);
        if (summary.status === "fulfilled") setScanSummary(summary.value);
        refetchWatch();
      } catch { /* meta may not exist */ }
    })();
  }, [task?.status, task?.output_dir]); // eslint-disable-line react-hooks/exhaustive-deps

  const watchItems = watchState
    ? Object.values(watchState)
        .map((v) => v as Record<string, unknown>)
        .sort((a, b) => String(b.signal_date ?? "").localeCompare(String(a.signal_date ?? "")))
    : [];
  const ss = scanSummary?.snapshot;
  const newSignals = ss?.new_signals ?? [];
  const watchUpdates = [...(ss?.watch_updates ?? [])].sort((a, b) => b.signal_date.localeCompare(a.signal_date));
  const droppedItems = [...(ss?.dropped ?? [])].sort((a, b) => b.signal_date.localeCompare(a.signal_date));
  const todayEntries = ss?.today_entries ?? [];
  const todayExits = ss?.today_exits ?? [];
  const activePositions = ss?.active_positions ?? [];
  const closedTrades = ss?.closed_trades ?? [];
  const pendingHunts = (ss?.pending_hunts ?? []).filter((h) => !h.expired);
  const pendingSellHunts = ss?.pending_sell_hunts ?? [];
  const hasTradeData = todayEntries.length > 0 || todayExits.length > 0 || activePositions.length > 0 || closedTrades.length > 0 || pendingHunts.length > 0 || (ss?.portfolio_equity ?? 0) > 0;

  const handleReset = () => {
    setTaskId(null); setSnapshot(null); setScanSummary(null); setPushed(false); resultLoadedRef.current = false;
    setStep(1);
  };

  return (
    <div className="p-6 max-w-6xl mx-auto space-y-5">
      {/* Header + Stepper */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">信号扫描</h1>
          <p className="text-muted-foreground text-sm mt-0.5">配置 → 运行 → 查看结果</p>
        </div>
        <StepperBar step={step} onStepClick={(s) => { if (s < step) setStep(s); }} />
      </div>

      {/* ═══════ Step 1: Config ═══════ */}
      {step === 1 && (
        <div className="space-y-5">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
            {/* LEFT COLUMN */}
            <div className="space-y-4">
              {/* Date + Mode */}
              <div className="rounded-xl border border-border bg-card p-4 space-y-3">
                <div>
                  <label className="block text-xs font-medium text-muted-foreground mb-1">扫描日期</label>
                  <input type="date" value={date} onChange={(e) => setDate(e.target.value)} className="input-field w-48" />
                  {!latestBar.loading && (
                    <div className="mt-1.5 flex items-center gap-1.5 text-[10px]">
                      {latestBar.date ? (
                        latestBar.date >= date ? (
                          latestBar.dailyReady ? (
                            <span className="text-emerald-600 dark:text-emerald-400">● 数据已就绪（{latestBar.date}）</span>
                          ) : (
                            <span className="text-emerald-600 dark:text-emerald-400" title={latestBar.hint || ""}>● 分钟线就绪（{latestBar.date}），日线更新中</span>
                          )
                        ) : (
                          <span className="text-amber-600 dark:text-amber-400">● 数据尚未更新至 {date}（当前 {latestBar.date}）</span>
                        )
                      ) : (
                        <span className="text-red-500">● 无法获取数据状态{latestBar.error ? `：${latestBar.error}` : ""}</span>
                      )}
                      <button onClick={probeLatestBar} className="text-muted-foreground hover:text-foreground"><RefreshCw className="h-3 w-3" /></button>
                    </div>
                  )}
                </div>
                <div>
                  <label className="block text-xs font-medium text-muted-foreground mb-1">运行模式</label>
                  <div className="flex gap-1.5">
                    {(["auto", "preview", "confirm"] as SignalMode[]).map((m) => (
                      <button key={m} onClick={() => setSignalMode(m)}
                        className={cn("rounded-full px-3 py-1 text-xs font-medium transition-all",
                          signalMode === m ? (m === "preview" ? "bg-amber-500/20 text-amber-600 shadow-sm" : m === "confirm" ? "bg-success/20 text-success shadow-sm" : "bg-primary text-primary-foreground shadow-sm") : "bg-muted text-muted-foreground hover:bg-accent",
                        )}>
                        {MODE_LABELS[m]}
                      </button>
                    ))}
                  </div>
                  <p className="text-[10px] text-muted-foreground mt-1">
                    {signalMode === "auto" ? "自动判断: 15:00前盘中预测, 之后盘后确认" : signalMode === "preview" ? "盘中预测: 分钟数据合成日线" : "盘后确认: 完整收盘数据"}
                  </p>
                </div>
              </div>

              {/* Strategy Config */}
              <div className="rounded-xl border border-border bg-card p-4">
                <button onClick={() => setShowStrategyConfig(!showStrategyConfig)} className="flex items-center gap-2 text-xs font-medium text-muted-foreground hover:text-foreground transition-colors w-full">
                  <Settings2 className="h-3.5 w-3.5" />
                  <span>策略参数</span>
                  {showStrategyConfig ? <ChevronDown className="h-3 w-3 ml-auto" /> : <ChevronRight className="h-3 w-3 ml-auto" />}
                </button>
                {showStrategyConfig && (
                  <div className="mt-3 space-y-3">
                    <div className="flex flex-wrap gap-x-5 gap-y-2">
                      <div>
                        <label className="block text-[10px] font-medium text-muted-foreground mb-0.5">观察窗口</label>
                        <div className="flex items-center gap-1">
                          <input type="number" min={1} max={30} value={watchWindowDays} onChange={(e) => setWatchWindowDays(+e.target.value)} className="input-field w-12 tabular-nums" />
                          <span className="text-[10px] text-muted-foreground">天</span>
                        </div>
                      </div>
                      <div>
                        <label className="block text-[10px] font-medium text-muted-foreground mb-0.5">入场等待</label>
                        <div className="flex items-center gap-1">
                          <input type="number" min={1} max={10} value={huntWindowDays} onChange={(e) => setHuntWindowDays(+e.target.value)} className="input-field w-12 tabular-nums" />
                          <span className="text-[10px] text-muted-foreground">天</span>
                        </div>
                      </div>
                      <div>
                        <label className="block text-[10px] font-medium text-muted-foreground mb-0.5">回踩缓冲</label>
                        <div className="flex items-center gap-1">
                          <input type="number" min={0} max={0.05} step={0.001} value={huntBufferPct} onChange={(e) => setHuntBufferPct(+e.target.value)} className="input-field w-14 tabular-nums" />
                          <span className="text-[10px] text-muted-foreground">{(huntBufferPct * 100).toFixed(1)}%</span>
                        </div>
                      </div>
                    </div>
                    {/* Trend spear execution config */}
                    <div className="border-t border-border/40 pt-2">
                      <button onClick={() => setShowTsConfig(!showTsConfig)} className="flex items-center gap-1.5 text-[11px] font-medium text-muted-foreground hover:text-foreground transition-colors">
                        <Settings2 className="h-3 w-3" />
                        <span>趋势长枪执行参数</span>
                        {showTsConfig ? <ChevronDown className="h-3 w-3" /> : <ChevronRight className="h-3 w-3" />}
                      </button>
                      {showTsConfig && (
                        <div className="mt-2 space-y-2 pl-1">
                          <div className="flex flex-wrap items-center gap-x-4 gap-y-1.5">
                            <span className="text-[10px] font-medium text-muted-foreground">信号过滤</span>
                            <label className="flex items-center gap-1.5 cursor-pointer select-none text-[11px]">
                              <input type="checkbox" checked={tsAtrStop} onChange={(e) => setTsAtrStop(e.target.checked)} className="rounded border-border accent-primary" />
                              <span>ATR止损</span>
                            </label>
                            <label className="flex items-center gap-1.5 cursor-pointer select-none text-[11px]">
                              <input type="checkbox" checked={tsIqrFilter} onChange={(e) => setTsIqrFilter(e.target.checked)} className="rounded border-border accent-primary" />
                              <span>IQR过滤</span>
                            </label>
                            {tsIqrFilter && (
                              <div className="flex items-center gap-1">
                                <span className="text-[10px] text-muted-foreground">≤</span>
                                <input type="number" step={0.05} min={0} max={3} value={tsIqrThreshold} onChange={(e) => setTsIqrThreshold(+e.target.value)}
                                  className="input-field w-12 text-[10px] tabular-nums text-right" />
                              </div>
                            )}
                            <label className="flex items-center gap-1.5 cursor-pointer select-none text-[11px]">
                              <input type="checkbox" checked={tsElevFilter} onChange={(e) => setTsElevFilter(e.target.checked)} className="rounded border-border accent-primary" />
                              <span>Elevation</span>
                            </label>
                            {tsElevFilter && (
                              <div className="flex items-center gap-1">
                                <span className="text-[10px] text-muted-foreground">≤</span>
                                <input type="number" step={0.1} min={0} max={5} value={tsElevThreshold} onChange={(e) => setTsElevThreshold(+e.target.value)}
                                  className="input-field w-12 text-[10px] tabular-nums text-right" />
                              </div>
                            )}
                          </div>
                          <div className="border-t border-border/30" />
                          <div className="flex items-center gap-3">
                            <label className="flex items-center gap-1.5 cursor-pointer select-none text-[11px]">
                              <input type="checkbox" checked={tsDynamicHold} onChange={(e) => setTsDynamicHold(e.target.checked)} className="rounded border-border accent-primary" />
                              <span className="font-medium">动态持仓管理</span>
                            </label>
                            <span className="text-[10px] text-muted-foreground">涨停延长 / 无涨停收紧</span>
                            <button onClick={() => { setTsDynamicHold(false); setTsLimitupExtendDays(15); setTsLimitupWideAtrMult(2.5); setTsLimitupStopFloorPct(0.92); setTsNoboardTightenDays(5); setTsNoboardTightAtrMult(1.5); setTsNoboardMaxHold(5); setTsVolExhaustionExit(false); setTsAtrStop(true); setTsIqrFilter(false); setTsElevFilter(false); }}
                              className="ml-auto text-[10px] text-muted-foreground hover:text-foreground transition-colors" title="1129abd：无IQR/Elevation过滤，固定10天持仓 + 固定止损">
                              <RotateCcw className="h-3 w-3 inline mr-0.5" />当前版本（静态）
                            </button>
                            <button onClick={() => { setTsDynamicHold(true); setTsLimitupExtendDays(15); setTsLimitupWideAtrMult(2.5); setTsLimitupStopFloorPct(0.92); setTsNoboardTightenDays(5); setTsNoboardTightAtrMult(1.5); setTsNoboardMaxHold(5); setTsVolExhaustionExit(true); setTsAtrStop(true); setTsIqrFilter(true); setTsIqrThreshold(0.85); setTsElevFilter(true); setTsElevThreshold(1.0); }}
                              className="text-[10px] text-muted-foreground hover:text-foreground transition-colors" title="3c10e7c：IQR+Elevation过滤 + 涨停延长/无板收紧/量能衰竭">
                              <RotateCcw className="h-3 w-3 inline mr-0.5" />3c10e7c（动态）
                            </button>
                          </div>
                          {tsDynamicHold && (
                            <div className="pl-5 space-y-1.5">
                              <div className="flex flex-wrap items-center gap-x-3 gap-y-1">
                                <span className="text-[10px] text-muted-foreground w-full">涨停板 →</span>
                                <div className="flex items-center gap-1">
                                  <span className="text-[10px] text-muted-foreground">延长</span>
                                  <input type="number" min={5} max={30} value={tsLimitupExtendDays} onChange={(e) => setTsLimitupExtendDays(+e.target.value)} className="input-field w-10 text-[10px] tabular-nums text-right" />
                                  <span className="text-[10px] text-muted-foreground">天</span>
                                </div>
                                <div className="flex items-center gap-1">
                                  <span className="text-[10px] text-muted-foreground">止损</span>
                                  <input type="number" step={0.1} min={0.5} max={5} value={tsLimitupWideAtrMult} onChange={(e) => setTsLimitupWideAtrMult(+e.target.value)} className="input-field w-10 text-[10px] tabular-nums text-right" />
                                  <span className="text-[10px] text-muted-foreground">×ATR</span>
                                </div>
                                <div className="flex items-center gap-1">
                                  <span className="text-[10px] text-muted-foreground">底线</span>
                                  <input type="number" step={1} min={80} max={99} value={Math.round(tsLimitupStopFloorPct * 100)} onChange={(e) => setTsLimitupStopFloorPct(+e.target.value / 100)} className="input-field w-10 text-[10px] tabular-nums text-right" />
                                  <span className="text-[10px] text-muted-foreground">%</span>
                                </div>
                              </div>
                              <div className="flex flex-wrap items-center gap-x-3 gap-y-1">
                                <span className="text-[10px] text-muted-foreground w-full">无涨停 →</span>
                                <div className="flex items-center gap-1">
                                  <span className="text-[10px] text-muted-foreground">等待</span>
                                  <input type="number" min={1} max={15} value={tsNoboardTightenDays} onChange={(e) => setTsNoboardTightenDays(+e.target.value)} className="input-field w-10 text-[10px] tabular-nums text-right" />
                                  <span className="text-[10px] text-muted-foreground">天</span>
                                </div>
                                <div className="flex items-center gap-1">
                                  <span className="text-[10px] text-muted-foreground">止损</span>
                                  <input type="number" step={0.1} min={0.5} max={5} value={tsNoboardTightAtrMult} onChange={(e) => setTsNoboardTightAtrMult(+e.target.value)} className="input-field w-10 text-[10px] tabular-nums text-right" />
                                  <span className="text-[10px] text-muted-foreground">×ATR</span>
                                </div>
                                <div className="flex items-center gap-1">
                                  <span className="text-[10px] text-muted-foreground">缩至</span>
                                  <input type="number" min={1} max={15} value={tsNoboardMaxHold} onChange={(e) => setTsNoboardMaxHold(+e.target.value)} className="input-field w-10 text-[10px] tabular-nums text-right" />
                                  <span className="text-[10px] text-muted-foreground">天</span>
                                </div>
                              </div>
                            </div>
                          )}
                          <label className="flex items-center gap-1.5 cursor-pointer select-none text-[11px]">
                            <input type="checkbox" checked={tsVolExhaustionExit} onChange={(e) => setTsVolExhaustionExit(e.target.checked)} className="rounded border-border accent-primary" />
                            <span className="font-medium">量能衰竭出场</span>
                            <span className="text-[10px] text-muted-foreground">涨停后放量阴线 → 卖出</span>
                          </label>
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>

              {/* Options */}
              <div className="rounded-xl border border-border bg-card p-4 space-y-2">
                <div className="flex flex-wrap items-end gap-x-5 gap-y-2">
                  <div>
                    <label className="block text-[10px] font-medium text-muted-foreground mb-0.5">预热 bars</label>
                    <input type="number" min={120} max={900} step={50} value={warmupBars} onChange={(e) => setWarmupBars(+e.target.value)} className="input-field w-16 tabular-nums" />
                  </div>
                  <label className="flex items-center gap-1.5 cursor-pointer select-none text-xs pb-0.5">
                    <input type="checkbox" checked={ytd} onChange={(e) => setYtd(e.target.checked)} className="rounded border-border accent-primary" />
                    全年回测
                  </label>
                  <label className="flex items-center gap-1.5 cursor-pointer select-none text-xs pb-0.5">
                    <input type="checkbox" checked={disableEnvMapping} onChange={(e) => setDisableEnvMapping(e.target.checked)} className="rounded border-border accent-primary" />
                    禁用行业映射 <span className="text-[9px] text-muted-foreground">(推荐，回测基准)</span>
                  </label>
                </div>
                <p className="text-[9px] text-muted-foreground leading-relaxed">
                  {ytd ? `从 ${date.slice(0, 4)}-01-01 完整回测，保证持仓连续。` : "预热 = 扫描前加载的 K 线数，不同值的信号不可直接对比。"}
                </p>
              </div>

              {/* Notify Config */}
              <div className="rounded-xl border border-border bg-card p-4">
                <button onClick={() => setShowNotifyConfig(!showNotifyConfig)} className="flex items-center gap-2 text-xs font-medium text-muted-foreground hover:text-foreground transition-colors w-full">
                  <Bell className="h-3.5 w-3.5" />
                  <span>推送 + 飞书</span>
                  <span className="text-[10px] text-muted-foreground ml-1">(Top {pushTopNew}/{pushTopWatch}/{pushTopDrops})</span>
                  {showNotifyConfig ? <ChevronDown className="h-3 w-3 ml-auto" /> : <ChevronRight className="h-3 w-3 ml-auto" />}
                </button>
                {showNotifyConfig && (
                  <div className="mt-3 space-y-3">
                    <div className="flex items-center gap-3">
                      <div><label className="block text-[10px] text-muted-foreground mb-0.5">新信号</label><input type="number" min={0} max={50} value={pushTopNew} onChange={(e) => setPushTopNew(+e.target.value)} className="input-field w-16 tabular-nums" /></div>
                      <div><label className="block text-[10px] text-muted-foreground mb-0.5">观察中</label><input type="number" min={0} max={50} value={pushTopWatch} onChange={(e) => setPushTopWatch(+e.target.value)} className="input-field w-16 tabular-nums" /></div>
                      <div><label className="block text-[10px] text-muted-foreground mb-0.5">已失效</label><input type="number" min={0} max={50} value={pushTopDrops} onChange={(e) => setPushTopDrops(+e.target.value)} className="input-field w-16 tabular-nums" /></div>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="flex gap-1.5">
                        {(["all", "A"] as const).map((v) => (
                          <button key={v} onClick={() => setMinConfidence(v)} className={cn("rounded-full px-2.5 py-0.5 text-[10px] font-medium transition-all", minConfidence === v ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground hover:bg-accent")}>
                            {v === "all" ? "全部" : "仅A级"}
                          </button>
                        ))}
                      </div>
                    </div>
                    <div className="flex items-center gap-2 pt-1">
                      <button onClick={() => hasFeishuConfig && setAutoPush(!autoPush)}
                        className={cn("relative inline-flex h-5 w-9 items-center rounded-full transition-colors", autoPush && hasFeishuConfig ? "bg-blue-600" : "bg-muted", !hasFeishuConfig && "opacity-40 cursor-not-allowed")}>
                        <span className={cn("inline-block h-3.5 w-3.5 rounded-full bg-white transition-transform shadow-sm", autoPush && hasFeishuConfig ? "translate-x-4" : "translate-x-0.5")} />
                      </button>
                      <span className={cn("text-xs", autoPush && hasFeishuConfig ? "text-blue-600 font-medium" : "text-muted-foreground")}>
                        {hasFeishuConfig ? "扫描完成后自动推送飞书" : "请先配置飞书 Webhook"}
                      </span>
                    </div>
                    <div className="border-t border-border/50 pt-2 space-y-1.5">
                      <label className="block text-[10px] font-medium text-muted-foreground">Webhook</label>
                      <input type="text" value={feishuWebhook} onChange={(e) => setFeishuWebhook(e.target.value)} placeholder="https://open.feishu.cn/..." className="input-field w-full text-xs font-mono" />
                      <label className="block text-[10px] font-medium text-muted-foreground">密钥</label>
                      <input type="password" value={feishuSecret} onChange={(e) => setFeishuSecret(e.target.value)} placeholder="SEC..." className="input-field w-full text-xs font-mono" />
                      <button disabled={feishuSaving} onClick={async () => { setFeishuSaving(true); try { await api.saveFeishuConfig(feishuWebhook.trim(), feishuSecret.trim()); toast.success("飞书配置已保存"); } catch (e: unknown) { toast.error(String(e)); } finally { setFeishuSaving(false); } }}
                        className="rounded-md px-3 py-1 text-xs font-medium bg-primary/10 text-primary hover:bg-primary/20">{feishuSaving ? "保存中..." : "保存飞书配置"}</button>
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* RIGHT COLUMN */}
            <div className="space-y-4">
              {/* Pool */}
              <div className="rounded-xl border border-border bg-card p-4 space-y-3">
                <label className="block text-xs font-medium text-muted-foreground">标的池</label>
                <div className="flex gap-1.5">
                  {(["random", "named", "custom"] as PoolMode[]).map((m) => (
                    <button key={m} onClick={() => { setPoolMode(m); setPreview(null); }} className={cn("rounded-full px-3 py-1 text-xs font-medium transition-all", poolMode === m ? "bg-primary text-primary-foreground shadow-sm" : "bg-muted text-muted-foreground hover:bg-accent")}>
                      {m === "random" ? "随机" : m === "named" ? "命名池" : "自定义"}
                    </button>
                  ))}
                </div>
                {poolMode === "random" && (
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <div><label className="block text-[10px] text-muted-foreground mb-0.5">数量</label><input type="number" min={1} value={poolSize} onChange={(e) => setPoolSize(+e.target.value)} className="input-field w-20 tabular-nums" /></div>
                      <div><label className="block text-[10px] text-muted-foreground mb-0.5">方式</label><select value={poolSampling} onChange={(e) => setPoolSampling(e.target.value)} className="input-field w-24">{SAMPLINGS.map((s) => (<option key={s} value={s}>{s === "random" ? "随机" : "顺序"}</option>))}</select></div>
                      <div><label className="block text-[10px] text-muted-foreground mb-0.5">种子</label><input type="number" value={poolSeed} onChange={(e) => setPoolSeed(+e.target.value)} className="input-field w-20 tabular-nums" /></div>
                    </div>
                    <button onClick={handlePreview} disabled={previewLoading} className="flex items-center gap-1.5 text-xs font-medium text-primary hover:text-primary/80">
                      {previewLoading ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Eye className="h-3.5 w-3.5" />}预览
                    </button>
                    {preview && <PoolPreviewPanel preview={preview} onClose={() => setPreview(null)} />}
                  </div>
                )}
                {poolMode === "named" && (
                  <div className="space-y-1.5">
                    <div className="flex items-center gap-2">
                      <select value={poolName} onChange={(e) => setPoolName(e.target.value)} className="input-field flex-1">
                        <option value="">— 选择 —</option>
                        {(pools ?? []).map((p) => (<option key={p.name} value={p.name}>{p.label} ({p.symbol_count}){!p.builtin ? " [自定义]" : ""}</option>))}
                      </select>
                      {poolName && <button onClick={handlePreview} disabled={previewLoading} className="text-xs text-primary">{previewLoading ? <Loader2 className="h-3 w-3 animate-spin" /> : "预览"}</button>}
                      {poolName && !(pools ?? []).find((p) => p.name === poolName)?.builtin && (
                        <button onClick={async () => { if (!confirm(`确定删除「${poolName}」?`)) return; try { await api.deletePool(poolName); toast.success("已删除"); setPoolName(""); refetchPools(); } catch (e: unknown) { toast.error(String(e)); } }} className="text-xs text-destructive"><Trash2 className="h-3 w-3" /></button>
                      )}
                    </div>
                    {preview && <PoolPreviewPanel preview={preview} onClose={() => setPreview(null)} />}
                  </div>
                )}
                {poolMode === "custom" && (
                  <div className="space-y-2">
                    <textarea rows={2} value={symbolsRaw} onChange={(e) => setSymbolsRaw(e.target.value)} placeholder="000001, 600519, 300750 ..." className="input-field w-full resize-none font-mono text-xs" />
                    {symbolsRaw.trim() && (
                      <div className="flex items-center gap-3">
                        <span className="text-xs text-muted-foreground">{parseSymbols(symbolsRaw).length} 只</span>
                        <button onClick={() => setShowSavePool(true)} className="flex items-center gap-1 text-xs text-primary"><Save className="h-3 w-3" />保存为命名池</button>
                      </div>
                    )}
                    {showSavePool && symbolsRaw.trim() && <SavePoolDialog symbols={parseSymbols(symbolsRaw)} onSaved={() => refetchPools()} onClose={() => setShowSavePool(false)} />}
                  </div>
                )}
              </div>

              {/* Position Config */}
              <div className="rounded-xl border border-border bg-card p-4">
                <button onClick={() => setShowPosConfig(!showPosConfig)} className="flex items-center gap-2 text-xs font-medium text-muted-foreground hover:text-foreground transition-colors w-full">
                  <Filter className="h-3.5 w-3.5" />
                  <span>仓位 & 信号比重</span>
                  <span className="text-[10px] text-muted-foreground ml-1">({maxPositions}仓 {(basePosPct * 100).toFixed(0)}%)</span>
                  {showPosConfig ? <ChevronDown className="h-3 w-3 ml-auto" /> : <ChevronRight className="h-3 w-3 ml-auto" />}
                </button>
                {showPosConfig && (
                  <div className="mt-3 space-y-4">
                    <div className="flex items-end gap-4">
                      <div>
                        <label className="block text-[10px] font-medium text-muted-foreground mb-1">最大持仓</label>
                        <input type="number" min={1} max={20} value={maxPositions} onChange={(e) => setMaxPositions(+e.target.value)} className="input-field w-16 tabular-nums" />
                      </div>
                      <div>
                        <label className="block text-[10px] font-medium text-muted-foreground mb-1">基础仓位</label>
                        <div className="flex items-center gap-1">
                          <input type="number" min={5} max={100} value={Math.round(basePosPct * 100)} onChange={(e) => setBasePosPct(+e.target.value / 100)} className="input-field w-16 tabular-nums" />
                          <span className="text-[10px] text-muted-foreground">%</span>
                        </div>
                      </div>
                      <div>
                        <label className="block text-[10px] font-medium text-muted-foreground mb-1">仓位基准</label>
                        <select value={positionSizingBase} onChange={(e) => setPositionSizingBase(e.target.value as "cash" | "equity")} className="input-field text-xs w-24">
                          <option value="cash">剩余现金</option>
                          <option value="equity">总权益</option>
                        </select>
                      </div>
                      <p className="text-[9px] text-muted-foreground pb-1">每个信号实际仓位 = {positionSizingBase === "equity" ? "总权益" : "剩余现金"} × 基础仓位 × 比重系数</p>
                    </div>
                    {/* Presets */}
                    <div className="flex flex-wrap gap-1.5">
                      {POS_PRESETS.map((p) => (
                        <button key={p.label} title={p.desc} onClick={() => { setBasePosPct(p.bp); setMaxPositions(p.mp); setPositionSizingBase(p.sizing); setPosMults((prev) => ({ ...prev, ...p.mults })); setPosMultEnabled((prev) => Object.fromEntries(POS_MULT_FIELDS.map((f) => [f.key, true]))); }}
                          className="rounded-md border border-border px-2.5 py-1 text-[10px] hover:bg-accent transition-colors">
                          {p.label}
                        </button>
                      ))}
                    </div>

                    {/* Multiplier table with on/off toggle */}
                    <div className="rounded-lg border border-border overflow-hidden">
                      <table className="w-full text-[11px]">
                        <thead>
                          <tr className="bg-muted/30 text-muted-foreground">
                            <th className="text-center px-1.5 py-1.5 font-medium w-8">开</th>
                            <th className="text-left px-2 py-1.5 font-medium">信号类型</th>
                            <th className="text-center px-2 py-1.5 font-medium">比重系数</th>
                            <th className="text-right px-2.5 py-1.5 font-medium w-14">仓位</th>
                          </tr>
                        </thead>
                        <tbody>
                          {POS_MULT_FIELDS.map((f) => {
                            const v = posMults[f.key] ?? f.default_;
                            const isOn = posMultEnabled[f.key] ?? true; // mult=0 = 打开并=0，不因 0 而显示为关
                            const effPct = basePosPct * v * 100;
                            return (
                              <tr key={f.key} className={`border-t border-border/50 ${!isOn ? "opacity-40" : ""}`}>
                                <td className="px-1.5 py-1 text-center">
                                  <input
                                    type="checkbox"
                                    checked={isOn}
                                    onChange={(e) => {
                                      const on = e.target.checked;
                                      setPosMultEnabled((p) => ({ ...p, [f.key]: on }));
                                      setPosMults((p) => ({ ...p, [f.key]: on ? (f.default_ ?? 0) : 0 }));
                                    }}
                                    className="h-3 w-3 rounded accent-primary"
                                  />
                                </td>
                                <td className="px-2 py-1 text-muted-foreground whitespace-nowrap">{f.label}</td>
                                <td className="px-2 py-1">
                                  <div className="flex items-center justify-center gap-0.5">
                                    <button disabled={!isOn} onClick={() => setPosMults((p) => ({ ...p, [f.key]: Math.max(0, (p[f.key] ?? f.default_) - 0.05) }))} className="rounded px-1 py-0.5 text-xs bg-muted hover:bg-accent leading-none disabled:opacity-30">-</button>
                                    <input type="number" min={0} max={3} step={0.05} value={v} disabled={!isOn} onChange={(e) => setPosMults((p) => ({ ...p, [f.key]: Math.max(0, Math.min(3, +e.target.value || 0)) }))}
                                      className="input-field w-12 text-center tabular-nums font-medium disabled:opacity-30" />
                                    <button disabled={!isOn} onClick={() => setPosMults((p) => ({ ...p, [f.key]: Math.min(3.0, (p[f.key] ?? f.default_) + 0.05) }))} className="rounded px-1 py-0.5 text-xs bg-muted hover:bg-accent leading-none disabled:opacity-30">+</button>
                                  </div>
                                </td>
                                <td className={`px-2.5 py-1 text-right tabular-nums font-medium whitespace-nowrap ${!isOn ? "" : effPct > 30 ? "text-red-500" : ""}`}>{effPct.toFixed(0)}%</td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}
              </div>

              {/* Cron Config */}
              <div className="rounded-xl border border-border bg-card p-4">
                <button onClick={() => setShowCronConfig(!showCronConfig)} className="flex items-center gap-2 text-xs font-medium text-muted-foreground hover:text-foreground transition-colors w-full">
                  <Clock className="h-3.5 w-3.5" />
                  <span>定时任务</span>
                  <span className="text-[10px] text-muted-foreground ml-1">({cronEnabled ? `${cronHour}:${cronMinute.padStart(2, "0")}` : "未启用"})</span>
                  {showCronConfig ? <ChevronDown className="h-3 w-3 ml-auto" /> : <ChevronRight className="h-3 w-3 ml-auto" />}
                </button>
                {showCronConfig && (
                  <div className="mt-3 space-y-2">
                    <div className="flex items-center gap-3">
                      <div><label className="block text-[10px] text-muted-foreground mb-0.5">时 <span className="text-muted-foreground/60">(北京)</span></label><input type="number" min={0} max={23} value={cronHour} onChange={(e) => setCronHour(e.target.value)} className="input-field w-14 tabular-nums" /></div>
                      <div><label className="block text-[10px] text-muted-foreground mb-0.5">分</label><input type="number" min={0} max={59} value={cronMinute} onChange={(e) => setCronMinute(e.target.value)} className="input-field w-14 tabular-nums" /></div>
                      <div><label className="block text-[10px] text-muted-foreground mb-0.5">工作日</label><select value={cronWeekdays} onChange={(e) => setCronWeekdays(e.target.value)} className="input-field text-xs"><option value="1-5">周一至周五</option><option value="0-6">每天</option></select></div>
                      <div><label className="block text-[10px] text-muted-foreground mb-0.5">启用</label><button onClick={() => setCronEnabled(!cronEnabled)} className={cn("rounded-full px-2.5 py-0.5 text-[10px] font-medium", cronEnabled ? "bg-success/20 text-success" : "bg-muted text-muted-foreground hover:bg-accent")}>{cronEnabled ? "启用" : "关闭"}</button></div>
                    </div>
                    <button disabled={cronSaving} onClick={async () => {
                      setCronSaving(true);
                      try {
                        const existing = (schedules ?? []).find((s) => s.kind === "signal_scan");
                        const id = existing?.id ?? `signal_scan_${Date.now().toString(36)}`;
                        await api.saveSchedule({ id, name: `信号扫描 ${cronHour}:${cronMinute.padStart(2, "0")}`, enabled: cronEnabled, minute: cronMinute, hour: cronHour, weekdays: cronWeekdays, command_preview: "", kind: "signal_scan",
                          payload: { date: "auto", pool: poolMode === "random" ? poolSize : 9999, pool_sampling: poolSampling, pool_seed: poolSeed, execution_profile: "delayed_limit_hunt", output_dir: "", mode: signalMode, warmup_bars: warmupBars, watch_window_days: watchWindowDays, hunt_price_buffer_pct: huntBufferPct, hunt_window_days: huntWindowDays, max_positions: maxPositions, base_pos_pct: basePosPct, position_sizing_base: positionSizingBase, ...posMults, push_top_new: pushTopNew, push_top_watch: pushTopWatch, push_top_drops: pushTopDrops, min_confidence: minConfidence === "A" ? 0.78 : 0.0, auto_push: true, disable_env_mapping: disableEnvMapping, trend_spear_dynamic_hold: tsDynamicHold, ...(tsDynamicHold ? { trend_spear_limitup_extend_days: tsLimitupExtendDays, trend_spear_limitup_wide_atr_mult: tsLimitupWideAtrMult, trend_spear_limitup_stop_floor_pct: tsLimitupStopFloorPct, trend_spear_noboard_tighten_days: tsNoboardTightenDays, trend_spear_noboard_tight_atr_mult: tsNoboardTightAtrMult, trend_spear_noboard_max_hold: tsNoboardMaxHold } : {}), trend_spear_vol_exhaustion_exit: tsVolExhaustionExit, ts_atr_stop: tsAtrStop, ts_iqr_filter: tsIqrFilter, ts_iqr_threshold: tsIqrThreshold, ts_elev_filter: tsElevFilter, ts_elev_threshold: tsElevThreshold, ytd, ...(poolMode === "named" ? { pool_name: poolName } : {}), ...(poolMode === "custom" ? { symbols: parseSymbols(symbolsRaw) } : {}) },
                        });
                        refetchSchedules();
                        toast.success(cronEnabled ? "定时任务已启用" : "已保存（未启用）");
                      } catch (e: unknown) { toast.error(String(e)); } finally { setCronSaving(false); }
                    }} className="rounded-md px-3 py-1 text-xs font-medium bg-primary/10 text-primary hover:bg-primary/20">{cronSaving ? "保存中..." : "保存定时"}</button>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Full-width start button */}
          <button onClick={handleSubmit} disabled={isRunning}
            className={cn("w-full flex items-center justify-center gap-2 rounded-xl px-6 py-3 text-sm font-semibold transition-all shadow-sm",
              isRunning ? "bg-muted text-muted-foreground cursor-not-allowed" : "bg-primary text-primary-foreground hover:bg-primary/90",
            )}>
            {isRunning ? <Loader2 className="h-4 w-4 animate-spin" /> : <Play className="h-4 w-4" />}
            {isRunning ? "扫描中..." : "开始扫描"}
          </button>
        </div>
      )}

      {/* ═══════ Step 2: Running ═══════ */}
      {step === 2 && task && (
        <div className="rounded-xl border border-border bg-card p-5 space-y-4">
          <div className="flex items-center gap-3">
            <span className="text-sm font-medium">Task {task.id}</span>
            <span className={cn("rounded-full px-2.5 py-0.5 text-xs font-medium",
              task.status === "succeeded" ? "bg-success/20 text-success" : task.status === "failed" ? "bg-destructive/20 text-destructive" : "bg-warning/20 text-warning",
            )}>{task.status}</span>
          </div>
          {isRunning && <TaskLogPanel logLines={logLines} isRunning />}
          {task.status === "failed" && (
            <>
              <p className="text-sm text-destructive">任务失败 (code {task.return_code})</p>
              <TaskLogPanel logLines={logLines} isRunning={false} />
              <button onClick={handleReset} className="flex items-center gap-2 rounded-lg px-4 py-2 text-sm font-medium border border-border hover:bg-accent"><RotateCcw className="h-4 w-4" />重新配置</button>
            </>
          )}
        </div>
      )}

      {/* ═══════ Step 3: Results ═══════ */}
      {step === 3 && snapshot && (
        <div className="space-y-4">
          {/* Top bar: mode info + back button */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              {String(snapshot.mode ?? "") && (
                <span className={cn("rounded-full px-2.5 py-0.5 text-xs font-medium", String(snapshot.mode) === "preview" ? "bg-amber-500/20 text-amber-600" : "bg-success/20 text-success")}>
                  {String(snapshot.mode) === "preview" ? "盘中预测" : "盘后确认"}
                </span>
              )}
              {Boolean(snapshot.effective_date) && snapshot.effective_date !== snapshot.requested_date && (
                <span className="text-xs text-warning">数据截至 {String(snapshot.effective_date)}（请求 {String(snapshot.requested_date)}）</span>
              )}
            </div>
            <button onClick={handleReset} className="flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-medium border border-border hover:bg-accent"><RotateCcw className="h-3.5 w-3.5" />重新配置</button>
          </div>

          {/* View toggle */}
          {hasTradeData && (
            <div className="flex rounded-lg border border-border overflow-hidden">
              <button onClick={() => setViewMode("signals")} className={cn("flex-1 flex items-center justify-center gap-2 px-4 py-2 text-xs font-semibold transition-all", viewMode === "signals" ? "bg-primary text-primary-foreground" : "bg-card text-muted-foreground hover:bg-muted")}>
                <Eye className="h-3.5 w-3.5" />信号总览
              </button>
              <button onClick={() => setViewMode("strategy")} className={cn("flex-1 flex items-center justify-center gap-2 px-4 py-2 text-xs font-semibold transition-all border-l border-border", viewMode === "strategy" ? "bg-primary text-primary-foreground" : "bg-card text-muted-foreground hover:bg-muted")}>
                <Activity className="h-3.5 w-3.5" />策略拟真
              </button>
            </div>
          )}

          {/* Stat bar */}
          {viewMode === "strategy" && hasTradeData ? (
            <div className="grid grid-cols-4 lg:grid-cols-7 gap-2">
              <StatCard value={String(todayEntries.length)} label="今日入场" color="text-up" />
              <StatCard value={String(todayExits.length)} label="今日出场" color="text-down" />
              <StatCard value={String(snapshot.new_signals ?? "0")} label="新信号" color="text-primary" />
              <StatCard value={String(activePositions.length)} label="持仓数" color="text-blue-500" />
              <StatCard value={String(closedTrades.length)} label="已平仓" color="text-muted-foreground" />
              <StatCard value={String(snapshot.active_watch ?? "0")} label="观察中" color="text-success" />
              <StatCard value={String(snapshot.dropped ?? "0")} label="已失效" color="text-destructive" />
            </div>
          ) : (
            <div className="grid grid-cols-3 gap-3">
              <StatCard value={String(snapshot.new_signals ?? "0")} label="新信号" color="text-primary" />
              <StatCard value={String(snapshot.active_watch ?? "0")} label="观察中" color="text-success" />
              <StatCard value={String(snapshot.dropped ?? "0")} label="已失效" color="text-destructive" />
            </div>
          )}

          {/* Sub-tabs */}
          <div className="flex gap-1 flex-wrap">
            {(viewMode === "strategy"
              ? [
                  { key: "positions" as ResultTab, label: "仓位", count: activePositions.length },
                  { key: "hunts" as ResultTab, label: "挂单", count: pendingHunts.length + pendingSellHunts.length },
                  { key: "trades" as ResultTab, label: "交易", count: todayEntries.length + todayExits.length },
                  { key: "closed" as ResultTab, label: "已平仓", count: closedTrades.length },
                  { key: "new" as ResultTab, label: "新信号", count: newSignals.length },
                  { key: "watch" as ResultTab, label: "观察中", count: watchUpdates.length },
                  { key: "dropped" as ResultTab, label: "已失效", count: droppedItems.length },
                ]
              : [
                  { key: "new" as ResultTab, label: "新信号", count: newSignals.length },
                  { key: "watch" as ResultTab, label: "观察中", count: watchUpdates.length },
                  { key: "dropped" as ResultTab, label: "已失效", count: droppedItems.length },
                ]
            ).map((tab) => (
              <button key={tab.key} onClick={() => setResultTab(tab.key)}
                className={cn("rounded-full px-3 py-1 text-[11px] font-medium transition-all",
                  resultTab === tab.key ? "bg-primary text-primary-foreground shadow-sm" : "bg-muted/60 text-muted-foreground hover:bg-muted hover:text-foreground",
                )}>
                {tab.label}{tab.count > 0 && <span className="ml-1 opacity-70">{tab.count}</span>}
              </button>
            ))}
          </div>

          {/* Tab content: Positions */}
          {resultTab === "positions" && viewMode === "strategy" && (() => {
            const equity = ss?.portfolio_equity ?? 0;
            return (
              <div className="rounded-lg border border-border bg-background p-4 space-y-3">
                <div className="flex gap-4 rounded-lg bg-muted/50 border border-border px-4 py-2">
                  <MiniStat label="总权益" value={`${(equity / 10000).toFixed(1)}万`} />
                  <MiniStat label="现金" value={`${((ss?.portfolio_cash ?? 0) / 10000).toFixed(1)}万`} />
                  <MiniStat label="仓位" value={`${ss?.portfolio_exposure_pct?.toFixed(1) ?? 0}%`} color={Number(ss?.portfolio_exposure_pct ?? 0) > 80 ? "text-warning" : undefined} />
                </div>
                {activePositions.length > 0 ? (
                  <div className="overflow-x-auto">
                    <table className="w-full text-xs">
                      <thead><tr className="border-b border-border text-left text-muted-foreground">
                        <th className="pb-1.5 pr-3 font-medium">标的</th><th className="pb-1.5 pr-3 font-medium">入场日</th><th className="pb-1.5 pr-3 font-medium">入场价</th><th className="pb-1.5 pr-3 font-medium">现价</th><th className="pb-1.5 pr-3 font-medium">浮盈%</th><th className="pb-1.5 pr-3 font-medium">仓位%</th><th className="pb-1.5 pr-3 font-medium">天数</th><th className="pb-1.5 font-medium">类型</th>
                      </tr></thead>
                      <tbody>
                        {activePositions.map((p, i) => {
                          const weight = equity > 0 ? (p.qty * p.current_price) / equity * 100 : 0;
                          return (
                            <tr key={`pos-${i}`} className="border-b border-border/50 last:border-0">
                              <td className="py-1.5 pr-3 font-mono font-medium">{p.symbol}{p.name && <span className="ml-1 font-normal text-muted-foreground">{p.name}</span>}</td>
                              <td className="py-1.5 pr-3">{p.entry_date}</td>
                              <td className={cn("py-1.5 pr-3 font-mono", isNearLimitUp(p.entry_price, p.entry_limit_up) && "text-orange-500")}>{p.entry_price.toFixed(2)}</td>
                              <td className="py-1.5 pr-3 font-mono">{p.current_price.toFixed(2)}</td>
                              <td className={cn("py-1.5 pr-3 font-mono font-medium", p.unrealized_pnl_pct >= 0 ? "text-up" : "text-down")}>{p.unrealized_pnl_pct >= 0 ? "+" : ""}{p.unrealized_pnl_pct.toFixed(2)}%</td>
                              <td className="py-1.5 pr-3 font-mono">{weight.toFixed(1)}%</td>
                              <td className="py-1.5 pr-3">D+{p.days_held}</td>
                              <td className="py-1.5 text-muted-foreground">{labelEvent(p.source_event)}</td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                ) : <p className="text-[11px] text-muted-foreground text-center py-4">暂无持仓</p>}
              </div>
            );
          })()}

          {/* Tab content: Pending Hunts */}
          {resultTab === "hunts" && viewMode === "strategy" && (
            <div className="rounded-lg border border-border bg-background p-4 space-y-3">
              {pendingHunts.length > 0 ? (
                <>
                  <div className="text-xs font-medium text-muted-foreground">挂单预购池 ({pendingHunts.length})</div>
                  <div className="overflow-x-auto">
                    <table className="w-full text-xs">
                      <thead><tr className="border-b border-border text-left text-muted-foreground">
                        <th className="pb-1.5 pr-3 font-medium">标的</th>
                        <th className="pb-1.5 pr-3 font-medium">类型</th>
                        <th className="pb-1.5 pr-3 font-medium">城门价</th>
                        <th className="pb-1.5 pr-3 font-medium">止损价</th>
                        <th className="pb-1.5 pr-3 font-medium">仓位</th>
                        <th className="pb-1.5 pr-3 font-medium">有效期</th>
                        <th className="pb-1.5 font-medium">状态</th>
                      </tr></thead>
                      <tbody>
                        {pendingHunts.map((h, i) => (
                          <tr key={`hunt-${i}`} className="border-b border-border/50 last:border-0">
                            <td className="py-1.5 pr-3 font-mono font-medium">{h.symbol}{h.name && <span className="ml-1 font-normal text-muted-foreground">{h.name}</span>}</td>
                            <td className="py-1.5 pr-3">{labelEvent(h.source_event ?? "")}</td>
                            <td className="py-1.5 pr-3 font-mono">¥{h.target_price.toFixed(2)}</td>
                            <td className="py-1.5 pr-3 font-mono text-destructive">¥{h.invalidate_price.toFixed(2)}</td>
                            <td className="py-1.5 pr-3 font-mono">{(h.position_mult * 100).toFixed(0)}%</td>
                            <td className="py-1.5 pr-3 tabular-nums">{h.valid_from_date} ~ {h.valid_until_date}</td>
                            <td className="py-1.5">{h.status ?? "等待触发"}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </>
              ) : <p className="text-[11px] text-muted-foreground text-center py-4">暂无买入挂单</p>}
              {pendingSellHunts.length > 0 && (
                <>
                  <div className="text-xs font-medium text-muted-foreground mt-3">卖出挂单 ({pendingSellHunts.length})</div>
                  <div className="overflow-x-auto">
                    <table className="w-full text-xs">
                      <thead><tr className="border-b border-border text-left text-muted-foreground">
                        <th className="pb-1.5 pr-3 font-medium">标的</th>
                        <th className="pb-1.5 pr-3 font-medium">目标价</th>
                        <th className="pb-1.5 pr-3 font-medium">类型</th>
                        <th className="pb-1.5 font-medium">有效至</th>
                      </tr></thead>
                      <tbody>
                        {pendingSellHunts.map((sh, i) => (
                          <tr key={`sh-${i}`} className="border-b border-border/50 last:border-0">
                            <td className="py-1.5 pr-3 font-mono font-medium">{sh.symbol}</td>
                            <td className="py-1.5 pr-3 font-mono">¥{sh.target_price.toFixed(2)}</td>
                            <td className="py-1.5 pr-3">{sh.reason ?? ""}</td>
                            <td className="py-1.5">{sh.valid_until_date ?? ""}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </>
              )}
            </div>
          )}

          {/* Tab content: Trades */}
          {resultTab === "trades" && viewMode === "strategy" && (
            <div className="rounded-lg border border-border bg-background p-4 space-y-3">
              {todayEntries.length > 0 && (
                <>
                  <div className="text-xs font-medium text-muted-foreground">入场 ({todayEntries.length})</div>
                  <div className="overflow-x-auto">
                    <table className="w-full text-xs">
                      <thead><tr className="border-b border-border text-left text-muted-foreground"><th className="pb-1.5 pr-3 font-medium">标的</th><th className="pb-1.5 pr-3 font-medium">价格</th><th className="pb-1.5 pr-3 font-medium">数量</th><th className="pb-1.5 pr-3 font-medium">来源</th><th className="pb-1.5 font-medium">仓位%</th></tr></thead>
                      <tbody>{todayEntries.map((t, i) => (<tr key={`e-${i}`} className="border-b border-border/50 last:border-0"><td className="py-1.5 pr-3 font-mono font-medium">{t.symbol}{t.name && <span className="ml-1 font-normal text-muted-foreground">{t.name}</span>}</td><td className="py-1.5 pr-3 font-mono">{t.price.toFixed(2)}</td><td className="py-1.5 pr-3 font-mono">{t.qty.toFixed(0)}</td><td className="py-1.5 pr-3">{labelEvent(t.signal_type || t.reason)}</td><td className="py-1.5 font-mono">{t.position_pct.toFixed(1)}%</td></tr>))}</tbody>
                    </table>
                  </div>
                </>
              )}
              {todayExits.length > 0 && (
                <>
                  <div className="text-xs font-medium text-muted-foreground">出场 ({todayExits.length})</div>
                  <div className="overflow-x-auto">
                    <table className="w-full text-xs">
                      <thead><tr className="border-b border-border text-left text-muted-foreground"><th className="pb-1.5 pr-3 font-medium">标的</th><th className="pb-1.5 pr-3 font-medium">价格</th><th className="pb-1.5 font-medium">原因</th></tr></thead>
                      <tbody>{todayExits.map((t, i) => (<tr key={`x-${i}`} className="border-b border-border/50 last:border-0"><td className="py-1.5 pr-3 font-mono font-medium">{t.symbol}{t.name && <span className="ml-1 font-normal text-muted-foreground">{t.name}</span>}</td><td className="py-1.5 pr-3 font-mono">{t.price.toFixed(2)}</td><td className="py-1.5">{labelReason(t.reason)}</td></tr>))}</tbody>
                    </table>
                  </div>
                </>
              )}
              {todayEntries.length === 0 && todayExits.length === 0 && <p className="text-[11px] text-muted-foreground text-center py-4">暂无今日交易</p>}
            </div>
          )}

          {/* Tab content: Closed */}
          {resultTab === "closed" && viewMode === "strategy" && (
            <div className="rounded-lg border border-border bg-background p-4">
              {closedTrades.length > 0 ? (
                <div className="overflow-x-auto">
                  <table className="w-full text-xs">
                    <thead><tr className="border-b border-border text-left text-muted-foreground"><th className="pb-1.5 pr-3 font-medium">标的</th><th className="pb-1.5 pr-3 font-medium">买入</th><th className="pb-1.5 pr-3 font-medium">买价</th><th className="pb-1.5 pr-3 font-medium">卖出</th><th className="pb-1.5 pr-3 font-medium">卖价</th><th className="pb-1.5 pr-3 font-medium">盈亏%</th><th className="pb-1.5 pr-3 font-medium">天数</th><th className="pb-1.5 font-medium">原因</th></tr></thead>
                    <tbody>
                      {closedTrades.map((ct, i) => (
                        <tr key={`ct-${i}`} className="border-b border-border/50 last:border-0">
                          <td className="py-1.5 pr-3 font-mono font-medium">{ct.symbol}{ct.name && <span className="ml-1 font-normal text-muted-foreground">{ct.name}</span>}</td>
                          <td className="py-1.5 pr-3 font-mono">{ct.buy_date}</td>
                          <td className="py-1.5 pr-3 font-mono">{ct.buy_price.toFixed(2)}</td>
                          <td className="py-1.5 pr-3 font-mono">{ct.sell_date}</td>
                          <td className="py-1.5 pr-3 font-mono">{ct.sell_price.toFixed(2)}</td>
                          <td className={cn("py-1.5 pr-3 font-mono font-medium", ct.pnl_pct >= 0 ? "text-up" : "text-down")}>{ct.pnl_pct >= 0 ? "+" : ""}{ct.pnl_pct.toFixed(2)}%</td>
                          <td className="py-1.5 pr-3 font-mono">{ct.holding_days}天</td>
                          <td className="py-1.5 text-muted-foreground">{labelReason(ct.reason) || labelEvent(ct.source_event) || "—"}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              ) : <p className="text-[11px] text-muted-foreground text-center py-4">暂无已平仓</p>}
            </div>
          )}

          {/* Tab content: New Signals */}
          {resultTab === "new" && newSignals.length > 0 && (
            <div className="rounded-lg border border-border bg-background p-4">
              <div className="overflow-x-auto">
                <table className="w-full text-xs">
                  <thead><tr className="border-b border-border text-left text-muted-foreground">
                    <th className="pb-1.5 pr-3 font-medium">标的</th><th className="pb-1.5 pr-3 font-medium">类型</th><th className="pb-1.5 pr-3 font-medium">入场</th><th className="pb-1.5 pr-3 font-medium">城门价</th><th className="pb-1.5 pr-3 font-medium">止损价</th><th className="pb-1.5 pr-3 font-medium" title="同类信号盘中峰值中位数 - 城门溢价">预期上行</th><th className="pb-1.5 pr-3 font-medium">板块</th><th className="pb-1.5 pr-3 font-medium">同板块联动</th>
                    {viewMode === "strategy" && <th className="pb-1.5 font-medium">交易</th>}
                  </tr></thead>
                  <tbody>
                    {newSignals.slice(newSigPage * PAGE_SIZE, (newSigPage + 1) * PAGE_SIZE).map((s, i) => (
                      <tr key={`${s.symbol}-${s.event_type}-${i}`} className="border-b border-border/50 last:border-0">
                        <td className="py-1.5 pr-3 font-mono font-medium">{s.symbol}{s.name && <span className="ml-1 font-normal text-muted-foreground">{s.name}</span>}{s.peer_tier === "high" && (s.event_type === "attack" || s.event_type === "arb") && <span className="ml-1 text-[9px] rounded-full px-1 py-0.5 bg-success/15 text-success font-medium">板块联动强</span>}</td>
                        <td className="py-1.5 pr-3">{labelEvent(s.event_type)}</td>
                        <td className="py-1.5 pr-3">{labelEntryStyle(s.entry_style)}</td>
                        <td className="py-1.5 pr-3 font-mono">{s.gate_price?.toFixed(2) ?? "—"}{(s.gate_gap_pct ?? 0) > 0.005 && <span className="ml-0.5 text-warning text-[10px]">+{((s.gate_gap_pct ?? 0) * 100).toFixed(1)}%</span>}</td>
                        <td className="py-1.5 pr-3 font-mono text-destructive">{s.invalidation_price?.toFixed(2) ?? "—"}</td>
                        <td className="py-1.5 pr-3 font-mono text-primary font-medium">{(s.adj_potential ?? 0) > 0 ? `~${((s.adj_potential ?? 0) * 100).toFixed(0)}%` : "—"}</td>
                        <td className="py-1.5 pr-3">{s.theme_label}</td>
                        <td className="py-1.5 pr-3">{formatEnv(s, disableEnvMapping)}</td>
                        {viewMode === "strategy" && <td className="py-1.5">{s.traded ? <span className="rounded-full px-1.5 py-0.5 text-[10px] font-medium bg-success/20 text-success">已入场</span> : s.near_gate ? <span className="rounded-full px-1.5 py-0.5 text-[10px] font-medium bg-amber-500/20 text-amber-600">接近城门</span> : <span className="text-[10px] text-muted-foreground">—</span>}</td>}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <Pagination page={newSigPage} totalPages={Math.ceil(newSignals.length / PAGE_SIZE)} totalItems={newSignals.length} pageSize={PAGE_SIZE} onPageChange={setNewSigPage} />
            </div>
          )}
          {resultTab === "new" && newSignals.length === 0 && <p className="text-[11px] text-muted-foreground text-center py-6">暂无新信号</p>}

          {/* Tab content: Watch */}
          {resultTab === "watch" && watchUpdates.length > 0 && (
            <div className="rounded-lg border border-border bg-background p-4">
              <div className="overflow-x-auto">
                <table className="w-full text-xs">
                  <thead><tr className="border-b border-border text-left text-muted-foreground">
                    <th className="pb-1.5 pr-3 font-medium">标的</th><th className="pb-1.5 pr-3 font-medium">类型</th><th className="pb-1.5 pr-3 font-medium">信号日</th><th className="pb-1.5 pr-3 font-medium">天数</th><th className="pb-1.5 pr-3 font-medium">状态</th><th className="pb-1.5 pr-3 font-medium">收益</th><th className="pb-1.5 pr-3 font-medium">峰值</th><th className="pb-1.5 pr-3 font-medium">回撤</th><th className="pb-1.5 pr-3 font-medium">触价</th><th className="pb-1.5 font-medium">备注</th>
                  </tr></thead>
                  <tbody>
                    {watchUpdates.slice(watchUpPage * PAGE_SIZE, (watchUpPage + 1) * PAGE_SIZE).map((w, i) => {
                      const dd = w.drawdown_from_peak ?? 0;
                      const noteText = [w.path_hint ?? "", w.note].filter(Boolean).join(" · ");
                      return (
                        <tr key={`${w.symbol}-${w.event_type}-${i}`} className="border-b border-border/50 last:border-0">
                          <td className="py-1.5 pr-3 font-mono font-medium">{w.symbol}{w.name && <span className="ml-1 font-normal text-muted-foreground">{w.name}</span>}</td>
                          <td className="py-1.5 pr-3">{labelEvent(w.event_type)}</td>
                          <td className="py-1.5 pr-3">{w.signal_date}</td>
                          <td className="py-1.5 pr-3">D+{w.obs_day}</td>
                          <td className="py-1.5 pr-3"><span className={cn("rounded-full px-1.5 py-0.5 text-[10px] font-medium", w.status_label.includes("强") ? "bg-success/20 text-success" : w.status_label.includes("弱") ? "bg-destructive/20 text-destructive" : "bg-muted text-muted-foreground")}>{w.status_label}</span></td>
                          <td className={cn("py-1.5 pr-3 font-mono", w.close_ret_since_signal >= 0 ? "text-up" : "text-down")}>{prettyPct(w.close_ret_since_signal)}</td>
                          <td className="py-1.5 pr-3 font-mono text-up">{prettyPct(w.max_ret_since_signal)}</td>
                          <td className={cn("py-1.5 pr-3 font-mono", dd > 0.05 ? "text-destructive font-medium" : "text-muted-foreground")}>{dd > 0.001 ? prettyPct(-dd) : "—"}</td>
                          <td className="py-1.5 pr-3">{w.hunt_touched ? "✓" : "—"}</td>
                          <td className="py-1.5 text-muted-foreground max-w-[140px] truncate">{noteText}</td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
              <Pagination page={watchUpPage} totalPages={Math.ceil(watchUpdates.length / PAGE_SIZE)} totalItems={watchUpdates.length} pageSize={PAGE_SIZE} onPageChange={setWatchUpPage} />
            </div>
          )}
          {resultTab === "watch" && watchUpdates.length === 0 && <p className="text-[11px] text-muted-foreground text-center py-6">暂无观察中的信号</p>}

          {/* Tab content: Dropped */}
          {resultTab === "dropped" && droppedItems.length > 0 && (
            <div className="rounded-lg border border-border bg-background p-4">
              <div className="overflow-x-auto">
                <table className="w-full text-xs">
                  <thead><tr className="border-b border-border text-left text-muted-foreground"><th className="pb-1.5 pr-3 font-medium">标的</th><th className="pb-1.5 pr-3 font-medium">类型</th><th className="pb-1.5 pr-3 font-medium">信号日</th><th className="pb-1.5 pr-3 font-medium">观察天数</th><th className="pb-1.5 pr-3 font-medium">失效时收益</th><th className="pb-1.5 pr-3 font-medium">期间最高涨幅</th><th className="pb-1.5 font-medium">原因</th></tr></thead>
                  <tbody>
                    {droppedItems.slice(droppedPage * PAGE_SIZE, (droppedPage + 1) * PAGE_SIZE).map((d, i) => (
                      <tr key={`${d.symbol}-${d.event_type}-${i}`} className="border-b border-border/50 last:border-0">
                        <td className="py-1.5 pr-3 font-mono font-medium">{d.symbol}{d.name && <span className="ml-1 font-normal text-muted-foreground">{d.name}</span>}</td>
                        <td className="py-1.5 pr-3">{labelEvent(d.event_type)}</td>
                        <td className="py-1.5 pr-3">{d.signal_date}</td>
                        <td className="py-1.5 pr-3 tabular-nums">D+{d.obs_day}</td>
                        <td className={cn("py-1.5 pr-3 font-mono", d.close_ret_since_signal >= 0 ? "text-up" : "text-down")}>{prettyPct(d.close_ret_since_signal)}</td>
                        <td className="py-1.5 pr-3 font-mono text-up">{prettyPct(d.max_ret_since_signal)}</td>
                        <td className="py-1.5 text-muted-foreground">{d.note}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <Pagination page={droppedPage} totalPages={Math.ceil(droppedItems.length / PAGE_SIZE)} totalItems={droppedItems.length} pageSize={PAGE_SIZE} onPageChange={setDroppedPage} />
            </div>
          )}
          {resultTab === "dropped" && droppedItems.length === 0 && <p className="text-[11px] text-muted-foreground text-center py-6">暂无已失效信号</p>}

          {/* Feishu preview + push */}
          {scanSummary?.markdown && (
            <div className="rounded-lg border border-border bg-background">
              <button onClick={() => setShowMessagePreview(!showMessagePreview)} className="w-full flex items-center gap-2 px-4 py-2.5 text-xs font-medium hover:bg-muted/50 transition-colors">
                <FileText className="h-3.5 w-3.5 text-blue-400" /><span>飞书消息预览</span>
                {showMessagePreview ? <ChevronDown className="h-3.5 w-3.5 ml-auto text-muted-foreground" /> : <ChevronRight className="h-3.5 w-3.5 ml-auto text-muted-foreground" />}
              </button>
              {showMessagePreview && (
                <div className="px-4 pb-3 border-t border-border pt-3">
                  <pre className="text-xs leading-relaxed whitespace-pre-wrap font-mono text-foreground/90 max-h-80 overflow-y-auto">{scanSummary.markdown}</pre>
                </div>
              )}
            </div>
          )}

          <div className="flex items-center gap-3">
            <button onClick={handlePush} disabled={pushing || pushed || !hasFeishuConfig}
              className={cn("flex items-center gap-2 rounded-lg px-4 py-2 text-sm font-medium transition-colors",
                pushed ? "bg-success/20 text-success cursor-default" : !hasFeishuConfig ? "bg-muted text-muted-foreground cursor-not-allowed" : "bg-blue-600 text-white hover:bg-blue-700",
              )}>
              {pushing ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
              {pushed ? "已推送" : pushing ? "推送中..." : "推送到飞书"}
            </button>
            {!hasFeishuConfig && <span className="text-xs text-muted-foreground">未配置飞书 Webhook</span>}
          </div>
        </div>
      )}

      {/* ═══════ Always visible: Persistent Watch ═══════ */}
      <PersistentWatchSection items={watchItems} filter={watchFilter} onFilterChange={setWatchFilter} />
    </div>
  );
}

function StatCard({ value, label, color }: { value: string; label: string; color: string }) {
  return (
    <div className="rounded-lg bg-background border border-border p-3 text-center">
      <div className={cn("text-2xl font-bold tabular-nums", color)}>{value}</div>
      <div className="text-[10px] text-muted-foreground mt-0.5">{label}</div>
    </div>
  );
}

function PoolPreviewPanel({ preview, onClose }: { preview: PoolPreview; onClose: () => void }) {
  const missingSet = new Set(preview.missing_symbols ?? []);
  const missingCount = missingSet.size;
  return (
    <div className="rounded-lg border border-border bg-background p-3">
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center gap-2">
          <span className="text-xs font-medium">{preview.count} 只标的</span>
          {missingCount > 0 && (
            <span className="text-[10px] text-amber-600 dark:text-amber-400">
              ({missingCount} 缺缓存)
            </span>
          )}
        </div>
        <button onClick={onClose} className="text-muted-foreground hover:text-foreground"><X className="h-3.5 w-3.5" /></button>
      </div>
      <div className="max-h-48 overflow-y-auto">
        <table className="w-full text-xs">
          <thead><tr className="border-b border-border text-left text-muted-foreground">
            <th className="pb-1 pr-3 font-medium w-8">#</th><th className="pb-1 pr-3 font-medium">代码</th><th className="pb-1 font-medium">名称</th>
          </tr></thead>
          <tbody>
            {preview.symbols.map((s, i) => {
              const isMissing = missingSet.has(s.symbol);
              return (
                <tr key={s.symbol} className={cn("border-b border-border/30 last:border-0", isMissing && "text-amber-600 dark:text-amber-400")}>
                  <td className="py-0.5 pr-3 text-muted-foreground">{i + 1}</td>
                  <td className="py-0.5 pr-3 font-mono">{s.symbol}</td>
                  <td className={cn("py-0.5", isMissing ? "text-amber-500/70 dark:text-amber-400/70" : "text-muted-foreground")}>{s.name || (isMissing ? "无缓存" : "")}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function CollapsibleSection({ title, defaultOpen = false, open: controlledOpen, onToggle, badge, children }: {
  title: string; defaultOpen?: boolean; open?: boolean; onToggle?: () => void;
  badge: "primary" | "success" | "destructive" | "default"; children: React.ReactNode;
}) {
  const [internalOpen, setInternalOpen] = useState(defaultOpen);
  const isOpen = controlledOpen !== undefined ? controlledOpen : internalOpen;
  const handleToggle = onToggle ?? (() => setInternalOpen(v => !v));
  const badgeClass = badge === "primary" ? "bg-primary/20 text-primary" : badge === "success" ? "bg-success/20 text-success" : badge === "destructive" ? "bg-destructive/20 text-destructive" : "bg-muted text-muted-foreground";
  return (
    <div className="rounded-lg border border-border bg-background">
      <button onClick={handleToggle} className="w-full flex items-center gap-2 px-4 py-2.5 text-xs font-medium hover:bg-muted/50 transition-colors">
        <span className={cn("rounded-full px-2 py-0.5 text-[10px] font-medium", badgeClass)}>{title}</span>
        {isOpen ? <ChevronDown className="h-3.5 w-3.5 ml-auto text-muted-foreground" /> : <ChevronRight className="h-3.5 w-3.5 ml-auto text-muted-foreground" />}
      </button>
      {isOpen && <div className="px-4 pb-3 border-t border-border pt-3">{children}</div>}
    </div>
  );
}

type WatchFilterState = { status: string; type: string };

function PersistentWatchSection({ items, filter, onFilterChange }: {
  items: Record<string, unknown>[];
  filter: WatchFilterState;
  onFilterChange: (f: WatchFilterState) => void;
}) {
  const activeItems = useMemo(() => items.filter((i) => i.active !== false), [items]);

  const uniqueStatuses = useMemo(() => [...new Set(activeItems.map((i) => String(i.status_label ?? "")))].filter(Boolean).sort(), [activeItems]);
  const uniqueTypes = useMemo(() => [...new Set(activeItems.map((i) => String(i.event_type ?? "")))].filter(Boolean).sort(), [activeItems]);
  const filtered = useMemo(() => {
    let result = activeItems;
    if (filter.status) result = result.filter((i) => i.status_label === filter.status);
    if (filter.type) result = result.filter((i) => i.event_type === filter.type);
    return result;
  }, [activeItems, filter]);

  const stats = useMemo(() => {
    if (!filtered.length) return null;
    const rets = filtered.map((i) => Number(i.close_ret_since_signal ?? 0));
    const maxRets = filtered.map((i) => Number(i.max_ret_since_signal ?? 0));
    const days = filtered.map((i) => Number(i.obs_day ?? 0));
    const winCount = rets.filter((r) => r > 0).length;
    const avg = (arr: number[]) => arr.reduce((a, b) => a + b, 0) / arr.length;
    return {
      total: filtered.length,
      winRate: winCount / filtered.length,
      avgRet: avg(rets),
      avgMaxRet: avg(maxRets),
      avgDays: avg(days),
      huntRate: filtered.filter((i) => i.hunt_touched).length / filtered.length,
    };
  }, [filtered]);

  const hasFilter = filter.status || filter.type;

  return (
    <div className="rounded-xl border border-border bg-card p-5 space-y-3">
      <div className="flex items-center gap-3 mb-1">
        <h2 className="text-sm font-semibold">信号观察池</h2>
        <span className="text-[10px] text-muted-foreground bg-muted rounded-full px-2 py-0.5">
          {activeItems.length} 活跃
        </span>
      </div>
      <p className="text-[10px] text-muted-foreground">所有信号的完整生命周期追踪。飞书推送仅发送每日摘要，此表为跨次运行的持久化全量状态。</p>

      {/* Filter chips */}
      {activeItems.length > 0 && (
        <div className="flex flex-wrap items-center gap-2">
          <Filter className="h-3 w-3 text-muted-foreground" />
          <FilterChipGroup label="状态" options={uniqueStatuses} value={filter.status} onChange={(v) => onFilterChange({ ...filter, status: v })} />
          <FilterChipGroup label="类型" options={uniqueTypes} value={filter.type} onChange={(v) => onFilterChange({ ...filter, type: v })} labelFn={labelEvent} />
          {hasFilter && (
            <button onClick={() => onFilterChange({ status: "", type: "" })} className="text-[10px] text-muted-foreground hover:text-foreground underline">
              清除筛选
            </button>
          )}
        </div>
      )}

      {/* Stats bar */}
      {stats && (
        <div className="flex gap-4 rounded-lg bg-muted/50 border border-border px-4 py-2">
          <MiniStat label="数量" value={String(stats.total)} />
          <MiniStat label="胜率" value={`${(stats.winRate * 100).toFixed(0)}%`} color={stats.winRate >= 0.5 ? "text-up" : "text-down"} />
          <MiniStat label="平均收益" value={prettyPct(stats.avgRet)} color={stats.avgRet >= 0 ? "text-up" : "text-down"} />
          <MiniStat label="平均最大" value={prettyPct(stats.avgMaxRet)} color="text-up" />
          <MiniStat label="平均天数" value={`D+${stats.avgDays.toFixed(1)}`} />
          <MiniStat label="触价率" value={`${(stats.huntRate * 100).toFixed(0)}%`} />
        </div>
      )}

      <WatchStateTable items={filtered as never[]} />
    </div>
  );
}

function FilterChipGroup({ label, options, value, onChange, labelFn }: {
  label: string; options: string[]; value: string; onChange: (v: string) => void; labelFn?: (v: string) => string;
}) {
  if (options.length <= 1) return null;
  return (
    <div className="flex items-center gap-1">
      <span className="text-[10px] text-muted-foreground mr-0.5">{label}:</span>
      {options.map((opt) => (
        <button
          key={opt}
          onClick={() => onChange(value === opt ? "" : opt)}
          className={cn(
            "rounded-full px-2 py-0.5 text-[10px] font-medium transition-all",
            value === opt ? "bg-primary text-primary-foreground shadow-sm" : "bg-muted text-muted-foreground hover:bg-accent",
          )}
        >
          {labelFn ? labelFn(opt) : opt}
        </button>
      ))}
    </div>
  );
}

function MiniStat({ label, value, color }: { label: string; value: string; color?: string }) {
  return (
    <div className="text-center">
      <div className={cn("text-xs font-semibold tabular-nums", color)}>{value}</div>
      <div className="text-[9px] text-muted-foreground">{label}</div>
    </div>
  );
}
