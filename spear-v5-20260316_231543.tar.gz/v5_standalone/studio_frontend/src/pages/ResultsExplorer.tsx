import { Activity, ChevronDown, ChevronRight, Crosshair, Eye, FileText, FolderOpen, Loader2, RotateCcw, Trash2, X } from "lucide-react";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { EquityChart, TradeMarkerLegend } from "../components/EquityChart";
import { OverviewPanel } from "../components/OverviewPanel";
import { Pagination } from "../components/Pagination";

import { TradesTable } from "../components/TradesTable";
import { useApi } from "../hooks/useApi";
import {
  api,
  type BacktestStat,
  type BacktestStatEntry,
  type EquityPoint,
  type MetaInfo,
  type NotableTrade,
  type ClosedTradeItem,
  type PendingHuntItem,
  type PendingSellHuntItem,
  type PositionSummaryItem,
  type ResultEntry,
  type ResultOverview,
  type SignalScanSummary,
  type SignalSnapshotItem,
  type TradeSummaryItem,
  type WatchUpdateItem,
} from "../lib/api";
import { cn, prettyDate, prettyDateTime, prettyPct } from "../lib/utils";

/* ── Helpers ───────────────────────────────────────────── */

function hasStats(s: BacktestStat["stats"]): s is BacktestStatEntry {
  return "total_closed" in s && (s as BacktestStatEntry).total_closed > 0;
}

function pct(v: number | undefined | null, digits = 2): string {
  if (v === undefined || v === null) return "—";
  return `${v >= 0 ? "+" : ""}${v.toFixed(digits)}%`;
}

function money(v: number | undefined | null): string {
  if (v === undefined || v === null) return "—";
  const n = Number(v);
  const abs = Math.abs(n);
  if (abs >= 1e6) return `¥${(n / 1e6).toFixed(2)}M`;
  if (abs >= 1e4) return `¥${(n / 1e3).toFixed(1)}K`;
  return `¥${n.toLocaleString()}`;
}

function retColor(v: number | undefined | null): string {
  if (v === undefined || v === null || v === 0) return "";
  return v > 0 ? "text-up" : "text-down";
}

function isNearLimitUp(price: number, limitUp?: number): boolean {
  return limitUp != null && price >= limitUp * 0.998;
}
function isNearLimitDown(price: number, limitDown?: number): boolean {
  return limitDown != null && price <= limitDown * 1.002;
}

const PROF_SHORT: Record<string, string> = {
  day_level_ideal: "DLI",
  next_open_realistic: "NOR",
  delayed_limit_hunt: "DLH",
};
const PROF_LABEL: Record<string, string> = {
  day_level_ideal: "当日收盘",
  next_open_realistic: "次日开盘",
  delayed_limit_hunt: "挂单猎手",
};

const EVENT_LABELS: Record<string, string> = {
  trend_spear: "趋势长枪", post_limit: "板后长枪", failed_board: "烂板长枪",
  youzi: "游资长枪", sector_spear: "板块长枪", attack: "进攻长枪",
  arb: "套利长枪", escape: "逃命长枪", tail_close: "尾盘入场",
  breakout: "突破入场", continuation: "趋势延续",
};
const ENTRY_STYLE_LABELS: Record<string, string> = {
  breakout: "突破入场", tail_close: "尾盘入场",
};
const REASON_LABELS: Record<string, string> = {
  stop_loss: "止损", take_profit: "止盈", time_exit: "到期",
  no_premium: "无溢价", failed_continuation: "趋势失败",
  theme_collapse: "主题退潮", rebreak: "跌破支撑",
  escape_risk_off: "风险逃离", sell_hunt_expired: "挂单到期",
};
function labelEvent(code: string): string {
  if (!code) return "—";
  const clean = code.replace(/^entry:/, "");
  return EVENT_LABELS[clean] ?? clean;
}
function labelEntryStyle(code: string): string {
  if (!code) return "—";
  return ENTRY_STYLE_LABELS[code] ?? code;
}
function labelReason(code: string): string {
  if (!code) return "—";
  const clean = code.replace(/_forced$/, "");
  return REASON_LABELS[clean] ?? code;
}
function formatEnv(s: { sector_hot: boolean; peer_confirmation: number; leader_strength: number }): React.JSX.Element {
  const peer = s.peer_confirmation;
  const leader = s.leader_strength;

  if (s.sector_hot) {
    return (
      <span className="inline-flex items-center gap-1">
        <span className="text-warning font-medium">热门</span>
        <span className="text-muted-foreground text-[10px]">{peer}只共振 {leader}只龙头</span>
      </span>
    );
  }
  if (peer > 0 || leader > 0) {
    return <span className="text-muted-foreground">{peer}只共振 {leader}只龙头</span>;
  }
  return <span className="text-muted-foreground/50">无</span>;
}

function parseYearKey(name: string, config?: Record<string, unknown>): string {
  if (config?.start && config?.end) {
    const s = String(config.start).slice(0, 4);
    const e = String(config.end).slice(0, 4);
    return s === e ? s : `${s}-${e}`;
  }
  const match = name.match(/\d{8}_(\d{4})-(\d{4})/);
  if (match) return match[1] === match[2] ? match[1] : `${match[1]}-${match[2]}`;
  return "其他";
}

function humanName(name: string, config?: Record<string, unknown>): { title: string; sub: string } {
  const pool = config?.pool_name
    ? String(config.pool_name)
    : config?.pool ? `Pool ${config.pool}` : "";
  const prof = PROF_LABEL[String(config?.execution_profile ?? "")] ?? "";
  const period = config?.start && config?.end
    ? `${String(config.start).slice(0, 10)} ~ ${String(config.end).slice(0, 10)}`
    : "";
  if (period && prof) return { title: `${period}`, sub: [prof, pool].filter(Boolean).join(" · ") };
  const m = name.match(/^\d{8}_(.+?)_[a-f0-9]{6}$/);
  if (m) return { title: m[1].replace(/_/g, " "), sub: "" };
  return { title: name.replace(/_/g, " "), sub: "" };
}

/* ── Signal Row (table-style) ─────────────────────────── */

function SignalRow({
  result, selected, onSelect, onDelete,
}: {
  result: ResultEntry; selected: boolean; onSelect: () => void; onDelete: () => void;
}) {
  const m = result.meta;
  const cfg = (m?.config ?? {}) as Record<string, unknown>;
  const effectiveDate = String(m?.effective_date ?? m?.date ?? result.name);
  const requestedDate = String(m?.requested_date ?? "");
  const dataStale = Boolean(m?.data_stale) || (requestedDate && requestedDate !== effectiveDate);
  const tsMatch = result.name.match(/T(\d{2})(\d{2})\d{2}$/);
  const dateDisplay = tsMatch ? `${effectiveDate} ${tsMatch[1]}:${tsMatch[2]}` : effectiveDate;
  const mode = String(m?.mode ?? "");
  const newSig = Number(m?.new_signals ?? 0);
  const watch = Number(m?.active_watch ?? 0);
  const dropped = Number(m?.dropped ?? 0);
  const poolLabel = cfg.pool_name ? String(cfg.pool_name) : m?.pool_size ? String(m.pool_size) : null;
  const profShort = PROF_SHORT[String(m?.execution_profile ?? "")] ?? "";
  const [confirmDelete, setConfirmDelete] = useState(false);

  return (
    <tr
      className={cn(
        "group cursor-pointer transition-colors border-b border-border/40 last:border-0",
        selected ? "bg-primary/[0.06]" : "hover:bg-muted/50",
      )}
      onClick={onSelect}
    >
      <td className="py-2 px-3">
        <div className="flex items-center gap-1.5">
          <span className={cn("w-1 h-4 rounded-full flex-shrink-0", selected ? "bg-primary" : dataStale ? "bg-warning" : "bg-success/60")} />
          <span className="text-xs font-bold tabular-nums">{dateDisplay}</span>
          {dataStale && (
            <span
              className="rounded-full px-1.5 py-0.5 text-[9px] font-medium bg-warning/15 text-warning"
              title={`目标 ${requestedDate}，实际数据截止 ${effectiveDate}`}
            >
              数据滞后
            </span>
          )}
          {mode && (
            <span className={cn(
              "rounded-full px-1.5 py-0.5 text-[9px] font-medium",
              mode === "confirm" ? "bg-success/15 text-success" : "bg-warning/15 text-warning",
            )}>
              {mode === "confirm" ? "确认" : mode === "preview" ? "预览" : mode}
            </span>
          )}
          {profShort && (
            <span className="rounded bg-muted px-1 py-0.5 text-[9px] font-medium text-muted-foreground">{profShort}</span>
          )}
          {Boolean(cfg.ytd) && <span className="rounded bg-blue-500/15 px-1 py-0.5 text-[9px] font-medium text-blue-500">YTD</span>}
          {Boolean(cfg.disable_env_mapping) && <span className="rounded bg-amber-500/15 px-1 py-0.5 text-[9px] font-medium text-amber-600">无行业</span>}
        </div>
      </td>
      <td className="py-2 px-2 text-center"><span className="text-xs font-bold tabular-nums text-primary">{newSig}</span></td>
      <td className="py-2 px-2 text-center"><span className="text-xs font-bold tabular-nums text-up">{watch}</span></td>
      <td className="py-2 px-2 text-center"><span className="text-xs font-bold tabular-nums text-down">{dropped}</span></td>
      <td className="py-2 px-2 text-center text-[10px] text-muted-foreground tabular-nums" title={poolLabel ?? ""}>{poolLabel ?? "—"}</td>
      <td className="py-2 px-2 text-right text-[10px] text-muted-foreground tabular-nums">{prettyDateTime(result.updated_at)}</td>
      <td className="py-2 px-2 w-8">
        {!confirmDelete ? (
          <button
            onClick={(e) => { e.stopPropagation(); setConfirmDelete(true); }}
            className="opacity-0 group-hover:opacity-100 rounded p-1 hover:bg-destructive/10 text-muted-foreground hover:text-destructive transition-all"
            title="删除"
          ><Trash2 className="h-3 w-3" /></button>
        ) : (
          <div className="flex items-center gap-0.5" onClick={(e) => e.stopPropagation()}>
            <button onClick={onDelete} className="text-[9px] font-medium text-destructive hover:bg-destructive/10 px-1 py-0.5 rounded">删</button>
            <button onClick={() => setConfirmDelete(false)} className="text-[9px] font-medium text-muted-foreground hover:bg-muted px-1 py-0.5 rounded">取</button>
          </div>
        )}
      </td>
    </tr>
  );
}

/* ── Backtest Row (table-style) ───────────────────────── */

function BacktestRow({
  result, stat, selected, onSelect, onDelete,
}: {
  result: ResultEntry; stat?: BacktestStat; selected: boolean; onSelect: () => void; onDelete: () => void;
}) {
  const s = stat && hasStats(stat.stats) ? (stat.stats as BacktestStatEntry) : null;
  const profile = stat ? PROF_SHORT[String(stat.config.execution_profile ?? "")] : "";
  const { title, sub } = humanName(result.name, stat?.config);
  const [confirmDelete, setConfirmDelete] = useState(false);

  return (
    <tr
      className={cn(
        "group cursor-pointer transition-colors border-b border-border/40 last:border-0",
        selected ? "bg-primary/[0.06]" : "hover:bg-muted/50",
      )}
      onClick={onSelect}
    >
      <td className="py-2 px-3">
        <div className="flex items-center gap-1.5 min-w-0">
          <span className={cn("w-1 h-4 rounded-full flex-shrink-0", selected ? "bg-primary" : s ? ((s.total_return_pct ?? 0) > 0 ? "bg-up/60" : "bg-down/60") : "bg-muted-foreground/30")} />
          <div className="min-w-0">
            <p className="text-xs font-semibold truncate leading-tight" title={result.name}>{title}</p>
            {sub && <p className="text-[9px] text-muted-foreground truncate">{sub}</p>}
          </div>
        </div>
      </td>
      <td className="py-2 px-2 text-center">{profile && <span className="rounded bg-muted px-1 py-0.5 text-[9px] font-medium text-muted-foreground">{profile}</span>}</td>
      <td className="py-2 px-2 text-right"><span className={cn("text-xs font-bold tabular-nums", retColor(s?.total_return_pct))}>{s ? pct(s.total_return_pct) : "—"}</span></td>
      <td className="py-2 px-2 text-right"><span className={cn("text-xs font-bold tabular-nums", s ? (s.win_rate >= 0.5 ? "text-up" : "text-down") : "")}>{s ? `${(s.win_rate * 100).toFixed(1)}%` : "—"}</span></td>
      <td className="py-2 px-2 text-right"><span className={cn("text-[10px] font-semibold tabular-nums", retColor(s?.total_pnl))}>{s ? money(s.total_pnl) : "—"}</span></td>
      <td className="py-2 px-2 text-right"><span className="text-[10px] font-semibold tabular-nums text-down">{s?.max_drawdown_pct != null ? pct(s.max_drawdown_pct) : "—"}</span></td>
      <td className="py-2 px-2 text-right text-[10px] text-muted-foreground tabular-nums">{s ? `${s.total_closed}笔` : "—"}</td>
      <td className="py-2 px-2 text-right text-[10px] text-muted-foreground tabular-nums">{prettyDateTime(result.updated_at)}</td>
      <td className="py-2 px-2 w-8">
        {!confirmDelete ? (
          <button
            onClick={(e) => { e.stopPropagation(); setConfirmDelete(true); }}
            className="opacity-0 group-hover:opacity-100 rounded p-1 hover:bg-destructive/10 text-muted-foreground hover:text-destructive transition-all"
            title="删除"
          ><Trash2 className="h-3 w-3" /></button>
        ) : (
          <div className="flex items-center gap-0.5" onClick={(e) => e.stopPropagation()}>
            <button onClick={onDelete} className="text-[9px] font-medium text-destructive hover:bg-destructive/10 px-1 py-0.5 rounded">删</button>
            <button onClick={() => setConfirmDelete(false)} className="text-[9px] font-medium text-muted-foreground hover:bg-muted px-1 py-0.5 rounded">取</button>
          </div>
        )}
      </td>
    </tr>
  );
}

/* ── Signal Sub-Content (shared between Signal Overview and Strategy > Signals) ── */

function SignalSubContent({
  newSignals, watchUpdates, droppedItems,
  newSigPage, setNewSigPage,
  watchUpPage, setWatchUpPage,
  droppedPage, setDroppedPage,
  pageSize, showTradeCol,
  activeTab, onTabChange,
}: {
  newSignals: SignalSnapshotItem[];
  watchUpdates: WatchUpdateItem[];
  droppedItems: WatchUpdateItem[];
  newSigPage: number; setNewSigPage: (p: number) => void;
  watchUpPage: number; setWatchUpPage: (p: number) => void;
  droppedPage: number; setDroppedPage: (p: number) => void;
  pageSize: number; showTradeCol: boolean;
  activeTab?: string; onTabChange?: (t: string) => void;
}) {
  const [localTab, setLocalTab] = useState<string>("new");
  const tab = activeTab ?? localTab;
  const setTab = onTabChange ?? setLocalTab;

  return (
    <div className="space-y-3">
      {/* Inner sub-tabs if this is strategy > signals (where parent controls tabs) are hidden — parent already shows the pill bar */}
      {!activeTab && (
        <div className="flex gap-1 flex-wrap">
          {([
            { key: "new", label: "新信号", count: newSignals.length },
            { key: "watch", label: "观察池", count: watchUpdates.length },
            { key: "dropped", label: "已失效", count: droppedItems.length },
          ]).map((t) => (
            <button
              key={t.key}
              onClick={() => setTab(t.key)}
              className={cn(
                "rounded-full px-3 py-1 text-[11px] font-medium transition-all",
                tab === t.key
                  ? "bg-primary text-primary-foreground shadow-sm"
                  : "bg-muted/60 text-muted-foreground hover:bg-muted hover:text-foreground",
              )}
            >
              {t.label}
              {t.count > 0 && <span className="ml-1 opacity-70">{t.count}</span>}
            </button>
          ))}
        </div>
      )}

      {/* New Signals */}
      {tab === "new" && (
        newSignals.length > 0 ? (
          <div className="rounded-lg border border-border bg-background overflow-hidden">
            <div className="px-3 py-2 border-b border-border bg-muted/30 text-[11px] font-semibold">新信号 ({newSignals.length})</div>
            <div className="overflow-x-auto">
              <table className="w-full text-[11px]">
                <thead><tr className="border-b border-border text-left text-muted-foreground">
                  <th className="pb-1.5 pr-3 px-3 font-medium">标的</th><th className="pb-1.5 pr-3 font-medium">类型</th>
                  <th className="pb-1.5 pr-3 font-medium">信心</th><th className="pb-1.5 pr-3 font-medium">入场</th>
                  <th className="pb-1.5 pr-3 font-medium whitespace-nowrap">城门价</th><th className="pb-1.5 pr-3 font-medium whitespace-nowrap">止损价</th>
                  <th className="pb-1.5 pr-3 font-medium">板块</th><th className="pb-1.5 pr-3 font-medium whitespace-nowrap">同板块联动</th>
                  {showTradeCol && <th className="pb-1.5 font-medium">交易</th>}
                </tr></thead>
                <tbody>
                  {newSignals.slice(newSigPage * pageSize, (newSigPage + 1) * pageSize).map((s, i) => (
                    <tr key={`${s.symbol}-${s.event_type}-${i}`} className="border-b border-border/50 last:border-0">
                      <td className="py-1.5 pr-3 px-3 font-mono font-medium whitespace-nowrap">{s.symbol}{s.name && <span className="ml-1 font-normal text-muted-foreground">{s.name}</span>}</td>
                      <td className="py-1.5 pr-3 whitespace-nowrap">{labelEvent(s.event_type)}</td>
                      <td className="py-1.5 pr-3 whitespace-nowrap">
                        <span className={cn("font-medium", s.signal_confidence >= 0.78 ? "text-up" : "text-primary")}>{s.signal_confidence.toFixed(2)}</span>
                        <span className="ml-1 text-muted-foreground">{s.signal_confidence >= 0.78 ? "A" : "B"}</span>
                      </td>
                      <td className="py-1.5 pr-3 whitespace-nowrap">{labelEntryStyle(s.entry_style)}</td>
                      <td className="py-1.5 pr-3 font-mono whitespace-nowrap">{s.gate_price?.toFixed(2) ?? "—"}</td>
                      <td className="py-1.5 pr-3 font-mono whitespace-nowrap">{s.invalidation_price?.toFixed(2) ?? "—"}</td>
                      <td className="py-1.5 pr-3 whitespace-nowrap">{s.theme_label}</td>
                      <td className="py-1.5 pr-3 whitespace-nowrap">{formatEnv(s)}</td>
                      {showTradeCol && (
                        <td className="py-1.5 whitespace-nowrap">
                          {s.traded ? <span className="rounded-full px-1.5 py-0.5 text-[10px] font-medium bg-success/20 text-success">已入场</span>
                            : s.near_gate ? <span className="rounded-full px-1.5 py-0.5 text-[10px] font-medium bg-amber-500/20 text-amber-600">接近城门</span>
                            : s.blocked_reason ? <span className="text-[10px] text-muted-foreground" title={s.blocked_reason}>等待</span>
                            : <span className="text-[10px] text-muted-foreground">—</span>}
                        </td>
                      )}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <Pagination page={newSigPage} totalPages={Math.ceil(newSignals.length / pageSize)} totalItems={newSignals.length} pageSize={pageSize} onPageChange={setNewSigPage} />
          </div>
        ) : (
          <p className="text-[11px] text-muted-foreground text-center py-6">暂无新信号</p>
        )
      )}

      {/* Watch Pool */}
      {tab === "watch" && (
        watchUpdates.length > 0 ? (
          <div className="rounded-lg border border-border bg-background overflow-hidden">
            <div className="px-3 py-2 border-b border-border bg-muted/30 text-[11px] font-semibold">信号完整周期-持久化观察池 ({watchUpdates.length})</div>
            <div className="overflow-x-auto">
              <table className="w-full text-[11px]">
                <thead><tr className="border-b border-border text-left text-muted-foreground">
                  <th className="pb-1.5 pr-3 px-3 font-medium">标的</th><th className="pb-1.5 pr-3 font-medium">类型</th>
                  <th className="pb-1.5 pr-3 font-medium whitespace-nowrap">信号日</th>
                  <th className="pb-1.5 pr-3 font-medium text-right" title="信号置信度">信心</th>
                  <th className="pb-1.5 pr-3 font-medium text-right whitespace-nowrap" title="信号日收盘价">信号价</th>
                  <th className="pb-1.5 pr-3 font-medium text-right whitespace-nowrap" title="入场触发价">城门价</th>
                  <th className="pb-1.5 pr-3 font-medium">天数</th>
                  <th className="pb-1.5 pr-3 font-medium">状态</th>
                  <th className="pb-1.5 pr-3 font-medium text-right" title="基于信号日收盘价的累计收益">收益</th>
                  <th className="pb-1.5 pr-3 font-medium text-right" title="最大收益">峰值</th>
                  <th className="pb-1.5 pr-3 font-medium text-center">触价</th>
                  <th className="pb-1.5 pr-3 font-medium">备注</th>
                  {showTradeCol && <th className="pb-1.5 font-medium">交易</th>}
                </tr></thead>
                <tbody>
                  {watchUpdates.slice(watchUpPage * pageSize, (watchUpPage + 1) * pageSize).map((w, i) => (
                    <tr key={`${w.symbol}-${w.event_type}-${i}`} className="border-b border-border/50 last:border-0">
                      <td className="py-1 pr-3 px-3 font-mono font-medium whitespace-nowrap">{w.symbol}{w.name && <span className="ml-1 font-normal text-muted-foreground">{w.name}</span>}</td>
                      <td className="py-1 pr-3 whitespace-nowrap">{labelEvent(w.event_type)}</td>
                      <td className="py-1 pr-3 tabular-nums whitespace-nowrap">{w.signal_date}</td>
                      <td className="py-1 pr-3 text-right whitespace-nowrap">
                        <span className={cn("font-medium", (w.signal_confidence ?? 0) >= 0.78 ? "text-up" : "text-primary")}>{(w.signal_confidence ?? 0).toFixed(2)}</span>
                      </td>
                      <td className="py-1 pr-3 text-right font-mono tabular-nums whitespace-nowrap">{w.signal_close != null ? Number(w.signal_close).toFixed(2) : "—"}</td>
                      <td className="py-1 pr-3 text-right font-mono tabular-nums whitespace-nowrap">{w.gate_price != null ? Number(w.gate_price).toFixed(2) : "—"}</td>
                      <td className="py-1 pr-3 tabular-nums whitespace-nowrap">D+{w.obs_day}</td>
                      <td className="py-1 pr-3 whitespace-nowrap">
                        <span className={cn("rounded-full px-1.5 py-0.5 text-[9px] font-medium",
                          w.status_label === "Chase Candidate" ? "bg-warning/20 text-warning" :
                          w.status_label.includes("强") ? "bg-success/20 text-success" :
                          w.status_label.includes("弱") ? "bg-destructive/20 text-destructive" :
                          "bg-muted text-muted-foreground"
                        )}>{w.status_label}</span>
                      </td>
                      <td className={cn("py-1 pr-3 text-right font-mono tabular-nums whitespace-nowrap", w.close_ret_since_signal >= 0 ? "text-up" : "text-down")}>{prettyPct(w.close_ret_since_signal)}</td>
                      <td className="py-1 pr-3 text-right font-mono tabular-nums text-up whitespace-nowrap">{prettyPct(w.max_ret_since_signal)}</td>
                      <td className="py-1 pr-3 text-center whitespace-nowrap">{w.hunt_touched ? "✓" : "—"}</td>
                      <td className="py-1 pr-3 text-muted-foreground text-[10px] max-w-[120px] truncate" title={w.note}>{w.note}</td>
                      {showTradeCol && (
                        <td className="py-1 whitespace-nowrap">
                          {w.traded ? <span className="rounded-full px-1.5 py-0.5 text-[9px] font-medium bg-success/20 text-success">已入场</span>
                            : w.days_to_expiry !== undefined && w.days_to_expiry > 0 ? <span className="text-[10px] text-muted-foreground">剩{w.days_to_expiry}天</span>
                            : <span className="text-[10px] text-muted-foreground">—</span>}
                        </td>
                      )}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <Pagination page={watchUpPage} totalPages={Math.ceil(watchUpdates.length / pageSize)} totalItems={watchUpdates.length} pageSize={pageSize} onPageChange={setWatchUpPage} />
          </div>
        ) : (
          <p className="text-[11px] text-muted-foreground text-center py-6">暂无观察中的信号</p>
        )
      )}

      {/* Dropped */}
      {tab === "dropped" && (
        droppedItems.length > 0 ? (
          <div className="rounded-lg border border-border bg-background overflow-hidden">
            <div className="px-3 py-2 border-b border-border bg-muted/30 text-[11px] font-semibold">已失效 ({droppedItems.length})</div>
            <div className="overflow-x-auto">
              <table className="w-full text-[11px]">
                <thead><tr className="border-b border-border text-left text-muted-foreground">
                  <th className="pb-1.5 pr-3 px-3 font-medium">标的</th><th className="pb-1.5 pr-3 font-medium">类型</th>
                  <th className="pb-1.5 pr-3 font-medium whitespace-nowrap">信号日</th><th className="pb-1.5 pr-3 font-medium">观察天数</th><th className="pb-1.5 pr-3 font-medium whitespace-nowrap">失效时收益</th>
                  <th className="pb-1.5 pr-3 font-medium whitespace-nowrap">期间最高涨幅</th>
                  <th className="pb-1.5 font-medium">原因</th>
                </tr></thead>
                <tbody>
                  {droppedItems.slice(droppedPage * pageSize, (droppedPage + 1) * pageSize).map((d, i) => (
                    <tr key={`${d.symbol}-${d.event_type}-${i}`} className="border-b border-border/50 last:border-0">
                      <td className="py-1.5 pr-3 px-3 font-mono font-medium whitespace-nowrap">{d.symbol}{d.name && <span className="ml-1 font-normal text-muted-foreground">{d.name}</span>}</td>
                      <td className="py-1.5 pr-3 whitespace-nowrap">{labelEvent(d.event_type)}</td>
                      <td className="py-1.5 pr-3 whitespace-nowrap">{d.signal_date}</td>
                      <td className="py-1.5 pr-3 tabular-nums">D+{d.obs_day}</td>
                      <td className={cn("py-1.5 pr-3 font-mono whitespace-nowrap", d.close_ret_since_signal >= 0 ? "text-up" : "text-down")}>{prettyPct(d.close_ret_since_signal)}</td>
                      <td className="py-1.5 pr-3 font-mono text-up whitespace-nowrap">{prettyPct(d.max_ret_since_signal)}</td>
                      <td className="py-1.5 text-muted-foreground">{d.note}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <Pagination page={droppedPage} totalPages={Math.ceil(droppedItems.length / pageSize)} totalItems={droppedItems.length} pageSize={pageSize} onPageChange={setDroppedPage} />
          </div>
        ) : (
          <p className="text-[11px] text-muted-foreground text-center py-6">暂无已失效信号</p>
        )
      )}
    </div>
  );
}

/* ── Detail Panel ──────────────────────────────────────── */

function DetailPanel({ result, onClose, onApplyConfig, onApplyConfigToSignal }: {
  result: ResultEntry;
  onClose: () => void;
  onApplyConfig?: (cfg: Record<string, unknown>) => void;
  onApplyConfigToSignal?: (cfg: Record<string, unknown>) => void;
}) {
  const [meta, setMeta] = useState<MetaInfo | null>(null);
  const [equityCurve, setEquityCurve] = useState<EquityPoint[]>([]);
  const [trades, setTrades] = useState<Record<string, unknown>[]>([]);
  const [tradesCols, setTradesCols] = useState<string[]>([]);
  const [tradesSource, setTradesSource] = useState("");
  const [tradesTotal, setTradesTotal] = useState(0);
  const [tradesPage, setTradesPage] = useState(1);
  const [notable, setNotable] = useState<NotableTrade[]>([]);
  const [overview, setOverview] = useState<ResultOverview | null>(null);
  const [scanSummary, setScanSummary] = useState<SignalScanSummary | null>(null);
  const [showCeiling, setShowCeiling] = useState(false);
  const [loadingDetail, setLoadingDetail] = useState(true);
  const [loadingTrades, setLoadingTrades] = useState(false);
  const [pageSize, setPageSize] = useState(20);
  const [highlightIndex, setHighlightIndex] = useState<number | null>(null);
  const [sortCol, setSortCol] = useState<string | null>(null);
  const [sortDir, setSortDir] = useState<"asc" | "desc">("desc");
  const loaded = useRef(false);

  const isSignal = result.kind === "signal_scan";
  const [newSigPage, setNewSigPage] = useState(0);
  const [watchUpPage, setWatchUpPage] = useState(0);
  const [droppedPage, setDroppedPage] = useState(0);
  const PAGE_SIZE = 20;
  type ViewMode = "signals" | "strategy";
  const [viewMode, setViewMode] = useState<ViewMode>("signals");
  type SignalSubTab = "new" | "watch" | "dropped";
  type StrategySubTab = "positions" | "hunts" | "trades" | "signals";
  const [sigSubTab, setSigSubTab] = useState<SignalSubTab>("new");
  const [stratSubTab, setStratSubTab] = useState<StrategySubTab>("positions");
  const [showMessagePreview, setShowMessagePreview] = useState(false);
  const [feishuPushing, setFeishuPushing] = useState(false);
  const [feishuPushed, setFeishuPushed] = useState(false);

  const fetchTrades = useCallback(async (opts: {
    page?: number; size?: number; sort?: string; dir?: "asc" | "desc";
    findSymbol?: string; findSellDate?: string;
  } = {}) => {
    const pg = opts.page ?? 1;
    const ps = opts.size ?? pageSize;
    const sb = opts.sort ?? sortCol ?? "";
    const sd = opts.dir ?? sortDir;
    setLoadingTrades(true);
    setHighlightIndex(null);
    try {
      const tr = await api.trades(result.name, pg, ps, sb, sd, opts.findSymbol ?? "", opts.findSellDate ?? "");
      setTrades(tr.rows);
      if (tr.columns) setTradesCols(tr.columns);
      if (tr.source) setTradesSource(tr.source);
      setTradesTotal(tr.total);
      setTradesPage(tr.found_page ?? pg);
      setHighlightIndex(tr.found_index ?? null);
    } finally {
      setLoadingTrades(false);
    }
  }, [result.name, pageSize, sortCol, sortDir]);

  useState(() => {
    if (loaded.current) return;
    loaded.current = true;
    (async () => {
      try {
        if (isSignal) {
          const [m, sm] = await Promise.allSettled([
            api.resultMeta(result.name),
            api.scanSummary(result.name),
          ]);
          if (m.status === "fulfilled") setMeta(m.value);
          if (sm.status === "fulfilled") setScanSummary(sm.value);
        } else {
          const [m, eq, tr, nt, ov] = await Promise.allSettled([
            api.resultMeta(result.name),
            api.equityCurve(result.name),
            api.trades(result.name, 1, pageSize),
            api.notableTrades(result.name),
            api.resultOverview(result.name),
          ]);
          if (m.status === "fulfilled") setMeta(m.value);
          if (eq.status === "fulfilled") setEquityCurve(eq.value);
          if (tr.status === "fulfilled") {
            setTrades(tr.value.rows);
            setTradesCols(tr.value.columns ?? []);
            setTradesSource(tr.value.source ?? "");
            setTradesTotal(tr.value.total);
          }
          if (nt.status === "fulfilled") setNotable(nt.value);
          if (ov.status === "fulfilled") setOverview(ov.value);
        }
      } finally {
        setLoadingDetail(false);
      }
    })();
  });

  const ss = scanSummary?.snapshot;
  const newSignals = ss?.new_signals ?? [];
  const watchUpdates = [...(ss?.watch_updates ?? [])].sort((a, b) => b.signal_date.localeCompare(a.signal_date));
  const droppedItems = [...(ss?.dropped ?? [])].sort((a, b) => b.signal_date.localeCompare(a.signal_date));
  const todayEntries: TradeSummaryItem[] = ss?.today_entries ?? [];
  const todayExits: TradeSummaryItem[] = ss?.today_exits ?? [];
  const activePositions: PositionSummaryItem[] = ss?.active_positions ?? [];
  const closedTrades: ClosedTradeItem[] = ss?.closed_trades ?? [];
  const pendingHunts: PendingHuntItem[] = (ss?.pending_hunts ?? []).filter((h) => !h.expired);
  const pendingSellHunts: PendingSellHuntItem[] = ss?.pending_sell_hunts ?? [];
  const hasTradeData = todayEntries.length > 0 || todayExits.length > 0 || activePositions.length > 0 || closedTrades.length > 0 || pendingHunts.length > 0 || (ss?.portfolio_equity ?? 0) > 0;

  return (
    <div className="space-y-4">
      {loadingDetail && (
        <div className="flex items-center justify-center py-8">
          <Loader2 className="h-6 w-6 animate-spin text-primary" />
        </div>
      )}

      {/* Signal meta (when snapshot not loaded yet) */}
      {isSignal && !ss && meta && (
        <div className="rounded-lg border border-border bg-muted/20 p-4">
          <div className="flex items-center gap-3 text-xs text-muted-foreground mb-3 flex-wrap">
            <span>扫描日期: <strong className="text-foreground">{String(meta.effective_date ?? meta.date ?? "")}</strong></span>
            {Boolean(meta.requested_date) && String(meta.requested_date) !== String(meta.effective_date ?? meta.date) && (
              <span className="rounded-full px-1.5 py-0.5 text-[9px] font-medium bg-warning/15 text-warning">
                目标 {String(meta.requested_date)}，数据滞后
              </span>
            )}
            {String(meta.execution_profile ?? "") && (
              <span>模式: {PROF_LABEL[String(meta.execution_profile)] ?? String(meta.execution_profile)}</span>
            )}
            {meta.pool_size !== undefined && <span>标的池: {String(meta.pool_size)}</span>}
          </div>
          <div className="grid grid-cols-3 gap-3">
            <StatCard value={String(meta.new_signals ?? 0)} label="新信号" color="text-primary" />
            <StatCard value={String(meta.active_watch ?? 0)} label="观察中" color="text-up" />
            <StatCard value={String(meta.dropped ?? 0)} label="已失效" color="text-down" />
          </div>
        </div>
      )}

      {/* ── Signal scan detail ── */}
      {isSignal && ss && (
        <div className="space-y-3">
          {/* Config banner — compact, pinned to top */}
          {meta?.config && (
            <ConfigBanner
              meta={meta}
              compact
              onApply={onApplyConfigToSignal ? () => onApplyConfigToSignal(meta!.config as Record<string, unknown>) : undefined}
            />
          )}

          {/* View mode toggle */}
          {hasTradeData && (
            <div className="flex rounded-lg border border-border overflow-hidden">
              <button onClick={() => setViewMode("signals")}
                className={cn("flex-1 flex items-center justify-center gap-2 px-4 py-2 text-xs font-semibold transition-all",
                  viewMode === "signals" ? "bg-primary text-primary-foreground" : "bg-card text-muted-foreground hover:bg-muted",
                )}>
                <Eye className="h-3.5 w-3.5" />
                信号总览
              </button>
              <button onClick={() => setViewMode("strategy")}
                className={cn("flex-1 flex items-center justify-center gap-2 px-4 py-2 text-xs font-semibold transition-all border-l border-border",
                  viewMode === "strategy" ? "bg-primary text-primary-foreground" : "bg-card text-muted-foreground hover:bg-muted",
                )}>
                <Activity className="h-3.5 w-3.5" />
                策略拟真
              </button>
            </div>
          )}

          {/* Stat bar */}
          {viewMode === "strategy" && hasTradeData ? (
            <div className="grid grid-cols-4 lg:grid-cols-8 gap-2">
              <StatCard value={String(todayEntries.length)} label="今日入场" color="text-up" />
              <StatCard value={String(todayExits.length)} label="今日出场" color="text-down" />
              <StatCard value={String(pendingHunts.length)} label="挂单中" color="text-amber-500" />
              <StatCard value={String(newSignals.length)} label="新信号" color="text-primary" />
              <StatCard value={String(activePositions.length)} label="持仓数" color="text-blue-500" />
              <StatCard value={String(closedTrades.length)} label="已平仓" color="text-muted-foreground" />
              <StatCard value={String(watchUpdates.length)} label="观察中" color="text-success" />
              <StatCard value={String(droppedItems.length)} label="已失效" color="text-destructive" />
            </div>
          ) : (
            <div className="grid grid-cols-3 gap-3">
              <StatCard value={String(newSignals.length)} label="新信号" color="text-primary" />
              <StatCard value={String(watchUpdates.length)} label="观察中" color="text-success" />
              <StatCard value={String(droppedItems.length)} label="已失效" color="text-destructive" />
            </div>
          )}

          {/* ── Sub-tab navigation (pill style) ── */}
          {viewMode === "strategy" ? (
            <div className="flex gap-1 flex-wrap">
              {([
                { key: "positions" as const, label: "仓位", count: activePositions.length },
                { key: "hunts" as const, label: "挂单", count: pendingHunts.length + pendingSellHunts.length },
                { key: "trades" as const, label: "交易", count: todayEntries.length + todayExits.length + closedTrades.length },
                { key: "signals" as const, label: "信号", count: newSignals.length + watchUpdates.length + droppedItems.length },
              ]).map((tab) => (
                <button
                  key={tab.key}
                  onClick={() => setStratSubTab(tab.key)}
                  className={cn(
                    "rounded-full px-3 py-1 text-[11px] font-medium transition-all",
                    stratSubTab === tab.key
                      ? "bg-primary text-primary-foreground shadow-sm"
                      : "bg-muted/60 text-muted-foreground hover:bg-muted hover:text-foreground",
                  )}
                >
                  {tab.label}
                  {tab.count > 0 && <span className="ml-1 opacity-70">{tab.count}</span>}
                </button>
              ))}
            </div>
          ) : (
            <div className="flex gap-1 flex-wrap">
              {([
                { key: "new" as const, label: "新信号", count: newSignals.length },
                { key: "watch" as const, label: "观察池", count: watchUpdates.length },
                { key: "dropped" as const, label: "已失效", count: droppedItems.length },
              ]).map((tab) => (
                <button
                  key={tab.key}
                  onClick={() => setSigSubTab(tab.key)}
                  className={cn(
                    "rounded-full px-3 py-1 text-[11px] font-medium transition-all",
                    sigSubTab === tab.key
                      ? "bg-primary text-primary-foreground shadow-sm"
                      : "bg-muted/60 text-muted-foreground hover:bg-muted hover:text-foreground",
                  )}
                >
                  {tab.label}
                  {tab.count > 0 && <span className="ml-1 opacity-70">{tab.count}</span>}
                </button>
              ))}
            </div>
          )}

          {/* ═══════════════ Strategy sub-tab content ═══════════════ */}

          {/* Strategy > 仓位 */}
          {viewMode === "strategy" && stratSubTab === "positions" && (() => {
            const equity = ss?.portfolio_equity ?? 0;
            return (
              <div className="space-y-3">
                <div className="flex gap-4 rounded-lg bg-muted/50 border border-border px-4 py-2">
                  <MiniStat label="总权益" value={`${(equity / 10000).toFixed(1)}万`} />
                  <MiniStat label="现金" value={`${((ss?.portfolio_cash ?? 0) / 10000).toFixed(1)}万`} />
                  <MiniStat label="仓位" value={`${ss?.portfolio_exposure_pct?.toFixed(1) ?? 0}%`} color={Number(ss?.portfolio_exposure_pct ?? 0) > 80 ? "text-warning" : undefined} />
                  {ss?.market_context?.conversion_rate !== undefined && (
                    <MiniStat label="转化率" value={`${(ss.market_context.conversion_rate * 100).toFixed(0)}%`} />
                  )}
                </div>
                {activePositions.length > 0 ? (
                  <div className="rounded-lg border border-border bg-background overflow-hidden">
                    <div className="px-3 py-2 border-b border-border bg-muted/30 text-[11px] font-semibold">当前持仓 ({activePositions.length})</div>
                    <div className="overflow-x-auto">
                      <table className="w-full text-[11px]">
                        <thead><tr className="border-b border-border text-left text-muted-foreground">
                          <th className="pb-1.5 pr-3 px-3 font-medium">标的</th><th className="pb-1.5 pr-3 font-medium">入场日</th>
                          <th className="pb-1.5 pr-3 font-medium">入场价</th><th className="pb-1.5 pr-3 font-medium">现价</th>
                          <th className="pb-1.5 pr-3 font-medium">浮盈%</th><th className="pb-1.5 pr-3 font-medium">仓位%</th>
                          <th className="pb-1.5 pr-3 font-medium">持有天数</th>
                          <th className="pb-1.5 font-medium">信号类型</th>
                        </tr></thead>
                        <tbody>
                          {activePositions.map((p, i) => {
                            const weight = equity > 0 ? (p.qty * p.current_price) / equity * 100 : 0;
                            return (
                              <tr key={`pos-${i}`} className="border-b border-border/50 last:border-0">
                                <td className="py-1.5 pr-3 px-3 font-mono font-medium whitespace-nowrap">{p.symbol}{p.name && <span className="ml-1 font-normal text-muted-foreground">{p.name}</span>}</td>
                                <td className="py-1.5 pr-3 whitespace-nowrap">{p.entry_date}</td>
                                <td className={cn("py-1.5 pr-3 font-mono whitespace-nowrap", isNearLimitUp(p.entry_price, p.entry_limit_up) && "text-orange-500")} title={isNearLimitUp(p.entry_price, p.entry_limit_up) ? `接近涨停价 ${p.entry_limit_up?.toFixed(2)}` : undefined}>{p.entry_price.toFixed(2)}{isNearLimitUp(p.entry_price, p.entry_limit_up) && <span className="ml-0.5 text-[10px]">涨</span>}</td>
                                <td className="py-1.5 pr-3 font-mono whitespace-nowrap">{p.current_price.toFixed(2)}</td>
                                <td className={cn("py-1.5 pr-3 font-mono font-medium whitespace-nowrap", p.unrealized_pnl_pct >= 0 ? "text-up" : "text-down")}>{p.unrealized_pnl_pct >= 0 ? "+" : ""}{p.unrealized_pnl_pct.toFixed(2)}%</td>
                                <td className="py-1.5 pr-3 font-mono whitespace-nowrap">{weight.toFixed(1)}%</td>
                                <td className="py-1.5 pr-3 whitespace-nowrap">D+{p.days_held}</td>
                                <td className="py-1.5 text-muted-foreground whitespace-nowrap">{labelEvent(p.source_event)}</td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  </div>
                ) : (
                  <p className="text-[11px] text-muted-foreground text-center py-6">暂无持仓</p>
                )}
              </div>
            );
          })()}

          {/* Strategy > 挂单 */}
          {viewMode === "strategy" && stratSubTab === "hunts" && (
            <div className="space-y-3">
              {pendingHunts.length > 0 ? (
                <div className="rounded-lg border border-border bg-background overflow-hidden">
                  <div className="px-3 py-2 border-b border-border bg-muted/30 text-[11px] font-semibold">挂单预购池 ({pendingHunts.length})</div>
                  <p className="text-[10px] text-muted-foreground px-3 py-1.5 border-b border-border/50">
                    策略正挂出限价单等待触发。价格进入「目标价 +/- 缓冲」区间时自动成交，超过有效期则取消。
                  </p>
                  <div className="overflow-x-auto">
                    <table className="w-full text-[11px] table-fixed">
                      <colgroup>
                        <col className="w-[15%]" />{/* 标的 */}
                        <col className="w-[9%]" />{/* 信号来源 */}
                        <col className="w-[8%]" />{/* 目标价 */}
                        <col className="w-[13%]" />{/* 触发区间 */}
                        <col className="w-[8%]" />{/* 止损价 */}
                        <col className="w-[7%]" />{/* 止盈% */}
                        <col className="w-[6%]" />{/* 倍率 */}
                        <col className="w-[11%]" />{/* 挂单日 */}
                        <col className="w-[11%]" />{/* 有效至 */}
                        <col className="w-[12%]" />{/* 状态 */}
                      </colgroup>
                      <thead><tr className="border-b border-border text-left text-muted-foreground">
                        <th className="pb-1.5 px-2 font-medium">标的</th>
                        <th className="pb-1.5 px-2 font-medium">信号来源</th>
                        <th className="pb-1.5 px-2 font-medium">目标价</th>
                        <th className="pb-1.5 px-2 font-medium">触发区间</th>
                        <th className="pb-1.5 px-2 font-medium">止损价</th>
                        <th className="pb-1.5 px-2 font-medium">止盈%</th>
                        <th className="pb-1.5 px-2 font-medium">倍率</th>
                        <th className="pb-1.5 px-2 font-medium">挂单日</th>
                        <th className="pb-1.5 px-2 font-medium">有效至</th>
                        <th className="pb-1.5 px-2 font-medium">状态</th>
                      </tr></thead>
                      <tbody>
                        {pendingHunts.map((h, i) => {
                          const lo = h.target_price * (1 - h.buffer_pct);
                          const hi = h.target_price * (1 + h.buffer_pct);
                          return (
                            <tr key={`hunt-${i}`} className={cn("border-b border-border/50 last:border-0", h.expired ? "opacity-50" : "")}>
                              <td className="py-1.5 px-2 font-mono font-medium whitespace-nowrap truncate">
                                {h.symbol}
                                {h.name && <span className="ml-1 font-normal text-muted-foreground">{h.name}</span>}
                              </td>
                              <td className="py-1.5 px-2 whitespace-nowrap">{labelEvent(h.source_event)}</td>
                              <td className="py-1.5 px-2 font-mono tabular-nums font-medium text-primary whitespace-nowrap">{h.target_price.toFixed(2)}</td>
                              <td className="py-1.5 px-2 font-mono tabular-nums text-muted-foreground whitespace-nowrap">{lo.toFixed(2)}–{hi.toFixed(2)}</td>
                              <td className="py-1.5 px-2 font-mono tabular-nums text-down whitespace-nowrap">{h.invalidate_price.toFixed(2)}</td>
                              <td className="py-1.5 px-2 font-mono tabular-nums text-up whitespace-nowrap">+{(h.take_profit_pct * 100).toFixed(0)}%</td>
                              <td className="py-1.5 px-2 font-mono tabular-nums whitespace-nowrap">{h.position_mult.toFixed(2)}x</td>
                              <td className="py-1.5 px-2 tabular-nums whitespace-nowrap">{h.created_date}</td>
                              <td className="py-1.5 px-2 tabular-nums whitespace-nowrap">{h.valid_until_date}</td>
                              <td className="py-1.5 px-2 whitespace-nowrap">
                                <span className={cn("rounded-full px-1.5 py-0.5 text-[9px] font-medium",
                                  h.expired ? "bg-destructive/15 text-destructive"
                                  : h.position_blocked ? "bg-orange-500/15 text-orange-600"
                                  : "bg-amber-500/15 text-amber-600"
                                )}>{h.status}</span>
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                </div>
              ) : (
                <p className="text-[11px] text-muted-foreground text-center py-6">暂无买入挂单</p>
              )}

              {pendingSellHunts.length > 0 && (
                <div className="rounded-lg border border-border bg-background overflow-hidden">
                  <div className="px-3 py-2 border-b border-border bg-muted/30 text-[11px] font-semibold">卖出挂单 ({pendingSellHunts.length})</div>
                  <div className="overflow-x-auto">
                    <table className="w-full text-[11px]">
                      <thead><tr className="border-b border-border text-left text-muted-foreground">
                        <th className="pb-1.5 pr-3 px-3 font-medium">标的</th>
                        <th className="pb-1.5 pr-3 font-medium text-right whitespace-nowrap">目标卖出价</th>
                        <th className="pb-1.5 pr-3 font-medium">原因</th>
                        <th className="pb-1.5 pr-3 font-medium whitespace-nowrap">有效至</th>
                        <th className="pb-1.5 font-medium whitespace-nowrap">信号来源</th>
                      </tr></thead>
                      <tbody>
                        {pendingSellHunts.map((sh, i) => (
                          <tr key={`sh-${i}`} className="border-b border-border/50 last:border-0">
                            <td className="py-1.5 pr-3 px-3 font-mono font-medium whitespace-nowrap">{sh.symbol}{sh.name && <span className="ml-1 font-normal text-muted-foreground">{sh.name}</span>}</td>
                            <td className="py-1.5 pr-3 text-right font-mono tabular-nums text-down whitespace-nowrap">{sh.target_price.toFixed(2)}</td>
                            <td className="py-1.5 pr-3 whitespace-nowrap">{labelReason(sh.reason)}</td>
                            <td className="py-1.5 pr-3 tabular-nums whitespace-nowrap">{sh.valid_until_date}</td>
                            <td className="py-1.5 text-muted-foreground whitespace-nowrap">{labelEvent(sh.source_event)}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {pendingHunts.length === 0 && pendingSellHunts.length === 0 && (
                <p className="text-[11px] text-muted-foreground text-center py-6">暂无挂单</p>
              )}
            </div>
          )}

          {/* Strategy > 交易 */}
          {viewMode === "strategy" && stratSubTab === "trades" && (
            <div className="space-y-3">
              {(todayEntries.length > 0 || todayExits.length > 0) && (
                <div className="rounded-lg border border-border bg-background overflow-hidden">
                  <div className="px-3 py-2 border-b border-border bg-muted/30 text-[11px] font-semibold">今日交易 ({todayEntries.length + todayExits.length})</div>
                  <div className="p-3 space-y-3">
                    {todayEntries.length > 0 && (
                      <>
                        <div className="text-[11px] font-medium text-muted-foreground">入场 ({todayEntries.length})</div>
                        <div className="overflow-x-auto">
                          <table className="w-full text-[11px]">
                            <thead><tr className="border-b border-border text-left text-muted-foreground">
                              <th className="pb-1.5 pr-3 font-medium">标的</th><th className="pb-1.5 pr-3 font-medium">价格</th>
                              <th className="pb-1.5 pr-3 font-medium">数量</th><th className="pb-1.5 pr-3 font-medium">信号来源</th>
                              <th className="pb-1.5 font-medium">仓位%</th>
                            </tr></thead>
                            <tbody>
                              {todayEntries.map((t, i) => (
                                <tr key={`entry-${i}`} className="border-b border-border/50 last:border-0">
                                  <td className="py-1.5 pr-3 font-mono font-medium whitespace-nowrap">{t.symbol}{t.name && <span className="ml-1 font-normal text-muted-foreground">{t.name}</span>}</td>
                                  <td className="py-1.5 pr-3 font-mono whitespace-nowrap">{t.price.toFixed(2)}</td>
                                  <td className="py-1.5 pr-3 font-mono whitespace-nowrap">{t.qty.toFixed(0)}</td>
                                  <td className="py-1.5 pr-3 whitespace-nowrap">{labelEvent(t.signal_type || t.reason)}{t.signal_date && <span className="ml-1 text-muted-foreground">({t.signal_date})</span>}</td>
                                  <td className="py-1.5 font-mono whitespace-nowrap">{t.position_pct.toFixed(1)}%</td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      </>
                    )}
                    {todayExits.length > 0 && (
                      <>
                        <div className="text-[11px] font-medium text-muted-foreground">出场 ({todayExits.length})</div>
                        <div className="overflow-x-auto">
                          <table className="w-full text-[11px]">
                            <thead><tr className="border-b border-border text-left text-muted-foreground">
                              <th className="pb-1.5 pr-3 font-medium">标的</th><th className="pb-1.5 pr-3 font-medium">价格</th>
                              <th className="pb-1.5 font-medium">原因</th>
                            </tr></thead>
                            <tbody>
                              {todayExits.map((t, i) => (
                                <tr key={`exit-${i}`} className="border-b border-border/50 last:border-0">
                                  <td className="py-1.5 pr-3 font-mono font-medium whitespace-nowrap">{t.symbol}{t.name && <span className="ml-1 font-normal text-muted-foreground">{t.name}</span>}</td>
                                  <td className="py-1.5 pr-3 font-mono whitespace-nowrap">{t.price.toFixed(2)}</td>
                                  <td className="py-1.5 whitespace-nowrap">{labelReason(t.reason)}</td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      </>
                    )}
                  </div>
                </div>
              )}

              {closedTrades.length > 0 && (
                <div className="rounded-lg border border-border bg-background overflow-hidden">
                  <div className="px-3 py-2 border-b border-border bg-muted/30 text-[11px] font-semibold">已平仓记录 ({closedTrades.length})</div>
                  <div className="overflow-x-auto">
                    <table className="w-full text-[11px]">
                      <thead><tr className="border-b border-border text-left text-muted-foreground">
                        <th className="pb-1.5 pr-3 px-3 font-medium">标的</th>
                        <th className="pb-1.5 pr-3 font-medium whitespace-nowrap">买入日</th>
                        <th className="pb-1.5 pr-3 font-medium whitespace-nowrap">买入价</th>
                        <th className="pb-1.5 pr-3 font-medium whitespace-nowrap">卖出日</th>
                        <th className="pb-1.5 pr-3 font-medium whitespace-nowrap">卖出价</th>
                        <th className="pb-1.5 pr-3 font-medium whitespace-nowrap">盈亏%</th>
                        <th className="pb-1.5 pr-3 font-medium whitespace-nowrap">天数</th>
                        <th className="pb-1.5 font-medium">原因</th>
                      </tr></thead>
                      <tbody>
                        {closedTrades.map((ct, i) => (
                          <tr key={`ct-${i}`} className="border-b border-border/50 last:border-0">
                            <td className="py-1.5 pr-3 px-3 font-mono font-medium whitespace-nowrap">{ct.symbol}{ct.name && <span className="ml-1 font-normal text-muted-foreground">{ct.name}</span>}</td>
                            <td className="py-1.5 pr-3 font-mono whitespace-nowrap">{ct.buy_date}</td>
                            <td className={cn("py-1.5 pr-3 font-mono whitespace-nowrap", isNearLimitUp(ct.buy_price, ct.buy_limit_up) && "text-orange-500")}>{ct.buy_price.toFixed(2)}{isNearLimitUp(ct.buy_price, ct.buy_limit_up) && <span className="ml-0.5 text-[10px]">涨</span>}</td>
                            <td className="py-1.5 pr-3 font-mono whitespace-nowrap">{ct.sell_date}</td>
                            <td className={cn("py-1.5 pr-3 font-mono whitespace-nowrap", isNearLimitDown(ct.sell_price, ct.sell_limit_down) && "text-orange-500")}>{ct.sell_price.toFixed(2)}{isNearLimitDown(ct.sell_price, ct.sell_limit_down) && <span className="ml-0.5 text-[10px]">跌</span>}</td>
                            <td className={cn("py-1.5 pr-3 font-mono font-medium whitespace-nowrap", ct.pnl_pct >= 0 ? "text-up" : "text-down")}>{ct.pnl_pct >= 0 ? "+" : ""}{ct.pnl_pct.toFixed(2)}%</td>
                            <td className="py-1.5 pr-3 font-mono whitespace-nowrap">{ct.holding_days}天</td>
                            <td className="py-1.5 text-muted-foreground whitespace-nowrap">
                              {labelReason(ct.reason) || labelEvent(ct.source_event) || "—"}
                              {ct.reason?.replace(/_forced$/, "") === "stop_loss" && ct.pnl_pct > 0 && (
                                <span className="ml-1 text-[10px] text-amber-500" title="止损价高于买入价">止盈止损</span>
                              )}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {todayEntries.length === 0 && todayExits.length === 0 && closedTrades.length === 0 && (
                <p className="text-[11px] text-muted-foreground text-center py-6">暂无交易记录</p>
              )}
            </div>
          )}

          {/* Strategy > 信号 (same content as signal overview but with trade column) */}
          {viewMode === "strategy" && stratSubTab === "signals" && (
            <SignalSubContent
              newSignals={newSignals} watchUpdates={watchUpdates} droppedItems={droppedItems}
              newSigPage={newSigPage} setNewSigPage={setNewSigPage}
              watchUpPage={watchUpPage} setWatchUpPage={setWatchUpPage}
              droppedPage={droppedPage} setDroppedPage={setDroppedPage}
              pageSize={PAGE_SIZE} showTradeCol
            />
          )}

          {/* ═══════════════ Signal overview sub-tab content ═══════════════ */}

          {viewMode === "signals" && (
            <SignalSubContent
              newSignals={newSignals} watchUpdates={watchUpdates} droppedItems={droppedItems}
              newSigPage={newSigPage} setNewSigPage={setNewSigPage}
              watchUpPage={watchUpPage} setWatchUpPage={setWatchUpPage}
              droppedPage={droppedPage} setDroppedPage={setDroppedPage}
              pageSize={PAGE_SIZE} showTradeCol={false}
              activeTab={sigSubTab} onTabChange={setSigSubTab as (t: string) => void}
            />
          )}

          {/* Bottom spacer for floating Feishu button */}
          {scanSummary?.markdown && <div className="h-12" />}
        </div>
      )}

      {/* Feishu preview — floating button (bottom-right of drawer) */}
      {isSignal && scanSummary?.markdown && (
        <>
          <button
            onClick={() => setShowMessagePreview(!showMessagePreview)}
            className={cn(
              "fixed bottom-4 right-8 z-50 flex items-center gap-1.5 rounded-full px-3 py-2 text-[11px] font-medium shadow-lg transition-all",
              showMessagePreview
                ? "bg-primary text-primary-foreground"
                : "bg-card border border-border text-muted-foreground hover:text-foreground hover:shadow-xl",
            )}
            title="飞书消息预览"
          >
            <FileText className="h-3.5 w-3.5" />
            飞书预览
          </button>
          {showMessagePreview && (
            <div className="fixed bottom-14 right-8 z-50 w-[420px] max-h-[50vh] rounded-lg border border-border bg-card shadow-2xl overflow-hidden">
              <div className="flex items-center justify-between px-3 py-2 border-b border-border bg-muted/30">
                <span className="text-[11px] font-semibold">飞书消息预览</span>
                <div className="flex items-center gap-2">
                  <button
                    disabled={feishuPushing || feishuPushed}
                    onClick={async () => {
                      setFeishuPushing(true);
                      try {
                        const effectiveDate = String(scanSummary?.snapshot?.as_of_date ?? meta?.effective_date ?? meta?.date ?? "");
                        const outputDir = result.path ?? result.name ?? "";
                        await api.feishuPush(effectiveDate, outputDir);
                        setFeishuPushed(true);
                      } catch (e: unknown) {
                        console.error(e);
                      } finally {
                        setFeishuPushing(false);
                      }
                    }}
                    className={cn("rounded px-2 py-0.5 text-[10px] font-medium transition-colors",
                      feishuPushed ? "bg-success/20 text-success" : feishuPushing ? "bg-muted text-muted-foreground" : "bg-blue-600/20 text-blue-600 hover:bg-blue-600/30",
                    )}
                  >
                    {feishuPushed ? "已推送" : feishuPushing ? "推送中..." : "推送到飞书"}
                  </button>
                  <button onClick={() => setShowMessagePreview(false)} className="rounded p-0.5 hover:bg-muted"><X className="h-3 w-3" /></button>
                </div>
              </div>
              <div className="p-3 overflow-y-auto max-h-[calc(50vh-40px)]">
                <pre className="text-[11px] leading-relaxed whitespace-pre-wrap font-mono text-foreground/90">{scanSummary.markdown}</pre>
              </div>
            </div>
          )}
        </>
      )}

      {/* Backtest: config banner */}
      {!isSignal && meta && (
        <ConfigBanner
          meta={meta}
          onApply={onApplyConfig && meta.config ? () => onApplyConfig(meta.config as Record<string, unknown>) : undefined}
        />
      )}
      {overview && result.kind === "backtest" && (
        <OverviewPanel overview={overview} showCeiling={showCeiling} onCeilingToggle={setShowCeiling} />
      )}
      {equityCurve.length > 0 && (
        <div>
          <h4 className="text-sm font-semibold mb-2">收益曲线</h4>
          <EquityChart
            data={equityCurve}
            notableTrades={notable}
            oracleCurve={showCeiling ? overview?.ceiling?.oracle_curve : undefined}
          />
          <TradeMarkerLegend trades={notable} onTradeClick={async (t) => {
            await fetchTrades({ findSymbol: t.symbol, findSellDate: t.sell_date });
          }} />
        </div>
      )}
      {(trades.length > 0 || tradesTotal > 0) && (
        <div>
          <h4 className="text-sm font-semibold mb-2">交易记录 ({tradesTotal})</h4>
          {loadingTrades ? (
            <div className="flex justify-center py-4"><Loader2 className="h-5 w-5 animate-spin text-primary" /></div>
          ) : (
            <TradesTable
              data={trades} columns={tradesCols} source={tradesSource}
              notableTrades={notable} highlightIndex={highlightIndex}
              sortCol={sortCol} sortDir={sortDir}
              onSort={async (col, dir) => { setSortCol(col); setSortDir(dir); await fetchTrades({ page: 1, sort: col, dir }); }}
            />
          )}
          {tradesTotal > 0 && (
            <div className="flex items-center justify-between mt-3 text-sm flex-wrap gap-2">
              <span className="text-muted-foreground text-xs">
                {(tradesPage - 1) * pageSize + 1}–{Math.min(tradesPage * pageSize, tradesTotal)} / {tradesTotal}
              </span>
              <div className="flex items-center gap-3">
                <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                  <span>每页</span>
                  <select
                    value={pageSize}
                    onChange={async (e) => { const ns = Number(e.target.value); setPageSize(ns); await fetchTrades({ page: 1, size: ns }); }}
                    className="rounded border border-border bg-card px-1.5 py-0.5 text-xs"
                  >
                    {[20, 50, 100, 200].map((sz) => <option key={sz} value={sz}>{sz}</option>)}
                  </select>
                </div>
                <div className="flex gap-1.5">
                  <button
                    disabled={tradesPage <= 1}
                    onClick={async () => await fetchTrades({ page: tradesPage - 1 })}
                    className={cn("px-3 py-1 rounded border border-border text-xs font-medium transition-colors", tradesPage <= 1 ? "opacity-40 cursor-not-allowed" : "hover:bg-accent")}
                  >上一页</button>
                  <button
                    disabled={tradesPage * pageSize >= tradesTotal}
                    onClick={async () => await fetchTrades({ page: tradesPage + 1 })}
                    className={cn("px-3 py-1 rounded border border-border text-xs font-medium transition-colors", tradesPage * pageSize >= tradesTotal ? "opacity-40 cursor-not-allowed" : "hover:bg-accent")}
                  >下一页</button>
                </div>
              </div>
            </div>
          )}
        </div>
      )}
      {!loadingDetail && !meta && !scanSummary && equityCurve.length === 0 && (
        <p className="text-sm text-muted-foreground py-4 text-center">暂无该结果的详细数据</p>
      )}
    </div>
  );
}

/* ── Group Header ──────────────────────────────────────── */

function GroupHeader({
  yearKey, count, open, onToggle,
}: {
  yearKey: string; count: number; open: boolean; onToggle: () => void;
}) {
  return (
    <tr onClick={onToggle} className="bg-muted/30 border-b border-border cursor-pointer hover:bg-muted/50 transition-colors">
      <td className="py-1.5 px-3" colSpan={9}>
        <div className="flex items-center gap-2">
          {open ? <ChevronDown className="h-3 w-3 text-muted-foreground" /> : <ChevronRight className="h-3 w-3 text-muted-foreground" />}
          <FolderOpen className="h-3 w-3 text-primary" />
          <span className="text-xs font-bold tabular-nums">{yearKey}</span>
          <span className="text-[9px] text-muted-foreground bg-muted rounded-full px-1.5 py-0.5">{count}</span>
        </div>
      </td>
    </tr>
  );
}

/* ── Main Component ────────────────────────────────────── */

export function ResultsExplorer() {
  const navigate = useNavigate();
  const location = useLocation();
  const { data: results, loading, error, refetch } = useApi(() => api.results(), []);
  const [filter, setFilter] = useState<"all" | "backtest" | "signal_scan">("all");
  const [search, setSearch] = useState("");
  const [selectedResult, setSelectedResult] = useState<ResultEntry | null>(null);
  const [signalSectionOpen, setSignalSectionOpen] = useState(false);

  const prevLocationKey = useRef(location.key);
  useEffect(() => {
    if (location.key !== prevLocationKey.current) {
      prevLocationKey.current = location.key;
      refetch();
    }
  }, [location.key, refetch]);

  useEffect(() => {
    const onVisible = () => {
      if (document.visibilityState === "visible") refetch();
    };
    document.addEventListener("visibilitychange", onVisible);
    return () => document.removeEventListener("visibilitychange", onVisible);
  }, [refetch]);

  const handleApplyConfig = useCallback((cfg: Record<string, unknown>) => {
    const payload = metaConfigToPayload(cfg);
    navigate("/backtest", { state: { applyConfig: payload } });
  }, [navigate]);

  const handleApplyConfigToSignal = useCallback((cfg: Record<string, unknown>) => {
    navigate("/signals", { state: { applyConfig: cfg } });
  }, [navigate]);

  const signalResults = useMemo(() => {
    if (!results) return [];
    return results.filter((r) => r.kind === "signal_scan");
  }, [results]);

  const backtestGroups = useMemo(() => {
    if (!results) return [];
    const backtests = results.filter((r) => r.kind === "backtest");
    const map: Record<string, ResultEntry[]> = {};
    for (const r of backtests) {
      const key = parseYearKey(r.name);
      if (!map[key]) map[key] = [];
      map[key].push(r);
    }
    return Object.entries(map)
      .map(([yearKey, items]) => ({ yearKey, results: items }))
      .sort((a, b) => {
        if (a.yearKey === "其他") return 1;
        if (b.yearKey === "其他") return -1;
        return b.yearKey.localeCompare(a.yearKey);
      });
  }, [results]);

  async function handleDelete(name: string) {
    try {
      await api.deleteResult(name);
      if (selectedResult?.name === name) setSelectedResult(null);
      refetch();
    } catch { /* ignore */ }
  }

  function handleSelect(result: ResultEntry) {
    setSelectedResult((prev) => prev?.name === result.name ? null : result);
  }

  const showSignals = filter === "all" || filter === "signal_scan";
  const showBacktests = filter === "all" || filter === "backtest";

  const filteredSignals = useMemo(() =>
    signalResults.filter((r) => !search || r.name.toLowerCase().includes(search.toLowerCase())),
    [signalResults, search],
  );

  return (
    <>
      <div className="p-4 lg:p-6 max-w-[1400px] mx-auto space-y-4">
        {/* Header row: title + filter + search */}
        <div className="flex items-center gap-4 flex-wrap">
          <h1 className="text-lg font-bold tracking-tight mr-auto">历史结果</h1>
          <div className="flex gap-1">
            {(["all", "signal_scan", "backtest"] as const).map((f) => (
              <button
                key={f}
                onClick={() => setFilter(f)}
                className={cn(
                  "rounded-full px-2.5 py-0.5 text-[10px] font-medium transition-colors",
                  filter === f ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground hover:bg-accent",
                )}
              >
                {f === "all" ? `全部 ${results?.length ?? 0}` : f === "backtest" ? `回测 ${backtestGroups.reduce((s, g) => s + g.results.length, 0)}` : `信号 ${signalResults.length}`}
              </button>
            ))}
          </div>
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="搜索..."
            className="input-field w-40 text-xs py-1"
          />
          <button
            onClick={() => refetch()}
            className="rounded-lg p-1.5 border border-border hover:bg-accent transition-colors"
            title="刷新"
          >
            <RotateCcw className="h-3.5 w-3.5" />
          </button>
        </div>

        {loading && (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="h-6 w-6 animate-spin text-primary" />
          </div>
        )}
        {error && <p className="text-xs text-destructive">Error: {error}</p>}

        {!loading && (
          <div className="space-y-4">
            {/* ── Signal scans table (collapsible) ── */}
            {showSignals && filteredSignals.length > 0 && (
              <div className="rounded-lg border border-border bg-card overflow-hidden">
                <button
                  onClick={() => setSignalSectionOpen(!signalSectionOpen)}
                  className="w-full flex items-center gap-2 px-3 py-2 bg-muted/30 border-b border-border hover:bg-muted/50 transition-colors text-left"
                >
                  {signalSectionOpen ? <ChevronDown className="h-3 w-3 text-muted-foreground" /> : <ChevronRight className="h-3 w-3 text-muted-foreground" />}
                  <Crosshair className="h-3 w-3 text-success" />
                  <span className="text-xs font-bold">信号扫描</span>
                  <span className="text-[9px] text-muted-foreground bg-muted rounded-full px-1.5 py-0.5">{filteredSignals.length}</span>
                </button>
                {signalSectionOpen && (
                  <table className="w-full text-xs">
                    <thead>
                      <tr className="border-b border-border/60 text-muted-foreground">
                        <th className="py-1.5 px-3 text-left font-medium">日期</th>
                        <th className="py-1.5 px-2 text-center font-medium w-14">新</th>
                        <th className="py-1.5 px-2 text-center font-medium w-14">观察</th>
                        <th className="py-1.5 px-2 text-center font-medium w-14">失效</th>
                        <th className="py-1.5 px-2 text-center font-medium w-14">池</th>
                        <th className="py-1.5 px-2 text-right font-medium w-28">时间</th>
                        <th className="w-8" />
                      </tr>
                    </thead>
                    <tbody>
                      {filteredSignals.map((r) => (
                        <SignalRow
                          key={r.name}
                          result={r}
                          selected={selectedResult?.name === r.name}
                          onSelect={() => handleSelect(r)}
                          onDelete={() => handleDelete(r.name)}
                        />
                      ))}
                    </tbody>
                  </table>
                )}
              </div>
            )}

            {/* ── Backtest table groups ── */}
            {showBacktests && backtestGroups.length > 0 && backtestGroups.map((g) => (
              <BacktestGroup
                key={g.yearKey}
                yearKey={g.yearKey}
                results={g.results}
                search={search}
                defaultOpen={false}
                selectedName={selectedResult?.name ?? null}
                onSelect={handleSelect}
                onDelete={handleDelete}
              />
            ))}

            {filteredSignals.length === 0 && backtestGroups.length === 0 && (
              <div className="text-center py-12">
                <FolderOpen className="h-10 w-10 text-muted-foreground/30 mx-auto mb-2" />
                <p className="text-xs text-muted-foreground">暂无结果</p>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Slide-over drawer */}
      {selectedResult && (
        <>
          {/* Backdrop */}
          <div
            className="fixed inset-0 bg-black/30 z-40 transition-opacity"
            onClick={() => setSelectedResult(null)}
          />
          {/* Drawer */}
          <div className="fixed top-0 right-0 z-50 h-screen w-[min(80vw,1100px)] bg-card border-l border-border shadow-2xl flex flex-col">
            {/* Drawer header */}
            <div className="flex items-center justify-between px-6 py-4 border-b border-border bg-card flex-shrink-0 relative z-10 shadow-[0_1px_0_0_hsl(var(--border))]">
              <div className="min-w-0 flex-1 mr-4">
                <h3 className="text-sm font-semibold truncate">{selectedResult.name}</h3>
                <p className="text-xs text-muted-foreground mt-0.5">{prettyDateTime(selectedResult.updated_at)}</p>
              </div>
              <div className="flex items-center gap-2 flex-shrink-0">
                
                <button onClick={() => setSelectedResult(null)} className="rounded-lg p-1.5 hover:bg-accent transition-colors">
                  <X className="h-4 w-4" />
                </button>
              </div>
            </div>
            {/* Drawer body */}
            <div className="flex-1 overflow-y-auto p-6">
              <DetailPanel
                key={selectedResult.name}
                result={selectedResult}
                onClose={() => setSelectedResult(null)}
                onApplyConfig={selectedResult.kind === "backtest" ? handleApplyConfig : undefined}
                onApplyConfigToSignal={selectedResult.kind === "signal_scan" ? handleApplyConfigToSignal : undefined}
              />
            </div>
          </div>
        </>
      )}
    </>
  );
}

/* ── Backtest Group ────────────────────────────────────── */

const GROUP_PAGE_SIZE = 20;

function BacktestGroup({
  yearKey, results, search, defaultOpen, selectedName, onSelect, onDelete,
}: {
  yearKey: string;
  results: ResultEntry[];
  search: string;
  defaultOpen: boolean;
  selectedName: string | null;
  onSelect: (r: ResultEntry) => void;
  onDelete: (name: string) => void;
}) {
  const [open, setOpen] = useState(defaultOpen);
  const [stats, setStats] = useState<BacktestStat[]>([]);
  const [total, setTotal] = useState(results.length);
  const [loadingMore, setLoadingMore] = useState(false);
  const loadedRef = useRef(false);

  useEffect(() => {
    if (!open || loadedRef.current) return;
    loadedRef.current = true;
    api.batchStats(yearKey, 0, GROUP_PAGE_SIZE).then((res) => {
      setStats(res.items ?? []);
      setTotal(res.total ?? 0);
    }).catch(() => {});
  }, [open, yearKey]);

  const hasMore = stats.length < total;

  const loadMore = useCallback(() => {
    setLoadingMore(true);
    api.batchStats(yearKey, stats.length, GROUP_PAGE_SIZE).then((res) => {
      setStats((prev) => [...prev, ...(res.items ?? [])]);
      setTotal(res.total ?? 0);
      setLoadingMore(false);
    }).catch(() => setLoadingMore(false));
  }, [yearKey, stats.length]);

  const resultMap = useMemo(() => {
    const m = new Map<string, ResultEntry>();
    for (const r of results) m.set(r.name, r);
    return m;
  }, [results]);

  if (results.length === 0) return null;

  return (
    <div className="rounded-lg border border-border bg-card overflow-hidden">
      <table className="w-full text-xs">
        <tbody>
          <GroupHeader yearKey={yearKey} count={total} open={open} onToggle={() => setOpen(!open)} />
          {open && stats.map((s) => {
            const r = resultMap.get(s.name);
            if (!r) return null;
            if (search && !r.name.toLowerCase().includes(search.toLowerCase())) return null;
            return (
              <BacktestRow
                key={s.name}
                result={r}
                stat={s}
                selected={r.name === selectedName}
                onSelect={() => onSelect(r)}
                onDelete={() => onDelete(r.name)}
              />
            );
          })}
          {open && (hasMore || stats.length > GROUP_PAGE_SIZE) && (
            <tr>
              <td colSpan={9} className="py-2 text-center space-x-3">
                {hasMore && (
                  <button
                    onClick={loadMore}
                    disabled={loadingMore}
                    className="text-xs text-primary hover:underline disabled:opacity-50"
                  >
                    {loadingMore ? "加载中..." : `显示更多 (${total - stats.length} 条)`}
                  </button>
                )}
                {stats.length > GROUP_PAGE_SIZE && (
                  <button
                    onClick={() => setStats((prev) => prev.slice(0, GROUP_PAGE_SIZE))}
                    className="text-xs text-muted-foreground hover:underline"
                  >
                    收起
                  </button>
                )}
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
}

/* ── Support Components ────────────────────────────────── */

const MODEL_LABELS: Record<string, string> = {
  escape: "逃命长枪", post_limit: "板后长枪", failed_board: "烂板长枪",
  trend_spear: "趋势长枪", attack: "进攻长枪", arb: "套利长枪",
  youzi: "游资长枪", sector_spear: "板块长枪",
};

const ENTRY_LABELS: Record<string, string> = {
  day_level_ideal: "当天精确价",
  next_open_realistic: "次日开盘",
  delayed_limit_hunt: "挂单猎手",
};

const _EXIT_LABELS: Record<string, string> = {
  ideal: "当天精确价",
  next_open: "次日开盘",
  hunt_exit: "挂单猎手",
};

function StatCard({ value, label, color }: { value: string; label: string; color?: string }) {
  return (
    <div className="rounded-lg bg-background border border-border p-3 text-center">
      <div className={cn("text-2xl font-bold tabular-nums", color)}>{value}</div>
      <div className="text-[10px] text-muted-foreground mt-0.5">{label}</div>
    </div>
  );
}

function CollapsibleSection({ title, defaultOpen = false, open: controlledOpen, onToggle, badge, children }: {
  title: string; defaultOpen?: boolean; open?: boolean; onToggle?: () => void;
  badge: "primary" | "success" | "destructive" | "default"; children: React.ReactNode;
}) {
  const [internalOpen, setInternalOpen] = useState(defaultOpen);
  const isOpen = controlledOpen !== undefined ? controlledOpen : internalOpen;
  const handleToggle = onToggle ?? (() => setInternalOpen(v => !v));
  const badgeClass = badge === "primary" ? "bg-primary/20 text-primary" : badge === "success" ? "bg-success/20 text-success" : badge === "destructive" ? "bg-destructive/20 text-destructive" : "bg-muted text-muted-foreground";
  return (
    <div className="rounded-lg border border-border bg-background">
      <button onClick={handleToggle} className="w-full flex items-center gap-2 px-4 py-2.5 text-xs font-medium hover:bg-muted/50 transition-colors">
        <span className={cn("rounded-full px-2 py-0.5 text-[10px] font-medium", badgeClass)}>{title}</span>
        {isOpen ? <ChevronDown className="h-3.5 w-3.5 ml-auto text-muted-foreground" /> : <ChevronRight className="h-3.5 w-3.5 ml-auto text-muted-foreground" />}
      </button>
      {isOpen && <div className="px-4 pb-3 border-t border-border pt-3">{children}</div>}
    </div>
  );
}

function MiniStat({ label, value, color }: { label: string; value: string; color?: string }) {
  return (
    <div className="text-center">
      <div className={cn("text-xs font-semibold tabular-nums", color)}>{value}</div>
      <div className="text-[9px] text-muted-foreground">{label}</div>
    </div>
  );
}

/** Convert backend meta.config (run_config) to launcher payload shape so applyConfig receives exact keys it expects. */
function metaConfigToPayload(cfg: Record<string, unknown>): Record<string, unknown> {
  const out: Record<string, unknown> = { ...cfg };
  if (cfg.pool_size !== undefined && out.pool === undefined) out.pool = cfg.pool_size;
  const mults = cfg.position_multipliers as Record<string, number> | undefined;
  if (mults) {
    for (const [k, v] of Object.entries(mults)) out[`${k}_pos_mult`] = v;
    delete out.position_multipliers;
  }
  if (cfg.base_pos_pct === undefined && cfg.max_positions) out.base_pos_pct = 1 / Number(cfg.max_positions);
  if (out.realistic_exit !== undefined && out.exit_mode === undefined) {
    out.exit_mode = out.realistic_exit ? "next_open" : "ideal";
    delete out.realistic_exit;
  }
  if (cfg.trend_spear_dynamic_hold_enabled !== undefined && out.trend_spear_dynamic_hold === undefined) {
    out.trend_spear_dynamic_hold = cfg.trend_spear_dynamic_hold_enabled;
  }
  const ee = out.enable_events;
  if (Array.isArray(ee) && ee.length === 0) delete out.enable_events;
  delete (out as Record<string, unknown>).pool_size;
  return out;
}

function ConfigBanner({ meta, onApply, compact }: { meta: MetaInfo; onApply?: () => void; compact?: boolean }) {
  const cfg = meta.config as Record<string, unknown> | undefined;
  if (!cfg) {
    return (
      <div className="rounded-lg border border-border bg-muted/30 p-4 text-sm">
        <span className="text-muted-foreground">{meta.kind} · {prettyDate(meta.created_at)}</span>
      </div>
    );
  }

  const isSignalScan = meta.kind === "signal_scan";
  const posMults = cfg.position_multipliers as Record<string, number> | undefined;
  const rawEvents = cfg.enable_events as string[] | undefined;
  const enableEvents = rawEvents && rawEvents.length > 0 ? rawEvents : undefined;
  const entryKey = String(cfg.execution_profile ?? meta.execution_profile ?? "");
  const entryLabel = ENTRY_LABELS[entryKey] ?? entryKey;
  const poolLabel = cfg.pool_name
    ? String(cfg.pool_name)
    : [cfg.pool_size ?? cfg.pool ?? meta.pool_size, cfg.pool_sampling, cfg.pool_seed !== undefined ? `seed ${cfg.pool_seed}` : ""].filter(Boolean).join(" · ");

  const basePosPct = cfg.base_pos_pct ?? (cfg.max_positions ? 1 / Number(cfg.max_positions) : undefined);
  const entryHuntSuffix = cfg.hunt_price_buffer_pct !== undefined
    ? ` · ${(Number(cfg.hunt_price_buffer_pct) * 100).toFixed(1)}% / ${cfg.hunt_window_days ?? 3}天`
    : "";
  const entryDisplay = entryKey === "delayed_limit_hunt" ? entryLabel + entryHuntSuffix : entryLabel;

  const modeLabel = isSignalScan
    ? (String(meta.mode ?? "") === "confirm" ? "盘后确认" : String(meta.mode ?? "") === "preview" ? "盘中预测" : String(meta.mode ?? ""))
    : "";

  const dataStale = Boolean(meta.data_stale) ||
    (meta.requested_date && String(meta.requested_date) !== String(meta.effective_date ?? meta.date));

  /* ── Compact mode: single-line tag bar for signal scans ── */
  if (compact) {
    const tags: { label: string; value: string; warn?: boolean }[] = [
      ...(modeLabel ? [{ label: "模式", value: modeLabel }] : []),
      ...(dataStale ? [{ label: "目标", value: String(meta.requested_date ?? ""), warn: true }, { label: "实际", value: String(meta.effective_date ?? meta.date ?? ""), warn: true }] : []),
      { label: "入场", value: entryLabel },
      { label: "池", value: poolLabel },
      { label: "仓位", value: `${cfg.max_positions ?? "—"}仓 / ${basePosPct !== undefined ? `${(Number(basePosPct) * 100).toFixed(0)}%` : "—"}` },
      ...(cfg.disable_env_mapping ? [{ label: "", value: "无行业" }] : []),
      ...(cfg.ytd ? [{ label: "", value: "YTD" }] : []),
    ].filter((t) => t.value && t.value !== "—");
    return (
      <div className="flex flex-wrap items-center gap-1.5 text-[10px] text-muted-foreground px-1 py-1">
        {tags.map((t, i) => (
          <span key={i} className={cn("inline-flex items-center gap-0.5 rounded px-1.5 py-0.5", t.warn ? "bg-warning/15" : "bg-muted/60")}>
            {t.label && <span className="opacity-60">{t.label}</span>}
            <span className={cn("font-medium", t.warn ? "text-warning" : "text-foreground/80")}>{t.value}</span>
          </span>
        ))}
        {onApply && (
          <button
            onClick={onApply}
            className="shrink-0 ml-auto inline-flex items-center gap-1 rounded-md px-2 py-0.5 text-[10px] font-medium bg-primary/10 text-primary hover:bg-primary/20 transition-colors"
          >
            <RotateCcw className="h-3 w-3" />
            应用到信号页
          </button>
        )}
      </div>
    );
  }

  /* ── Full mode: grid for backtests ── */
  const params: { label: string; value: string }[] = [
    ...(isSignalScan
      ? [
          { label: "扫描日期", value: dataStale
            ? `目标 ${String(meta.requested_date ?? "—")} → 实际 ${String(meta.effective_date ?? meta.date ?? "—")}`
            : String(meta.effective_date ?? meta.date ?? "—") },
          ...(modeLabel ? [{ label: "模式", value: modeLabel }] : []),
        ]
      : [{ label: "回测区间", value: `${String(cfg.start ?? "")} — ${String(cfg.end ?? "")}` }]
    ),
    { label: "入场", value: entryDisplay },
    { label: "标的池", value: poolLabel + (meta.symbols_count !== undefined ? ` (${meta.symbols_count})` : "") },
    { label: "初始资金", value: cfg.init_cash !== undefined ? `¥${Number(cfg.init_cash).toLocaleString()}` : "—" },
    { label: "最大持仓", value: String(cfg.max_positions ?? "—") },
    { label: "基础仓位", value: basePosPct !== undefined ? `${(Number(basePosPct) * 100).toFixed(0)}%` : "—" },
    { label: "止盈", value: cfg.take_profit_pct !== undefined ? `${(Number(cfg.take_profit_pct) * 100).toFixed(0)}%` : "—" },
    { label: "冷却", value: cfg.cooldown_days !== undefined ? `${cfg.cooldown_days}天` : "—" },
    ...(cfg.disable_env_mapping ? [{ label: "行业映射", value: "已禁用" }] : []),
    ...(cfg.ytd ? [{ label: "回测范围", value: "全年 (YTD)" }] : []),
  ].filter((p) => p.value !== "—" && p.value !== "");

  return (
    <div className="rounded-lg border border-border bg-muted/20 overflow-hidden text-xs">
      <div className="grid grid-cols-2 lg:grid-cols-3 divide-x divide-border border-b border-border">
        {params.map((p) => (
          <div key={p.label} className="px-3 py-2">
            <div className="text-[10px] text-muted-foreground">{p.label}</div>
            <div className="font-medium mt-0.5 truncate" title={p.value}>{p.value}</div>
          </div>
        ))}
      </div>

      <div className="px-3 py-2 flex items-center justify-between gap-2">
        <div className="flex flex-wrap items-center gap-1.5">
          {(() => {
            const multMap = posMults ?? Object.fromEntries(
              Object.keys(MODEL_LABELS)
                .map((k) => [k, cfg[`${k}_pos_mult`]])
                .filter(([, v]) => v !== undefined)
            ) as Record<string, number>;
            const hasMults = Object.keys(multMap).length > 0;
            if (!enableEvents && !hasMults) return null;
            return (
              <>
                <span className="text-[10px] text-muted-foreground mr-1">模型</span>
                {(enableEvents ?? Object.keys(MODEL_LABELS)).map((key) => {
                  const mult = multMap[key];
                  const label = MODEL_LABELS[key] ?? key;
                  const isActive = !enableEvents || enableEvents.includes(key);
                  return (
                    <span
                      key={key}
                      className={cn(
                        "inline-flex items-center gap-0.5 rounded px-1 py-0.5 text-[9px] font-medium",
                        isActive ? "bg-primary/10 text-primary" : "bg-muted text-muted-foreground",
                      )}
                    >
                      {label}
                      {mult !== undefined && mult !== 1 && <span className="opacity-50">×{mult}</span>}
                    </span>
                  );
                })}
              </>
            );
          })()}
        </div>

        {onApply && (
          <button
            onClick={onApply}
            className="shrink-0 inline-flex items-center gap-1 rounded-md px-2 py-0.5 text-[10px] font-medium bg-primary/10 text-primary hover:bg-primary/20 transition-colors"
          >
            <RotateCcw className="h-3 w-3" />
            应用配置
          </button>
        )}
      </div>
    </div>
  );
}
