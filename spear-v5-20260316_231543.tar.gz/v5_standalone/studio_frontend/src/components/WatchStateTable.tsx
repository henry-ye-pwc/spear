import { ArrowDown, ArrowUp, ArrowUpDown } from "lucide-react";
import { useMemo, useState } from "react";
import { cn, prettyPct } from "../lib/utils";
import { Pagination } from "./Pagination";

const EVENT_LABELS: Record<string, string> = {
  trend_spear: "趋势长枪", post_limit: "板后长枪", failed_board: "烂板长枪",
  youzi: "游资长枪", sector_spear: "板块长枪", attack: "进攻长枪",
  arb: "套利长枪", escape: "逃命长枪", tail_close: "尾盘入场",
  breakout: "突破入场", continuation: "趋势延续",
};
function labelEvent(code: string): string {
  if (!code) return "—";
  return EVENT_LABELS[code.replace(/^entry:/, "")] ?? code;
}

interface WatchItem {
  symbol: string;
  name?: string;
  event_type: string;
  signal_date: string;
  signal_confidence: number;
  signal_close: number;
  latest_close: number;
  gate_price?: number | null;
  invalidation_price?: number | null;
  entry_style?: string;
  theme_label?: string;
  status_label: string;
  priority_rank: string;
  obs_day: number;
  close_ret_since_signal: number;
  max_ret_since_signal: number;
  hunt_touched: boolean;
  traded?: boolean;
  trade_price?: number | null;
  days_to_expiry?: number;
  note?: string;
  peer_tier?: string;
  drawdown_from_peak?: number;
  close_vs_gate_pct?: number;
  path_hint?: string;
  adj_potential?: number;
}

type SortKey = "symbol" | "event_type" | "signal_date" | "status_label" | "obs_day" | "close_ret_since_signal" | "max_ret_since_signal" | "hunt_touched" | "close_vs_gate_pct" | "drawdown_from_peak" | "signal_close";
type SortDir = "asc" | "desc";

const STATUS_ORDER: Record<string, number> = { "Chase Candidate": 0 };
const RANK_ORDER: Record<string, number> = { "A级": 0, "B级": 1, "C级": 2 };

function cmpVal(a: WatchItem, b: WatchItem, key: SortKey): number {
  switch (key) {
    case "obs_day":
    case "close_ret_since_signal":
    case "max_ret_since_signal":
    case "signal_close":
    case "close_vs_gate_pct":
    case "drawdown_from_peak":
      return ((a as unknown as Record<string, unknown>)[key] as number ?? 0) - ((b as unknown as Record<string, unknown>)[key] as number ?? 0);
    case "hunt_touched":
      return (a.hunt_touched ? 1 : 0) - (b.hunt_touched ? 1 : 0);
    case "status_label":
      return (STATUS_ORDER[a.status_label] ?? 10) - (STATUS_ORDER[b.status_label] ?? 10) || a.status_label.localeCompare(b.status_label);
    default:
      return String((a as unknown as Record<string, unknown>)[key] ?? "").localeCompare(String((b as unknown as Record<string, unknown>)[key] ?? ""));
  }
}

const COLUMNS: { key: SortKey; label: string; align?: "right" | "center"; tip?: string }[] = [
  { key: "symbol", label: "标的" },
  { key: "event_type", label: "类型" },
  { key: "signal_date", label: "信号日" },
  { key: "signal_close", label: "信号价", align: "right", tip: "信号日收盘价" },
  { key: "status_label", label: "状态" },
  { key: "obs_day", label: "天数", align: "right" },
  { key: "close_ret_since_signal", label: "收益", align: "right", tip: "基于信号日收盘价的累计收益" },
  { key: "max_ret_since_signal", label: "峰值", align: "right", tip: "信号日后最高价相对信号收盘的最大收益" },
  { key: "drawdown_from_peak", label: "回撤", align: "right", tip: "从峰值回落幅度 (max_ret - close_ret)" },
  { key: "close_vs_gate_pct", label: "距城门", align: "right", tip: "当前价格相对城门价的距离" },
  { key: "hunt_touched", label: "触价", align: "center", tip: "挂单价格区间是否被触及" },
];

const PAGE_SIZE = 20;

interface Props {
  items: WatchItem[];
  title?: string;
}

export function WatchStateTable({ items, title }: Props) {
  const [sortKey, setSortKey] = useState<SortKey>("signal_date");
  const [sortDir, setSortDir] = useState<SortDir>("desc");
  const [page, setPage] = useState(0);

  const sorted = useMemo(() => {
    const arr = [...items];
    arr.sort((a, b) => {
      const c = cmpVal(a, b, sortKey);
      return sortDir === "asc" ? c : -c;
    });
    return arr;
  }, [items, sortKey, sortDir]);

  const totalPages = Math.ceil(sorted.length / PAGE_SIZE);
  const pageItems = sorted.slice(page * PAGE_SIZE, (page + 1) * PAGE_SIZE);

  function handleSort(key: SortKey) {
    if (sortKey === key) {
      setSortDir((d) => (d === "asc" ? "desc" : "asc"));
    } else {
      setSortKey(key);
      setSortDir(key === "signal_date" || key === "close_ret_since_signal" || key === "max_ret_since_signal" || key === "drawdown_from_peak" ? "desc" : "asc");
    }
    setPage(0);
  }

  if (!items.length) {
    return <p className="text-muted-foreground text-[11px] py-6 text-center">{title ? `暂无${title}数据` : "暂无观察中的信号"}</p>;
  }

  return (
    <div>
      <div className="overflow-x-auto rounded-lg border border-border">
        <table className="w-full text-[11px]">
          <thead>
            <tr className="border-b border-border bg-muted/50">
              {COLUMNS.map((col) => (
                <th
                  key={col.key}
                  onClick={() => handleSort(col.key)}
                  title={col.tip}
                  className={cn(
                    "px-2 py-1.5 font-medium text-muted-foreground cursor-pointer select-none hover:text-foreground transition-colors whitespace-nowrap",
                    col.align === "right" ? "text-right" : col.align === "center" ? "text-center" : "text-left",
                  )}
                >
                  <span className="inline-flex items-center gap-0.5">
                    {col.label}
                    {sortKey === col.key
                      ? (sortDir === "asc" ? <ArrowUp className="h-2.5 w-2.5" /> : <ArrowDown className="h-2.5 w-2.5" />)
                      : <ArrowUpDown className="h-2.5 w-2.5 opacity-30" />}
                  </span>
                </th>
              ))}
              <th className="px-2 py-1.5 text-left font-medium text-muted-foreground">备注</th>
            </tr>
          </thead>
          <tbody>
            {pageItems.map((item, idx) => {
              const dd = item.drawdown_from_peak ?? 0;
              const cvg = item.close_vs_gate_pct;
              const noteText = [item.path_hint, item.note].filter(Boolean).join(" · ");
              return (
                <tr key={`${item.symbol}-${item.event_type}-${idx}`} className="border-b border-border last:border-0 hover:bg-muted/30 transition-colors">
                  <td className="px-2 py-1.5 font-mono font-medium whitespace-nowrap">
                    {item.symbol}
                    {item.name && <span className="ml-1 text-muted-foreground font-normal">{item.name}</span>}
                    {item.traded && <span className="ml-1 text-[9px] rounded-full px-1 py-0.5 bg-success/15 text-success font-medium">已入场</span>}
                    {item.peer_tier === "high" && (item.event_type === "attack" || item.event_type === "arb") && (
                      <span className="ml-1 text-[9px] rounded-full px-1 py-0.5 bg-success/15 text-success font-medium">板块联动强</span>
                    )}
                  </td>
                  <td className="px-2 py-1.5">{labelEvent(item.event_type)}</td>
                  <td className="px-2 py-1.5 tabular-nums">{item.signal_date}</td>
                  <td className="px-2 py-1.5 text-right font-mono tabular-nums">{(item.signal_close ?? 0).toFixed(2)}</td>
                  <td className="px-2 py-1.5">
                    <span
                      className={cn(
                        "rounded-full px-1.5 py-0.5 text-[9px] font-medium",
                        item.status_label === "Chase Candidate"
                          ? "bg-warning/20 text-warning"
                          : item.status_label.includes("强")
                            ? "bg-success/20 text-success"
                            : item.status_label.includes("弱") || item.status_label === "失效"
                              ? "bg-destructive/20 text-destructive"
                              : "bg-muted text-muted-foreground",
                      )}
                    >
                      {item.status_label}
                    </span>
                  </td>
                  <td className="px-2 py-1.5 text-right tabular-nums">D+{item.obs_day}</td>
                  <td className={cn("px-2 py-1.5 text-right font-mono tabular-nums", item.close_ret_since_signal >= 0 ? "text-up" : "text-down")}>
                    {prettyPct(item.close_ret_since_signal)}
                  </td>
                  <td className="px-2 py-1.5 text-right font-mono tabular-nums text-up">{prettyPct(item.max_ret_since_signal)}</td>
                  <td className={cn("px-2 py-1.5 text-right font-mono tabular-nums", dd > 0.05 ? "text-down font-medium" : "text-muted-foreground")}>
                    {dd > 0.001 ? prettyPct(-dd) : "—"}
                  </td>
                  <td className={cn("px-2 py-1.5 text-right font-mono tabular-nums", cvg != null && cvg >= 0 ? "text-up" : "text-muted-foreground")}>
                    {cvg != null ? prettyPct(cvg) : "—"}
                  </td>
                  <td className="px-2 py-1.5 text-center">{item.hunt_touched ? "✓" : "—"}</td>
                  <td className="px-2 py-1.5 text-muted-foreground text-[10px] max-w-[160px] truncate" title={noteText}>{noteText || ""}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
      <Pagination page={page} totalPages={totalPages} totalItems={sorted.length} pageSize={PAGE_SIZE} onPageChange={setPage} />
    </div>
  );
}
