import { cn } from "../lib/utils";

interface Signal {
  symbol: string;
  name?: string;
  event_type: string;
  signal_date: string;
  signal_confidence: number;
  entry_style?: string;
  gate_price?: number | null;
  signal_close: number;
  theme_label?: string;
  peer_confirmation?: number;
  leader_strength?: number;
  sector_hot?: boolean;
  gate_gap_pct?: number;
  stop_gap_pct?: number;
  adj_potential?: number;
  peer_tier?: string;
  outcome_dist?: Record<string, number>;
  peer_lift_hint?: string;
  spear_role?: string;
  multi_spear_count?: number;
}

interface Props {
  signal: Signal;
}

const DIST_COLORS: Record<string, string> = {
  dud: "bg-destructive/60",
  small: "bg-muted-foreground/40",
  mid: "bg-primary/50",
  big: "bg-success/60",
};

const DIST_LABELS: Record<string, string> = {
  dud: "废票",
  small: "小肉",
  mid: "中肉",
  big: "大肉",
};

function OutcomeMiniBar({ dist }: { dist: Record<string, number> }) {
  const keys = ["dud", "small", "mid", "big"];
  const total = keys.reduce((s, k) => s + (dist[k] ?? 0), 0);
  if (total <= 0) return null;
  return (
    <div className="mt-2">
      <div className="flex h-2 w-full rounded-full overflow-hidden">
        {keys.map((k) => {
          const pct = ((dist[k] ?? 0) / total) * 100;
          if (pct <= 0) return null;
          return (
            <div
              key={k}
              className={cn("h-full", DIST_COLORS[k])}
              style={{ width: `${pct}%` }}
              title={`${DIST_LABELS[k]}: ${(dist[k] ?? 0) * 100 | 0}%`}
            />
          );
        })}
      </div>
      <div className="flex justify-between text-[9px] text-muted-foreground mt-0.5">
        {keys.map((k) => (
          <span key={k}>{DIST_LABELS[k]} {((dist[k] ?? 0) * 100).toFixed(0)}%</span>
        ))}
      </div>
    </div>
  );
}

export function SignalCard({ signal: s }: Props) {
  const peerColor =
    s.peer_tier === "high" ? "bg-success/20 text-success" :
    s.peer_tier === "low" ? "bg-destructive/20 text-destructive" :
    "bg-muted text-muted-foreground";

  const showPeerBadge = s.peer_tier && s.peer_tier !== "mid" &&
    (s.event_type === "attack" || s.event_type === "arb");

  return (
    <div className="rounded-lg border border-border bg-card p-4 hover:shadow-md transition-shadow">
      <div className="flex items-start justify-between mb-2">
        <div>
          <span className="font-mono text-base font-semibold">{s.symbol}</span>
          {s.name && <span className="ml-2 text-sm text-muted-foreground">{s.name}</span>}
        </div>
        {(s.adj_potential ?? 0) > 0 && (
          <span className="text-xs font-medium text-primary" title="扣除 gate 门槛后的预期路径空间 (oracle_gap - gate_gap)">
            ~{((s.adj_potential ?? 0) * 100).toFixed(1)}%
          </span>
        )}
      </div>
      <div className="flex flex-wrap gap-1.5 text-xs">
        <span className="rounded bg-accent px-2 py-0.5 font-medium">{s.event_type}</span>
        {s.entry_style && (
          <span className="rounded bg-accent px-2 py-0.5">{s.entry_style}</span>
        )}
        {s.theme_label && s.theme_label !== "其他" && (
          <span className="rounded bg-primary/10 text-primary px-2 py-0.5">{s.theme_label}</span>
        )}
        {s.sector_hot && (
          <span className="rounded bg-warning/20 text-warning px-2 py-0.5 font-medium">Hot</span>
        )}
        {showPeerBadge && (
          <span className={cn("rounded px-2 py-0.5 font-medium", peerColor)}>
            {s.peer_tier === "high" ? "板块联动强" : "联动弱"}
          </span>
        )}
        {s.spear_role && s.spear_role !== "none" && (
          <span className="rounded bg-accent px-2 py-0.5">{s.spear_role}</span>
        )}
        {(s.multi_spear_count ?? 0) > 1 && (
          <span className="rounded bg-accent px-2 py-0.5">{s.multi_spear_count}枪</span>
        )}
      </div>
      <div className="mt-2 grid grid-cols-4 gap-2 text-xs text-muted-foreground">
        <div>
          <span className="block text-foreground font-medium">¥{s.signal_close.toFixed(2)}</span>
          Close
        </div>
        {s.gate_price != null && (
          <div>
            <span className="block text-foreground font-medium">
              ¥{s.gate_price.toFixed(2)}
              {(s.gate_gap_pct ?? 0) > 0.005 && (
                <span className="ml-0.5 text-warning">+{((s.gate_gap_pct ?? 0) * 100).toFixed(1)}%</span>
              )}
            </span>
            Gate
          </div>
        )}
        {s.stop_gap_pct != null && s.stop_gap_pct < 0 && (
          <div>
            <span className="block text-destructive font-medium">
              {((s.stop_gap_pct ?? 0) * 100).toFixed(1)}%
            </span>
            Risk
          </div>
        )}
        <div>
          <span className="block text-foreground font-medium">{s.peer_confirmation ?? 0}</span>
          Peers
        </div>
      </div>
      {s.peer_lift_hint && (
        <div className="mt-1.5 text-[10px] text-muted-foreground">{s.peer_lift_hint}</div>
      )}
      {s.outcome_dist && Object.keys(s.outcome_dist).length > 0 && (
        <OutcomeMiniBar dist={s.outcome_dist} />
      )}
      <div className="mt-1 text-[9px] text-muted-foreground/60" title="信号置信度 (与结局无统计相关性)">
        conf {(s.signal_confidence * 100).toFixed(0)}%
      </div>
    </div>
  );
}
