import { Loader2, Save, X } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { api } from "../lib/api";
import { cn } from "../lib/utils";

interface Props {
  symbols: string[];
  onSaved?: () => void;
  onClose: () => void;
}

export function SavePoolDialog({ symbols, onSaved, onClose }: Props) {
  const [name, setName] = useState("");
  const [label, setLabel] = useState("");
  const [description, setDescription] = useState("");
  const [saving, setSaving] = useState(false);

  const safeName = name.trim().replace(/[^a-zA-Z0-9_-]/g, "_");

  async function handleSave() {
    if (!safeName) {
      toast.error("Pool name is required");
      return;
    }
    setSaving(true);
    try {
      const result = await api.savePool(safeName, label || safeName, symbols, description);
      toast.success(`Pool "${result.label}" saved (${result.symbol_count} symbols)`);
      onSaved?.();
      onClose();
    } catch (e: unknown) {
      toast.error(String(e));
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="rounded-lg border border-primary/30 bg-card p-4 space-y-3">
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-semibold">Save as Named Pool</h3>
        <button onClick={onClose} className="text-muted-foreground hover:text-foreground">
          <X className="h-4 w-4" />
        </button>
      </div>
      <p className="text-xs text-muted-foreground">
        Save these {symbols.length} symbol(s) so you can reuse them from the Named Pool dropdown.
      </p>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <div>
          <label className="block text-xs font-medium text-muted-foreground mb-1">Pool Name (ID)</label>
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="my_watchlist"
            className="input-field w-full text-xs font-mono"
          />
          {name && safeName !== name.trim() && (
            <p className="text-[10px] text-muted-foreground mt-0.5">Will be saved as: {safeName}</p>
          )}
        </div>
        <div>
          <label className="block text-xs font-medium text-muted-foreground mb-1">Label (display name)</label>
          <input
            type="text"
            value={label}
            onChange={(e) => setLabel(e.target.value)}
            placeholder={safeName || "My Watchlist"}
            className="input-field w-full text-xs"
          />
        </div>
      </div>
      <div>
        <label className="block text-xs font-medium text-muted-foreground mb-1">Description (optional)</label>
        <input
          type="text"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          placeholder="e.g. 2026 Q1 focus list"
          className="input-field w-full text-xs"
        />
      </div>
      <div className="flex items-center gap-3 pt-1">
        <button
          onClick={handleSave}
          disabled={saving || !safeName || symbols.length === 0}
          className={cn(
            "flex items-center gap-1.5 rounded-lg px-4 py-2 text-xs font-medium transition-colors",
            saving || !safeName
              ? "bg-muted text-muted-foreground cursor-not-allowed"
              : "bg-primary text-primary-foreground hover:bg-primary/90"
          )}
        >
          {saving ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Save className="h-3.5 w-3.5" />}
          Save Pool ({symbols.length} symbols)
        </button>
        <button onClick={onClose} className="text-xs text-muted-foreground hover:text-foreground">
          Cancel
        </button>
      </div>
    </div>
  );
}
