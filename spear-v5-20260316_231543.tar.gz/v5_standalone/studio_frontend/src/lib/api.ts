const BASE = "/api";

export class ApiError extends Error {
  status: number;
  constructor(status: number, statusText: string) {
    super(`${status} ${statusText}`);
    this.status = status;
  }
}

async function fetchJSON<T>(path: string, init?: RequestInit): Promise<T> {
  const res = await fetch(`${BASE}${path}`, init);
  if (!res.ok) throw new ApiError(res.status, res.statusText);
  return res.json();
}

export interface ResultEntry {
  name: string;
  path: string;
  summary_path: string | null;
  overview_path: string | null;
  master_table_path: string | null;
  snapshot_path: string | null;
  updated_at: string;
  kind: "backtest" | "signal_scan" | "other";
  meta?: Record<string, unknown> | null;
}

export interface TaskRecord {
  id: string;
  kind: string;
  status: "pending" | "running" | "succeeded" | "failed";
  command: string[];
  output_dir: string;
  created_at: string;
  updated_at: string;
  return_code: number | null;
  log_path: string;
  payload: Record<string, unknown>;
}

export interface NamedPool {
  name: string;
  label: string;
  source_path: string;
  description: string;
  symbol_count: number;
  builtin: boolean;
}

export interface ScheduleConfig {
  id: string;
  name: string;
  enabled: boolean;
  minute: string;
  hour: string;
  weekdays: string;
  command_preview: string;
  kind: string;
  payload: Record<string, unknown>;
  cron_line?: string;
}

export interface EquityPoint {
  date: string;
  equity: number;
}

export interface MetaInfo {
  kind: string;
  created_at: string;
  config?: Record<string, unknown>;
  [key: string]: unknown;
}

export interface NotableTrade {
  symbol: string;
  name: string;
  buy_date: string;
  sell_date: string;
  buy_price: number;
  sell_price: number;
  pnl_pct: number;
  reason: string;
  signal_type?: string;
  post_trend?: string;
  diagnosis?: string;
  mfe_pct?: number | null;
}

export interface TradeSummaryItem {
  symbol: string;
  name: string;
  action: string;
  price: number;
  qty: number;
  reason: string;
  signal_date: string;
  signal_type: string;
  pnl_pct: number | null;
  holding_days: number | null;
  position_pct: number;
  limit_up?: number;
  limit_down?: number;
}

export interface PositionSummaryItem {
  symbol: string;
  name: string;
  entry_date: string;
  entry_price: number;
  current_price: number;
  qty: number;
  unrealized_pnl: number;
  unrealized_pnl_pct: number;
  days_held: number;
  source_event: string;
  entry_limit_up?: number;
}

export interface ClosedTradeItem {
  symbol: string;
  name: string;
  buy_date: string;
  buy_price: number;
  sell_date: string;
  sell_price: number;
  qty: number;
  pnl_pct: number;
  holding_days: number;
  reason: string;
  buy_limit_up?: number;
  sell_limit_down?: number;
  source_event: string;
}

export interface MarketContextItem {
  sector_signal_counts: Record<string, number>;
  signal_density: number;
  trailing_5d_avg_density: number;
  conversion_rate: number;
  portfolio_concentration: Record<string, number>;
  signal_health?: string;
  recent_expired_count?: number;
  recent_actual_dud_rate?: number;
  recent_actual_hit10_rate?: number;
}

export interface PendingHuntItem {
  symbol: string;
  name: string;
  source_event: string;
  target_price: number;
  buffer_pct: number;
  invalidate_price: number;
  take_profit_pct: number;
  entry_style: string;
  position_mult: number;
  created_date: string;
  valid_from_date: string;
  valid_until_date: string;
  expired: boolean;
  status: string;
  confidence: number;
  position_blocked: boolean;
  blocked_date: string;
}

export interface PendingSellHuntItem {
  symbol: string;
  name: string;
  target_price: number;
  reason: string;
  valid_until_date: string;
  source_event: string;
}

export interface SignalScanSummary {
  markdown: string;
  snapshot: {
    as_of_date: string;
    new_signals: SignalSnapshotItem[];
    watch_updates: WatchUpdateItem[];
    dropped: WatchUpdateItem[];
    today_entries?: TradeSummaryItem[];
    today_exits?: TradeSummaryItem[];
    active_positions?: PositionSummaryItem[];
    closed_trades?: ClosedTradeItem[];
    pending_hunts?: PendingHuntItem[];
    pending_sell_hunts?: PendingSellHuntItem[];
    portfolio_equity?: number;
    portfolio_cash?: number;
    portfolio_exposure_pct?: number;
    market_context?: MarketContextItem | null;
  } | null;
}

export interface SignalSnapshotItem {
  symbol: string;
  name: string;
  event_type: string;
  signal_date: string;
  signal_confidence: number;
  entry_style: string;
  gate_price: number | null;
  invalidation_price: number | null;
  signal_close: number;
  theme_label: string;
  peer_confirmation: number;
  leader_strength: number;
  sector_hot: boolean;
  gate_gap_pct?: number;
  stop_gap_pct?: number;
  adj_potential?: number;
  peer_tier?: string;
  outcome_dist?: Record<string, number>;
  peer_lift_hint?: string;
  spear_role?: string;
  multi_spear_count?: number;
  traded?: boolean;
  trade_price?: number | null;
  trade_date?: string;
  near_gate?: boolean;
  blocked_reason?: string;
}

export interface WatchUpdateItem {
  symbol: string;
  name: string;
  event_type: string;
  signal_date: string;
  signal_confidence: number;
  signal_close?: number | null;
  gate_price?: number | null;
  status_label: string;
  priority_rank: string;
  obs_day: number;
  close_ret_since_signal: number;
  max_ret_since_signal: number;
  hunt_touched: boolean;
  new_same_side_signal: boolean;
  note: string;
  active: boolean;
  gate_gap_pct?: number;
  stop_gap_pct?: number;
  adj_potential?: number;
  peer_tier?: string;
  outcome_dist?: Record<string, number>;
  peer_lift_hint?: string;
  drawdown_from_peak?: number;
  days_since_peak?: number;
  path_hint?: string;
  close_vs_gate_pct?: number;
  spear_role?: string;
  multi_spear_count?: number;
  traded?: boolean;
  trade_price?: number | null;
  trade_date?: string;
  days_to_expiry?: number;
}

export interface PathFateBucket {
  pct: number;
  hit10: number;
  mfe_median: number;
}

export interface ConditionalMaeBucket {
  mae_median: number;
  mae_5d?: number;
}

export interface OracleMetrics {
  n: number;
  // HDI (replaces oracle_gap mean)
  hdi_lo: number;
  hdi_hi: number;
  oracle_gap_median: number;
  oracle_gap_p99: number;
  // Core rates
  hit10_20d: number;
  dud_rate: number;
  retention_10: number;
  // Distributions
  outcome_dist?: Record<string, number>;
  mfe_cutoffs?: Record<string, number>;
  hit10_by_day?: Record<string, number>;
  // Path analysis
  path_fate?: Record<string, PathFateBucket>;
  conditional_mae?: Record<string, ConditionalMaeBucket>;
  new_low_5to10_good?: number;
  new_low_5to10_bad?: number;
  // Peer
  peer_lift_stable?: boolean;
  peer_high_hit10?: number;
  peer_high_dud?: number;
  peer_low_hit10?: number;
  peer_low_dud?: number;
  // Legacy (kept for backward compat)
  oracle_gap?: number;
  washout_rate?: number;
  next_day_up?: number;
}

export interface SignalOracleData {
  oracle: Record<string, Record<string, OracleMetrics>>;
  pool_baseline: Record<string, number | string>;
  meta: { years: number[]; source: string; last_validated: string; stability_method: string };
}

export interface CeilingData {
  ceiling_equity: number;
  ceiling_return_pct: number;
  ceiling_win_rate: number;
  ceiling_total_pnl: number;
  actual_equity: number;
  actual_return_pct: number;
  wrong_count: number;
  ceiling_uplift_pct: number;
  oracle_curve: EquityPoint[];
}

export interface OverviewStats {
  total_closed: number;
  win_count: number;
  loss_count: number;
  win_rate: number;
  avg_ret_pct: number;
  avg_hold_days: number;
  avg_mfe_pct: number;
  avg_mae_pct: number;
  avg_mfe_capture: number;
  total_pnl: number;
  avg_win_ret_pct?: number;
  avg_loss_ret_pct?: number;
  peak_equity?: number;
  max_drawdown_pct?: number;
  max_drawdown_amount?: number;
  diagnosis: Record<string, number>;
}

export interface ResultOverview {
  summary: Record<string, unknown>;
  stats: OverviewStats | Record<string, never>;
  ceiling: CeilingData | null;
}

export interface BacktestStatEntry {
  total_closed: number;
  win_count: number;
  loss_count: number;
  win_rate: number;
  avg_ret_pct: number;
  avg_hold_days: number;
  total_pnl: number;
  final_equity?: number;
  peak_equity?: number;
  total_return_pct?: number;
  max_drawdown_pct?: number;
}

export interface BacktestStat {
  name: string;
  updated_at: string;
  config: Record<string, unknown>;
  stats: BacktestStatEntry | Record<string, never>;
}

export interface PoolPreview {
  count: number;
  symbols: { symbol: string; name: string }[];
  missing_symbols?: string[];
  cached_count?: number;
}

export interface InconsistentSymbol {
  symbol: string;
  max_deviation_pct: number;
  last_pkl_update: string;
  overlap_bars: number;
}

export interface ConsistencyCheckResult {
  total_symbols: number;
  total_cached: number;
  checked: number;
  consistent: number;
  inconsistent: number;
  errors: number;
  skipped?: number;
  inconsistent_symbols: InconsistentSymbol[];
  checked_at: string;
  oldest_update: string | null;
  newest_update: string | null;
  qfq_migrated?: boolean;
}

export const api = {
  health: () => fetchJSON<{ status: string }>("/health"),
  results: () => fetchJSON<ResultEntry[]>("/results"),
  deleteResult: (name: string) =>
    fetchJSON<{ ok: boolean }>(`/results/${encodeURIComponent(name)}`, { method: "DELETE" }),
  batchStats: (year: string, offset = 0, limit = 20, sortBy = "updated_at", sortDir = "desc") =>
    fetchJSON<{ total: number; summary: { total_trades: number }; items: BacktestStat[] }>(
      `/results/batch-stats?year=${encodeURIComponent(year)}&offset=${offset}&limit=${limit}&sort_by=${encodeURIComponent(sortBy)}&sort_dir=${encodeURIComponent(sortDir)}`
    ),
  resultMeta: (name: string) => fetchJSON<MetaInfo>(`/results/${name}/meta`),
  resultOverview: (name: string) => fetchJSON<ResultOverview>(`/results/${name}/overview`),
  equityCurve: (name: string) => fetchJSON<EquityPoint[]>(`/results/${name}/equity-curve`),
  trades: (
    name: string, page = 1, pageSize = 50,
    sortBy = "", sortDir = "desc",
    findSymbol = "", findSellDate = "",
  ) => {
    let url = `/results/${name}/trades?page=${page}&page_size=${pageSize}`;
    if (sortBy) url += `&sort_by=${encodeURIComponent(sortBy)}&sort_dir=${sortDir}`;
    if (findSymbol && findSellDate) {
      url += `&find_symbol=${findSymbol}&find_sell_date=${findSellDate}`;
    }
    return fetchJSON<{
      total: number; page: number; page_size: number; source: string;
      columns: string[]; rows: Record<string, unknown>[];
      found_page?: number; found_index?: number;
    }>(url);
  },
  notableTrades: (name: string, topN = 5) =>
    fetchJSON<NotableTrade[]>(`/results/${name}/notable-trades?top_n=${topN}`),
  scanSummary: (name: string) =>
    fetchJSON<SignalScanSummary>(`/results/${name}/summary`),
  tasks: () => fetchJSON<TaskRecord[]>("/tasks"),
  cancelTask: (id: string) =>
    fetchJSON<TaskRecord>(`/tasks/${id}/cancel`, { method: "POST" }),
  deleteTask: (id: string) =>
    fetchJSON<{ ok: boolean }>(`/tasks/${id}`, { method: "DELETE" }),
  task: (id: string) => fetchJSON<TaskRecord>(`/tasks/${id}`),
  taskLog: (id: string, tail = 80) =>
    fetchJSON<{ lines: string[]; total_lines: number }>(`/task-log?task_id=${id}&tail=${tail}`),
  createBacktest: (payload: Record<string, unknown>) =>
    fetchJSON<TaskRecord>("/tasks/backtest", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    }),
  createSignalScan: (payload: Record<string, unknown>) =>
    fetchJSON<TaskRecord>("/tasks/signal-scan", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    }),
  pools: () => fetchJSON<NamedPool[]>("/pools"),
  savePool: (name: string, label: string, symbols: string[], description = "") =>
    fetchJSON<NamedPool>("/pools", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, label, symbols, description }),
    }),
  deletePool: (name: string) =>
    fetchJSON<{ ok: boolean }>(`/pools/${name}`, { method: "DELETE" }),

  /** Saved named configurations (full backtest config). */
  listConfigs: () =>
    fetchJSON<{ name: string; updated_at: number }[]>("/configs"),
  getConfig: (name: string) =>
    fetchJSON<Record<string, unknown>>(`/configs/${encodeURIComponent(name)}`),
  saveConfig: (name: string, payload: Record<string, unknown>) =>
    fetchJSON<{ ok: boolean; name: string }>("/configs", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, payload }),
    }),
  deleteConfig: (name: string) =>
    fetchJSON<{ ok: boolean; name: string }>(`/configs/${encodeURIComponent(name)}`, { method: "DELETE" }),

  poolPreview: (size: number, sampling: string, seed: number, poolName?: string) => {
    const sp = new URLSearchParams({ size: String(size), sampling, seed: String(seed) });
    if (poolName) sp.set("pool_name", poolName);
    return fetchJSON<PoolPreview>(`/pool-preview?${sp.toString()}`);
  },
  schedules: () => fetchJSON<ScheduleConfig[]>("/schedules"),
  saveSchedule: (s: Record<string, unknown>) =>
    fetchJSON<ScheduleConfig>("/schedules", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(s) }),
  deleteSchedule: (id: string) =>
    fetchJSON<{ deleted: string }>(`/schedules/${id}`, { method: "DELETE" }),
  toggleSchedule: (id: string, enabled: boolean) =>
    fetchJSON<ScheduleConfig>(`/schedules/${id}`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ enabled }) }),
  fileText: (path: string) =>
    fetchJSON<{ path: string; content: string }>(`/files/text?path=${encodeURIComponent(path)}`),
  signalOracle: () => fetchJSON<SignalOracleData>("/signal-oracle"),
  watchState: () => fetchJSON<Record<string, unknown>>("/state/watch"),
  audit: (limit = 200) => fetchJSON<Record<string, unknown>[]>(`/state/audit?limit=${limit}`),
  feishuConfig: () => fetchJSON<{ webhook: string; secret: string }>("/config/feishu"),
  saveFeishuConfig: (webhook: string, secret: string) =>
    fetchJSON<{ webhook: string; secret: string }>("/config/feishu", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ webhook, secret }) }),
  dataStatus: (params: { pool_name?: string; pool_size?: number; pool_sampling?: string; pool_seed?: number }) => {
    const sp = new URLSearchParams();
    if (params.pool_name) sp.set("pool_name", params.pool_name);
    if (params.pool_size) sp.set("pool_size", String(params.pool_size));
    if (params.pool_sampling) sp.set("pool_sampling", params.pool_sampling);
    if (params.pool_seed !== undefined) sp.set("pool_seed", String(params.pool_seed));
    return fetchJSON<{
      total_symbols: number;
      cached: number;
      missing: number;
      stale: number;
      coverage_pct: number;
      est_download_seconds: number;
      cache_dir: string;
      needs_migration?: boolean;
    }>(`/data/status?${sp.toString()}`);
  },
  latestBar: () => fetchJSON<{ latest_date: string | null; symbol: string; error?: string; hint?: string; daily_ready?: boolean; daily_latest?: string; source?: string }>("/data/latest-bar"),
  dataPrepare: (payload: { pool_name?: string; pool_size?: number; pool_sampling?: string; pool_seed?: number; end_date?: string }) =>
    fetchJSON<{ task_id: string; total_symbols: number }>("/data/prepare", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    }),
  feishuPush: (date: string, outputDir?: string) =>
    fetchJSON<{ ok: boolean; date: string; feishu_response: Record<string, unknown> }>(
      "/feishu-push",
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ date, output_dir: outputDir }),
      },
    ),
  consistencyCheck: (params?: { pool_name?: string; pool_size?: number; sample_size?: number }) => {
    const sp = new URLSearchParams();
    if (params?.pool_name) sp.set("pool_name", params.pool_name);
    if (params?.pool_size) sp.set("pool_size", String(params.pool_size));
    if (params?.sample_size) sp.set("sample_size", String(params.sample_size));
    return fetchJSON<ConsistencyCheckResult>(`/data/consistency-check?${sp.toString()}`);
  },
  fullRefresh: (payload?: { pool_name?: string; symbols?: string[] }) =>
    fetchJSON<{ task_id: string; total_symbols: number; force_refresh: boolean }>("/data/full-refresh", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload ?? {}),
    }),
  refreshSymbol: (symbol: string) =>
    fetchJSON<{ task_id: string; symbol: string }>(`/data/refresh-symbol/${symbol}`, { method: "POST" }),
};
