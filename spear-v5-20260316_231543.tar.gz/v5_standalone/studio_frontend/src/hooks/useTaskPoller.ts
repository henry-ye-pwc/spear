import { useEffect, useRef, useState } from "react";
import { api, ApiError, type TaskRecord } from "../lib/api";

export interface TaskPollState {
  task: TaskRecord | null;
  logLines: string[];
  taskNotFound: boolean;
}

const MAX_BACKOFF_MS = 30_000;

export function useTaskPoller(taskId: string | null, intervalMs = 2000): TaskPollState {
  const [task, setTask] = useState<TaskRecord | null>(null);
  const [logLines, setLogLines] = useState<string[]>([]);
  const [taskNotFound, setTaskNotFound] = useState(false);
  const timer = useRef<ReturnType<typeof setInterval> | null>(null);
  const failCount = useRef(0);
  const backoffTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    if (!taskId) {
      setTask(null);
      setLogLines([]);
      setTaskNotFound(false);
      failCount.current = 0;
      return;
    }
    setTaskNotFound(false);

    const clearTimers = () => {
      if (timer.current) { clearInterval(timer.current); timer.current = null; }
      if (backoffTimer.current) { clearTimeout(backoffTimer.current); backoffTimer.current = null; }
    };

    const poll = async () => {
      try {
        const t = await api.task(taskId);
        setTask(t);
        failCount.current = 0;
        if (t.status === "running" || t.status === "pending") {
          try {
            const log = await api.taskLog(taskId);
            setLogLines(log.lines);
          } catch { /* log may not exist yet */ }
        }
        if (t.status === "succeeded" || t.status === "failed") {
          try {
            const log = await api.taskLog(taskId);
            setLogLines(log.lines);
          } catch { /* ignore */ }
          clearTimers();
        }
      } catch (err) {
        if (err instanceof ApiError && err.status === 404) {
          setTask(null);
          setLogLines([]);
          setTaskNotFound(true);
          clearTimers();
          return;
        }
        failCount.current++;
        if (failCount.current >= 3 && timer.current) {
          clearInterval(timer.current);
          timer.current = null;
          const delay = Math.min(MAX_BACKOFF_MS, intervalMs * Math.pow(2, failCount.current - 2));
          backoffTimer.current = setTimeout(() => {
            poll();
            timer.current = setInterval(poll, intervalMs);
          }, delay);
        }
      }
    };

    poll();
    timer.current = setInterval(poll, intervalMs);
    return clearTimers;
  }, [taskId, intervalMs]);

  return { task, logLines, taskNotFound };
}
