from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
import pandas as pd

from cq_backtest.data.feed import DataFeed
from cq_backtest.shared.market_rules import limit_pct


def _safe_div(a: pd.Series, b: pd.Series) -> pd.Series:
    den = b.replace(0, np.nan)
    return (a / den).replace([np.inf, -np.inf], np.nan)


def preprocess_daily(df: pd.DataFrame, symbol: str) -> pd.DataFrame:
    if df is None or df.empty:
        return pd.DataFrame()

    out = df.copy().sort_index()
    out["symbol"] = symbol
    out["ret_1"] = out["close"].pct_change()
    out["ret_20"] = out["close"].pct_change(20)
    out["amp_pct"] = _safe_div(out["high"] - out["low"], out["low"]).fillna(0.0)

    top = out[["open", "close"]].max(axis=1)
    bot = out[["open", "close"]].min(axis=1)
    out["upper_shadow_pct"] = _safe_div(out["high"] - top, top).fillna(0.0)
    out["lower_shadow_pct"] = _safe_div(bot - out["low"], bot).fillna(0.0)
    out["body_pct"] = _safe_div((out["close"] - out["open"]).abs(), out["open"]).fillna(0.0)
    out["close_pos"] = _safe_div(out["close"] - out["low"], out["high"] - out["low"]).fillna(0.5)
    out["vwap_proxy"] = (out["open"] + out["high"] + out["low"] + out["close"]) / 4.0
    out["amount"] = out.get("amount", out["close"] * out["volume"]).astype(float)
    out["log_amount"] = np.log(out["amount"].clip(lower=1.0))
    out["ma20"] = out["close"].rolling(20, min_periods=10).mean()
    out["ma60"] = out["close"].rolling(60, min_periods=20).mean()
    out["hhv60"] = out["high"].rolling(60, min_periods=20).max()
    out["llv60"] = out["low"].rolling(60, min_periods=20).min()

    prev_close = out["close"].shift(1)
    out["limit_pct"] = limit_pct(symbol, is_st=False)
    out["limit_up"] = prev_close * (1.0 + out["limit_pct"])
    out["touch_limit_up"] = out["high"] >= out["limit_up"] * 0.998
    out["is_limit_up_close"] = (
        out["ret_1"] >= (out["limit_pct"] - 0.005)
    ) & ((out["high"] - out["close"]).abs() <= out["close"] * 0.002)
    out["is_failed_board"] = out["touch_limit_up"] & (~out["is_limit_up_close"])
    out["board_upper_shadow_min"] = 0.05 if symbol.startswith("3") else 0.03

    return out


@dataclass(slots=True)
class V4DataAdapter:
    cache_dir: str = "./cache"
    count: int = 420
    pool_sampling: str = "head"
    pool_seed: int | None = 42
    cache_only: bool = False
    feed: DataFeed = field(init=False)

    def __post_init__(self) -> None:
        self.feed = DataFeed(cache_dir=self.cache_dir)

    def load_symbol(self, symbol: str, start: str, end: str) -> pd.DataFrame:
        raw = self.feed.get_kline(symbol, end_date=end, count=self.count, cache_only=self.cache_only)
        if raw is None or raw.empty:
            return pd.DataFrame()
        if start:
            raw = raw[raw.index >= pd.Timestamp(start)]
        return preprocess_daily(raw, symbol)

    def load_universe(self, pool_size: int) -> list[str]:
        stocks = self.feed.get_stock_list()
        if stocks is None or stocks.empty:
            return []
        code_col = "code" if "code" in stocks.columns else stocks.columns[1]
        name_col = "name" if "name" in stocks.columns else None
        df = stocks.copy()
        df["symbol"] = df[code_col].astype(str).str.zfill(6)
        prefixes = ("000", "001", "002", "003", "300", "301", "600", "601", "603", "605", "688", "689")
        df = df[df["symbol"].str.startswith(prefixes)]
        if name_col:
            clean_name = (
                df[name_col]
                .astype(str)
                .str.replace("\x00", "", regex=False)
                .str.replace(" ", "", regex=False)
                .str.upper()
            )
            df = df[~clean_name.str.contains("ST", regex=False)]

        symbols = df["symbol"].drop_duplicates().tolist()
        if self.pool_sampling == "random":
            sample_n = min(pool_size, len(symbols))
            sampled = pd.Series(symbols).sample(n=sample_n, random_state=self.pool_seed, replace=False)
            return sampled.tolist()
        return symbols[:pool_size]
