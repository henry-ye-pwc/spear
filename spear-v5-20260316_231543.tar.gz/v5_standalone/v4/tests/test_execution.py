from __future__ import annotations

from cq_backtest.shared.signal_schema import SignalEventV2
from v4.execution.state_machine import PositionState, V4ExecutionStateMachine


def test_tail_close_buys_same_day():
    sm = V4ExecutionStateMachine(max_positions=1)
    ev = SignalEventV2(
        event_type="arb",
        symbol="000001",
        ts="2024-03-01",
        confidence=0.8,
        side="long",
        entry_plan={"style": "tail_close"},
        invalidation={"price": 9.6},
        exit_plan={"hold_days": 3, "take_profit_pct": 0.1},
    )
    decisions = sm.on_day(
        date="2024-03-01",
        d_idx=100,
        symbol="000001",
        open_price=10.0,
        close=10.1,
        high=10.3,
        low=9.9,
        events=[ev],
        cash=1_000_000.0,
    )
    assert any(x.action == "buy" for x in decisions)


def test_escape_cancels_pending():
    sm = V4ExecutionStateMachine(max_positions=1)
    trend = SignalEventV2(
        event_type="trend_spear",
        symbol="000001",
        ts="2024-03-01",
        confidence=0.8,
        side="long",
        entry_plan={"style": "breakout", "gate_price": 10.0, "valid_for_days": 5},
        invalidation={"price": 9.5},
        exit_plan={"hold_days": 8, "take_profit_pct": 0.2},
    )
    sm.on_day(
        date="2024-03-01",
        d_idx=100,
        symbol="000001",
        open_price=9.8,
        close=9.9,
        high=9.95,
        low=9.7,
        events=[trend],
        cash=1_000_000.0,
    )
    escape = SignalEventV2(
        event_type="escape",
        symbol="000001",
        ts="2024-03-02",
        confidence=0.9,
        side="risk_off",
    )
    decisions = sm.on_day(
        date="2024-03-02",
        d_idx=101,
        symbol="000001",
        open_price=9.8,
        close=9.7,
        high=9.9,
        low=9.6,
        events=[escape],
        cash=1_000_000.0,
    )
    assert decisions == []
    assert "000001" not in sm.pending_entries


def test_multiple_breakout_routes_are_staged():
    sm = V4ExecutionStateMachine(max_positions=1)
    trend = SignalEventV2(
        event_type="trend_spear",
        symbol="000001",
        ts="2024-03-01",
        confidence=0.82,
        side="long",
        entry_plan={"style": "breakout", "gate_price": 10.2, "valid_for_days": 5},
        invalidation={"price": 9.7},
        exit_plan={"style": "trend_hold", "hold_days": 8, "take_profit_pct": 0.2},
    )
    post = SignalEventV2(
        event_type="post_limit",
        symbol="000001",
        ts="2024-03-01",
        confidence=0.76,
        side="long",
        entry_plan={"style": "breakout", "gate_price": 10.1, "valid_for_days": 4},
        invalidation={"price": 9.8},
        exit_plan={"style": "swing_confirm", "hold_days": 6, "take_profit_pct": 0.16},
    )
    decisions = sm.on_day(
        date="2024-03-01",
        d_idx=100,
        symbol="000001",
        open_price=9.9,
        close=10.0,
        high=10.05,
        low=9.8,
        events=[trend, post],
        cash=1_000_000.0,
    )
    assert decisions == []
    assert len(sm.pending_entries["000001"]) == 2


def test_breakout_route_wins_when_tail_is_not_clearly_better():
    sm = V4ExecutionStateMachine(max_positions=1)
    trend = SignalEventV2(
        event_type="trend_spear",
        symbol="000001",
        ts="2024-03-01",
        confidence=0.82,
        side="long",
        entry_plan={"style": "breakout", "gate_price": 10.2, "valid_for_days": 5},
        invalidation={"price": 9.7},
        exit_plan={"style": "trend_hold", "hold_days": 8, "take_profit_pct": 0.2},
    )
    attack = SignalEventV2(
        event_type="attack",
        symbol="000001",
        ts="2024-03-01",
        confidence=0.79,
        side="long",
        entry_plan={"style": "tail_close"},
        invalidation={"price": 9.6},
        exit_plan={"style": "continuation", "hold_days": 5, "take_profit_pct": 0.1},
    )
    decisions = sm.on_day(
        date="2024-03-01",
        d_idx=100,
        symbol="000001",
        open_price=10.0,
        close=10.05,
        high=10.1,
        low=9.9,
        events=[trend, attack],
        cash=1_000_000.0,
    )
    assert decisions == []
    assert len(sm.pending_entries["000001"]) >= 1


def test_tail_close_route_preempts_only_when_clearly_stronger():
    sm = V4ExecutionStateMachine(max_positions=1)
    post = SignalEventV2(
        event_type="post_limit",
        symbol="000001",
        ts="2024-03-01",
        confidence=0.64,
        side="long",
        entry_plan={"style": "breakout", "gate_price": 10.2, "valid_for_days": 5},
        invalidation={"price": 9.7},
        exit_plan={"style": "swing_confirm", "hold_days": 8, "take_profit_pct": 0.16},
    )
    attack = SignalEventV2(
        event_type="attack",
        symbol="000001",
        ts="2024-03-01",
        confidence=0.90,
        side="long",
        entry_plan={"style": "tail_close"},
        invalidation={"price": 9.6},
        exit_plan={"style": "continuation", "hold_days": 5, "take_profit_pct": 0.1},
    )
    decisions = sm.on_day(
        date="2024-03-01",
        d_idx=100,
        symbol="000001",
        open_price=10.0,
        close=10.05,
        high=10.1,
        low=9.9,
        events=[post, attack],
        cash=1_000_000.0,
    )
    assert any(x.action == "buy" and x.reason == "entry:attack" for x in decisions)
    assert "000001" not in sm.pending_entries


def test_tactical_arb_exits_on_no_premium():
    sm = V4ExecutionStateMachine(max_positions=1)
    ev = SignalEventV2(
        event_type="arb",
        symbol="000001",
        ts="2024-03-01",
        confidence=0.8,
        side="long",
        entry_plan={"style": "tail_close"},
        invalidation={"price": 9.6},
        exit_plan={"style": "tactical_arb", "hold_days": 3, "take_profit_pct": 0.1},
    )
    d1 = sm.on_day(
        date="2024-03-01",
        d_idx=100,
        symbol="000001",
        open_price=10.0,
        close=10.0,
        high=10.1,
        low=9.9,
        events=[ev],
        cash=1_000_000.0,
    )
    assert any(x.action == "buy" for x in d1)
    d2 = sm.on_day(
        date="2024-03-04",
        d_idx=103,
        symbol="000001",
        open_price=9.95,
        close=10.0,
        high=10.05,
        low=9.8,
        events=[],
        cash=900_000.0,
        day_context={"sector_hot": False},
    )
    assert any(x.action == "sell" and x.reason == "no_premium" for x in d2)


def test_limit_up_blocks_tail_buy():
    sm = V4ExecutionStateMachine(max_positions=1)
    ev = SignalEventV2(
        event_type="attack",
        symbol="000001",
        ts="2024-03-01",
        confidence=0.8,
        side="long",
        entry_plan={"style": "tail_close"},
        invalidation={"price": 9.6},
        exit_plan={"style": "continuation", "hold_days": 5, "take_profit_pct": 0.1},
    )
    decisions = sm.on_day(
        date="2024-03-01",
        d_idx=100,
        symbol="000001",
        open_price=10.0,
        close=11.0,
        high=11.0,
        low=10.8,
        limit_up=11.0,
        limit_down=9.0,
        events=[ev],
        cash=1_000_000.0,
    )
    assert decisions == []


def test_position_sizing_respects_event_type_multiplier():
    sm = V4ExecutionStateMachine(
        max_positions=2,
        position_multipliers={"trend_spear": 1.0, "arb": 0.35},
    )
    trend = SignalEventV2(
        event_type="trend_spear",
        symbol="000001",
        ts="2024-03-01",
        confidence=0.82,
        side="long",
        entry_plan={"style": "tail_close"},
        invalidation={"price": 9.5},
        exit_plan={"style": "trend_hold", "hold_days": 8, "take_profit_pct": 0.2},
    )
    arb = SignalEventV2(
        event_type="arb",
        symbol="000002",
        ts="2024-03-01",
        confidence=0.70,
        side="long",
        entry_plan={"style": "tail_close"},
        invalidation={"price": 9.5},
        exit_plan={"style": "tactical_arb", "hold_days": 3, "take_profit_pct": 0.1},
    )
    d1 = sm.on_day(
        date="2024-03-01",
        d_idx=100,
        symbol="000001",
        open_price=10.0,
        close=10.0,
        high=10.1,
        low=9.9,
        events=[trend],
        cash=1_000_000.0,
    )
    d2 = sm.on_day(
        date="2024-03-01",
        d_idx=100,
        symbol="000002",
        open_price=10.0,
        close=10.0,
        high=10.1,
        low=9.9,
        events=[arb],
        cash=1_000_000.0,
    )
    trend_buy = next(x for x in d1 if x.action == "buy")
    arb_buy = next(x for x in d2 if x.action == "buy")
    assert trend_buy.qty > arb_buy.qty
    assert trend_buy.meta["position_mult"] == 1.0
    assert arb_buy.meta["position_mult"] == 0.35


def test_trend_management_suppresses_time_exit_until_structure_breaks():
    sm = V4ExecutionStateMachine(
        max_positions=1,
        trend_spear_trend_management_enabled=True,
        trend_spear_trend_drawdown_exit=0.12,
        trend_spear_trend_stale_days=3,
        trend_spear_trend_max_extension_days=6,
    )
    sm.positions["000001"] = PositionState(
        symbol="000001",
        entry_date="2024-03-01",
        entry_idx=100,
        entry_price=10.0,
        qty=100.0,
        source_event="trend_spear",
        stop_price=9.3,
        take_price=12.2,
        max_hold_days=5,
        exit_style="trend_hold",
        peak_price=12.0,
        peak_ret=0.20,
        peak_date="2024-03-05",
        days_since_peak=2,
        trend_mode_active=True,
        trend_mode_activation_date="2024-03-05",
    )

    d1 = sm.on_day(
        date="2024-03-06",
        d_idx=105,
        symbol="000001",
        open_price=11.6,
        close=11.5,
        high=11.8,
        low=11.3,
        events=[],
        cash=900_000.0,
        day_context={
            "close_vs_ma20_pct": 0.03,
            "close_vs_release_pct": 0.02,
            "close_pos": 0.80,
            "trend_up": True,
        },
    )
    assert d1 == []
    assert "000001" in sm.positions

    d2 = sm.on_day(
        date="2024-03-07",
        d_idx=106,
        symbol="000001",
        open_price=10.9,
        close=10.7,
        high=11.0,
        low=10.6,
        events=[],
        cash=900_000.0,
        day_context={
            "close_vs_ma20_pct": -0.03,
            "close_vs_release_pct": -0.02,
            "close_pos": 0.32,
            "trend_up": False,
        },
    )
    assert any(x.action == "sell" and x.reason == "trend_drawdown_exit" for x in d2)


def test_stop_loss_watch_can_reenter_without_waiting_for_cooldown():
    sm = V4ExecutionStateMachine(
        max_positions=1,
        cooldown_days=3,
        trend_spear_reentry_watch_enabled=True,
        trend_spear_reentry_watch_days=3,
        trend_spear_reentry_min_near_pressure_days=2,
        trend_spear_reentry_min_near_support_days=2,
        trend_spear_reentry_shrink_threshold=0.90,
        trend_spear_reentry_expand_threshold=1.05,
    )
    sm.positions["000001"] = PositionState(
        symbol="000001",
        entry_date="2024-03-01",
        entry_idx=100,
        entry_price=10.0,
        qty=100.0,
        source_event="trend_spear",
        stop_price=9.5,
        take_price=12.0,
        max_hold_days=8,
        exit_style="trend_hold",
        signal_date="2024-02-29",
        signal_confidence=0.82,
        near_pressure_days=2,
        near_support_days=2,
        entry_plan_meta={"gate_price": 10.0},
        exit_plan_meta={"style": "trend_hold", "hold_days": 8, "take_profit_pct": 0.22},
        invalidation_meta={"price": 9.5},
    )

    d1 = sm.on_day(
        date="2024-03-06",
        d_idx=105,
        symbol="000001",
        open_price=9.7,
        close=9.45,
        high=9.8,
        low=9.4,
        events=[],
        cash=900_000.0,
        day_context={
            "amount_vs_prev20_med": 0.80,
            "volume_vs_prev20_med": 0.82,
            "close_vs_ma20_pct": -0.05,
            "close_pos": 0.28,
        },
    )
    assert any(x.action == "sell" and x.reason == "stop_loss" for x in d1)
    assert "000001" in sm.pending_reentries

    d2 = sm.on_day(
        date="2024-03-07",
        d_idx=106,
        symbol="000001",
        open_price=9.6,
        close=9.7,
        high=9.8,
        low=9.55,
        events=[],
        cash=900_000.0,
        day_context={
            "amount_vs_prev20_med": 1.15,
            "volume_vs_prev20_med": 1.18,
            "close_vs_ma20_pct": 0.02,
            "close_pos": 0.75,
        },
    )
    assert any(x.action == "buy" and x.reason == "entry:trend_spear" for x in d2)
    assert "000001" in sm.positions
    assert sm.positions["000001"].entry_style == "reentry_watch"
    assert sm.positions["000001"].reentry_count == 1
