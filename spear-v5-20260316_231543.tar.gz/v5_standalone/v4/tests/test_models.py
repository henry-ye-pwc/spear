from __future__ import annotations

import numpy as np
import pandas as pd

from v4.data.adapter import preprocess_daily
from v4.features import add_robust_volume_features, add_sequence_features, add_structure_features
from v4.models.attack import detect_attack
from v4.models.post_limit import detect_post_limit
from v4.models.trend_spear import detect_trend_spear
from v4.models.youzi import detect_youzi


def _base_frame(n: int = 140) -> pd.DataFrame:
    idx = pd.date_range("2024-01-01", periods=n, freq="B")
    close = np.linspace(10, 16, n)
    open_ = close * 0.99
    high = close * 1.01
    low = close * 0.98
    volume = np.linspace(1e6, 1.6e6, n)
    amount = close * volume
    raw = pd.DataFrame({"open": open_, "high": high, "low": low, "close": close, "volume": volume, "amount": amount}, index=idx)
    out = preprocess_daily(raw, "000001")
    out.iloc[-2, out.columns.get_loc("is_limit_up_close")] = True
    out.iloc[-1, out.columns.get_loc("high")] = out.iloc[-1]["close"] * 1.06
    out.iloc[-1, out.columns.get_loc("upper_shadow_pct")] = 0.04
    out.iloc[-1, out.columns.get_loc("touch_limit_up")] = False
    out = add_robust_volume_features(out)
    out = add_sequence_features(out)
    out = add_structure_features(out)
    out.iloc[-1, out.columns.get_loc("consolidation_ok")] = True
    out.iloc[-1, out.columns.get_loc("anchored_vwap")] = out.iloc[-1]["close"] * 1.005
    return out


def _doc_metric_frame(*, divergent: bool = False) -> pd.DataFrame:
    n = 160
    idx = pd.date_range("2024-01-01", periods=n, freq="B")
    close = np.linspace(10, 16, n)
    open_ = close * 0.995
    high = close * 1.01
    low = close * 0.99
    base_volume = 5.5e5 if divergent else 1.0e6
    volume = np.full(n, base_volume)

    up_steps = [0.012, -0.004, 0.013, -0.003, 0.012, -0.002, 0.011, -0.002, 0.012, 0.011]
    good_vol = [1.40e6, 0.72e6, 1.48e6, 0.66e6, 1.52e6, 0.62e6, 1.55e6, 0.58e6, 1.49e6, 1.53e6]
    bad_vol = [1.28e6, 0.95e6, 1.24e6, 0.91e6, 1.26e6, 0.89e6, 1.22e6, 0.87e6, 1.25e6, 1.23e6]
    recent_vol = bad_vol if divergent else good_vol

    prev_close = close[n - 11]
    for offset, step in enumerate(up_steps, start=n - 10):
        if divergent:
            step = 0.001 if step > 0 else -0.001
        o = prev_close * (1.0 - 0.002 if step > 0 else 1.0 + 0.003)
        c = prev_close * (1.0 + step)
        open_[offset] = o
        close[offset] = c
        high[offset] = max(o, c) * (1.0 + (0.018 if step > 0 else 0.010))
        low[offset] = min(o, c) * (1.0 - (0.010 if step > 0 else 0.018))
        volume[offset] = recent_vol[offset - (n - 10)]
        prev_close = c

    raw = pd.DataFrame(
        {
            "open": open_,
            "high": high,
            "low": low,
            "close": close,
            "volume": volume,
            "amount": close * volume,
        },
        index=idx,
    )
    out = preprocess_daily(raw, "000001")
    out = add_robust_volume_features(out)
    out = add_sequence_features(out)
    out = add_structure_features(out)
    return out


def test_doc_metric_scores_detect_zhangyang_hanshu_and_chengshangqixia():
    frame = _doc_metric_frame()
    row = frame.iloc[-1]
    assert bool(row["zhangyang_hanshu_score"]) is True
    assert float(row["zhang_ratio_10"]) > 1.2
    assert float(row["xu_ratio_10"]) < 1.8
    assert float(row["han_ratio_10"]) < 0.6
    assert bool(row["chengshangqixia_position_ok"]) is True
    assert bool(row["chengshangqixia_score"]) is True


def test_doc_metric_scores_flag_volume_price_divergence():
    frame = _doc_metric_frame(divergent=True)
    row = frame.iloc[-1]
    assert bool(row["zhangyang_vol_price_divergence"]) is True
    assert bool(row["zhangyang_hanshu_score"]) is False


def test_post_limit_gate_not_forced_to_high():
    frame = _base_frame()
    frame.iloc[-2, frame.columns.get_loc("is_amount_explosive")] = False
    frame.iloc[-1, frame.columns.get_loc("is_amount_explosive")] = False
    frame.iloc[-1, frame.columns.get_loc("is_amount_confirm")] = True
    frame.iloc[-1, frame.columns.get_loc("amount")] = frame.iloc[-2]["amount"] * 0.98
    ev = detect_post_limit(frame, "000001", lookback=8, env={"theme_label": "科技", "peer_confirmation": 1, "leader_strength": 0, "_enforce_env": True})
    assert ev is not None
    gate = float(ev.entry_plan["gate_price"])
    high = float(frame.iloc[-1]["high"])
    assert gate < high


def test_post_limit_filters_consecutive_explosive_volume():
    frame = _base_frame()
    frame.iloc[-2, frame.columns.get_loc("amount")] = 2.0e8
    frame.iloc[-2, frame.columns.get_loc("is_amount_explosive")] = True
    frame.iloc[-1, frame.columns.get_loc("amount")] = 3.2e8
    frame.iloc[-1, frame.columns.get_loc("is_amount_explosive")] = True
    frame.iloc[-1, frame.columns.get_loc("is_amount_confirm")] = False
    ev = detect_post_limit(frame, "000001", lookback=8, env={"theme_label": "科技", "peer_confirmation": 1, "leader_strength": 0, "_enforce_env": True})
    assert ev is None


def test_post_limit_rejects_weak_consolidation_only_setup():
    frame = _base_frame()
    frame.iloc[-1, frame.columns.get_loc("consolidation_ok")] = True
    frame.iloc[-1, frame.columns.get_loc("near_peak_pressure")] = False
    frame.iloc[-1, frame.columns.get_loc("two_side_active")] = False
    frame.iloc[-1, frame.columns.get_loc("close_pos")] = 0.4
    frame.iloc[-1, frame.columns.get_loc("range_position_120")] = 0.78
    frame.iloc[-1, frame.columns.get_loc("is_amount_confirm")] = True
    frame.iloc[-1, frame.columns.get_loc("amount")] = frame.iloc[-2]["amount"] * 0.92
    ev = detect_post_limit(frame, "000001", lookback=8, env={"theme_label": "其他", "peer_confirmation": 0, "leader_strength": 0})
    assert ev is None


def test_post_limit_rejects_nonconfirm_touch_limit_spike():
    frame = _base_frame()
    frame.iloc[-1, frame.columns.get_loc("consolidation_ok")] = False
    frame.iloc[-1, frame.columns.get_loc("near_peak_pressure")] = True
    frame.iloc[-1, frame.columns.get_loc("touch_limit_up")] = True
    frame.iloc[-1, frame.columns.get_loc("is_amount_confirm")] = False
    frame.iloc[-1, frame.columns.get_loc("is_amount_explosive")] = False
    frame.iloc[-1, frame.columns.get_loc("amount_rank")] = 0.98
    frame.iloc[-1, frame.columns.get_loc("amount_z")] = 2.7
    frame.iloc[-1, frame.columns.get_loc("amount")] = frame.iloc[-2]["amount"] * 1.02
    ev = detect_post_limit(frame, "000001", lookback=8, env={"theme_label": "其他", "peer_confirmation": 0, "leader_strength": 0})
    assert ev is None


def test_trend_requires_environment_confirmation():
    frame = _base_frame()
    for idx in [-4, -1]:
        frame.iloc[idx, frame.columns.get_loc("upper_shadow_pct")] = 0.04
    for idx, amount in zip([-4, -1], [1.4e7, 1.2e7]):
        frame.iloc[idx, frame.columns.get_loc("amount")] = amount
        frame.iloc[idx, frame.columns.get_loc("is_amount_explosive")] = False
    frame = add_sequence_features(frame)
    frame = add_structure_features(frame)
    # Ensure at least 2 spears in last 5 days (structure may not set is_spear from upper_shadow_pct alone)
    for idx in [-4, -1]:
        frame.iloc[idx, frame.columns.get_loc("is_spear")] = True
    # Keep vol_elevation below threshold so ts_elev_filter does not reject (test focuses on env confirmation)
    if "vol_elevation" in frame.columns:
        frame.iloc[-1, frame.columns.get_loc("vol_elevation")] = 0.9
    ev_none = detect_trend_spear(frame, "000001", multi_days=5, env={"theme_label": "其他", "peer_confirmation": 0, "leader_strength": 0, "_enforce_env": True})
    assert ev_none is None
    ev = detect_trend_spear(frame, "000001", multi_days=5, env={"theme_label": "科技", "peer_confirmation": 1, "leader_strength": 0, "_enforce_env": True})
    assert ev is not None


def test_attack_rejects_progressive_expand_three_guns():
    frame = _base_frame()
    for idx, amount in zip([-5, -3, -1], [1.2e8, 1.5e8, 2.0e8]):
        frame.iloc[idx, frame.columns.get_loc("upper_shadow_pct")] = 0.04
        frame.iloc[idx, frame.columns.get_loc("amount")] = amount
    frame.iloc[-1, frame.columns.get_loc("touch_limit_up")] = True
    frame.iloc[-1, frame.columns.get_loc("is_amount_explosive")] = False
    frame = add_sequence_features(frame)
    ev = detect_attack(frame, "000001", lookback=10, env={"theme_label": "科技", "peer_confirmation": 1, "leader_strength": 0, "_enforce_env": True})
    assert ev is None


def test_youzi_requires_peer_confirmation():
    frame = _base_frame(220)
    frame.iloc[-1, frame.columns.get_loc("upper_shadow_pct")] = 0.04
    frame.iloc[-1, frame.columns.get_loc("range_position_120")] = 0.55
    frame.iloc[-1, frame.columns.get_loc("near_peak_pressure")] = True
    frame.iloc[-1, frame.columns.get_loc("is_amount_explosive")] = False
    for idx in [-120, -60, -2]:
        frame.iloc[idx, frame.columns.get_loc("is_limit_up_close")] = True
    ev_none = detect_youzi(frame, "000001", env={"theme_label": "科技", "peer_confirmation": 0, "leader_strength": 0})
    assert ev_none is None
    ev = detect_youzi(frame, "000001", env={"theme_label": "科技", "peer_confirmation": 2, "leader_strength": 1})
    assert ev is not None
