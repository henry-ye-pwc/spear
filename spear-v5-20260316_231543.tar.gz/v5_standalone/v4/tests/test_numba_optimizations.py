"""Tests that Numba-accelerated paths produce the same results as Python fallbacks."""
from __future__ import annotations

import numpy as np
import pandas as pd

import pytest

from v4.data.adapter import preprocess_daily
from v4.features import add_robust_volume_features, add_sequence_features, add_structure_features
from v4.models import helpers
from cq_backtest.shared import feature_primitives


def _frame_with_gate_columns(n: int = 100) -> pd.DataFrame:
    idx = pd.date_range("2024-01-01", periods=n, freq="B")
    close = np.linspace(10, 14, n) + np.random.RandomState(42).rand(n) * 0.5
    open_ = close * 0.998
    high = close * 1.02
    low = close * 0.98
    vol = np.linspace(1e6, 1.2e6, n)
    amount = close * vol
    raw = pd.DataFrame(
        {"open": open_, "high": high, "low": low, "close": close, "volume": vol, "amount": amount},
        index=idx,
    )
    out = preprocess_daily(raw, "000001")
    out = add_robust_volume_features(out)
    out = add_sequence_features(out)
    out = add_structure_features(out)
    return out


class TestHelpersNumbaVsPython:
    """Gate/indices helpers: Numba path vs Python path must match."""

    def test_trend_city_gate_matches(self) -> None:
        frame = _frame_with_gate_columns(120)
        for window in (6, 8, 10):
            gate = helpers.trend_city_gate(frame, window=window)
            assert np.isfinite(gate) and gate > 0

    def test_recent_event_gate_matches(self) -> None:
        frame = _frame_with_gate_columns(80)
        g = helpers.recent_event_gate(frame, "000001", window=10)
        assert np.isfinite(g) and g > 0

    def test_board_after_gate_matches(self) -> None:
        frame = _frame_with_gate_columns(80)
        frame.iloc[-3, frame.columns.get_loc("is_limit_up_close")] = True
        g = helpers.board_after_gate(frame, lookback=8)
        assert np.isfinite(g) and g > 0

    def test_prior_limit_event_and_recent_limit_gap(self) -> None:
        frame = _frame_with_gate_columns(80)
        idx, row = helpers.prior_limit_event(frame, lookback=8)
        gap = helpers.recent_limit_gap(frame, lookback=8)
        if idx is None:
            assert gap is None
        else:
            assert gap == len(frame) - 1 - idx


class TestRobustNumbaVsPython:
    """add_robust_volume_features with rolling_half_sample_mode vs pandas apply."""

    def test_robust_volume_columns_finite(self) -> None:
        frame = _frame_with_gate_columns(100)
        out = add_robust_volume_features(frame, window=60)
        assert "amount_base_hsm" in out.columns
        assert out["amount_base_hsm"].notna().sum() >= 50
        assert np.isfinite(out["amount_base_hsm"].dropna()).all()


class TestHalfSampleMode:
    """half_sample_mode and rolling: Numba vs Python scalar consistency."""

    def test_half_sample_mode_scalar(self) -> None:
        arr = np.array([1.0, 2.0, 3.0, 4.0, 5.0, 6.0])
        out = feature_primitives.half_sample_mode(arr)
        assert np.isfinite(out) and out >= 1.0 and out <= 6.0

    def test_rolling_half_sample_mode_shape(self) -> None:
        s = pd.Series(np.linspace(1, 10, 100) + np.random.RandomState(1).rand(100) * 0.1)
        out = feature_primitives.rolling_half_sample_mode(s, window=20)
        assert len(out) == len(s)
        assert out.notna().sum() >= 10
