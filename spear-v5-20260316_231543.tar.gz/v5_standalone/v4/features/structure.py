from __future__ import annotations

import numpy as np
import pandas as pd

try:
    from numba import njit
    _HAS_NUMBA = True
except ImportError:
    _HAS_NUMBA = False


# ---------------------------------------------------------------------------
# Numba-accelerated kernel for add_structure_features.
#
# PERFORMANCE CONTEXT (2026-03):
#   Original pure-Python loop: ~1500ms per symbol (3200 bars).
#   Numba kernel:              ~15-30ms per symbol.
#   This is the single biggest bottleneck in prepare_bundle Phase A.
#
# ROLLBACK: If the numba kernel produces incorrect results or causes issues,
#   replace the body of add_structure_features() with a call to
#   _add_structure_features_original() below. The original implementation
#   is preserved verbatim as a reference.
# ---------------------------------------------------------------------------

if _HAS_NUMBA:
    @njit(cache=True)
    def _structure_kernel(
        highs, lows, closes, amp_pct, amount_rank, is_spear, is_limit_up_close,
        ma20, ma60, vwap_proxy, amount, volume,
        peak_window, drawdown_min, peak_touch_eps, consolidation_window,
        n,
    ):
        peak_price = np.full(n, np.nan)
        release_price = np.full(n, np.nan)
        range_position = np.full(n, np.nan)
        near_peak = np.full(n, 0.0)
        near_release = np.full(n, 0.0)
        two_side_active = np.full(n, 0.0)
        consolidation_ok = np.full(n, 0.0)
        trend_up = np.full(n, 0.0)
        anchor_vwap_out = np.full(n, np.nan)
        event_anchor_start = np.full(n, np.nan)

        last_spear_idx = -1
        last_limit_idx = -1

        for i in range(n):
            if is_spear[i]:
                last_spear_idx = i
            if is_limit_up_close[i]:
                last_limit_idx = i

            s = i - peak_window if i - peak_window > 0 else 0
            seg_len = i + 1 - s
            if seg_len < 20:
                continue

            hi = highs[s]
            lo = lows[s]
            for j in range(s + 1, i + 1):
                if highs[j] > hi:
                    hi = highs[j]
                if lows[j] < lo:
                    lo = lows[j]
            rng = hi - lo
            range_position[i] = (closes[i] - lo) / rng if rng > 0 else 0.5

            hist_len = i - s
            if hist_len < 10:
                continue
            peak_rel = 0
            peak_val = highs[s]
            for j in range(s + 1, i):
                if highs[j] > peak_val:
                    peak_val = highs[j]
                    peak_rel = j - s
            peak_idx = s + peak_rel
            pressure = highs[peak_idx]
            peak_price[i] = pressure

            trough_val = lows[peak_idx]
            trough_idx = peak_idx
            for j in range(peak_idx + 1, i + 1):
                if lows[j] < trough_val:
                    trough_val = lows[j]
                    trough_idx = j
            release = lows[trough_idx]
            release_price[i] = release
            band = pressure - release
            if band < 1e-6:
                band = 1e-6

            near_peak[i] = 1.0 if highs[i] >= pressure * (1.0 - peak_touch_eps) else 0.0
            near_release[i] = 1.0 if lows[i] <= release * 1.03 else 0.0

            bar_range = highs[i] - lows[i]
            if near_peak[i] > 0 and near_release[i] > 0 and bar_range / band >= 0.55:
                two_side_active[i] = 1.0
            else:
                two_side_active[i] = 0.0

            # consolidation check
            c_start = trough_idx if trough_idx > i - consolidation_window + 1 else i - consolidation_window + 1
            c_len = i + 1 - c_start
            min_c = consolidation_window // 3
            if min_c < 8:
                min_c = 8
            if c_len >= min_c:
                # median of amp_pct[c_start:i+1]
                tmp_amp = amp_pct[c_start:i + 1].copy()
                tmp_amp.sort()
                mid = len(tmp_amp) // 2
                med_amp = tmp_amp[mid] if len(tmp_amp) % 2 == 1 else (tmp_amp[mid - 1] + tmp_amp[mid]) / 2.0
                low_vol = med_amp <= 0.06

                tmp_ar = amount_rank[c_start:i + 1].copy()
                tmp_ar.sort()
                mid2 = len(tmp_ar) // 2
                med_ar = tmp_ar[mid2] if len(tmp_ar) % 2 == 1 else (tmp_ar[mid2 - 1] + tmp_ar[mid2]) / 2.0
                low_turn = med_ar <= 0.65

                if low_vol and low_turn:
                    consolidation_ok[i] = 1.0

                anchor_start = c_start
                if last_spear_idx >= anchor_start and last_spear_idx <= i:
                    anchor_start = last_spear_idx
                if last_limit_idx >= anchor_start and last_limit_idx <= i:
                    if last_limit_idx > anchor_start:
                        anchor_start = last_limit_idx
                event_anchor_start[i] = float(anchor_start)

                # inline anchored_vwap
                total_amt = 0.0
                weighted_price = 0.0
                for j in range(anchor_start, i + 1):
                    a = amount[j]
                    if a > 0:
                        total_amt += a
                        weighted_price += vwap_proxy[j] * a
                if total_amt > 0:
                    anchor_vwap_out[i] = weighted_price / total_amt
                else:
                    total_vol = 0.0
                    weighted_price2 = 0.0
                    for j in range(anchor_start, i + 1):
                        v = volume[j]
                        if v > 0:
                            total_vol += v
                            weighted_price2 += vwap_proxy[j] * v
                    if total_vol > 0:
                        anchor_vwap_out[i] = weighted_price2 / total_vol

            # trend check
            m20 = ma20[i]
            m60 = ma60[i]
            if np.isfinite(m20) and np.isfinite(m60) and m20 > m60 and closes[i] > m20:
                trend_up[i] = 1.0

            # drawdown filter
            if pressure > 0 and release > 0:
                dd = (release / pressure) - 1.0
                if dd > -abs(drawdown_min):
                    two_side_active[i] = 0.0

        return (peak_price, release_price, range_position,
                near_peak, near_release, two_side_active,
                consolidation_ok, trend_up, anchor_vwap_out, event_anchor_start)


def add_structure_features(
    df: pd.DataFrame,
    peak_window: int = 120,
    drawdown_min: float = 0.15,
    peak_touch_eps: float = 0.03,
    consolidation_window: int = 30,
) -> pd.DataFrame:
    out = df.copy()
    n = len(out)

    if not _HAS_NUMBA or n == 0:
        return _add_trend_spear_doc_metrics(
            _add_structure_features_original(out, peak_window, drawdown_min, peak_touch_eps, consolidation_window)
        )

    highs = out["high"].to_numpy(dtype=np.float64)
    lows = out["low"].to_numpy(dtype=np.float64)
    closes = out["close"].to_numpy(dtype=np.float64)
    amp_pct = out["amp_pct"].to_numpy(dtype=np.float64) if "amp_pct" in out.columns else np.zeros(n)
    amount_rank = out["amount_rank"].to_numpy(dtype=np.float64) if "amount_rank" in out.columns else np.full(n, 0.5)
    is_spear = out["is_spear"].to_numpy(dtype=bool) if "is_spear" in out.columns else np.zeros(n, dtype=bool)
    is_limit = out["is_limit_up_close"].to_numpy(dtype=bool) if "is_limit_up_close" in out.columns else np.zeros(n, dtype=bool)
    ma20_arr = out["ma20"].to_numpy(dtype=np.float64) if "ma20" in out.columns else np.full(n, np.nan)
    ma60_arr = out["ma60"].to_numpy(dtype=np.float64) if "ma60" in out.columns else np.full(n, np.nan)
    vwap_proxy = out["vwap_proxy"].to_numpy(dtype=np.float64) if "vwap_proxy" in out.columns else closes.copy()
    amount_arr = out["amount"].to_numpy(dtype=np.float64) if "amount" in out.columns else np.zeros(n)
    volume_arr = out["volume"].to_numpy(dtype=np.float64) if "volume" in out.columns else np.zeros(n)

    (peak_price, release_price, range_position,
     near_peak, near_release, two_side_active,
     consolidation_ok, trend_up, anchor_vwap, event_anchor_start) = _structure_kernel(
        highs, lows, closes, amp_pct, amount_rank, is_spear, is_limit,
        ma20_arr, ma60_arr, vwap_proxy, amount_arr, volume_arr,
        peak_window, drawdown_min, peak_touch_eps, consolidation_window, n,
    )

    out["pressure_price"] = peak_price
    out["release_price"] = release_price
    out["range_position_120"] = range_position
    out["near_peak_pressure"] = near_peak.astype(bool)
    out["near_release_support"] = near_release.astype(bool)
    out["two_side_active"] = two_side_active.astype(bool)
    out["consolidation_ok"] = consolidation_ok.astype(bool)
    out["trend_up"] = trend_up.astype(bool)
    out["anchored_vwap"] = anchor_vwap
    out["event_anchor_start"] = event_anchor_start
    return _add_trend_spear_doc_metrics(out)


def _add_trend_spear_doc_metrics(
    df: pd.DataFrame,
    *,
    recent_window: int = 10,
    hist_window: int = 60,
    long_window: int = 120,
    zhang_ratio_min: float = 1.2,
    xu_hist_p90_mult: float = 1.8,
    explosive_long_p95_mult: float = 2.0,
    han_ratio_max: float = 0.6,
    divergence_vol_ratio: float = 2.0,
    divergence_price_gain: float = 0.02,
    chengshangqixia_range_min: float = 0.75,
) -> pd.DataFrame:
    """Add explicit metrics for docs 01 and 03.

    01 `zhangyang_hanshu` is implemented from the document's pseudo-code:
    recent up/down-day median volume, historical median/P90, long-window P95,
    explosive-volume exclusion, and volume/price divergence veto.

    03 `chengshangqixia` is implemented as a position-aware companion metric:
    the existing chip-loosen proxy (`two_side_active`) plus the document's
    suggested joint filter of `near_peak_pressure + high range position +
    zhangyang_hanshu_score`.
    """
    out = df.copy()
    if not {"open", "close", "high", "low", "volume"}.issubset(out.columns):
        return out

    open_ = out["open"].astype(float)
    close = out["close"].astype(float)
    high = out["high"].astype(float)
    low = out["low"].astype(float)
    volume = out["volume"].astype(float)

    up_mask = close > open_
    down_mask = close < open_

    min_recent = max(5, recent_window // 2)
    min_hist = max(10, hist_window // 3)
    min_long = max(20, long_window // 3)

    up_days = up_mask.rolling(recent_window, min_periods=1).sum()
    down_days = down_mask.rolling(recent_window, min_periods=1).sum()
    vol_up_median = volume.where(up_mask).rolling(recent_window, min_periods=2).median()
    vol_down_median = volume.where(down_mask).rolling(recent_window, min_periods=2).median()
    vol_hist_median = volume.rolling(hist_window, min_periods=min_hist).median()
    vol_hist_p90 = volume.rolling(hist_window, min_periods=min_hist).quantile(0.90)
    vol_long_p95 = volume.rolling(long_window, min_periods=min_long).quantile(0.95)
    max_recent_vol = volume.rolling(recent_window, min_periods=min_recent).max()
    recent_price_gain = (close / open_.shift(recent_window - 1) - 1.0).replace([np.inf, -np.inf], np.nan)

    zhang_ratio = (vol_up_median / vol_down_median).replace([np.inf, -np.inf], np.nan)
    xu_ratio = (max_recent_vol / vol_hist_p90).replace([np.inf, -np.inf], np.nan)
    han_ratio = (vol_down_median / vol_up_median).replace([np.inf, -np.inf], np.nan)
    recent_vol_ratio = (vol_up_median / vol_hist_median).replace([np.inf, -np.inf], np.nan)

    explosive_day = volume > (vol_long_p95 * explosive_long_p95_mult)
    explosive_recent = explosive_day.rolling(recent_window, min_periods=min_recent).max().fillna(0).astype(bool)

    enough_recent = (up_days >= 2) & (down_days >= 2)
    zhang_ok = enough_recent & (zhang_ratio > zhang_ratio_min)
    xu_ok = xu_ratio < xu_hist_p90_mult
    han_ok = enough_recent & (han_ratio < han_ratio_max)
    vol_price_divergence = (recent_vol_ratio > divergence_vol_ratio) & (recent_price_gain < divergence_price_gain)
    zhangyang_hanshu_score = zhang_ok & xu_ok & han_ok & (~explosive_recent) & (~vol_price_divergence)

    range_position = pd.to_numeric(out.get("range_position_120", 0.0), errors="coerce").fillna(0.0)
    near_peak_pressure = out.get("near_peak_pressure", pd.Series(False, index=out.index)).astype(bool)
    two_side_active = out.get("two_side_active", pd.Series(False, index=out.index)).astype(bool)
    pressure_price = pd.to_numeric(out.get("pressure_price", np.nan), errors="coerce")
    release_price = pd.to_numeric(out.get("release_price", np.nan), errors="coerce")

    pressure_touch_pct = (high / pressure_price - 1.0).replace([np.inf, -np.inf], np.nan)
    release_touch_pct = (low / release_price - 1.0).replace([np.inf, -np.inf], np.nan)
    position_ok = near_peak_pressure & (range_position > chengshangqixia_range_min)
    chengshangqixia_score = position_ok & zhangyang_hanshu_score

    out["zhangyang_up_days_10"] = up_days.astype(float)
    out["zhangyang_down_days_10"] = down_days.astype(float)
    out["zhang_ratio_10"] = zhang_ratio
    out["xu_ratio_10"] = xu_ratio
    out["han_ratio_10"] = han_ratio
    out["zhangyang_recent_vol_ratio_10"] = recent_vol_ratio
    out["zhangyang_recent_price_gain_10"] = recent_price_gain
    out["zhangyang_zhang_ok"] = zhang_ok.astype(bool)
    out["zhangyang_xu_ok"] = xu_ok.fillna(False).astype(bool)
    out["zhangyang_han_ok"] = han_ok.astype(bool)
    out["zhangyang_explosive_recent"] = explosive_recent.astype(bool)
    out["zhangyang_vol_price_divergence"] = vol_price_divergence.fillna(False).astype(bool)
    out["zhangyang_hanshu_score"] = zhangyang_hanshu_score.fillna(False).astype(bool)

    out["chengshangqixia_chip_loosen"] = two_side_active.astype(bool)
    out["chengshangqixia_position_ok"] = position_ok.astype(bool)
    out["chengshangqixia_score"] = chengshangqixia_score.fillna(False).astype(bool)
    out["chengshangqixia_pressure_touch_pct"] = pressure_touch_pct
    out["chengshangqixia_release_touch_pct"] = release_touch_pct
    return out


# ---------------------------------------------------------------------------
# ORIGINAL IMPLEMENTATION (preserved as reference / rollback target).
# If the numba kernel above produces incorrect results, swap the call in
# add_structure_features() to use this function instead.
# ---------------------------------------------------------------------------
def _add_structure_features_original(
    out: pd.DataFrame,
    peak_window: int = 120,
    drawdown_min: float = 0.15,
    peak_touch_eps: float = 0.03,
    consolidation_window: int = 30,
) -> pd.DataFrame:
    from cq_backtest.shared.feature_primitives import anchored_vwap

    n = len(out)
    peak_price = np.full(n, np.nan)
    release_price = np.full(n, np.nan)
    range_position = np.full(n, np.nan)
    near_peak = np.full(n, False)
    near_release = np.full(n, False)
    two_side_active = np.full(n, False)
    consolidation_ok = np.full(n, False)
    trend_up = np.full(n, False)
    anchor_vwap_arr = np.full(n, np.nan)
    event_anchor_start = np.full(n, np.nan)

    highs = out["high"].to_numpy(dtype=float)
    lows = out["low"].to_numpy(dtype=float)
    closes = out["close"].to_numpy(dtype=float)

    for i in range(n):
        s = max(0, i - peak_window)
        seg_h = highs[s : i + 1]
        seg_l = lows[s : i + 1]
        if len(seg_h) < 20:
            continue
        hi = float(np.max(seg_h))
        lo = float(np.min(seg_l))
        rng = hi - lo
        range_position[i] = (closes[i] - lo) / rng if rng > 0 else 0.5

        hist_h = highs[s:i]
        if len(hist_h) < 10:
            continue
        peak_rel = int(np.argmax(hist_h))
        peak_idx = s + peak_rel
        pressure = float(highs[peak_idx])
        peak_price[i] = pressure
        trough_idx = peak_idx + int(np.argmin(lows[peak_idx : i + 1]))
        release = float(lows[trough_idx])
        release_price[i] = release
        band = max(pressure - release, 1e-6)
        near_peak[i] = highs[i] >= pressure * (1.0 - peak_touch_eps)
        near_release[i] = lows[i] <= release * 1.03
        two_side_active[i] = bool(near_peak[i] and near_release[i] and (highs[i] - lows[i]) / band >= 0.55)

        c_start = max(trough_idx, i - consolidation_window + 1)
        c = out.iloc[c_start : i + 1]
        if len(c) >= max(8, consolidation_window // 3):
            low_vol = float(c["amp_pct"].median()) <= 0.06
            low_turn = float(c["amount_rank"].median()) <= 0.65 if "amount_rank" in c.columns else True
            consolidation_ok[i] = low_vol and low_turn
            anchor_start = c_start
            if "is_spear" in out.columns:
                spear_candidates = np.where(out.iloc[: i + 1]["is_spear"].to_numpy(dtype=bool))[0]
                if len(spear_candidates) > 0:
                    anchor_start = max(anchor_start, int(spear_candidates[-1]))
            if "is_limit_up_close" in out.columns:
                limit_candidates = np.where(out.iloc[: i + 1]["is_limit_up_close"].to_numpy(dtype=bool))[0]
                if len(limit_candidates) > 0:
                    anchor_start = max(anchor_start, int(limit_candidates[-1]))
            event_anchor_start[i] = anchor_start
            anchor_vwap_arr[i] = anchored_vwap(out.iloc[: i + 1], anchor_start)

        ma20_val = float(out.iloc[i]["ma20"]) if pd.notna(out.iloc[i]["ma20"]) else np.nan
        ma60_val = float(out.iloc[i]["ma60"]) if pd.notna(out.iloc[i]["ma60"]) else np.nan
        trend_up[i] = bool(np.isfinite(ma20_val) and np.isfinite(ma60_val) and ma20_val > ma60_val and closes[i] > ma20_val)

        if pressure > 0 and release > 0:
            dd = (release / pressure) - 1.0
            if dd > -abs(drawdown_min):
                two_side_active[i] = False

    out["pressure_price"] = peak_price
    out["release_price"] = release_price
    out["range_position_120"] = range_position
    out["near_peak_pressure"] = near_peak
    out["near_release_support"] = near_release
    out["two_side_active"] = two_side_active
    out["consolidation_ok"] = consolidation_ok
    out["trend_up"] = trend_up
    out["anchored_vwap"] = anchor_vwap_arr
    out["event_anchor_start"] = event_anchor_start
    return out
