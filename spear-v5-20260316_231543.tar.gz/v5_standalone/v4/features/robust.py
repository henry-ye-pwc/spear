from __future__ import annotations

import numpy as np
import pandas as pd

from cq_backtest.shared.feature_primitives import rolling_half_sample_mode, rolling_mad, rolling_rank_pct


def add_robust_volume_features(df: pd.DataFrame, window: int = 60) -> pd.DataFrame:
    out = df.copy()
    amount = out["amount"].astype(float)
    log_amount = out["log_amount"].astype(float)
    med = log_amount.rolling(window, min_periods=max(10, window // 3)).median()
    mad = rolling_mad(log_amount, window).replace(0.0, np.nan)
    hsm = rolling_half_sample_mode(amount, window)

    out["amount_rank"] = rolling_rank_pct(amount, window).fillna(0.5)
    out["amount_z"] = ((log_amount - med) / mad).replace([np.inf, -np.inf], np.nan).fillna(0.0)
    out["amount_base_hsm"] = hsm.fillna(amount.rolling(window, min_periods=5).median())
    out["amount_q95"] = amount.rolling(window, min_periods=max(10, window // 3)).quantile(0.95).fillna(amount)
    out["is_amount_outlier"] = out["amount_z"] >= 4.0
    out["is_amount_confirm"] = (out["amount"] >= out["amount_base_hsm"] * 1.30) & (out["amount"] <= out["amount_q95"] * 1.05)
    out["is_amount_explosive"] = (out["amount_rank"] >= 0.985) | (out["amount_z"] >= 4.5)

    vol = df["volume"].astype(float)
    vol_med = vol.rolling(window, min_periods=10).median()
    vol_p75 = vol.rolling(window, min_periods=10).quantile(0.75)
    vol_p25 = vol.rolling(window, min_periods=10).quantile(0.25)
    out["vol60_iqr_norm"] = ((vol_p75 - vol_p25) / vol_med).replace([np.inf, -np.inf], np.nan)

    long_window = window * 2
    vol_med_long = vol.rolling(long_window, min_periods=20).median()
    out["vol_elevation"] = (vol_med / vol_med_long).replace([np.inf, -np.inf], np.nan)

    hi = df["high"].astype(float)
    lo = df["low"].astype(float)
    cl = df["close"].astype(float)
    prev_cl = cl.shift(1)
    tr = pd.concat([hi - lo, (hi - prev_cl).abs(), (lo - prev_cl).abs()], axis=1).max(axis=1)
    out["atr_20d_pct"] = (tr.rolling(20, min_periods=5).mean() / cl).replace([np.inf, -np.inf], np.nan)

    return out
