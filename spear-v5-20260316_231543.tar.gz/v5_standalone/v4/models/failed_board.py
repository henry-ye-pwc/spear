from __future__ import annotations

import pandas as pd

from cq_backtest.shared.signal_schema import SignalEventV2
from v4.models.helpers import dual_spear_cut_gate, is_spear, themed_env_ok


def detect_failed_board(frame: pd.DataFrame, symbol: str, env: dict | None = None, *, cur: dict | None = None) -> SignalEventV2 | None:
    if cur is None:
        cur = frame.iloc[-1]
    if not bool(cur.get("is_failed_board", False)) or not is_spear(cur):
        return None
    if not themed_env_ok(env):
        return None
    if float(cur.get("close_pos", 0.5)) > 0.55:
        return None
    if float(cur.get("amount_rank", 0.5)) < 0.58:
        return None
    if bool(cur.get("is_amount_explosive", False)):
        return None
    if not (bool(cur.get("two_side_active", False)) or bool(cur.get("near_peak_pressure", False))):
        return None
    if int(cur.get("recent_spear_count_10", 0)) < 2:
        return None
    if pd.isna(cur.get("last_two_spear_cut_price")):
        return None

    gate = dual_spear_cut_gate(frame, window=10)
    invalid = min(float(cur["low"]), gate * 0.985)
    confidence = 0.68
    if float(cur.get("recent_spear_count_5", 0)) >= 2:
        confidence += 0.06
    if bool(cur.get("is_amount_confirm", False)):
        confidence += 0.04
    if float(cur.get("dual_spear_distance", 1.0) or 1.0) <= 0.06:
        confidence += 0.03

    return SignalEventV2(
        event_type="failed_board",
        symbol=symbol,
        ts=str(frame.index[-1])[:10],
        confidence=min(0.9, round(confidence, 3)),
        side="long",
        tags=["rebalance", "failed_board"],
        entry_plan={"style": "breakout", "gate_price": round(gate, 3), "valid_for_days": 4},
        invalidation={"type": "below_gate_or_day_low", "price": round(invalid, 3)},
        exit_plan={"style": "rebalance_swing", "hold_days": 6, "take_profit_pct": 0.18},
        context={
            "gate_source": "dual_spear_cut",
            "amount_rank": float(cur.get("amount_rank", 0.5)),
            "dual_spear_distance": round(float(cur.get("dual_spear_distance", 0.0) or 0.0), 4),
            "microstructure_confirmed": False,
        },
    )
