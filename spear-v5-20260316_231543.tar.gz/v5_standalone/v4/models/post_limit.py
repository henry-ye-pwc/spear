from __future__ import annotations

import pandas as pd

from cq_backtest.shared.signal_schema import SignalEventV2
from v4.models.helpers import board_after_gate, is_spear, prior_limit_event, recent_limit_gap


def detect_post_limit(frame: pd.DataFrame, symbol: str, lookback: int = 8, env: dict | None = None, *, cur: dict | None = None) -> SignalEventV2 | None:
    if len(frame) < 20:
        return None
    if cur is None:
        cur = frame.iloc[-1]
    gap = recent_limit_gap(frame, lookback)
    if gap is None or gap < 1 or gap > 7 or not is_spear(cur):
        return None
    core_structure = bool(cur.get("two_side_active", False)) or bool(cur.get("near_peak_pressure", False))
    consolidation_only = bool(cur.get("consolidation_ok", False)) and not core_structure
    if not core_structure and not consolidation_only:
        return None
    limit_idx, limit_row = prior_limit_event(frame, lookback=lookback)
    if limit_row is None or limit_idx is None:
        return None
    prior_limit_amount = float(limit_row.get("amount", 0.0) or 0.0)
    gun_amount = float(cur.get("amount", 0.0) or 0.0)
    gun_vs_prior_limit = gun_amount / max(prior_limit_amount, 1.0)
    if bool(cur.get("is_amount_explosive", False)) and bool(limit_row.get("is_amount_explosive", False)):
        return None
    if bool(cur.get("is_amount_explosive", False)) and float(cur.get("range_position_120", 0.5)) > 0.82:
        return None
    if gun_vs_prior_limit > 1.25:
        return None
    if not (bool(cur.get("is_amount_confirm", False)) or gun_vs_prior_limit <= 1.05):
        return None
    if consolidation_only:
        if gap > 3:
            return None
        if float(cur.get("close_pos", 0.5)) < 0.45:
            return None
        if float(cur.get("range_position_120", 0.5)) > 0.82:
            return None
        if gun_vs_prior_limit > 0.95:
            return None
    if bool(cur.get("is_failed_board", False)) and float(cur.get("close_pos", 0.5)) <= 0.55:
        return None
    if not bool(cur.get("is_amount_confirm", False)):
        if bool(cur.get("touch_limit_up", False)):
            return None
        if float(cur.get("amount_rank", 0.5)) > 0.95 or float(cur.get("amount_z", 0.0)) > 2.5:
            return None

    gate = board_after_gate(frame, lookback=lookback)
    invalid = min(float(cur["low"]), gate * 0.985)
    confidence = 0.64
    if float(cur.get("recent_spear_count_5", 0)) >= 2:
        confidence += 0.05
    if bool(cur.get("is_amount_confirm", False)):
        confidence += 0.04
    if gun_vs_prior_limit <= 0.95:
        confidence += 0.03

    return SignalEventV2(
        event_type="post_limit",
        symbol=symbol,
        ts=str(frame.index[-1])[:10],
        confidence=min(0.9, round(confidence, 3)),
        side="long",
        tags=["post_limit_window"],
        entry_plan={"style": "breakout", "gate_price": round(gate, 3), "valid_for_days": 5},
        invalidation={"type": "below_gate_or_day_low", "price": round(invalid, 3)},
        exit_plan={"style": "swing_confirm", "hold_days": 7, "take_profit_pct": 0.16},
        context={
            "limit_gap": int(gap),
            "gate_source": "board_after",
            "prior_limit_amount": round(prior_limit_amount, 3),
            "gun_vs_prior_limit": round(gun_vs_prior_limit, 3),
            "structure_mode": "core" if core_structure else "consolidation_only",
            "relative_limit_volume_ok": bool(gun_vs_prior_limit <= 1.05),
        },
    )
