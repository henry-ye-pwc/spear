from __future__ import annotations

import pandas as pd

from cq_backtest.shared.signal_schema import SignalEventV2
from v4.models.helpers import is_spear, themed_env_ok


def detect_arb(frame: pd.DataFrame, symbol: str, lookback: int = 7, env: dict | None = None, *, cur: dict | None = None) -> SignalEventV2 | None:
    if len(frame) < 20:
        return None
    if cur is None:
        cur = frame.iloc[-1]
    if not is_spear(cur):
        return None
    if not themed_env_ok(env, allow_neutral=True):
        return None
    if float(cur.get("amp_pct", 0.0)) < 0.07:
        return None
    if float(cur.get("range_position_120", 0.5)) >= 0.8:
        return None
    gap = cur.get("last_limit_gap")
    recent_failed = bool(cur.get("is_failed_board", False)) or (not pd.isna(gap) and int(gap) <= lookback)
    if not recent_failed:
        return None
    if bool(cur.get("is_amount_explosive", False)):
        return None
    if float(cur.get("close_pos", 0.5)) < 0.25:
        return None

    invalid = float(cur["low"])
    confidence = 0.63
    if float(cur.get("amount_rank", 0.5)) <= 0.92:
        confidence += 0.04
    return SignalEventV2(
        event_type="arb",
        symbol=symbol,
        ts=str(frame.index[-1])[:10],
        confidence=min(0.85, round(confidence, 3)),
        side="long",
        tags=["tail_entry", "short_horizon"],
        entry_plan={"style": "tail_close"},
        invalidation={"type": "below_day_low", "price": round(invalid, 3)},
        exit_plan={"style": "tactical_arb", "hold_days": 3, "take_profit_pct": 0.10},
        context={"amp_pct": float(cur.get("amp_pct", 0.0)), "microstructure_confirmed": False},
    )
