from __future__ import annotations

import numpy as np
import pandas as pd

try:
    from numba import njit
    _HAS_NUMBA = True
except ImportError:
    _HAS_NUMBA = False
    njit = lambda f: f  # noqa: E731

# ---------------------------------------------------------------------------
# Numba kernels for gate/indices (array-in, scalar or fixed array out).
# Used when _HAS_NUMBA and frame has required columns; otherwise Python path.
# ---------------------------------------------------------------------------
if _HAS_NUMBA:
    @njit(cache=True)
    def _is_spear_nb(upper_shadow_pct: float, board_upper_shadow_min: float) -> bool:
        return upper_shadow_pct >= board_upper_shadow_min

    @njit(cache=True)
    def _dense_mid_nb(open_i: float, high_i: float, close_i: float) -> float:
        top = max(open_i, close_i)
        return (high_i + top) / 2.0

    @njit(cache=True)
    def _resolved_breakout_gate_nb(body_top: float, high_cur: float, dense_gate: float, avwap: float) -> float:
        candidates = [body_top]
        if np.isfinite(dense_gate):
            candidates.append(dense_gate)
        if np.isfinite(avwap):
            candidates.append(avwap)
        gate = max(candidates)
        return min(gate, high_cur)

    _MAX_INDICES = 64

    @njit(cache=True)
    def _recent_spear_indices_nb(
        upper_shadow_pct: np.ndarray,
        board_upper_shadow_min: np.ndarray,
        is_failed_board: np.ndarray,
        n: int,
        window: int,
    ) -> tuple[np.ndarray, int]:
        start = max(0, n - window)
        out = np.empty(_MAX_INDICES, dtype=np.int64)
        count = 0
        for i in range(start, n):
            if count >= _MAX_INDICES:
                break
            is_spear = upper_shadow_pct[i] >= board_upper_shadow_min[i]
            if is_spear or is_failed_board[i]:
                out[count] = i
                count += 1
        return out, count

    @njit(cache=True)
    def _prior_limit_event_nb(is_limit_up_close: np.ndarray, n: int, lookback: int) -> int:
        start = max(0, n - lookback - 1)
        last_idx = -1
        for i in range(start, n - 1):
            if is_limit_up_close[i]:
                last_idx = i
        return last_idx

    @njit(cache=True)
    def _recent_event_gate_nb(
        open_arr: np.ndarray,
        high_arr: np.ndarray,
        close_arr: np.ndarray,
        amount_arr: np.ndarray,
        upper_shadow_pct: np.ndarray,
        board_upper_shadow_min: np.ndarray,
        is_failed_board: np.ndarray,
        event_dense_mid: np.ndarray,
        n: int,
        window: int,
    ) -> float:
        indices, cnt = _recent_spear_indices_nb(
            upper_shadow_pct, board_upper_shadow_min, is_failed_board, n, window
        )
        if cnt == 0:
            return max(open_arr[n - 1], close_arr[n - 1])
        total = 0.0
        weight = 0.0
        for k in range(cnt):
            i = indices[k]
            amt = max(amount_arr[i], 1.0)
            mid = event_dense_mid[i] if np.isfinite(event_dense_mid[i]) else _dense_mid_nb(
                open_arr[i], high_arr[i], close_arr[i]
            )
            total += mid * amt
            weight += amt
        return total / weight if weight > 0 else close_arr[n - 1]

    @njit(cache=True)
    def _trend_city_gate_nb(
        open_arr: np.ndarray,
        high_arr: np.ndarray,
        close_arr: np.ndarray,
        amount_arr: np.ndarray,
        upper_shadow_pct: np.ndarray,
        board_upper_shadow_min: np.ndarray,
        is_failed_board: np.ndarray,
        event_dense_mid: np.ndarray,
        anchored_vwap: np.ndarray,
        n: int,
        window: int,
    ) -> float:
        body_top = max(open_arr[n - 1], close_arr[n - 1])
        high_cur = high_arr[n - 1]
        avwap = anchored_vwap[n - 1]
        indices, cnt = _recent_spear_indices_nb(
            upper_shadow_pct, board_upper_shadow_min, is_failed_board, n, window
        )
        if cnt == 0:
            dense_gate = body_top
        else:
            take = min(3, cnt)
            sum_mid = 0.0
            for k in range(cnt - take, cnt):
                i = indices[k]
                mid = event_dense_mid[i] if np.isfinite(event_dense_mid[i]) else _dense_mid_nb(
                    open_arr[i], high_arr[i], close_arr[i]
                )
                sum_mid += mid
            dense_gate = sum_mid / take
        candidates = [body_top, dense_gate]
        if np.isfinite(avwap):
            candidates.append(avwap)
        return min(high_cur, max(candidates))

    @njit(cache=True)
    def _board_after_gate_nb(
        open_arr: np.ndarray,
        high_arr: np.ndarray,
        close_arr: np.ndarray,
        amount_arr: np.ndarray,
        upper_shadow_pct: np.ndarray,
        board_upper_shadow_min: np.ndarray,
        is_failed_board: np.ndarray,
        is_limit_up_close: np.ndarray,
        event_dense_mid: np.ndarray,
        anchored_vwap: np.ndarray,
        n: int,
        lookback: int,
    ) -> float:
        body_top = max(open_arr[n - 1], close_arr[n - 1])
        high_cur = high_arr[n - 1]
        avwap = anchored_vwap[n - 1]
        limit_idx = _prior_limit_event_nb(is_limit_up_close, n, lookback)
        if limit_idx < 0:
            dense_gate = event_dense_mid[n - 1] if np.isfinite(event_dense_mid[n - 1]) else body_top
            return _resolved_breakout_gate_nb(body_top, high_cur, dense_gate, avwap)
        second_last_mid = 0.0
        last_mid = 0.0
        event_count = 0
        for i in range(limit_idx, n):
            is_spear = upper_shadow_pct[i] >= board_upper_shadow_min[i]
            if is_spear or is_failed_board[i] or is_limit_up_close[i]:
                mid = event_dense_mid[i] if np.isfinite(event_dense_mid[i]) else _dense_mid_nb(
                    open_arr[i], high_arr[i], close_arr[i]
                )
                second_last_mid = last_mid
                last_mid = mid
                event_count += 1
        if event_count == 0:
            dense_gate = event_dense_mid[n - 1] if np.isfinite(event_dense_mid[n - 1]) else body_top
        elif event_count == 1:
            dense_gate = last_mid
        else:
            dense_gate = (second_last_mid + last_mid) / 2.0
        gate = max(body_top, dense_gate)
        if np.isfinite(avwap) and avwap > gate:
            gate = avwap
        return min(high_cur, gate)


def is_spear(row: pd.Series) -> bool:
    return float(row["upper_shadow_pct"]) >= float(row["board_upper_shadow_min"])


def dense_mid(row: pd.Series) -> float:
    top = max(float(row["open"]), float(row["close"]))
    return (float(row["high"]) + top) / 2.0


def themed_env_ok(env: dict | None, *, allow_neutral: bool = False) -> bool:
    env = env or {}
    if "peer_confirmation" not in env and "leader_strength" not in env and not bool(env.get("_enforce_env", False)):
        return True
    peer = int(env.get("peer_confirmation", 0) or 0)
    leader = int(env.get("leader_strength", 0) or 0)
    theme = str(env.get("theme_label", "其他") or "其他")
    sector_hot = bool(env.get("sector_hot", False))
    if leader >= 1 or peer >= 1:
        return True
    if sector_hot and theme != "其他":
        return True
    if allow_neutral and theme != "其他":
        return True
    return False


def _required_gate_columns() -> tuple[str, ...]:
    return (
        "open", "high", "close", "amount",
        "upper_shadow_pct", "board_upper_shadow_min", "is_failed_board", "is_limit_up_close",
    )


def _get_frame_arrays(frame: pd.DataFrame):
    """Extract float/bool arrays for Numba gate kernels. Returns None if any required column missing."""
    req = _required_gate_columns()
    if not all(c in frame.columns for c in req):
        return None
    n = len(frame)
    open_arr = frame["open"].to_numpy(dtype=np.float64)
    high_arr = frame["high"].to_numpy(dtype=np.float64)
    close_arr = frame["close"].to_numpy(dtype=np.float64)
    amount_arr = frame["amount"].to_numpy(dtype=np.float64)
    upper_shadow_pct = frame["upper_shadow_pct"].to_numpy(dtype=np.float64)
    board_upper_shadow_min = frame["board_upper_shadow_min"].to_numpy(dtype=np.float64)
    is_failed_board = frame["is_failed_board"].to_numpy(dtype=bool)
    is_limit_up_close = frame["is_limit_up_close"].to_numpy(dtype=bool)
    event_dense_mid = frame["event_dense_mid"].to_numpy(dtype=np.float64) if "event_dense_mid" in frame.columns else np.full(n, np.nan)
    anchored_vwap = frame["anchored_vwap"].to_numpy(dtype=np.float64) if "anchored_vwap" in frame.columns else np.full(n, np.nan)
    return {
        "open": open_arr, "high": high_arr, "close": close_arr, "amount": amount_arr,
        "upper_shadow_pct": upper_shadow_pct, "board_upper_shadow_min": board_upper_shadow_min,
        "is_failed_board": is_failed_board, "is_limit_up_close": is_limit_up_close,
        "event_dense_mid": event_dense_mid, "anchored_vwap": anchored_vwap,
        "n": n,
    }


def recent_spear_indices(frame: pd.DataFrame, window: int = 10) -> list[int]:
    idx: list[int] = []
    for i in range(max(0, len(frame) - window), len(frame)):
        row = frame.iloc[i]
        if is_spear(row) or bool(row.get("is_failed_board", False)):
            idx.append(i)
    return idx


def recent_event_gate(frame: pd.DataFrame, symbol: str, window: int = 10) -> float:
    if _HAS_NUMBA:
        arrs = _get_frame_arrays(frame)
        if arrs is not None and arrs["n"] >= 1:
            return _recent_event_gate_nb(
                arrs["open"], arrs["high"], arrs["close"], arrs["amount"],
                arrs["upper_shadow_pct"], arrs["board_upper_shadow_min"], arrs["is_failed_board"],
                arrs["event_dense_mid"], arrs["n"], window,
            )
    idx = recent_spear_indices(frame, window=window)
    if not idx:
        row = frame.iloc[-1]
        return float(max(row["open"], row["close"]))
    total = 0.0
    weight = 0.0
    for i in idx:
        row = frame.iloc[i]
        amt = float(row.get("amount", 0.0) or 0.0)
        total += dense_mid(row) * max(amt, 1.0)
        weight += max(amt, 1.0)
    return total / weight if weight > 0 else float(frame.iloc[-1]["close"])


def resolved_breakout_gate(cur: pd.Series, dense_gate: float | None = None) -> float:
    body_top = float(max(cur["open"], cur["close"]))
    high = float(cur["high"])
    candidates = [body_top]
    if dense_gate is not None and np.isfinite(dense_gate):
        candidates.append(float(dense_gate))
    avwap = float(cur.get("anchored_vwap", np.nan))
    if np.isfinite(avwap):
        candidates.append(avwap)
    gate = max(candidates)
    return min(gate, high)


def prior_limit_event(frame: pd.DataFrame, lookback: int = 8) -> tuple[int | None, pd.Series | None]:
    if _HAS_NUMBA:
        arrs = _get_frame_arrays(frame)
        if arrs is not None:
            idx = _prior_limit_event_nb(arrs["is_limit_up_close"], arrs["n"], lookback)
            if idx >= 0:
                return idx, frame.iloc[idx]
            return None, None
    recent = frame.iloc[max(0, len(frame) - lookback - 1) : -1]
    lu_days = recent[recent["is_limit_up_close"]]
    if lu_days.empty:
        return None, None
    idx = frame.index.get_loc(lu_days.index[-1])
    return idx, frame.iloc[idx]


def board_after_gate(frame: pd.DataFrame, lookback: int = 8) -> float:
    if _HAS_NUMBA:
        arrs = _get_frame_arrays(frame)
        if arrs is not None and arrs["n"] >= 1:
            return _board_after_gate_nb(
                arrs["open"], arrs["high"], arrs["close"], arrs["amount"],
                arrs["upper_shadow_pct"], arrs["board_upper_shadow_min"], arrs["is_failed_board"],
                arrs["is_limit_up_close"], arrs["event_dense_mid"], arrs["anchored_vwap"],
                arrs["n"], lookback,
            )
    cur = frame.iloc[-1]
    limit_idx, _ = prior_limit_event(frame, lookback=lookback)
    body_top = float(max(cur["open"], cur["close"]))
    avwap = float(cur.get("anchored_vwap", np.nan))
    if limit_idx is None:
        return resolved_breakout_gate(cur, dense_gate=float(cur.get("event_dense_mid", body_top)))

    event_idx: list[int] = []
    for i in range(limit_idx, len(frame)):
        row = frame.iloc[i]
        if is_spear(row) or bool(row.get("is_failed_board", False)) or bool(row.get("is_limit_up_close", False)):
            event_idx.append(i)
    if not event_idx:
        dense_gate = float(cur.get("event_dense_mid", body_top))
    else:
        mids = [float(frame.iloc[i].get("event_dense_mid", dense_mid(frame.iloc[i]))) for i in event_idx[-2:]]
        dense_gate = float(np.mean(mids))
    candidates = [body_top, dense_gate]
    if np.isfinite(avwap):
        candidates.append(avwap)
    return min(float(cur["high"]), max(candidates))


def dual_spear_cut_gate(frame: pd.DataFrame, window: int = 10) -> float:
    cur = frame.iloc[-1]
    cut = float(cur.get("last_two_spear_cut_price", np.nan))
    if np.isfinite(cut):
        return min(float(cur["high"]), max(float(max(cur["open"], cur["close"])), cut))
    return resolved_breakout_gate(cur, dense_gate=recent_event_gate(frame, cur.get("symbol", ""), window=window))


def trend_city_gate(frame: pd.DataFrame, window: int = 10) -> float:
    if _HAS_NUMBA:
        arrs = _get_frame_arrays(frame)
        if arrs is not None and arrs["n"] >= window:
            return _trend_city_gate_nb(
                arrs["open"], arrs["high"], arrs["close"], arrs["amount"],
                arrs["upper_shadow_pct"], arrs["board_upper_shadow_min"], arrs["is_failed_board"],
                arrs["event_dense_mid"], arrs["anchored_vwap"], arrs["n"], window,
            )
    cur = frame.iloc[-1]
    recent_idx = recent_spear_indices(frame, window=window)
    body_top = float(max(cur["open"], cur["close"]))
    avwap = float(cur.get("anchored_vwap", np.nan))
    mids = [float(frame.iloc[i].get("event_dense_mid", dense_mid(frame.iloc[i]))) for i in recent_idx[-3:]]
    dense_gate = float(np.mean(mids)) if mids else body_top
    candidates = [body_top, dense_gate]
    if np.isfinite(avwap):
        candidates.append(avwap)
    return min(float(cur["high"]), max(candidates))


def recent_limit_gap(frame: pd.DataFrame, lookback: int) -> int | None:
    idx, _ = prior_limit_event(frame, lookback=lookback)
    if idx is None:
        return None
    return len(frame) - 1 - idx
