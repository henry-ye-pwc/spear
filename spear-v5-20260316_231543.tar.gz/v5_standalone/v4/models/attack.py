from __future__ import annotations

import pandas as pd

from cq_backtest.shared.signal_schema import SignalEventV2
from v4.models.helpers import is_spear, recent_event_gate, themed_env_ok


def detect_attack(frame: pd.DataFrame, symbol: str, lookback: int = 10, env: dict | None = None, *, cur: dict | None = None) -> SignalEventV2 | None:
    if len(frame) < 40:
        return None
    if cur is None:
        cur = frame.iloc[-1]
    if not is_spear(cur):
        return None
    if not themed_env_ok(env):
        return None
    gap = cur.get("last_limit_gap")
    if pd.isna(gap) or int(gap) < 1 or int(gap) > lookback:
        return None
    if not (bool(cur.get("trend_up", False)) or float(cur.get("range_position_120", 0.5)) < 0.45):
        return None
    if bool(cur.get("is_amount_explosive", False)):
        return None
    pattern = str(cur.get("three_gun_pattern", "mixed"))
    if pattern == "progressive_expand":
        return None
    if not (bool(cur.get("last_spear_shrink", False)) or pattern == "last_shrink"):
        return None

    dense_gate = recent_event_gate(frame, symbol)
    invalid = min(float(cur["low"]), dense_gate * 0.985)
    confidence = 0.67
    if bool(cur.get("last_spear_shrink", False)):
        confidence += 0.05
    if pattern == "last_shrink":
        confidence += 0.04

    return SignalEventV2(
        event_type="attack",
        symbol=symbol,
        ts=str(frame.index[-1])[:10],
        confidence=min(0.9, round(confidence, 3)),
        side="long",
        tags=["attack", "tail_entry"],
        entry_plan={"style": "tail_close"},
        invalidation={"type": "below_day_low", "price": round(invalid, 3)},
        exit_plan={"style": "continuation", "hold_days": 7, "take_profit_pct": 0.18},
        context={"dense_gate": round(float(dense_gate), 3), "limit_gap": int(gap), "three_gun_pattern": pattern},
    )
