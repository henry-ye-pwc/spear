from __future__ import annotations

import pandas as pd

from cq_backtest.shared.signal_schema import SignalEventV2
from v4.models.helpers import is_spear


def detect_escape(frame: pd.DataFrame, symbol: str, *, cur: dict | None = None) -> SignalEventV2 | None:
    if cur is None:
        cur = frame.iloc[-1]
    if not is_spear(cur):
        return None
    high_position = (
        float(cur.get("range_position_120", 0.5)) >= 0.82
        or bool(cur.get("near_peak_pressure", False))
        or float(cur.get("ret_20", 0.0)) >= 0.25
    )
    weak_close = float(cur.get("close_pos", 0.5)) <= 0.42
    explosive = bool(cur.get("is_amount_explosive", False)) or float(cur.get("amount_rank", 0.5)) >= 0.98
    failed_push = bool(cur.get("is_failed_board", False)) or bool(cur.get("touch_limit_up", False))
    if not (high_position and weak_close and explosive and failed_push):
        return None
    confidence = 0.78
    if bool(cur.get("is_amount_outlier", False)):
        confidence += 0.06
    return SignalEventV2(
        event_type="escape",
        symbol=symbol,
        ts=str(frame.index[-1])[:10],
        confidence=min(0.95, round(confidence, 3)),
        side="risk_off",
        tags=["distribution", "avoid_n_days_3"],
        invalidation={"type": "reclaim", "days": 3},
        context={"amount_rank": float(cur.get("amount_rank", 0.5)), "close_pos": float(cur.get("close_pos", 0.5))},
    )

