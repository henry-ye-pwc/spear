from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable

from cq_backtest.shared.market_rules import can_buy_strict, can_sell_strict
from cq_backtest.shared.signal_schema import SignalEventV2


@dataclass(slots=True)
class PositionState:
    symbol: str
    entry_date: str
    entry_idx: int
    entry_price: float
    qty: float
    source_event: str
    stop_price: float
    take_price: float
    max_hold_days: int
    exit_style: str
    signal_date: str = ""
    signal_confidence: float = 0.0
    entry_style: str = ""
    board_count: int = 0
    last_board_idx: int = -1
    atr_at_entry: float = 0.0
    peak_price: float = 0.0
    peak_ret: float = 0.0
    peak_date: str = ""
    trough_price: float = 0.0
    trough_ret: float = 0.0
    trough_date: str = ""
    drawdown_from_peak: float = 0.0
    days_since_peak: int = 0
    had_limit_up_close: bool = False
    limit_up_close_days: int = 0
    near_pressure_days: int = 0
    near_support_days: int = 0
    amount_explosive_days: int = 0
    above_ma20_days: int = 0
    above_vwap_days: int = 0
    close_pos_high_days: int = 0
    trend_mode_active: bool = False
    trend_mode_activation_date: str = ""
    reentry_count: int = 0
    signal_context: dict[str, Any] = field(default_factory=dict)
    entry_plan_meta: dict[str, Any] = field(default_factory=dict)
    exit_plan_meta: dict[str, Any] = field(default_factory=dict)
    invalidation_meta: dict[str, Any] = field(default_factory=dict)


@dataclass(slots=True)
class Decision:
    action: str
    symbol: str
    price: float | None
    qty: float = 0.0
    reason: str = ""
    meta: dict = field(default_factory=dict)


@dataclass(slots=True)
class PendingEntry:
    symbol: str
    created_idx: int
    valid_from_idx: int
    valid_until_idx: int
    trigger_price: float
    source_event: str
    confidence: float
    invalidate_price: float
    max_hold_days: int
    take_profit_pct: float
    exit_style: str
    signal_date: str = ""
    entry_style: str = "breakout"
    signal_context: dict[str, Any] = field(default_factory=dict)
    entry_plan_meta: dict[str, Any] = field(default_factory=dict)
    exit_plan_meta: dict[str, Any] = field(default_factory=dict)
    invalidation_meta: dict[str, Any] = field(default_factory=dict)


@dataclass(slots=True)
class PendingFill:
    action: str
    symbol: str
    execute_idx: int
    qty: float
    source_event: str
    entry_style: str = ""
    invalidate_price: float = 0.0
    max_hold_days: int = 5
    take_profit_pct: float = 0.18
    exit_style: str = "default"
    position_mult: float = 1.0
    signal_date: str = ""
    signal_confidence: float = 0.0
    decision_date: str = ""
    decision_meta: dict[str, Any] = field(default_factory=dict)
    signal_context: dict[str, Any] = field(default_factory=dict)
    entry_plan_meta: dict[str, Any] = field(default_factory=dict)
    exit_plan_meta: dict[str, Any] = field(default_factory=dict)
    invalidation_meta: dict[str, Any] = field(default_factory=dict)


@dataclass(slots=True)
class PendingHunt:
    symbol: str
    created_idx: int
    valid_from_idx: int
    valid_until_idx: int
    target_price: float
    buffer_pct: float
    source_event: str
    confidence: float
    invalidate_price: float
    max_hold_days: int
    take_profit_pct: float
    exit_style: str
    signal_date: str = ""
    entry_style: str = "hunt"
    qty: float = 0.0
    position_mult: float = 1.0
    last_blocked_date: str = ""
    signal_context: dict[str, Any] = field(default_factory=dict)
    entry_plan_meta: dict[str, Any] = field(default_factory=dict)
    exit_plan_meta: dict[str, Any] = field(default_factory=dict)
    invalidation_meta: dict[str, Any] = field(default_factory=dict)


@dataclass(slots=True)
class PendingSellHunt:
    symbol: str
    created_idx: int
    valid_from_idx: int
    valid_until_idx: int
    target_price: float
    buffer_pct: float
    qty: float
    reason: str
    source_event: str
    exit_style: str
    decision_date: str = ""
    decision_meta: dict[str, Any] = field(default_factory=dict)


@dataclass(slots=True)
class PendingReentry:
    symbol: str
    created_idx: int
    valid_from_idx: int
    valid_until_idx: int
    trigger_price: float
    invalidate_price: float
    source_event: str
    confidence: float
    stop_price: float
    stop_day_low: float
    stop_amount_vs_prev20_med: float
    stop_volume_vs_prev20_med: float
    near_pressure_days: int
    near_support_days: int
    reentry_count: int
    signal_date: str = ""
    entry_style: str = "reentry_watch"
    signal_context: dict[str, Any] = field(default_factory=dict)
    entry_plan_meta: dict[str, Any] = field(default_factory=dict)
    exit_plan_meta: dict[str, Any] = field(default_factory=dict)
    invalidation_meta: dict[str, Any] = field(default_factory=dict)


class V4ExecutionStateMachine:
    def __init__(
        self,
        *,
        max_positions: int = 4,
        base_pos_pct: float = 0.25,
        position_sizing_base: str = "cash",
        position_multipliers: dict[str, float] | None = None,
        cooldown_days: int = 3,
        default_take_profit_pct: float = 0.18,
        execution_profile: str = "day_level_ideal",
        hunt_price_buffer_pct: float = 0.005,
        hunt_window_days: int = 3,
        exit_hunt_buffer_pct: float = 0.005,
        exit_hunt_window_days: int = 3,
        exit_mode: str = "ideal",
        trend_spear_stop_mode: str = "intraday",
        trend_spear_stop_grace_days: int = 3,
        trend_spear_trend_management_enabled: bool = False,
        trend_spear_trend_activation_ret: float = 0.20,
        trend_spear_trend_drawdown_exit: float = 0.12,
        trend_spear_trend_stale_days: int = 3,
        trend_spear_trend_max_extension_days: int = 10,
        trend_spear_reentry_watch_enabled: bool = False,
        trend_spear_reentry_watch_days: int = 3,
        trend_spear_reentry_min_near_pressure_days: int = 2,
        trend_spear_reentry_min_near_support_days: int = 2,
        trend_spear_reentry_shrink_threshold: float = 0.90,
        trend_spear_reentry_expand_threshold: float = 1.05,
        trend_spear_dynamic_hold_enabled: bool = False,
        trend_spear_limitup_extend_days: int = 15,
        trend_spear_limitup_wide_atr_mult: float = 2.5,
        trend_spear_limitup_stop_floor_pct: float = 0.92,
        trend_spear_noboard_tighten_days: int = 5,
        trend_spear_noboard_tight_atr_mult: float = 1.5,
        trend_spear_noboard_max_hold: int = 5,
        trend_spear_vol_exhaustion_exit: bool = False,
        trace_hook: Callable[[dict[str, Any]], None] | None = None,
    ) -> None:
        self.max_positions = max_positions
        self.base_pos_pct = base_pos_pct
        self.position_sizing_base = position_sizing_base
        self.position_multipliers = position_multipliers or {}
        self.cooldown_days = cooldown_days
        self.default_take_profit_pct = default_take_profit_pct
        self.execution_profile = execution_profile
        self.hunt_price_buffer_pct = hunt_price_buffer_pct
        self.hunt_window_days = hunt_window_days
        self.exit_hunt_buffer_pct = exit_hunt_buffer_pct
        self.exit_hunt_window_days = exit_hunt_window_days
        self.exit_mode = exit_mode
        self.trend_spear_stop_mode = trend_spear_stop_mode
        self.trend_spear_stop_grace_days = max(0, int(trend_spear_stop_grace_days))
        self.trend_spear_trend_management_enabled = bool(trend_spear_trend_management_enabled)
        self.trend_spear_trend_activation_ret = max(0.0, float(trend_spear_trend_activation_ret))
        self.trend_spear_trend_drawdown_exit = max(0.0, float(trend_spear_trend_drawdown_exit))
        self.trend_spear_trend_stale_days = max(1, int(trend_spear_trend_stale_days))
        self.trend_spear_trend_max_extension_days = max(0, int(trend_spear_trend_max_extension_days))
        self.trend_spear_reentry_watch_enabled = bool(trend_spear_reentry_watch_enabled)
        self.trend_spear_reentry_watch_days = max(1, int(trend_spear_reentry_watch_days))
        self.trend_spear_reentry_min_near_pressure_days = max(0, int(trend_spear_reentry_min_near_pressure_days))
        self.trend_spear_reentry_min_near_support_days = max(0, int(trend_spear_reentry_min_near_support_days))
        self.trend_spear_reentry_shrink_threshold = float(trend_spear_reentry_shrink_threshold)
        self.trend_spear_reentry_expand_threshold = float(trend_spear_reentry_expand_threshold)
        self.trend_spear_dynamic_hold_enabled = bool(trend_spear_dynamic_hold_enabled)
        self.trend_spear_limitup_extend_days = max(1, int(trend_spear_limitup_extend_days))
        self.trend_spear_limitup_wide_atr_mult = max(0.0, float(trend_spear_limitup_wide_atr_mult))
        self.trend_spear_limitup_stop_floor_pct = max(0.5, float(trend_spear_limitup_stop_floor_pct))
        self.trend_spear_noboard_tighten_days = max(1, int(trend_spear_noboard_tighten_days))
        self.trend_spear_noboard_tight_atr_mult = max(0.0, float(trend_spear_noboard_tight_atr_mult))
        self.trend_spear_noboard_max_hold = max(1, int(trend_spear_noboard_max_hold))
        self.trend_spear_vol_exhaustion_exit = bool(trend_spear_vol_exhaustion_exit)
        self.trace_hook = trace_hook
        self.positions: dict[str, PositionState] = {}
        self.cooldowns: dict[str, int] = {}
        self.pending_entries: dict[str, list[PendingEntry]] = {}
        self.pending_fills: dict[str, PendingFill] = {}
        self.pending_hunts: dict[str, PendingHunt] = {}
        self.pending_sell_hunts: dict[str, PendingSellHunt] = {}
        self.pending_reentries: dict[str, PendingReentry] = {}

    def _trace(self, kind: str, **payload: Any) -> None:
        if self.trace_hook is None:
            return
        self.trace_hook({"kind": kind, **payload})

    def _can_open(self, symbol: str, d_idx: int) -> bool:
        if len(self.positions) >= self.max_positions:
            return False
        until = self.cooldowns.get(symbol)
        return until is None or d_idx > until

    def _position_multiplier(self, event: SignalEventV2) -> float:
        mult = float(self.position_multipliers.get(str(event.event_type), 1.0))
        return max(0.0, mult)

    def _is_realistic(self) -> bool:
        return self.execution_profile == "next_open_realistic" or self.exit_mode in ("next_open", "hunt_exit")

    def _is_hunt(self) -> bool:
        return self.execution_profile == "delayed_limit_hunt"

    @staticmethod
    def _ret_from_price(price: float, entry_price: float) -> float:
        if entry_price <= 0:
            return 0.0
        return price / entry_price - 1.0

    @staticmethod
    def _safe_float(value: Any, default: float = 0.0) -> float:
        try:
            if value is None:
                return default
            return float(value)
        except Exception:
            return default

    @classmethod
    def _signal_feature_snapshot(
        cls,
        *,
        signal_context: dict[str, Any],
        entry_plan: dict[str, Any],
        exit_plan: dict[str, Any],
        invalidation: dict[str, Any],
    ) -> dict[str, Any]:
        return {
            "signal_theme_label": str(signal_context.get("theme_label", "")),
            "signal_peer_confirmation": int(signal_context.get("peer_confirmation", 0) or 0),
            "signal_leader_strength": int(signal_context.get("leader_strength", 0) or 0),
            "signal_sector_hot": bool(signal_context.get("sector_hot", False)),
            "signal_lhb_net_sell": bool(signal_context.get("lhb_net_sell", False)),
            "signal_gate_source": str(signal_context.get("gate_source", "")),
            "signal_multi_spear_count": int(signal_context.get("multi_spear_count", 0) or 0),
            "signal_three_gun_pattern": str(signal_context.get("three_gun_pattern", "")),
            "signal_spear_role": str(signal_context.get("spear_role", "")),
            "signal_dense_gate": round(cls._safe_float(signal_context.get("dense_gate", 0.0)), 4),
            "signal_limit_gap": int(signal_context.get("limit_gap", 0) or 0),
            "signal_gun_vs_prior_limit": round(cls._safe_float(signal_context.get("gun_vs_prior_limit", 0.0)), 6),
            "signal_structure_mode": str(signal_context.get("structure_mode", "")),
            "signal_relative_limit_volume_ok": bool(signal_context.get("relative_limit_volume_ok", False)),
            "signal_prior_limit_amount": round(cls._safe_float(signal_context.get("prior_limit_amount", 0.0)), 4),
            "signal_entry_gate_price": round(cls._safe_float(entry_plan.get("gate_price", 0.0)), 4),
            "signal_entry_valid_for_days": int(entry_plan.get("valid_for_days", 0) or 0),
            "signal_invalidation_type": str(invalidation.get("type", "")),
            "signal_invalidation_price": round(cls._safe_float(invalidation.get("price", 0.0)), 4),
            "signal_exit_hold_days": int(exit_plan.get("hold_days", 0) or 0),
            "signal_take_profit_pct": round(cls._safe_float(exit_plan.get("take_profit_pct", 0.0)), 6),
            "signal_zhangyang_hanshu_score": bool(signal_context.get("zhangyang_hanshu_score", False)),
            "signal_zhang_ratio_10": round(cls._safe_float(signal_context.get("zhang_ratio_10", 0.0)), 6),
            "signal_xu_ratio_10": round(cls._safe_float(signal_context.get("xu_ratio_10", 0.0)), 6),
            "signal_han_ratio_10": round(cls._safe_float(signal_context.get("han_ratio_10", 0.0)), 6),
            "signal_chengshangqixia_chip_loosen": bool(signal_context.get("chengshangqixia_chip_loosen", False)),
            "signal_chengshangqixia_position_ok": bool(signal_context.get("chengshangqixia_position_ok", False)),
            "signal_chengshangqixia_score": bool(signal_context.get("chengshangqixia_score", False)),
        }

    @classmethod
    def _day_feature_snapshot(cls, day_context: dict[str, Any], *, close: float) -> dict[str, Any]:
        amount = cls._safe_float(day_context.get("amount", 0.0))
        volume = cls._safe_float(day_context.get("volume", 0.0))
        amount_base_hsm = cls._safe_float(day_context.get("amount_base_hsm", 0.0))
        amount_q95 = cls._safe_float(day_context.get("amount_q95", 0.0))
        pressure_price = cls._safe_float(day_context.get("pressure_price", 0.0))
        release_price = cls._safe_float(day_context.get("release_price", 0.0))
        anchored_vwap = cls._safe_float(day_context.get("anchored_vwap", 0.0))
        ma20 = cls._safe_float(day_context.get("ma20", 0.0))
        ma60 = cls._safe_float(day_context.get("ma60", 0.0))
        return {
            "day_theme_label": str(day_context.get("theme_label", "")),
            "day_peer_confirmation": int(day_context.get("peer_confirmation", 0) or 0),
            "day_leader_strength": int(day_context.get("leader_strength", 0) or 0),
            "day_sector_hot": bool(day_context.get("sector_hot", False)),
            "day_lhb_net_sell": bool(day_context.get("lhb_net_sell", False)),
            "day_is_limit_up_close": bool(day_context.get("is_limit_up_close", False)),
            "day_touch_limit_up": bool(day_context.get("touch_limit_up", False)),
            "day_is_failed_board": bool(day_context.get("is_failed_board", False)),
            "day_is_amount_confirm": bool(day_context.get("is_amount_confirm", False)),
            "day_is_amount_explosive": bool(day_context.get("is_amount_explosive", False)),
            "day_is_amount_outlier": bool(day_context.get("is_amount_outlier", False)),
            "day_near_peak_pressure": bool(day_context.get("near_peak_pressure", False)),
            "day_near_release_support": bool(day_context.get("near_release_support", False)),
            "day_two_side_active": bool(day_context.get("two_side_active", False)),
            "day_consolidation_ok": bool(day_context.get("consolidation_ok", False)),
            "day_trend_up": bool(day_context.get("trend_up", False)),
            "day_three_gun_pattern": str(day_context.get("three_gun_pattern", "")),
            "day_current_spear_role": str(day_context.get("current_spear_role", "")),
            "day_amount": round(amount, 4),
            "day_volume": round(volume, 4),
            "day_amount_rank": round(cls._safe_float(day_context.get("amount_rank", 0.0)), 6),
            "day_amount_z": round(cls._safe_float(day_context.get("amount_z", 0.0)), 6),
            "day_amount_base_hsm": round(amount_base_hsm, 4),
            "day_amount_q95": round(amount_q95, 4),
            "day_amount_vs_hsm": round(amount / amount_base_hsm, 6) if amount_base_hsm > 0 else 0.0,
            "day_amount_vs_q95": round(amount / amount_q95, 6) if amount_q95 > 0 else 0.0,
            "day_amount_vs_prev5_med": round(cls._safe_float(day_context.get("amount_vs_prev5_med", 0.0)), 6),
            "day_amount_vs_prev10_med": round(cls._safe_float(day_context.get("amount_vs_prev10_med", 0.0)), 6),
            "day_amount_vs_prev20_med": round(cls._safe_float(day_context.get("amount_vs_prev20_med", 0.0)), 6),
            "day_volume_vs_prev5_med": round(cls._safe_float(day_context.get("volume_vs_prev5_med", 0.0)), 6),
            "day_volume_vs_prev10_med": round(cls._safe_float(day_context.get("volume_vs_prev10_med", 0.0)), 6),
            "day_volume_vs_prev20_med": round(cls._safe_float(day_context.get("volume_vs_prev20_med", 0.0)), 6),
            "day_amp_pct": round(cls._safe_float(day_context.get("amp_pct", 0.0)), 6),
            "day_close_pos": round(cls._safe_float(day_context.get("close_pos", 0.0)), 6),
            "day_upper_shadow_pct": round(cls._safe_float(day_context.get("upper_shadow_pct", 0.0)), 6),
            "day_range_position_120": round(cls._safe_float(day_context.get("range_position_120", 0.0)), 6),
            "day_pressure_price": round(pressure_price, 4),
            "day_release_price": round(release_price, 4),
            "day_anchored_vwap": round(anchored_vwap, 4),
            "day_ma20": round(ma20, 4),
            "day_ma60": round(ma60, 4),
            "day_event_dense_mid": round(cls._safe_float(day_context.get("event_dense_mid", 0.0)), 4),
            "day_atr_20d_pct": round(cls._safe_float(day_context.get("atr_20d_pct", 0.0)), 6),
            "day_vol60_iqr_norm": round(cls._safe_float(day_context.get("vol60_iqr_norm", 0.0)), 6),
            "day_vol_elevation": round(cls._safe_float(day_context.get("vol_elevation", 0.0)), 6),
            "day_zhang_ratio_10": round(cls._safe_float(day_context.get("zhang_ratio_10", 0.0)), 6),
            "day_xu_ratio_10": round(cls._safe_float(day_context.get("xu_ratio_10", 0.0)), 6),
            "day_han_ratio_10": round(cls._safe_float(day_context.get("han_ratio_10", 0.0)), 6),
            "day_zhangyang_recent_vol_ratio_10": round(cls._safe_float(day_context.get("zhangyang_recent_vol_ratio_10", 0.0)), 6),
            "day_zhangyang_recent_price_gain_10": round(cls._safe_float(day_context.get("zhangyang_recent_price_gain_10", 0.0)), 6),
            "day_zhangyang_zhang_ok": bool(day_context.get("zhangyang_zhang_ok", False)),
            "day_zhangyang_xu_ok": bool(day_context.get("zhangyang_xu_ok", False)),
            "day_zhangyang_han_ok": bool(day_context.get("zhangyang_han_ok", False)),
            "day_zhangyang_explosive_recent": bool(day_context.get("zhangyang_explosive_recent", False)),
            "day_zhangyang_vol_price_divergence": bool(day_context.get("zhangyang_vol_price_divergence", False)),
            "day_zhangyang_hanshu_score": bool(day_context.get("zhangyang_hanshu_score", False)),
            "day_chengshangqixia_chip_loosen": bool(day_context.get("chengshangqixia_chip_loosen", False)),
            "day_chengshangqixia_position_ok": bool(day_context.get("chengshangqixia_position_ok", False)),
            "day_chengshangqixia_score": bool(day_context.get("chengshangqixia_score", False)),
            "day_chengshangqixia_pressure_touch_pct": round(cls._safe_float(day_context.get("chengshangqixia_pressure_touch_pct", 0.0)), 6),
            "day_chengshangqixia_release_touch_pct": round(cls._safe_float(day_context.get("chengshangqixia_release_touch_pct", 0.0)), 6),
            "day_close_vs_ma20_pct": round(close / ma20 - 1.0, 6) if ma20 > 0 else 0.0,
            "day_close_vs_ma60_pct": round(close / ma60 - 1.0, 6) if ma60 > 0 else 0.0,
            "day_close_vs_anchored_vwap_pct": round(close / anchored_vwap - 1.0, 6) if anchored_vwap > 0 else 0.0,
            "day_close_vs_pressure_pct": round(close / pressure_price - 1.0, 6) if pressure_price > 0 else 0.0,
            "day_close_vs_release_pct": round(close / release_price - 1.0, 6) if release_price > 0 else 0.0,
        }

    def _event_meta(self, event: SignalEventV2, *, pos_mult: float, order_type: str) -> dict[str, Any]:
        meta = {
            "style": str(event.entry_plan.get("style", "")),
            "exit_style": str(event.exit_plan.get("style", "default")),
            "position_mult": pos_mult,
            "order_type": order_type,
            "execution_profile": self.execution_profile,
            "signal_date": str(event.ts)[:10],
            "signal_event_type": str(event.event_type),
            "signal_confidence": round(float(event.confidence), 4),
            "signal_side": str(event.side),
            "signal_context": dict(event.context),
            "entry_plan": dict(event.entry_plan),
            "exit_plan": dict(event.exit_plan),
            "invalidation": dict(event.invalidation),
        }
        meta.update(self._signal_feature_snapshot(
            signal_context=dict(event.context),
            entry_plan=dict(event.entry_plan),
            exit_plan=dict(event.exit_plan),
            invalidation=dict(event.invalidation),
        ))
        return meta

    def _trend_mode_should_activate(self, pos: PositionState) -> bool:
        if not self.trend_spear_trend_management_enabled:
            return False
        if pos.source_event != "trend_spear" or pos.exit_style != "trend_hold":
            return False
        if pos.trend_mode_active:
            return True
        return bool(pos.had_limit_up_close or pos.peak_ret >= self.trend_spear_trend_activation_ret)

    def _maybe_activate_trend_mode(self, pos: PositionState, *, date: str) -> None:
        if not self._trend_mode_should_activate(pos):
            return
        if pos.trend_mode_active:
            return
        pos.trend_mode_active = True
        pos.trend_mode_activation_date = date
        self._trace(
            "trend_mode_activated",
            date=date,
            symbol=pos.symbol,
            source_event=pos.source_event,
            peak_ret=round(float(pos.peak_ret), 6),
            had_limit_up_close=bool(pos.had_limit_up_close),
            limit_up_close_days=int(pos.limit_up_close_days),
        )

    def _apply_dynamic_hold_management(
        self,
        pos: PositionState,
        *,
        holding_days: int,
        d_idx: int,
        day_context: dict[str, Any],
    ) -> None:
        """Dynamically adjust hold days and stop for trend_hold positions."""
        if pos.atr_at_entry == 0.0:
            ctx_atr = float(day_context.get("atr_20d_pct", 0.0))
            if ctx_atr > 0:
                pos.atr_at_entry = pos.entry_price * ctx_atr

        if bool(day_context.get("is_limit_up_close", False)):
            pos.board_count += 1
            pos.last_board_idx = d_idx
            pos.max_hold_days = max(pos.max_hold_days, self.trend_spear_limitup_extend_days)
            if pos.atr_at_entry > 0:
                wide_stop = pos.entry_price - self.trend_spear_limitup_wide_atr_mult * pos.atr_at_entry
                floor_stop = pos.entry_price * self.trend_spear_limitup_stop_floor_pct
                pos.stop_price = min(pos.stop_price, max(wide_stop, floor_stop))

        if (pos.board_count == 0
                and holding_days >= self.trend_spear_noboard_tighten_days
                and pos.atr_at_entry > 0):
            tight_stop = pos.entry_price - self.trend_spear_noboard_tight_atr_mult * pos.atr_at_entry
            pos.stop_price = max(pos.stop_price, tight_stop)
            pos.max_hold_days = min(pos.max_hold_days, self.trend_spear_noboard_max_hold)

    def _trend_management_exit_reason(
        self,
        pos: PositionState,
        *,
        holding_days: int,
        day_context: dict[str, Any],
    ) -> str | None:
        if not pos.trend_mode_active:
            return None
        close_vs_ma20 = self._safe_float(day_context.get("close_vs_ma20_pct", 0.0))
        close_vs_release = self._safe_float(day_context.get("close_vs_release_pct", 0.0))
        close_pos = self._safe_float(day_context.get("close_pos", 0.0))
        upper_shadow = self._safe_float(day_context.get("upper_shadow_pct", 0.0))
        near_pressure = bool(day_context.get("near_peak_pressure", False))
        explosive = bool(day_context.get("is_amount_explosive", False))
        stale = pos.days_since_peak >= self.trend_spear_trend_stale_days
        if pos.drawdown_from_peak >= self.trend_spear_trend_drawdown_exit:
            if close_vs_ma20 <= 0.0 or stale or close_pos <= 0.45:
                return "trend_drawdown_exit"
        if stale and close_vs_ma20 <= 0.0 and close_vs_release < 0.0:
            return "trend_stale_exit"
        if near_pressure and explosive and upper_shadow >= 0.30 and close_pos <= 0.45:
            return "trend_exhaustion_exit"
        if holding_days >= pos.max_hold_days + self.trend_spear_trend_max_extension_days and close_vs_ma20 <= 0.0:
            return "trend_timeout_exit"
        return None

    def _should_queue_reentry_watch(self, pos: PositionState, day_context: dict[str, Any]) -> bool:
        if not self.trend_spear_reentry_watch_enabled:
            return False
        if pos.source_event != "trend_spear":
            return False
        if pos.reentry_count > 0:
            return False
        if pos.near_pressure_days < self.trend_spear_reentry_min_near_pressure_days:
            return False
        if pos.near_support_days < self.trend_spear_reentry_min_near_support_days:
            return False
        amount_shrink = self._safe_float(day_context.get("amount_vs_prev20_med", 0.0))
        volume_shrink = self._safe_float(day_context.get("volume_vs_prev20_med", 0.0))
        if amount_shrink <= 0.0 and volume_shrink <= 0.0:
            return False
        return (
            amount_shrink <= self.trend_spear_reentry_shrink_threshold
            or volume_shrink <= self.trend_spear_reentry_shrink_threshold
        )

    def _queue_reentry_watch(
        self,
        *,
        pos: PositionState,
        date: str,
        d_idx: int,
        low: float,
        day_context: dict[str, Any],
    ) -> None:
        trigger_price = float(pos.stop_price)
        watch = PendingReentry(
            symbol=pos.symbol,
            created_idx=d_idx,
            valid_from_idx=d_idx + 1,
            valid_until_idx=d_idx + self.trend_spear_reentry_watch_days,
            trigger_price=trigger_price,
            invalidate_price=min(float(low), float(pos.stop_price) * 0.995),
            source_event=pos.source_event,
            confidence=max(0.55, float(pos.signal_confidence)),
            stop_price=float(pos.stop_price),
            stop_day_low=float(low),
            stop_amount_vs_prev20_med=self._safe_float(day_context.get("amount_vs_prev20_med", 0.0)),
            stop_volume_vs_prev20_med=self._safe_float(day_context.get("volume_vs_prev20_med", 0.0)),
            near_pressure_days=int(pos.near_pressure_days),
            near_support_days=int(pos.near_support_days),
            reentry_count=int(pos.reentry_count) + 1,
            signal_date=pos.signal_date,
            signal_context={
                **dict(pos.signal_context),
                "reentry_count": int(pos.reentry_count) + 1,
                "reentry_origin_signal_date": pos.signal_date,
                "reentry_watch_date": date,
                "reentry_from_stop": True,
                "reentry_prior_peak_ret": round(float(pos.peak_ret), 6),
                "reentry_prior_drawdown_from_peak": round(float(pos.drawdown_from_peak), 6),
            },
            entry_plan_meta={**dict(pos.entry_plan_meta), "style": "reentry_watch", "gate_price": round(trigger_price, 4), "valid_for_days": self.trend_spear_reentry_watch_days},
            exit_plan_meta=dict(pos.exit_plan_meta),
            invalidation_meta={"type": "reentry_failed", "price": round(min(float(low), float(pos.stop_price) * 0.995), 4)},
        )
        self.pending_reentries[pos.symbol] = watch
        self._trace(
            "reentry_watch_queued",
            date=date,
            symbol=pos.symbol,
            source_event=pos.source_event,
            trigger_price=round(trigger_price, 4),
            valid_until_idx=watch.valid_until_idx,
            stop_amount_vs_prev20_med=round(watch.stop_amount_vs_prev20_med, 6),
            stop_volume_vs_prev20_med=round(watch.stop_volume_vs_prev20_med, 6),
            near_pressure_days=int(pos.near_pressure_days),
            near_support_days=int(pos.near_support_days),
        )

    def _can_open_reentry(self) -> bool:
        return len(self.positions) < self.max_positions

    def _try_reentry(self, *, date: str, d_idx: int, symbol: str, open_price: float, high: float, close: float, cash: float, day_context: dict[str, Any]) -> Decision | None:
        watch = self.pending_reentries.get(symbol)
        if watch is None:
            return None
        if d_idx > watch.valid_until_idx:
            self.pending_reentries.pop(symbol, None)
            self._trace("reentry_watch_expired", date=date, symbol=symbol, source_event=watch.source_event, trigger_price=watch.trigger_price)
            return None
        if d_idx < watch.valid_from_idx or not self._can_open_reentry():
            return None
        expand_amount = self._safe_float(day_context.get("amount_vs_prev20_med", 0.0))
        expand_volume = self._safe_float(day_context.get("volume_vs_prev20_med", 0.0))
        expansion_ok = (
            expand_amount >= self.trend_spear_reentry_expand_threshold
            or expand_volume >= self.trend_spear_reentry_expand_threshold
        )
        reclaim_ok = close >= watch.trigger_price
        if not (reclaim_ok and expansion_ok):
            return None
        event = SignalEventV2(
            event_type=watch.source_event,
            symbol=symbol,
            ts=date,
            confidence=min(0.95, round(max(watch.confidence, 0.68) + 0.04, 3)),
            side="long",
            entry_plan=dict(watch.entry_plan_meta) or {"style": watch.entry_style, "gate_price": watch.trigger_price, "valid_for_days": self.trend_spear_reentry_watch_days},
            invalidation=dict(watch.invalidation_meta) or {"type": "reentry_failed", "price": watch.invalidate_price},
            exit_plan=dict(watch.exit_plan_meta) or {"style": "trend_hold", "hold_days": 8, "take_profit_pct": self.default_take_profit_pct},
            context={
                **dict(watch.signal_context),
                "reentry_trigger_date": date,
                "reentry_trigger_price": round(watch.trigger_price, 4),
                "reentry_trigger_amount_vs_prev20_med": round(expand_amount, 6),
                "reentry_trigger_volume_vs_prev20_med": round(expand_volume, 6),
            },
        )
        self.pending_reentries.pop(symbol, None)
        self._trace(
            "reentry_watch_triggered",
            date=date,
            symbol=symbol,
            source_event=watch.source_event,
            trigger_price=round(watch.trigger_price, 4),
            close_price=round(float(close), 4),
            amount_vs_prev20_med=round(expand_amount, 6),
            volume_vs_prev20_med=round(expand_volume, 6),
        )
        sizing_price = max(close, watch.trigger_price)
        if self._is_realistic():
            return self._queue_buy_next_open(d_idx=d_idx, symbol=symbol, cash=cash, sizing_price=sizing_price, event=event)
        if self._is_hunt():
            return self._queue_hunt(d_idx=d_idx, date=date, symbol=symbol, cash=cash, target_price=sizing_price, event=event)
        return self._buy_now(date, d_idx, symbol, sizing_price, cash, event)

    def _update_position_observability(
        self,
        pos: PositionState,
        *,
        date: str,
        high: float,
        low: float,
        close: float,
        day_context: dict[str, Any],
    ) -> None:
        if pos.peak_price <= 0.0:
            pos.peak_price = pos.entry_price
            pos.peak_ret = 0.0
            pos.peak_date = pos.entry_date
        if pos.trough_price <= 0.0:
            pos.trough_price = pos.entry_price
            pos.trough_ret = 0.0
            pos.trough_date = pos.entry_date
        if high >= pos.peak_price:
            pos.peak_price = high
            pos.peak_ret = self._ret_from_price(high, pos.entry_price)
            pos.peak_date = date
            pos.days_since_peak = 0
        else:
            pos.days_since_peak += 1
        if low <= pos.trough_price:
            pos.trough_price = low
            pos.trough_ret = self._ret_from_price(low, pos.entry_price)
            pos.trough_date = date
        close_ret = self._ret_from_price(close, pos.entry_price)
        pos.drawdown_from_peak = max(0.0, pos.peak_ret - close_ret)
        if bool(day_context.get("is_limit_up_close", False)):
            pos.had_limit_up_close = True
            pos.limit_up_close_days += 1
        if bool(day_context.get("near_peak_pressure", False)):
            pos.near_pressure_days += 1
        if bool(day_context.get("near_release_support", False)):
            pos.near_support_days += 1
        if bool(day_context.get("is_amount_explosive", False)):
            pos.amount_explosive_days += 1
        if self._safe_float(day_context.get("close_vs_ma20_pct", 0.0)) > 0.0:
            pos.above_ma20_days += 1
        if self._safe_float(day_context.get("close_vs_anchored_vwap_pct", 0.0)) > 0.0:
            pos.above_vwap_days += 1
        if self._safe_float(day_context.get("close_pos", 0.0)) >= 0.70:
            pos.close_pos_high_days += 1
        self._maybe_activate_trend_mode(pos, date=date)

    def _position_snapshot(
        self,
        pos: PositionState,
        *,
        date: str,
        holding_days: int,
        open_price: float,
        high: float,
        low: float,
        close: float,
        day_context: dict[str, Any],
    ) -> dict[str, Any]:
        close_ret = self._ret_from_price(close, pos.entry_price)
        low_ret = self._ret_from_price(low, pos.entry_price)
        high_ret = self._ret_from_price(high, pos.entry_price)
        base = {
            "date": date,
            "symbol": pos.symbol,
            "source_event": pos.source_event,
            "signal_event_type": pos.source_event,
            "signal_date": pos.signal_date,
            "signal_confidence": round(float(pos.signal_confidence), 4),
            "entry_date": pos.entry_date,
            "entry_style": pos.entry_style,
            "holding_days": holding_days,
            "entry_price": round(float(pos.entry_price), 4),
            "open_price": round(float(open_price), 4),
            "high_price": round(float(high), 4),
            "low_price": round(float(low), 4),
            "close_price": round(float(close), 4),
            "stop_price": round(float(pos.stop_price), 4),
            "take_price": round(float(pos.take_price), 4),
            "close_ret": round(close_ret, 6),
            "high_ret": round(high_ret, 6),
            "low_ret": round(low_ret, 6),
            "peak_price": round(float(pos.peak_price), 4),
            "peak_ret": round(float(pos.peak_ret), 6),
            "peak_date": pos.peak_date,
            "trough_price": round(float(pos.trough_price), 4),
            "trough_ret": round(float(pos.trough_ret), 6),
            "trough_date": pos.trough_date,
            "drawdown_from_peak": round(float(pos.drawdown_from_peak), 6),
            "days_since_peak": int(pos.days_since_peak),
            "intraday_drawdown_from_peak": round(max(0.0, float(pos.peak_ret) - low_ret), 6),
            "had_limit_up_close": bool(pos.had_limit_up_close),
            "limit_up_close_days": int(pos.limit_up_close_days),
            "near_pressure_days": int(pos.near_pressure_days),
            "near_support_days": int(pos.near_support_days),
            "amount_explosive_days": int(pos.amount_explosive_days),
            "above_ma20_days": int(pos.above_ma20_days),
            "above_vwap_days": int(pos.above_vwap_days),
            "close_pos_high_days": int(pos.close_pos_high_days),
            "trend_mode_active": bool(pos.trend_mode_active),
            "trend_mode_activation_date": pos.trend_mode_activation_date,
            "reentry_count": int(pos.reentry_count),
            "close_vs_stop_pct": round(close / float(pos.stop_price) - 1.0, 6) if pos.stop_price > 0 else 0.0,
            "low_vs_stop_pct": round(low / float(pos.stop_price) - 1.0, 6) if pos.stop_price > 0 else 0.0,
            "high_vs_take_pct": round(high / float(pos.take_price) - 1.0, 6) if pos.take_price > 0 else 0.0,
        }
        base.update(self._signal_feature_snapshot(
            signal_context=pos.signal_context,
            entry_plan=pos.entry_plan_meta,
            exit_plan=pos.exit_plan_meta,
            invalidation=pos.invalidation_meta,
        ))
        base.update(self._day_feature_snapshot(day_context, close=close))
        return base

    def _sell_meta(
        self,
        pos: PositionState,
        *,
        reason: str,
        date: str,
        holding_days: int,
        open_price: float,
        high: float,
        low: float,
        close: float,
        day_context: dict[str, Any],
        order_type: str,
    ) -> dict[str, Any]:
        meta = {
            "style": "",
            "exit_style": pos.exit_style,
            "position_mult": self.position_multipliers.get(pos.source_event, 1.0),
            "order_type": order_type,
            "execution_profile": self.execution_profile,
            "decision_date": date,
            "reason": reason,
        }
        meta.update(self._position_snapshot(
            pos,
            date=date,
            holding_days=holding_days,
            open_price=open_price,
            high=high,
            low=low,
            close=close,
            day_context=day_context,
        ))
        return meta

    def _stop_triggered(self, pos: PositionState, *, holding_days: int, low: float, close: float) -> bool:
        if pos.source_event != "trend_spear":
            return low <= pos.stop_price
        if self.trend_spear_stop_mode == "close_confirm":
            return close <= pos.stop_price
        if self.trend_spear_stop_mode == "grace_close":
            if holding_days <= self.trend_spear_stop_grace_days:
                return close <= pos.stop_price
            return low <= pos.stop_price
        return low <= pos.stop_price

    def _buy_now(self, date: str, d_idx: int, symbol: str, price: float, cash: float, event: SignalEventV2) -> Decision | None:
        pos_mult = self._position_multiplier(event)
        base = self._sizing_base(cash, getattr(self, "_current_equity", None))
        budget = min(base * self.base_pos_pct * pos_mult, cash)
        qty = (int(budget // price) + 99) // 100 * 100
        if qty <= 0:
            return None
        stop_price = float(event.invalidation.get("price", price * 0.94))
        take_profit_pct = float(event.exit_plan.get("take_profit_pct", self.default_take_profit_pct))
        max_hold_days = int(event.exit_plan.get("hold_days", 5))
        exit_style = str(event.exit_plan.get("style", "default"))
        entry_style = str(event.entry_plan.get("style", ""))
        signal_date = str(event.ts)[:10]
        self.pending_reentries.pop(symbol, None)
        self.positions[symbol] = PositionState(
            symbol=symbol,
            entry_date=date,
            entry_idx=d_idx,
            entry_price=price,
            qty=qty,
            source_event=event.event_type,
            stop_price=stop_price,
            take_price=price * (1.0 + take_profit_pct),
            max_hold_days=max_hold_days,
            exit_style=exit_style,
            signal_date=signal_date,
            signal_confidence=float(event.confidence),
            entry_style=entry_style,
            peak_price=price,
            peak_date=date,
            trough_price=price,
            trough_date=date,
            days_since_peak=0,
            reentry_count=int(event.context.get("reentry_count", 0) or 0),
            signal_context=dict(event.context),
            entry_plan_meta=dict(event.entry_plan),
            exit_plan_meta=dict(event.exit_plan),
            invalidation_meta=dict(event.invalidation),
        )
        self._trace(
            "position_opened",
            date=date,
            symbol=symbol,
            source_event=event.event_type,
            signal_date=signal_date,
            signal_confidence=round(float(event.confidence), 4),
            entry_style=entry_style,
            entry_price=round(float(price), 4),
            qty=round(float(qty), 2),
            order_type="market",
            **self._signal_feature_snapshot(
                signal_context=dict(event.context),
                entry_plan=dict(event.entry_plan),
                exit_plan=dict(event.exit_plan),
                invalidation=dict(event.invalidation),
            ),
        )
        return Decision(
            "buy",
            symbol,
            price,
            qty,
            f"entry:{event.event_type}",
            self._event_meta(event, pos_mult=pos_mult, order_type="market"),
        )

    def _queue_buy_next_open(
        self,
        *,
        d_idx: int,
        symbol: str,
        cash: float,
        sizing_price: float,
        event: SignalEventV2,
    ) -> Decision | None:
        pos_mult = self._position_multiplier(event)
        base = self._sizing_base(cash, getattr(self, "_current_equity", None))
        budget = min(base * self.base_pos_pct * pos_mult, cash)
        qty = (int(budget // max(sizing_price, 0.01)) + 99) // 100 * 100
        if qty <= 0:
            return None
        stop_price = float(event.invalidation.get("price", sizing_price * 0.94))
        take_profit_pct = float(event.exit_plan.get("take_profit_pct", self.default_take_profit_pct))
        max_hold_days = int(event.exit_plan.get("hold_days", 5))
        exit_style = str(event.exit_plan.get("style", "default"))
        signal_date = str(event.ts)[:10]
        self.pending_fills[symbol] = PendingFill(
            action="buy",
            symbol=symbol,
            execute_idx=d_idx + 1,
            qty=qty,
            source_event=event.event_type,
            entry_style=str(event.entry_plan.get("style", "")),
            invalidate_price=stop_price,
            max_hold_days=max_hold_days,
            take_profit_pct=take_profit_pct,
            exit_style=exit_style,
            position_mult=pos_mult,
            signal_date=signal_date,
            signal_confidence=float(event.confidence),
            decision_date=signal_date,
            signal_context=dict(event.context),
            entry_plan_meta=dict(event.entry_plan),
            exit_plan_meta=dict(event.exit_plan),
            invalidation_meta=dict(event.invalidation),
        )
        return Decision(
            "buy",
            symbol,
            None,
            qty,
            f"entry:{event.event_type}",
            self._event_meta(event, pos_mult=pos_mult, order_type="market"),
        )

    def _queue_hunt(
        self,
        *,
        d_idx: int,
        date: str,
        symbol: str,
        cash: float,
        target_price: float,
        event: SignalEventV2,
    ) -> Decision | None:
        pos_mult = self._position_multiplier(event)
        base = self._sizing_base(cash, getattr(self, "_current_equity", None))
        budget = min(base * self.base_pos_pct * pos_mult, cash)
        qty = (int(budget // max(target_price, 0.01)) + 99) // 100 * 100
        if qty <= 0:
            return None
        stop_price = float(event.invalidation.get("price", target_price * 0.94))
        take_profit_pct = float(event.exit_plan.get("take_profit_pct", self.default_take_profit_pct))
        max_hold_days = int(event.exit_plan.get("hold_days", 5))
        exit_style = str(event.exit_plan.get("style", "default"))
        signal_date = str(event.ts)[:10]
        existing = self.pending_hunts.get(symbol)
        if existing is not None:
            self._trace(
                "hunt_overwritten",
                date=date,
                symbol=symbol,
                old_source_event=existing.source_event,
                old_target_price=existing.target_price,
                new_source_event=event.event_type,
                new_target_price=target_price,
            )
        self.pending_hunts[symbol] = PendingHunt(
            symbol=symbol,
            created_idx=d_idx,
            valid_from_idx=d_idx + 1,
            valid_until_idx=d_idx + max(1, self.hunt_window_days),
            target_price=target_price,
            buffer_pct=self.hunt_price_buffer_pct,
            source_event=event.event_type,
            confidence=float(event.confidence),
            invalidate_price=stop_price,
            max_hold_days=max_hold_days,
            take_profit_pct=take_profit_pct,
            exit_style=exit_style,
            signal_date=signal_date,
            entry_style=str(event.entry_plan.get("style", "")),
            qty=qty,
            position_mult=pos_mult,
            signal_context=dict(event.context),
            entry_plan_meta=dict(event.entry_plan),
            exit_plan_meta=dict(event.exit_plan),
            invalidation_meta=dict(event.invalidation),
        )
        self._trace(
            "hunt_queued",
            date=date,
            symbol=symbol,
            source_event=event.event_type,
            signal_date=signal_date,
            target_price=target_price,
            valid_from_idx=d_idx + 1,
            valid_until_idx=d_idx + max(1, self.hunt_window_days),
            buffer_pct=self.hunt_price_buffer_pct,
            exit_style=exit_style,
            **self._signal_feature_snapshot(
                signal_context=dict(event.context),
                entry_plan=dict(event.entry_plan),
                exit_plan=dict(event.exit_plan),
                invalidation=dict(event.invalidation),
            ),
        )
        return None

    def _queue_sell_next_open(
        self,
        *,
        d_idx: int,
        symbol: str,
        pos: PositionState,
        reason: str,
        decision_date: str = "",
        decision_meta: dict[str, Any] | None = None,
    ) -> Decision:
        self.pending_fills[symbol] = PendingFill(
            action="sell",
            symbol=symbol,
            execute_idx=d_idx + 1,
            qty=float(pos.qty),
            source_event=pos.source_event,
            exit_style=pos.exit_style,
            signal_date=pos.signal_date,
            signal_confidence=pos.signal_confidence,
            decision_date=decision_date,
            decision_meta=decision_meta or {},
        )
        return Decision(
            "sell",
            symbol,
            None,
            pos.qty,
            reason,
            decision_meta or {
                "style": "",
                "exit_style": pos.exit_style,
                "position_mult": self.position_multipliers.get(pos.source_event, 1.0),
                "order_type": "market",
                "execution_profile": self.execution_profile,
                "decision_date": decision_date,
                "signal_date": pos.signal_date,
            },
        )

    def _apply_pending_fill(self, *, date: str, d_idx: int, symbol: str, open_price: float) -> Decision | None:
        fill = self.pending_fills.get(symbol)
        if fill is None or fill.execute_idx != d_idx:
            return None
        self.pending_fills.pop(symbol, None)
        if fill.action == "buy":
            self.pending_reentries.pop(symbol, None)
            self.positions[symbol] = PositionState(
                symbol=symbol,
                entry_date=date,
                entry_idx=d_idx,
                entry_price=open_price,
                qty=fill.qty,
                source_event=fill.source_event,
                stop_price=fill.invalidate_price,
                take_price=open_price * (1.0 + fill.take_profit_pct),
                max_hold_days=fill.max_hold_days,
                exit_style=fill.exit_style,
                signal_date=fill.signal_date,
                signal_confidence=fill.signal_confidence,
                entry_style=fill.entry_style,
                peak_price=open_price,
                peak_date=date,
                trough_price=open_price,
                trough_date=date,
                days_since_peak=0,
                reentry_count=int(fill.signal_context.get("reentry_count", 0) or 0),
                signal_context=dict(fill.signal_context),
                entry_plan_meta=dict(fill.entry_plan_meta),
                exit_plan_meta=dict(fill.exit_plan_meta),
                invalidation_meta=dict(fill.invalidation_meta),
            )
            self._trace(
                "position_opened",
                date=date,
                symbol=symbol,
                source_event=fill.source_event,
                signal_date=fill.signal_date,
                signal_confidence=round(float(fill.signal_confidence), 4),
                entry_style=fill.entry_style,
                entry_price=round(float(open_price), 4),
                qty=round(float(fill.qty), 2),
                order_type="market",
                **self._signal_feature_snapshot(
                    signal_context=dict(fill.signal_context),
                    entry_plan=dict(fill.entry_plan_meta),
                    exit_plan=dict(fill.exit_plan_meta),
                    invalidation=dict(fill.invalidation_meta),
                ),
            )
            return Decision(
                "buy", symbol, open_price, fill.qty,
                f"entry:{fill.source_event}",
                {
                    "source_event": fill.source_event,
                    "signal_date": fill.signal_date,
                    "signal_confidence": fill.signal_confidence,
                    "entry_style": fill.entry_style,
                    "pos_mult": fill.position_mult,
                    "order_type": "market",
                },
            )
        pos = self.positions.get(symbol)
        qty = pos.qty if pos else fill.qty
        reason = fill.decision_meta.get("reason", fill.reason if hasattr(fill, "reason") else "")
        self._trace(
            "position_closed_pending_fill",
            date=date,
            symbol=symbol,
            source_event=fill.source_event,
            reason=reason,
            decision_date=fill.decision_date,
            signal_date=fill.signal_date,
        )
        self.positions.pop(symbol, None)
        self.cooldowns[symbol] = d_idx + self.cooldown_days
        return Decision(
            "sell", symbol, open_price, qty, reason,
            dict(fill.decision_meta),
        )

    def _queue_sell_hunt(
        self, *, d_idx: int, date: str, symbol: str, pos: PositionState,
        target_price: float, reason: str, decision_meta: dict[str, Any] | None = None,
    ) -> None:
        self.pending_sell_hunts[symbol] = PendingSellHunt(
            symbol=symbol,
            created_idx=d_idx,
            valid_from_idx=d_idx + 1,
            valid_until_idx=d_idx + max(1, self.exit_hunt_window_days),
            target_price=target_price,
            buffer_pct=self.exit_hunt_buffer_pct,
            qty=pos.qty,
            reason=reason,
            source_event=pos.source_event,
            exit_style=pos.exit_style,
            decision_date=date,
            decision_meta=decision_meta or {},
        )
        self._trace(
            "sell_hunt_queued", date=date, symbol=symbol,
            target_price=target_price, reason=reason,
            valid_until_idx=d_idx + max(1, self.exit_hunt_window_days),
        )

    def _try_sell_hunt_fill(
        self, *, date: str, d_idx: int, symbol: str,
        open_price: float, high: float, low: float,
    ) -> Decision | None:
        hunt = self.pending_sell_hunts.get(symbol)
        if hunt is None:
            return None
        if d_idx < hunt.valid_from_idx:
            return None
        if d_idx > hunt.valid_until_idx:
            self._trace("sell_hunt_expired", date=date, symbol=symbol,
                        target_price=hunt.target_price, reason=hunt.reason)
            self.pending_sell_hunts.pop(symbol, None)
            self.positions.pop(symbol, None)
            self.cooldowns[symbol] = d_idx + self.cooldown_days
            return Decision("sell", symbol, open_price, hunt.qty, f"{hunt.reason}_forced",
                            {
                                **hunt.decision_meta,
                                "exit_style": hunt.exit_style,
                                "order_type": "market_forced",
                                "decision_date": hunt.decision_date,
                            })
        threshold = hunt.target_price * (1.0 - hunt.buffer_pct)
        if high < threshold:
            return None
        if open_price >= threshold:
            fill_price = open_price
        else:
            fill_price = hunt.target_price
        self._trace("sell_hunt_filled", date=date, symbol=symbol,
                    target_price=hunt.target_price, fill_price=fill_price, reason=hunt.reason)
        self.pending_sell_hunts.pop(symbol, None)
        self.positions.pop(symbol, None)
        self.cooldowns[symbol] = d_idx + self.cooldown_days
        return Decision("sell", symbol, fill_price, hunt.qty, hunt.reason,
                        {
                            **hunt.decision_meta,
                            "exit_style": hunt.exit_style,
                            "order_type": "hunt_limit",
                            "decision_date": hunt.decision_date,
                        })

    def _try_hunt_fill(
        self,
        *,
        date: str,
        d_idx: int,
        symbol: str,
        high: float,
        low: float,
        cash: float,
    ) -> Decision | None:
        hunt = self.pending_hunts.get(symbol)
        if hunt is None:
            return None
        if d_idx < hunt.valid_from_idx:
            return None
        if d_idx > hunt.valid_until_idx:
            self._trace(
                "hunt_expired",
                date=date,
                symbol=symbol,
                source_event=hunt.source_event,
                target_price=hunt.target_price,
                expired_idx=d_idx,
            )
            self.pending_hunts.pop(symbol, None)
            return None
        lower = hunt.target_price * (1.0 - hunt.buffer_pct)
        upper = hunt.target_price * (1.0 + hunt.buffer_pct)
        if not self._can_open(symbol, d_idx):
            if high >= lower and low <= upper:
                hunt.last_blocked_date = date
            self._trace(
                "hunt_blocked_max_positions",
                date=date,
                symbol=symbol,
                source_event=hunt.source_event,
                positions=len(self.positions),
                in_trigger_zone=high >= lower and low <= upper,
            )
            return None
        if high < lower or low > upper:
            return None
        fill_price = min(max(hunt.target_price, low), high)
        base = self._sizing_base(cash, getattr(self, "_current_equity", None))
        budget = min(base * self.base_pos_pct * hunt.position_mult, cash)
        qty = (int(budget // fill_price) + 99) // 100 * 100
        if qty <= 0:
            self._trace(
                "hunt_skipped_no_budget",
                date=date,
                symbol=symbol,
                source_event=hunt.source_event,
                cash=round(cash, 2),
                fill_price=fill_price,
            )
            self.pending_hunts.pop(symbol, None)
            return None
        self.pending_hunts.pop(symbol, None)
        self._trace(
            "hunt_filled",
            date=date,
            symbol=symbol,
            source_event=hunt.source_event,
            signal_date=hunt.signal_date,
            target_price=hunt.target_price,
            fill_price=fill_price,
            qty=qty,
            budget=round(budget, 2),
            high=high,
            low=low,
            **self._signal_feature_snapshot(
                signal_context=dict(hunt.signal_context),
                entry_plan=dict(hunt.entry_plan_meta),
                exit_plan=dict(hunt.exit_plan_meta),
                invalidation=dict(hunt.invalidation_meta),
            ),
        )
        self.pending_reentries.pop(symbol, None)
        self.positions[symbol] = PositionState(
            symbol=symbol,
            entry_date=date,
            entry_idx=d_idx,
            entry_price=fill_price,
            qty=qty,
            source_event=hunt.source_event,
            stop_price=hunt.invalidate_price,
            take_price=fill_price * (1.0 + hunt.take_profit_pct),
            max_hold_days=hunt.max_hold_days,
            exit_style=hunt.exit_style,
            signal_date=hunt.signal_date,
            signal_confidence=hunt.confidence,
            entry_style=hunt.entry_style,
            peak_price=fill_price,
            peak_date=date,
            trough_price=fill_price,
            trough_date=date,
            days_since_peak=0,
            reentry_count=int(hunt.signal_context.get("reentry_count", 0) or 0),
            signal_context=dict(hunt.signal_context),
            entry_plan_meta=dict(hunt.entry_plan_meta),
            exit_plan_meta=dict(hunt.exit_plan_meta),
            invalidation_meta=dict(hunt.invalidation_meta),
        )
        return Decision(
            "buy",
            symbol,
            fill_price,
            qty,
            f"entry:{hunt.source_event}",
            {
                "style": hunt.entry_style,
                "exit_style": hunt.exit_style,
                "position_mult": hunt.position_mult,
                "execution_profile": self.execution_profile,
                "order_type": "hunt_limit",
                "signal_event_type": hunt.source_event,
                "signal_date": hunt.signal_date,
                "signal_confidence": round(float(hunt.confidence), 4),
                "signal_context": dict(hunt.signal_context),
                "entry_plan": dict(hunt.entry_plan_meta),
                "exit_plan": dict(hunt.exit_plan_meta),
                "invalidation": dict(hunt.invalidation_meta),
                "hunt_target_price": hunt.target_price,
                "hunt_buffer_pct": hunt.buffer_pct,
                **self._signal_feature_snapshot(
                    signal_context=dict(hunt.signal_context),
                    entry_plan=dict(hunt.entry_plan_meta),
                    exit_plan=dict(hunt.exit_plan_meta),
                    invalidation=dict(hunt.invalidation_meta),
                ),
            },
        )

    @staticmethod
    def _route_candidates(events: list[SignalEventV2]) -> tuple[list[SignalEventV2], list[SignalEventV2]]:
        cands = [e for e in events if e.side == "long" and e.confidence >= 0.6]
        tail = [e for e in cands if str(e.entry_plan.get("style", "")) == "tail_close"]
        breakout = [e for e in cands if str(e.entry_plan.get("style", "breakout")) == "breakout"]
        tail.sort(key=lambda x: (V4ExecutionStateMachine._route_score(x), str(x.event_type)), reverse=True)
        breakout.sort(key=lambda x: (V4ExecutionStateMachine._route_score(x), str(x.event_type)), reverse=True)
        return tail, breakout

    @staticmethod
    def _event_priority(event_type: str) -> float:
        priorities = {
            "post_limit": 0.10,
            "trend_spear": 0.08,
            "failed_board": 0.07,
            "youzi": 0.05,
            "sector_spear": 0.04,
            "attack": 0.01,
            "arb": 0.00,
        }
        return priorities.get(event_type, 0.0)

    @classmethod
    def _route_score(cls, event: SignalEventV2) -> float:
        style = str(event.entry_plan.get("style", "breakout"))
        style_bonus = 0.01 if style == "breakout" else 0.0
        return float(event.confidence) + cls._event_priority(str(event.event_type)) + style_bonus

    def _dedupe_pending(self, symbol: str) -> None:
        routes = list(self.pending_entries.get(symbol, []))
        deduped: list[PendingEntry] = []
        seen: set[tuple[str, float, str]] = set()
        for route in routes:
            key = (route.source_event, round(route.trigger_price, 3), route.entry_style)
            if key in seen:
                continue
            seen.add(key)
            deduped.append(route)
        deduped.sort(key=lambda x: (x.confidence, x.trigger_price), reverse=True)
        self.pending_entries[symbol] = deduped[:2]

    def _sizing_base(self, cash: float, equity: float | None) -> float:
        """Return the capital base for position sizing (cash or equity)."""
        if self.position_sizing_base == "equity" and equity is not None and equity > 0:
            return equity
        return cash

    def on_day(
        self,
        *,
        date: str,
        d_idx: int,
        symbol: str,
        open_price: float,
        close: float,
        high: float,
        low: float,
        limit_up: float | None = None,
        limit_down: float | None = None,
        events: list[SignalEventV2],
        cash: float,
        equity: float | None = None,
        day_context: dict | None = None,
    ) -> list[Decision]:
        self._current_equity = equity
        decisions: list[Decision] = []
        day_context = day_context or {}
        if self._is_realistic():
            fill_dec = self._apply_pending_fill(date=date, d_idx=d_idx, symbol=symbol, open_price=open_price)
            if fill_dec is not None:
                decisions.append(fill_dec)
                if fill_dec.action == "buy":
                    return decisions
        sell_hunt_active = symbol in self.pending_sell_hunts
        if sell_hunt_active:
            dec = self._try_sell_hunt_fill(date=date, d_idx=d_idx, symbol=symbol,
                                           open_price=open_price, high=high, low=low)
            if dec is not None:
                return [dec]
        pos = self.positions.get(symbol)
        if sell_hunt_active and pos is not None:
            if low <= pos.stop_price and (limit_down is None or can_sell_strict(pos.stop_price, limit_down)):
                self.pending_sell_hunts.pop(symbol, None)
                self._trace("sell_hunt_cancelled", date=date, symbol=symbol, reason="stop_loss_override")
                if self._should_queue_reentry_watch(pos, day_context):
                    self._queue_reentry_watch(pos=pos, date=date, d_idx=d_idx, low=low, day_context=day_context)
                decision_meta = self._sell_meta(
                    pos,
                    reason="stop_loss",
                    date=date,
                    holding_days=max(0, d_idx - pos.entry_idx),
                    open_price=open_price,
                    high=high,
                    low=low,
                    close=close,
                    day_context=day_context,
                    order_type="market",
                )
                decisions.append(self._queue_sell_next_open(
                    d_idx=d_idx,
                    symbol=symbol,
                    pos=pos,
                    reason="stop_loss",
                    decision_date=date,
                    decision_meta=decision_meta,
                ))
                return decisions
            if symbol in self.pending_sell_hunts:
                return decisions
        pending = list(self.pending_entries.get(symbol, []))
        queued_fill = self.pending_fills.get(symbol)
        if pos is None and self._is_hunt():
            dec = self._try_hunt_fill(date=date, d_idx=d_idx, symbol=symbol, high=high, low=low, cash=cash)
            if dec is not None:
                return [dec]
            if symbol in self.pending_hunts:
                return decisions
        if pos is None:
            dec = self._try_reentry(
                date=date,
                d_idx=d_idx,
                symbol=symbol,
                open_price=open_price,
                high=high,
                close=close,
                cash=cash,
                day_context=day_context,
            )
            if dec is not None:
                return [dec]

        if pos is not None:
            holding_days = d_idx - pos.entry_idx
            self._update_position_observability(
                pos,
                date=date,
                high=high,
                low=low,
                close=close,
                day_context=day_context,
            )
            if self.trend_spear_dynamic_hold_enabled and pos.exit_style == "trend_hold":
                self._apply_dynamic_hold_management(pos, holding_days=holding_days, d_idx=d_idx, day_context=day_context)
            snapshot = self._position_snapshot(
                pos,
                date=date,
                holding_days=holding_days,
                open_price=open_price,
                high=high,
                low=low,
                close=close,
                day_context=day_context,
            )
            self._trace("position_mark", **snapshot)

            if self._is_realistic() and queued_fill is not None and queued_fill.action == "sell":
                return decisions
            if self._stop_triggered(pos, holding_days=holding_days, low=low, close=close) and (limit_down is None or can_sell_strict(pos.stop_price, limit_down)):
                if self._should_queue_reentry_watch(pos, day_context):
                    self._queue_reentry_watch(pos=pos, date=date, d_idx=d_idx, low=low, day_context=day_context)
                decision_meta = self._sell_meta(
                    pos,
                    reason="stop_loss",
                    date=date,
                    holding_days=holding_days,
                    open_price=open_price,
                    high=high,
                    low=low,
                    close=close,
                    day_context=day_context,
                    order_type="market",
                )
                self._trace("exit_triggered", trigger_reason="stop_loss", **snapshot)
                if self._is_realistic():
                    decisions.append(self._queue_sell_next_open(
                        d_idx=d_idx,
                        symbol=symbol,
                        pos=pos,
                        reason="stop_loss",
                        decision_date=date,
                        decision_meta=decision_meta,
                    ))
                else:
                    decisions.append(Decision("sell", symbol, pos.stop_price, pos.qty, "stop_loss", decision_meta))
                    self.positions.pop(symbol, None)
                    self.cooldowns[symbol] = d_idx + self.cooldown_days
                return decisions
            if pos.exit_style not in {"trend_hold"} and high >= pos.take_price and (limit_down is None or can_sell_strict(pos.take_price, limit_down)):
                decision_meta = self._sell_meta(
                    pos,
                    reason="take_profit",
                    date=date,
                    holding_days=holding_days,
                    open_price=open_price,
                    high=high,
                    low=low,
                    close=close,
                    day_context=day_context,
                    order_type="market" if self.exit_mode != "hunt_exit" else "hunt_limit",
                )
                self._trace("exit_triggered", trigger_reason="take_profit", **snapshot)
                if self.exit_mode == "hunt_exit":
                    self._queue_sell_hunt(d_idx=d_idx, date=date, symbol=symbol, pos=pos,
                                         target_price=pos.take_price, reason="take_profit", decision_meta=decision_meta)
                elif self._is_realistic():
                    decisions.append(self._queue_sell_next_open(
                        d_idx=d_idx,
                        symbol=symbol,
                        pos=pos,
                        reason="take_profit",
                        decision_date=date,
                        decision_meta=decision_meta,
                    ))
                else:
                    decisions.append(Decision("sell", symbol, pos.take_price, pos.qty, "take_profit", decision_meta))
                    self.positions.pop(symbol, None)
                    self.cooldowns[symbol] = d_idx + self.cooldown_days
                return decisions
            if pos.exit_style == "tactical_arb" and holding_days >= 3 and close <= pos.entry_price * 1.01 and (limit_down is None or can_sell_strict(close, limit_down)):
                decision_meta = self._sell_meta(
                    pos,
                    reason="no_premium",
                    date=date,
                    holding_days=holding_days,
                    open_price=open_price,
                    high=high,
                    low=low,
                    close=close,
                    day_context=day_context,
                    order_type="market",
                )
                self._trace("exit_triggered", trigger_reason="no_premium", **snapshot)
                if self._is_realistic():
                    decisions.append(self._queue_sell_next_open(
                        d_idx=d_idx,
                        symbol=symbol,
                        pos=pos,
                        reason="no_premium",
                        decision_date=date,
                        decision_meta=decision_meta,
                    ))
                else:
                    decisions.append(Decision("sell", symbol, close, pos.qty, "no_premium", decision_meta))
                    self.positions.pop(symbol, None)
                    self.cooldowns[symbol] = d_idx + self.cooldown_days
                return decisions
            if pos.exit_style == "continuation" and holding_days >= 3 and close < pos.entry_price * 0.99 and (limit_down is None or can_sell_strict(close, limit_down)):
                decision_meta = self._sell_meta(
                    pos,
                    reason="failed_continuation",
                    date=date,
                    holding_days=holding_days,
                    open_price=open_price,
                    high=high,
                    low=low,
                    close=close,
                    day_context=day_context,
                    order_type="market",
                )
                self._trace("exit_triggered", trigger_reason="failed_continuation", **snapshot)
                if self._is_realistic():
                    decisions.append(self._queue_sell_next_open(
                        d_idx=d_idx,
                        symbol=symbol,
                        pos=pos,
                        reason="failed_continuation",
                        decision_date=date,
                        decision_meta=decision_meta,
                    ))
                else:
                    decisions.append(Decision("sell", symbol, close, pos.qty, "failed_continuation", decision_meta))
                    self.positions.pop(symbol, None)
                    self.cooldowns[symbol] = d_idx + self.cooldown_days
                return decisions
            if pos.exit_style in {"theme_burst", "sector_burst"} and holding_days >= 1:
                if (not bool(day_context.get("sector_hot", False))) and close < pos.entry_price and (limit_down is None or can_sell_strict(close, limit_down)):
                    decision_meta = self._sell_meta(
                        pos,
                        reason="theme_collapse",
                        date=date,
                        holding_days=holding_days,
                        open_price=open_price,
                        high=high,
                        low=low,
                        close=close,
                        day_context=day_context,
                        order_type="market",
                    )
                    self._trace("exit_triggered", trigger_reason="theme_collapse", **snapshot)
                    if self._is_realistic():
                        decisions.append(self._queue_sell_next_open(
                            d_idx=d_idx,
                            symbol=symbol,
                            pos=pos,
                            reason="theme_collapse",
                            decision_date=date,
                            decision_meta=decision_meta,
                        ))
                    else:
                        decisions.append(Decision("sell", symbol, close, pos.qty, "theme_collapse", decision_meta))
                        self.positions.pop(symbol, None)
                        self.cooldowns[symbol] = d_idx + self.cooldown_days
                    return decisions
            if pos.exit_style in {"swing_confirm", "rebalance_swing"} and holding_days >= 2 and close <= pos.stop_price * 1.01 and (limit_down is None or can_sell_strict(close, limit_down)):
                decision_meta = self._sell_meta(
                    pos,
                    reason="rebreak",
                    date=date,
                    holding_days=holding_days,
                    open_price=open_price,
                    high=high,
                    low=low,
                    close=close,
                    day_context=day_context,
                    order_type="market",
                )
                self._trace("exit_triggered", trigger_reason="rebreak", **snapshot)
                if self._is_realistic():
                    decisions.append(self._queue_sell_next_open(
                        d_idx=d_idx,
                        symbol=symbol,
                        pos=pos,
                        reason="rebreak",
                        decision_date=date,
                        decision_meta=decision_meta,
                    ))
                else:
                    decisions.append(Decision("sell", symbol, close, pos.qty, "rebreak", decision_meta))
                    self.positions.pop(symbol, None)
                    self.cooldowns[symbol] = d_idx + self.cooldown_days
                return decisions
            if (self.trend_spear_vol_exhaustion_exit
                    and pos.exit_style == "trend_hold" and pos.board_count > 0 and holding_days >= 2
                    and bool(day_context.get("is_amount_explosive", False)) and close < open_price
                    and (limit_down is None or can_sell_strict(close, limit_down))):
                decision_meta = self._sell_meta(
                    pos,
                    reason="vol_exhaustion",
                    date=date,
                    holding_days=holding_days,
                    open_price=open_price,
                    high=high,
                    low=low,
                    close=close,
                    day_context=day_context,
                    order_type="market",
                )
                self._trace("exit_triggered", trigger_reason="vol_exhaustion", **snapshot)
                if self._is_realistic():
                    decisions.append(self._queue_sell_next_open(
                        d_idx=d_idx,
                        symbol=symbol,
                        pos=pos,
                        reason="vol_exhaustion",
                        decision_date=date,
                        decision_meta=decision_meta,
                    ))
                else:
                    decisions.append(Decision("sell", symbol, close, pos.qty, "vol_exhaustion", decision_meta))
                    self.positions.pop(symbol, None)
                    self.cooldowns[symbol] = d_idx + self.cooldown_days
                return decisions
            trend_exit_reason = self._trend_management_exit_reason(pos, holding_days=holding_days, day_context=day_context)
            if trend_exit_reason is not None and (limit_down is None or can_sell_strict(close, limit_down)):
                decision_meta = self._sell_meta(
                    pos,
                    reason=trend_exit_reason,
                    date=date,
                    holding_days=holding_days,
                    open_price=open_price,
                    high=high,
                    low=low,
                    close=close,
                    day_context=day_context,
                    order_type="market",
                )
                self._trace("exit_triggered", trigger_reason=trend_exit_reason, **snapshot)
                if self._is_realistic():
                    decisions.append(self._queue_sell_next_open(
                        d_idx=d_idx,
                        symbol=symbol,
                        pos=pos,
                        reason=trend_exit_reason,
                        decision_date=date,
                        decision_meta=decision_meta,
                    ))
                else:
                    decisions.append(Decision("sell", symbol, close, pos.qty, trend_exit_reason, decision_meta))
                    self.positions.pop(symbol, None)
                    self.cooldowns[symbol] = d_idx + self.cooldown_days
                return decisions
            allow_time_exit = not pos.trend_mode_active
            if holding_days >= pos.max_hold_days and allow_time_exit and (limit_down is None or can_sell_strict(close, limit_down)):
                decision_meta = self._sell_meta(
                    pos,
                    reason="time_exit",
                    date=date,
                    holding_days=holding_days,
                    open_price=open_price,
                    high=high,
                    low=low,
                    close=close,
                    day_context=day_context,
                    order_type="market",
                )
                self._trace("exit_triggered", trigger_reason="time_exit", **snapshot)
                if self._is_realistic():
                    decisions.append(self._queue_sell_next_open(
                        d_idx=d_idx,
                        symbol=symbol,
                        pos=pos,
                        reason="time_exit",
                        decision_date=date,
                        decision_meta=decision_meta,
                    ))
                else:
                    decisions.append(Decision("sell", symbol, close, pos.qty, "time_exit", decision_meta))
                    self.positions.pop(symbol, None)
                    self.cooldowns[symbol] = d_idx + self.cooldown_days
                return decisions
            if any(e.event_type == "escape" for e in events) and (limit_down is None or can_sell_strict(close, limit_down)):
                decision_meta = self._sell_meta(
                    pos,
                    reason="escape_risk_off",
                    date=date,
                    holding_days=holding_days,
                    open_price=open_price,
                    high=high,
                    low=low,
                    close=close,
                    day_context=day_context,
                    order_type="market",
                )
                self._trace("exit_triggered", trigger_reason="escape_risk_off", **snapshot)
                if self._is_realistic():
                    decisions.append(self._queue_sell_next_open(
                        d_idx=d_idx,
                        symbol=symbol,
                        pos=pos,
                        reason="escape_risk_off",
                        decision_date=date,
                        decision_meta=decision_meta,
                    ))
                else:
                    decisions.append(Decision("sell", symbol, close, pos.qty, "escape_risk_off", decision_meta))
                    self.positions.pop(symbol, None)
                    self.cooldowns[symbol] = d_idx + self.cooldown_days
                return decisions
            return decisions

        if any(e.event_type == "escape" for e in events):
            if symbol in self.pending_hunts:
                hunt = self.pending_hunts[symbol]
                self._trace(
                    "hunt_cleared_escape",
                    date=date,
                    symbol=symbol,
                    source_event=hunt.source_event,
                    target_price=hunt.target_price,
                )
            self.pending_entries.pop(symbol, None)
            self.pending_hunts.pop(symbol, None)
            if symbol in self.pending_reentries:
                self._trace("reentry_watch_cleared_escape", date=date, symbol=symbol)
            self.pending_reentries.pop(symbol, None)
            return decisions

        if self._is_realistic() and queued_fill is not None and queued_fill.action == "buy":
            return decisions

        if pending:
            active_pending: list[PendingEntry] = []
            triggered: list[PendingEntry] = []
            for route in pending:
                if d_idx > route.valid_until_idx:
                    continue
                active_pending.append(route)
                if d_idx >= route.valid_from_idx and high >= route.trigger_price:
                    if self._can_open(symbol, d_idx):
                        triggered.append(route)
                    elif self._is_hunt():
                        self._trace(
                            "hunt_blocked_can_open_on_trigger",
                            date=date,
                            symbol=symbol,
                            source_event=route.source_event,
                            trigger_price=route.trigger_price,
                        )
            if triggered:
                route = sorted(triggered, key=lambda x: (x.confidence, x.trigger_price), reverse=True)[0]
                fill = max(open_price, route.trigger_price)
                if self._is_realistic():
                    event = SignalEventV2(
                        event_type=route.source_event,
                        symbol=symbol,
                        ts=route.signal_date or date,
                        confidence=route.confidence,
                        side="long",
                        entry_plan=dict(route.entry_plan_meta) or {"style": route.entry_style},
                        invalidation=dict(route.invalidation_meta) or {"price": route.invalidate_price},
                        exit_plan=dict(route.exit_plan_meta) or {"style": route.exit_style, "hold_days": route.max_hold_days, "take_profit_pct": route.take_profit_pct},
                        context=dict(route.signal_context),
                    )
                    dec = self._queue_buy_next_open(
                        d_idx=d_idx,
                        symbol=symbol,
                        cash=cash,
                        sizing_price=max(close, route.trigger_price),
                        event=event,
                    )
                elif self._is_hunt():
                    event = SignalEventV2(
                        event_type=route.source_event,
                        symbol=symbol,
                        ts=route.signal_date or date,
                        confidence=route.confidence,
                        side="long",
                        entry_plan=dict(route.entry_plan_meta) or {"style": route.entry_style},
                        invalidation=dict(route.invalidation_meta) or {"price": route.invalidate_price},
                        exit_plan=dict(route.exit_plan_meta) or {"style": route.exit_style, "hold_days": route.max_hold_days, "take_profit_pct": route.take_profit_pct},
                        context=dict(route.signal_context),
                    )
                    dec = self._queue_hunt(
                        d_idx=d_idx,
                        date=date,
                        symbol=symbol,
                        cash=cash,
                        target_price=fill,
                        event=event,
                    )
                else:
                    if limit_up is not None and not can_buy_strict(fill, limit_up):
                        self.pending_entries[symbol] = active_pending
                        return decisions
                    event = SignalEventV2(
                        event_type=route.source_event,
                        symbol=symbol,
                        ts=date,
                        confidence=route.confidence,
                        side="long",
                        entry_plan=dict(route.entry_plan_meta) or {"style": route.entry_style},
                        invalidation=dict(route.invalidation_meta) or {"price": route.invalidate_price},
                        exit_plan=dict(route.exit_plan_meta) or {"style": route.exit_style, "hold_days": route.max_hold_days, "take_profit_pct": route.take_profit_pct},
                        context=dict(route.signal_context),
                    )
                    dec = self._buy_now(date, d_idx, symbol, fill, cash, event)
                self.pending_entries.pop(symbol, None)
                return [dec] if dec is not None else []
            if active_pending:
                self.pending_entries[symbol] = active_pending
            else:
                self.pending_entries.pop(symbol, None)

        if not self._can_open(symbol, d_idx):
            if self._is_hunt():
                pass  # let hunt creation proceed; execution-time check handles slot availability
            else:
                return decisions

        tail_routes, breakout_routes = self._route_candidates(events)
        best_tail = tail_routes[0] if tail_routes else None
        best_breakout = breakout_routes[0] if breakout_routes else None

        if best_tail is not None:
            tail_score = self._route_score(best_tail)
            breakout_score = self._route_score(best_breakout) if best_breakout is not None else -1e9
            if tail_score >= breakout_score + 0.03:
                if self._is_realistic():
                    dec = self._queue_buy_next_open(
                        d_idx=d_idx,
                        symbol=symbol,
                        cash=cash,
                        sizing_price=close,
                        event=best_tail,
                    )
                    self.pending_entries.pop(symbol, None)
                    return [dec] if dec is not None else []
                if self._is_hunt():
                    dec = self._queue_hunt(
                        d_idx=d_idx,
                        date=date,
                        symbol=symbol,
                        cash=cash,
                        target_price=close,
                        event=best_tail,
                    )
                    self.pending_entries.pop(symbol, None)
                    return [dec] if dec is not None else []
                if limit_up is None or can_buy_strict(low, limit_up):
                    dec = self._buy_now(date, d_idx, symbol, low, cash, best_tail)
                    self.pending_entries.pop(symbol, None)
                    return [dec] if dec is not None else []

        if not breakout_routes:
            if best_tail is not None:
                if self._is_realistic():
                    dec = self._queue_buy_next_open(
                        d_idx=d_idx,
                        symbol=symbol,
                        cash=cash,
                        sizing_price=close,
                        event=best_tail,
                    )
                    self.pending_entries.pop(symbol, None)
                    return [dec] if dec is not None else []
                if self._is_hunt():
                    dec = self._queue_hunt(
                        d_idx=d_idx,
                        date=date,
                        symbol=symbol,
                        cash=cash,
                        target_price=close,
                        event=best_tail,
                    )
                    self.pending_entries.pop(symbol, None)
                    return [dec] if dec is not None else []
                if limit_up is None or can_buy_strict(low, limit_up):
                    dec = self._buy_now(date, d_idx, symbol, low, cash, best_tail)
                    self.pending_entries.pop(symbol, None)
                    return [dec] if dec is not None else []
            return decisions

        staged = list(self.pending_entries.get(symbol, []))
        for route in breakout_routes[:2]:
            gate = float(route.entry_plan.get("gate_price", close))
            valid_for_days = int(route.entry_plan.get("valid_for_days", 5))
            staged.append(
                PendingEntry(
                    symbol=symbol,
                    created_idx=d_idx,
                    valid_from_idx=d_idx + 1,
                    valid_until_idx=d_idx + max(1, valid_for_days),
                    trigger_price=gate,
                    source_event=route.event_type,
                    confidence=float(route.confidence),
                    invalidate_price=float(route.invalidation.get("price", close * 0.94)),
                    max_hold_days=int(route.exit_plan.get("hold_days", 5)),
                    take_profit_pct=float(route.exit_plan.get("take_profit_pct", self.default_take_profit_pct)),
                    exit_style=str(route.exit_plan.get("style", "default")),
                    signal_date=str(route.ts)[:10],
                    entry_style="breakout",
                    signal_context=dict(route.context),
                    entry_plan_meta=dict(route.entry_plan),
                    exit_plan_meta=dict(route.exit_plan),
                    invalidation_meta=dict(route.invalidation),
                )
            )
        self.pending_entries[symbol] = staged
        self._dedupe_pending(symbol)
        return decisions
