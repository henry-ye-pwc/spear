import pandas as pd
import json
import numpy as np

# Load trades
trades = pd.read_csv("outputs/backtests/ts_stopexp_20260312_2025_dlh_intraday/closed_trades.csv")

# Load events
events = pd.read_csv("outputs/backtests/ts_stopexp_20260312_2025_dlh_intraday/events.csv")

# Filter trend_spear events and trades
trades = trades[trades['entry_reason'] == 'entry:trend_spear'].copy()
events = events[events['event_type'] == 'trend_spear'].copy()

# Parse context from events
def parse_context(ctx_str):
    try:
        return json.loads(ctx_str)
    except:
        return {}

events['ctx'] = events['context'].apply(parse_context)
events['atr_at_entry'] = events['ctx'].apply(lambda x: x.get('atr_at_entry', np.nan))
events['peer_confirmation'] = events['ctx'].apply(lambda x: x.get('peer_confirmation', np.nan))

# Drop duplicates if any (same date, symbol)
events = events.drop_duplicates(subset=['date', 'symbol'])

# Merge
trades['entry_date'] = pd.to_datetime(trades['entry_date']).dt.strftime('%Y-%m-%d')
events['date'] = pd.to_datetime(events['date']).dt.strftime('%Y-%m-%d')

df = pd.merge(trades, events, left_on=['symbol', 'entry_date'], right_on=['symbol', 'date'], how='left')

# Analyze Fake Drop vs Real Drop
print("=== 假摔 (卖飞) vs 真跌 (标的完全选错) 事前特征对比 ===")
fake_drop = df[df['diagnosis'] == '卖飞/止损过早']
real_drop = df[df['diagnosis'] == '标的完全选错']

print(f"Fake drop count: {len(fake_drop)}, Real drop count: {len(real_drop)}")
print("\n[ATR at entry]")
print(f"Fake drop ATR mean: {fake_drop['atr_at_entry'].mean():.4f}, median: {fake_drop['atr_at_entry'].median():.4f}")
print(f"Real drop ATR mean: {real_drop['atr_at_entry'].mean():.4f}, median: {real_drop['atr_at_entry'].median():.4f}")

print("\n[Peer Confirmation (板块热度)]")
print(f"Fake drop mean: {fake_drop['peer_confirmation'].mean():.2f}")
print(f"Real drop mean: {real_drop['peer_confirmation'].mean():.2f}")

print("\n=== 盈利卖早 vs 合理止盈 事前/事中特征对比 ===")
sold_early = df[df['diagnosis'] == '盈利但明显卖早']
sold_good = df[df['diagnosis'].isin(['盈利且兑现合理', '盈利且接近MFE高点'])]

print(f"Sold early count: {len(sold_early)}, Sold good count: {len(sold_good)}")
print("\n[Hold Days at Exit]")
print(f"Sold early mean hold days: {sold_early['hold_days'].mean():.2f}")
print(f"Sold good mean hold days: {sold_good['hold_days'].mean():.2f}")

