#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import os
import sys
from datetime import datetime, timedelta
from pathlib import Path
from zoneinfo import ZoneInfo

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import pandas as pd

from v5.backtest.prepare import prepare_bundle
from v5.config.pools import list_named_pools, resolve_named_pool
from v5.config.defaults import apply_execution_profile, load_default_config
from v5.data.prefetch import prefetch_symbols
from v5.notify.feishu import send_feishu_webhook
from v5.notify.scanner import enrich_snapshot_with_trades, snapshot_to_json, update_watch_state
from v5.notify.state import save_cron_meta, save_watch_state
from v5.notify.templates import build_feishu_card_payload, build_feishu_post_payload, render_markdown_summary

DEFAULT_STATE_DIR = "./outputs/state"
DEFAULT_OUTPUT_DIR = "./outputs/signals"


def _load_dotenv() -> None:
    """Load .env from project root if it exists (no third-party dependency)."""
    env_path = ROOT / ".env"
    if not env_path.exists():
        return
    for line in env_path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, value = line.partition("=")
        os.environ.setdefault(key.strip(), value.strip())


_load_dotenv()


def _peek_recent_trading_dates(cache_dir: str, n: int, up_to: str, symbols: list[str] | None = None, store=None) -> list[str]:
    """Build a trading-date calendar from DuckDB store or PKL files.

    Prefers DuckDB ``store.trading_dates()`` when available.  Falls back to
    sampling PKL files from the cache directory.
    """
    if store is not None:
        try:
            dates = store.trading_dates(up_to, n)
            if dates:
                return dates
        except Exception:
            pass

    cache_path = Path(cache_dir)
    if symbols:
        pkl_files = [cache_path / f"{str(s).zfill(6)}_full.pkl" for s in symbols]
        pkl_files = [p for p in pkl_files if p.exists()]
    else:
        pkl_files = sorted(cache_path.glob("*_full.pkl"))

    if not pkl_files:
        return [up_to]

    sample_size = min(20, len(pkl_files))
    if len(pkl_files) <= sample_size:
        candidates = pkl_files
    else:
        step = max(1, len(pkl_files) // sample_size)
        candidates = [pkl_files[i * step] for i in range(sample_size) if i * step < len(pkl_files)]
        if pkl_files[-1] not in candidates:
            candidates.append(pkl_files[-1])

    all_dates: set[str] = set()
    for pkl_file in candidates:
        try:
            df = pd.read_pickle(pkl_file)
            all_dates.update(str(d)[:10] for d in df.index)
        except Exception:
            continue

    if not all_dates:
        return [up_to]

    recent = sorted(d for d in all_dates if d <= up_to)
    return recent[-n:] if recent else [up_to]


def build_parser() -> argparse.ArgumentParser:
    cfg = load_default_config()
    p = argparse.ArgumentParser(prog="v5/daily_signal_job.py", description="Daily signal notifier")
    p.add_argument("--date", required=True, help="As-of trading date, YYYY-MM-DD")
    p.add_argument("--scan-start", default="", help="Optional explicit scan start date, YYYY-MM-DD")
    p.add_argument("--lookback-days", type=int, default=cfg.data.warmup_bars)
    p.add_argument("--warmup-bars", type=int, default=cfg.data.warmup_bars)
    p.add_argument("--pool", type=int, default=300)
    p.add_argument("--pool-sampling", default="random", choices=["random", "head"])
    p.add_argument("--pool-seed", type=int, default=99)
    p.add_argument("--execution-profile", default="delayed_limit_hunt", choices=["day_level_ideal", "next_open_realistic", "delayed_limit_hunt"])
    p.add_argument("--hunt-price-buffer-pct", type=float, default=0.005)
    p.add_argument("--hunt-window-days", type=int, default=3)
    p.add_argument("--watch-window-days", type=int, default=5)
    p.add_argument("--max-positions", type=int, default=cfg.execution.max_positions)
    p.add_argument("--base-pos-pct", type=float, default=cfg.execution.base_pos_pct)
    p.add_argument("--position-sizing-base", default=cfg.execution.position_sizing_base, choices=["cash", "equity"])
    p.add_argument("--trend-spear-pos-mult", type=float, default=cfg.execution.trend_spear_pos_mult)
    p.add_argument("--post-limit-pos-mult", type=float, default=cfg.execution.post_limit_pos_mult)
    p.add_argument("--failed-board-pos-mult", type=float, default=cfg.execution.failed_board_pos_mult)
    p.add_argument("--youzi-pos-mult", type=float, default=cfg.execution.youzi_pos_mult)
    p.add_argument("--sector-spear-pos-mult", type=float, default=cfg.execution.sector_spear_pos_mult)
    p.add_argument("--attack-pos-mult", type=float, default=cfg.execution.attack_pos_mult)
    p.add_argument("--arb-pos-mult", type=float, default=cfg.execution.arb_pos_mult)
    p.add_argument("--state-path", default="")
    p.add_argument("--state-dir", default=DEFAULT_STATE_DIR)
    p.add_argument("--output-dir", default=DEFAULT_OUTPUT_DIR)
    p.add_argument("--symbols", default="")
    p.add_argument("--pool-name", default="")
    p.add_argument("--cache-only", action="store_true", help="Skip fetching new data, use local cache only")
    p.add_argument("--dry-run", action="store_true")
    p.add_argument("--feishu-webhook", default=os.environ.get("FEISHU_WEBHOOK", ""))
    p.add_argument("--feishu-secret", default=os.environ.get("FEISHU_SECRET", ""))
    p.add_argument("--mode", default="auto", choices=["auto", "preview", "confirm"],
                   help="auto=detect from Beijing time, preview=intraday synthetic bar, confirm=post-close daily")
    p.add_argument("--push-top-new", type=int, default=3, help="Max new signals in Feishu push")
    p.add_argument("--push-top-watch", type=int, default=5, help="Max watch items in Feishu push")
    p.add_argument("--push-top-drops", type=int, default=5, help="Max dropped items in Feishu push")
    p.add_argument("--min-confidence", type=float, default=0.0, help="Min signal confidence for push (0=all, 0.78=A-only)")
    p.add_argument("--disable-env-mapping", action="store_true", help="Ignore sector/industry data (all mapped to 其他)")
    p.add_argument("--trend-spear-dynamic-hold", action="store_true", default=cfg.execution.trend_spear_dynamic_hold_enabled)
    p.add_argument("--trend-spear-limitup-extend-days", type=int, default=cfg.execution.trend_spear_limitup_extend_days)
    p.add_argument("--trend-spear-limitup-wide-atr-mult", type=float, default=cfg.execution.trend_spear_limitup_wide_atr_mult)
    p.add_argument("--trend-spear-limitup-stop-floor-pct", type=float, default=cfg.execution.trend_spear_limitup_stop_floor_pct)
    p.add_argument("--trend-spear-noboard-tighten-days", type=int, default=cfg.execution.trend_spear_noboard_tighten_days)
    p.add_argument("--trend-spear-noboard-tight-atr-mult", type=float, default=cfg.execution.trend_spear_noboard_tight_atr_mult)
    p.add_argument("--trend-spear-noboard-max-hold", type=int, default=cfg.execution.trend_spear_noboard_max_hold)
    p.add_argument("--trend-spear-vol-exhaustion-exit", action="store_true", default=cfg.execution.trend_spear_vol_exhaustion_exit)
    p.add_argument("--no-ts-atr-stop", action="store_true", help="Disable ATR-based initial stop for trend_spear")
    p.add_argument("--no-ts-iqr-filter", action="store_true", help="Disable IQR volume filter for trend_spear")
    p.add_argument("--ts-iqr-threshold", type=float, default=cfg.models.ts_iqr_threshold)
    p.add_argument("--no-ts-elev-filter", action="store_true", help="Disable elevation filter for trend_spear")
    p.add_argument("--ts-elev-threshold", type=float, default=cfg.models.ts_elev_threshold)
    p.add_argument("--ytd", action="store_true", help="Year-to-date backtest for consistent position tracking (confirm mode only)")
    p.add_argument("--db-path", default="", help="DuckDB market store path (enables DuckDB mode)")
    p.add_argument("--list-pools", action="store_true")
    return p



def main() -> None:
    args = build_parser().parse_args()
    if args.list_pools:
        print(json.dumps(list_named_pools(), ensure_ascii=False, indent=2))
        return

    as_of_date = args.date
    cfg = load_default_config()
    if args.scan_start.strip():
        start_date = args.scan_start.strip()
    else:
        start_lookback = max(int(args.lookback_days), int(cfg.data.warmup_bars))
        start_date = str((__import__("pandas").Timestamp(args.date) - timedelta(days=start_lookback)).date())

    cfg.data.warmup_bars = args.warmup_bars
    cfg.data.universe_provider = "mootdx"
    cfg.data.bar_provider = "mootdx"
    cfg.data.fallback_bar_provider = "mootdx"
    cfg.data.mootdx_cache_only = args.cache_only
    cfg.data.pool_sampling = args.pool_sampling
    cfg.data.pool_seed = args.pool_seed
    cfg.backtest.pool_size = args.pool
    cfg.data.disable_env_mapping = args.disable_env_mapping
    cfg = apply_execution_profile(cfg, args.execution_profile)
    cfg.execution.hunt_price_buffer_pct = args.hunt_price_buffer_pct
    cfg.execution.hunt_window_days = args.hunt_window_days
    cfg.execution.max_positions = args.max_positions
    cfg.execution.base_pos_pct = args.base_pos_pct
    cfg.execution.position_sizing_base = args.position_sizing_base
    cfg.execution.trend_spear_pos_mult = args.trend_spear_pos_mult
    cfg.execution.post_limit_pos_mult = args.post_limit_pos_mult
    cfg.execution.failed_board_pos_mult = args.failed_board_pos_mult
    cfg.execution.youzi_pos_mult = args.youzi_pos_mult
    cfg.execution.sector_spear_pos_mult = args.sector_spear_pos_mult
    cfg.execution.attack_pos_mult = args.attack_pos_mult
    cfg.execution.arb_pos_mult = args.arb_pos_mult
    cfg.execution.trend_spear_dynamic_hold_enabled = args.trend_spear_dynamic_hold
    cfg.execution.trend_spear_limitup_extend_days = args.trend_spear_limitup_extend_days
    cfg.execution.trend_spear_limitup_wide_atr_mult = args.trend_spear_limitup_wide_atr_mult
    cfg.execution.trend_spear_limitup_stop_floor_pct = args.trend_spear_limitup_stop_floor_pct
    cfg.execution.trend_spear_noboard_tighten_days = args.trend_spear_noboard_tighten_days
    cfg.execution.trend_spear_noboard_tight_atr_mult = args.trend_spear_noboard_tight_atr_mult
    cfg.execution.trend_spear_noboard_max_hold = args.trend_spear_noboard_max_hold
    cfg.execution.trend_spear_vol_exhaustion_exit = args.trend_spear_vol_exhaustion_exit
    cfg.models.ts_atr_stop = not args.no_ts_atr_stop
    cfg.models.ts_iqr_filter = not args.no_ts_iqr_filter
    cfg.models.ts_iqr_threshold = args.ts_iqr_threshold
    cfg.models.ts_elev_filter = not args.no_ts_elev_filter
    cfg.models.ts_elev_threshold = args.ts_elev_threshold

    if args.pool_name:
        symbols = resolve_named_pool(args.pool_name)
    else:
        symbols = [x.strip() for x in args.symbols.split(",") if x.strip()] or None

    # Resolve paths
    state_dir = Path(args.state_dir)
    if not state_dir.is_absolute():
        state_dir = ROOT / state_dir
    state_dir.mkdir(parents=True, exist_ok=True)

    if args.state_path:
        state_path = Path(args.state_path)
        if not state_path.is_absolute():
            state_path = ROOT / state_path
    else:
        state_path = state_dir / "watch_state.json"

    output_base = Path(args.output_dir)
    if not output_base.is_absolute():
        output_base = ROOT / output_base

    watch_window = args.watch_window_days
    cache_dir = os.path.join(str(ROOT), "cache")

    # ── Optional DuckDB store ──
    store = None
    if args.db_path:
        from v5.data.store import MarketStore
        db_path = args.db_path if os.path.isabs(args.db_path) else os.path.join(str(ROOT), args.db_path)
        store = MarketStore(db_path=db_path)
        print(f"[store] DuckDB: {db_path}", flush=True)
        if store.symbol_count() == 0:
            from v5.data.migrate_pkl import migrate
            pkl_dir = os.path.join(str(ROOT), "cache")
            if os.path.isdir(pkl_dir) and list(Path(pkl_dir).glob("*_full.pkl")):
                print(f"[store] Empty DuckDB — auto-migrating PKL data from {pkl_dir} ...", flush=True)
                migrate(pkl_dir, store, verify=False)  # type: ignore[arg-type]
                print(f"[store] Migration done: {store.symbol_count()} symbols, {store.total_bar_count()} bars", flush=True)

    # ── Resolve run mode from Beijing time ──
    bj_now = datetime.now(ZoneInfo("Asia/Shanghai"))
    bj_time_str = bj_now.strftime("%H:%M")
    if args.mode == "auto":
        if 9 <= bj_now.hour < 15 or (bj_now.hour == 9 and bj_now.minute >= 30):
            mode = "preview"
        else:
            mode = "confirm"
    else:
        mode = args.mode

    mode_hint = ""
    if mode == "preview":
        mode_hint = f"盘中预测 (截至 {bj_time_str})"
    print(f"[mode]  {mode} | {bj_time_str} Beijing" + (f" | {mode_hint}" if mode_hint else ""), flush=True)

    # ── Resolve prefetch symbols list (shared by both modes) ──
    from v5.data.providers.mootdx_provider import MootdxProvider
    _prov = MootdxProvider(
        cache_dir=cfg.data.mootdx_cache_dir,
        pool_sampling=cfg.data.pool_sampling,
        pool_seed=cfg.data.pool_seed,
        cache_only=True,
    )
    if symbols:
        prefetch_syms = [str(s).zfill(6) for s in symbols]
    else:
        _uni = _prov.load_universe(args.pool)
        prefetch_syms = _uni["symbol"].tolist() if not _uni.empty else []

    intraday_bars = None

    if mode == "preview":
        # Preview: build synthetic bars from minute data for today's scan.
        # First check if as_of_date is a trading day — if not, fall back to
        # confirm mode using the most recent trading day.
        if store is not None:
            calendar = store.trading_dates(up_to=as_of_date, n=watch_window + 2)
        else:
            calendar = _peek_recent_trading_dates(cache_dir, watch_window + 2, as_of_date, symbols=prefetch_syms)

        is_trading_day = as_of_date in calendar
        if not is_trading_day:
            effective_date = calendar[-1] if calendar else as_of_date
            print(f"[preview] {as_of_date} 非交易日，降级为 confirm 模式 (latest={effective_date})", flush=True)
            mode = "confirm"
        else:
            from v5.data.intraday import fetch_synthetic_bars
            if prefetch_syms:
                intraday_bars = fetch_synthetic_bars(
                    prefetch_syms,
                    cache_dir=cfg.data.mootdx_cache_dir,
                    target_date=as_of_date,
                    workers=4,
                )
            cfg.data.mootdx_cache_only = True

            if not intraday_bars:
                effective_date = calendar[-1] if calendar else as_of_date
                print(f"[preview] 0 分钟线，降级为 confirm 模式 (latest={effective_date})", flush=True)
                mode = "confirm"
            else:
                effective_date = as_of_date
                process_dates = calendar[-(watch_window + 1):] if calendar else [as_of_date]
                if as_of_date not in process_dates:
                    process_dates.append(as_of_date)
                target_dates_arg = list(process_dates)
                print(f"[preview] {len(intraday_bars)} synthetic bars, {len(process_dates)} date(s): {process_dates[0]} ~ {process_dates[-1]}", flush=True)

    if mode == "confirm":
        # Confirm: prefetch daily data FIRST, then peek calendar
        if not args.cache_only and prefetch_syms:
            prefetch_symbols(
                prefetch_syms,
                cache_dir=cfg.data.mootdx_cache_dir,
                end_date=as_of_date,
                workers=4,
                store=store,
            )
            # Pre-compute features: workers open DuckDB read-only. Close our
            # read-write connection so workers can lock the file, then reopen.
            from v5.data.prefetch_features import prefetch_features
            _db_path = str(store.db_path)
            store.close()
            try:
                prefetch_features(
                    cache_dir=cfg.data.mootdx_cache_dir,
                    cfg=cfg,
                    workers=4,
                    db_path=_db_path,
                    store=None,
                )
            finally:
                store = MarketStore(_db_path)

        if args.ytd:
            ytd_start = f"{as_of_date[:4]}-01-01"
            if store is not None:
                calendar = store.trading_dates(up_to=as_of_date, n=300)
            else:
                calendar = _peek_recent_trading_dates(cache_dir, 300, as_of_date, symbols=prefetch_syms)
            calendar = [d for d in calendar if d >= ytd_start]
        else:
            if store is not None:
                calendar = store.trading_dates(up_to=as_of_date, n=watch_window + 2)
            else:
                calendar = _peek_recent_trading_dates(cache_dir, watch_window + 2, as_of_date, symbols=prefetch_syms)

        effective_date = calendar[-1] if calendar else as_of_date
        if effective_date != as_of_date:
            print(f"[data]  latest={effective_date} (requested {as_of_date})", flush=True)

        # Fallback: if daily bars for effective_date are placeholders, use minute bars
        if effective_date == as_of_date and prefetch_syms:
            _sample = prefetch_syms[:5]
            _placeholder_count = 0
            for _s in _sample:
                try:
                    if store is not None:
                        _df = store.read_bars(_s)
                    else:
                        _pkl = Path(cache_dir) / f"{_s}_full.pkl"
                        _df = pd.read_pickle(_pkl) if _pkl.exists() else pd.DataFrame()
                    if not _df.empty:
                        _last = _df.iloc[-1]
                        _d = str(pd.Timestamp(_df.index[-1]))[:10]
                        if _d == as_of_date and float(_last["volume"]) < 100:
                            _placeholder_count += 1
                except Exception:
                    pass
            if _placeholder_count >= len(_sample) // 2:
                from v5.data.intraday import fetch_synthetic_bars
                print(f"[confirm] Daily bars are placeholders ({_placeholder_count}/{len(_sample)} sampled). Fetching minute bars as fallback ...", flush=True)
                intraday_bars = fetch_synthetic_bars(
                    prefetch_syms,
                    cache_dir=cfg.data.mootdx_cache_dir,
                    target_date=as_of_date,
                    workers=4,
                )
                print(f"[confirm] {len(intraday_bars or {})} synthetic bars built from minute data", flush=True)

        if args.ytd:
            process_dates = list(calendar)
            target_dates_arg = list(process_dates)
        else:
            process_dates = calendar[-(watch_window + 1):]
            target_dates_arg = list(process_dates)

    bundle = prepare_bundle(
        cfg,
        start=start_date,
        end=as_of_date,
        pool_size=args.pool,
        symbols=symbols,
        target_dates=target_dates_arg,
        intraday_bars=intraday_bars,
        store=store,
    )

    # Rebuild watch state from scratch (no dependency on persisted state)
    state: dict = {}
    final_snapshot = None
    n_process = len(process_dates)
    for i, run_date in enumerate(process_dates):
        snapshot, state = update_watch_state(
            bundle=bundle,
            as_of_date=run_date,
            current_state=state,
            hunt_buffer_pct=args.hunt_price_buffer_pct,
            watch_window_days=watch_window,
            state_dir=str(state_dir),
        )
        final_snapshot = snapshot
        if i >= n_process - 5:
            marker = " ←" if run_date == effective_date else ""
            print(f"  {run_date}: +{len(snapshot.new_signals)} new, {len(snapshot.watch_updates)} active, -{len(snapshot.dropped)} drop{marker}", flush=True)

    save_watch_state(state_path, state)
    save_cron_meta(state_dir, effective_date)
    assert final_snapshot is not None
    final_snapshot.mode = mode
    final_snapshot.hint = mode_hint

    # ── Mini-backtest for trade enrichment ──
    backtest_artifacts = None
    try:
        from v5.backtest.runner import run_backtest
        artifacts = run_backtest(
            cfg=cfg,
            start=start_date,
            end=effective_date,
            pool_size=args.pool,
            initial_cash=1_000_000.0,
            symbols=symbols,
            bundle=bundle,
        )
        backtest_artifacts = artifacts
        enrich_snapshot_with_trades(
            final_snapshot, artifacts, effective_date,
            watch_window_days=watch_window,
        )
        print(
            f"[bt]    {len(final_snapshot.today_entries)} entry, "
            f"{len(final_snapshot.today_exits)} exit, "
            f"{len(final_snapshot.active_positions)} pos, "
            f"equity={final_snapshot.portfolio_equity:,.0f}",
            flush=True,
        )
    except Exception as e:
        print(f"[bt]    skipped: {e}", flush=True)

    # Write outputs — output_base is already date-specific when called from
    # the task service, so write directly into it.
    output_dir = output_base
    output_dir.mkdir(parents=True, exist_ok=True)

    snapshot_path = output_dir / "snapshot.json"
    summary_path = output_dir / "summary.md"
    markdown = render_markdown_summary(
        snapshot=final_snapshot,
        watch_window_days=watch_window,
        execution_profile=args.execution_profile,
        push_top_new=args.push_top_new,
        push_top_watch=args.push_top_watch,
        push_top_drops=args.push_top_drops,
        min_confidence=args.min_confidence,
    )
    snapshot_path.write_text(snapshot_to_json(final_snapshot), encoding="utf-8")
    summary_path.write_text(markdown, encoding="utf-8")

    data_stale = effective_date != as_of_date
    meta = {
        "kind": "signal_scan",
        "created_at": __import__("datetime").datetime.now(__import__("datetime").UTC).isoformat(),
        "date": effective_date,
        "requested_date": as_of_date,
        "effective_date": effective_date,
        "data_stale": data_stale,
        "mode": mode,
        "hint": mode_hint,
        "pool_size": len(prefetch_syms) if prefetch_syms else args.pool,
        "warmup_bars": args.warmup_bars,
        "execution_profile": args.execution_profile,
        "new_signals": len(final_snapshot.new_signals),
        "active_watch": len(final_snapshot.watch_updates),
        "dropped": len(final_snapshot.dropped),
        "process_dates": process_dates,
        "push_top_new": args.push_top_new,
        "push_top_watch": args.push_top_watch,
        "push_top_drops": args.push_top_drops,
        "min_confidence": args.min_confidence,
        "config": {
            "pool_name": getattr(args, "pool_name", ""),
            "pool_sampling": getattr(args, "pool_sampling", "random"),
            "pool_seed": getattr(args, "pool_seed", 42),
            "max_positions": cfg.execution.max_positions,
            "base_pos_pct": cfg.execution.base_pos_pct,
            "position_sizing_base": cfg.execution.position_sizing_base,
            "cooldown_days": cfg.execution.cooldown_days,
            "take_profit_pct": cfg.execution.default_take_profit_pct,
            "hunt_price_buffer_pct": args.hunt_price_buffer_pct,
            "hunt_window_days": args.hunt_window_days,
            "exit_mode": cfg.execution.exit_mode,
            "exit_hunt_buffer_pct": cfg.execution.exit_hunt_buffer_pct,
            "exit_hunt_window_days": cfg.execution.exit_hunt_window_days,
            "init_cash": 1_000_000.0,
            "trend_spear_pos_mult": cfg.execution.trend_spear_pos_mult,
            "post_limit_pos_mult": cfg.execution.post_limit_pos_mult,
            "failed_board_pos_mult": cfg.execution.failed_board_pos_mult,
            "youzi_pos_mult": cfg.execution.youzi_pos_mult,
            "sector_spear_pos_mult": cfg.execution.sector_spear_pos_mult,
            "attack_pos_mult": cfg.execution.attack_pos_mult,
            "arb_pos_mult": cfg.execution.arb_pos_mult,
            "disable_env_mapping": cfg.data.disable_env_mapping,
            "ytd": args.ytd,
        },
    }
    (output_dir / "meta.json").write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")

    # Save full mini-backtest data (same CSV format as backtest output)
    equity_chart_data: list[dict] | None = None
    if backtest_artifacts is not None:
        import pandas as _pd
        result = backtest_artifacts.result
        if result.trades:
            _pd.DataFrame(result.trades).to_parquet(output_dir / "trades.parquet", engine="pyarrow", index=False)
        if result.events:
            _pd.DataFrame(result.events).to_parquet(output_dir / "events.parquet", engine="pyarrow", index=False)
        if result.open_positions:
            _pd.DataFrame(result.open_positions).to_parquet(output_dir / "open_positions.parquet", engine="pyarrow", index=False)
        if result.summary:
            (output_dir / "summary.json").write_text(json.dumps(result.summary, ensure_ascii=False, indent=2), encoding="utf-8")
        eq_curve = backtest_artifacts.equity_curve
        if eq_curve is not None and len(eq_curve):
            eq_df = eq_curve.reset_index()
            eq_df.columns = ["date", "equity"]
            eq_df["date"] = eq_df["date"].astype(str)
            eq_df.to_parquet(output_dir / "equity_curve.parquet", engine="pyarrow", index=False)
            if args.ytd:
                equity_chart_data = eq_df.to_dict(orient="records")

    payload = build_feishu_card_payload(
        snapshot=final_snapshot,
        push_top_new=args.push_top_new,
        push_top_watch=args.push_top_watch,
        push_top_drops=args.push_top_drops,
        min_confidence=args.min_confidence,
        data_stale=data_stale,
        equity_data=equity_chart_data,
    )
    (output_dir / "feishu_payload.json").write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")

    print(flush=True)
    print("═" * 44, flush=True)
    print(f"  Signal scan: {effective_date}", flush=True)
    print(f"  New: {len(final_snapshot.new_signals):>4}   Watch: {len(final_snapshot.watch_updates):<4}  Dropped: {len(final_snapshot.dropped)}", flush=True)
    print(f"  Output: {output_dir}", flush=True)

    if not args.dry_run and args.feishu_webhook:
        response = send_feishu_webhook(
            webhook_url=args.feishu_webhook,
            payload=payload,
            secret=(args.feishu_secret or None),
        )
        status_code = response.get("StatusCode", response.get("code", "?"))
        feishu_ok = status_code == 0
        print(f"  Feishu: {'sent' if feishu_ok else 'FAILED (' + str(response) + ')'}", flush=True)
    else:
        print(f"  Feishu: skipped", flush=True)
    print("═" * 44, flush=True)


if __name__ == "__main__":
    main()
