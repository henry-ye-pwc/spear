from __future__ import annotations

import json
import platform
import sys
import tempfile
from datetime import datetime, UTC
from pathlib import Path

import pandas as pd

from cq_backtest.shared.utils import ensure_dir
from v4.reports.analytics import (
    build_closed_trades,
    build_trade_master_table,
    enrich_closed_trades_with_path_stats,
    summarize_diagnosis,
    summarize_events,
    summarize_exits,
)
from v4.reports.overview import write_overview
from v5.backtest.prepare import PreparedBundle
from v4.backtest.engine import BacktestResult
from v5.config.defaults import V5Config


def _atomic_write_json(path: Path, data: dict) -> None:
    content = json.dumps(data, ensure_ascii=False, indent=2)
    tmp = Path(tempfile.mktemp(dir=path.parent, suffix=".tmp"))
    tmp.write_text(content, encoding="utf-8")
    tmp.rename(path)


def _atomic_write_jsonl(path: Path, rows: list[dict]) -> None:
    content = "".join(json.dumps(row, ensure_ascii=False) + "\n" for row in rows)
    tmp = Path(tempfile.mktemp(dir=path.parent, suffix=".tmp"))
    tmp.write_text(content, encoding="utf-8")
    tmp.rename(path)


def _flatten_meta_column(df: pd.DataFrame, *, column: str) -> pd.DataFrame:
    if df.empty or column not in df.columns:
        return df.copy()
    base = df.drop(columns=[column]).copy()
    meta_rows = []
    for value in df[column].fillna("{}"):
        try:
            meta_rows.append(json.loads(str(value)) if str(value).strip() else {})
        except Exception:
            meta_rows.append({})
    meta_df = pd.json_normalize(meta_rows, sep=".")
    if meta_df.empty:
        return base
    meta_df = meta_df.add_prefix(f"{column}.")
    return pd.concat([base.reset_index(drop=True), meta_df.reset_index(drop=True)], axis=1)


def _flatten_json_columns(df: pd.DataFrame, columns: list[str]) -> pd.DataFrame:
    out = df.copy()
    for column in columns:
        out = _flatten_meta_column(out, column=column)
    return out


def write_reports(outdir: str, result: BacktestResult, bundle: PreparedBundle, cfg: V5Config, start: str, end: str, equity_curve: pd.Series | None = None, pool_name: str = "", active_event_types: set[str] | None = None) -> None:
    root = ensure_dir(outdir)
    trades = pd.DataFrame(result.trades)
    events = pd.DataFrame(result.events)
    open_positions = pd.DataFrame(result.open_positions)
    closed = build_closed_trades(trades)
    closed = enrich_closed_trades_with_path_stats(closed, cfg=cfg, start=start, end=end, bars_cache=bundle.feature_data)
    event_summary = summarize_events(events, trades)
    exit_summary = summarize_exits(closed)
    diagnosis_summary = summarize_diagnosis(closed)
    master_table = build_trade_master_table(
        closed,
        events,
        cfg=cfg,
        start=start,
        end=end,
        bars_cache=bundle.feature_data,
        env=bundle.env,
    )

    _p = Path(root)
    trades.to_parquet(_p / "trades.parquet", engine="pyarrow", index=False)
    events.to_parquet(_p / "events.parquet", engine="pyarrow", index=False)
    open_positions.to_parquet(_p / "open_positions.parquet", engine="pyarrow", index=False)
    closed.to_parquet(_p / "closed_trades.parquet", engine="pyarrow", index=False)
    event_summary.to_parquet(_p / "event_summary.parquet", engine="pyarrow", index=False)
    exit_summary.to_parquet(_p / "exit_summary.parquet", engine="pyarrow", index=False)
    diagnosis_summary.to_parquet(_p / "diagnosis_summary.parquet", engine="pyarrow", index=False)
    master_table.to_csv(_p / "all_trades_master_table.csv", index=False, encoding="utf-8-sig")
    with (Path(root) / "summary.json").open("w", encoding="utf-8") as fh:
        json.dump(result.summary, fh, ensure_ascii=False, indent=2)
    write_overview(str(root), result.summary, closed, event_summary, exit_summary, diagnosis_summary)

    if equity_curve is not None and len(equity_curve) > 0:
        eq_df = pd.DataFrame({
            "date": [str(x)[:10] for x in equity_curve.index],
            "equity": equity_curve.values,
        })
        eq_daily = eq_df.groupby("date", sort=True)["equity"].last().reset_index()
        eq_daily = eq_daily[(eq_daily["date"] >= start) & (eq_daily["date"] <= end)]
        eq_daily.to_parquet(Path(root) / "equity_curve.parquet", engine="pyarrow", index=False)

    trace_events = list(getattr(result, "trace_events", []) or [])
    if trace_events:
        _atomic_write_jsonl(Path(root) / "trace_events.jsonl", trace_events)
        trace_df = pd.json_normalize(trace_events, sep=".")
        trace_df.to_parquet(Path(root) / "trace_events.parquet", engine="pyarrow", index=False)
        if "kind" in trace_df.columns:
            trace_df[trace_df["kind"] == "position_mark"].to_parquet(Path(root) / "position_marks.parquet", engine="pyarrow", index=False)
            trace_df[trace_df["kind"] == "exit_triggered"].to_parquet(Path(root) / "exit_triggers.parquet", engine="pyarrow", index=False)

    run_config: dict = {
        "start": start,
        "end": end,
        "pool_size": len(bundle.feature_data),
        "pool_sampling": cfg.data.pool_sampling,
        "pool_seed": cfg.data.pool_seed,
        "execution_profile": cfg.execution.execution_profile,
        "warmup_bars": cfg.data.warmup_bars,
        "hunt_price_buffer_pct": cfg.execution.hunt_price_buffer_pct,
        "hunt_window_days": cfg.execution.hunt_window_days,
        "exit_mode": cfg.execution.exit_mode,
        "exit_hunt_buffer_pct": cfg.execution.exit_hunt_buffer_pct,
        "exit_hunt_window_days": cfg.execution.exit_hunt_window_days,
        "trend_spear_stop_mode": cfg.execution.trend_spear_stop_mode,
        "trend_spear_stop_grace_days": cfg.execution.trend_spear_stop_grace_days,
        "trend_spear_trend_management_enabled": cfg.execution.trend_spear_trend_management_enabled,
        "trend_spear_trend_activation_ret": cfg.execution.trend_spear_trend_activation_ret,
        "trend_spear_trend_drawdown_exit": cfg.execution.trend_spear_trend_drawdown_exit,
        "trend_spear_trend_stale_days": cfg.execution.trend_spear_trend_stale_days,
        "trend_spear_trend_max_extension_days": cfg.execution.trend_spear_trend_max_extension_days,
        "trend_spear_reentry_watch_enabled": cfg.execution.trend_spear_reentry_watch_enabled,
        "trend_spear_reentry_watch_days": cfg.execution.trend_spear_reentry_watch_days,
        "trend_spear_reentry_min_near_pressure_days": cfg.execution.trend_spear_reentry_min_near_pressure_days,
        "trend_spear_reentry_min_near_support_days": cfg.execution.trend_spear_reentry_min_near_support_days,
        "trend_spear_reentry_shrink_threshold": cfg.execution.trend_spear_reentry_shrink_threshold,
        "trend_spear_reentry_expand_threshold": cfg.execution.trend_spear_reentry_expand_threshold,
        "init_cash": cfg.backtest.initial_cash,
        "max_positions": cfg.execution.max_positions,
        "base_pos_pct": cfg.execution.base_pos_pct,
        "position_sizing_base": cfg.execution.position_sizing_base,
        "cooldown_days": cfg.execution.cooldown_days,
        "take_profit_pct": cfg.execution.default_take_profit_pct,
        "position_multipliers": {
            "trend_spear": cfg.execution.trend_spear_pos_mult,
            "post_limit": cfg.execution.post_limit_pos_mult,
            "failed_board": cfg.execution.failed_board_pos_mult,
            "youzi": cfg.execution.youzi_pos_mult,
            "sector_spear": cfg.execution.sector_spear_pos_mult,
            "attack": cfg.execution.attack_pos_mult,
            "arb": cfg.execution.arb_pos_mult,
        },
        "disable_env_mapping": cfg.data.disable_env_mapping,
        "mootdx_cache_only": cfg.data.mootdx_cache_only,
        "show_progress": cfg.backtest.show_progress,
        "trend_spear_dynamic_hold": cfg.execution.trend_spear_dynamic_hold_enabled,
        "trend_spear_limitup_extend_days": cfg.execution.trend_spear_limitup_extend_days,
        "trend_spear_limitup_wide_atr_mult": cfg.execution.trend_spear_limitup_wide_atr_mult,
        "trend_spear_limitup_stop_floor_pct": cfg.execution.trend_spear_limitup_stop_floor_pct,
        "trend_spear_noboard_tighten_days": cfg.execution.trend_spear_noboard_tighten_days,
        "trend_spear_noboard_tight_atr_mult": cfg.execution.trend_spear_noboard_tight_atr_mult,
        "trend_spear_noboard_max_hold": cfg.execution.trend_spear_noboard_max_hold,
        "trend_spear_vol_exhaustion_exit": cfg.execution.trend_spear_vol_exhaustion_exit,
        "ts_atr_stop": cfg.models.ts_atr_stop,
        "ts_iqr_filter": cfg.models.ts_iqr_filter,
        "ts_iqr_threshold": cfg.models.ts_iqr_threshold,
        "ts_elev_filter": cfg.models.ts_elev_filter,
        "ts_elev_threshold": cfg.models.ts_elev_threshold,
    }
    if pool_name:
        run_config["pool_name"] = pool_name
    if active_event_types is not None:
        run_config["enable_events"] = sorted(active_event_types)
    meta = {
        "kind": "backtest",
        "created_at": datetime.now(UTC).isoformat(),
        "config": run_config,
        "runtime": {
            "python_version": sys.version,
            "platform": platform.platform(),
        },
        "symbols_count": len(bundle.feature_data),
        "events_count": len(result.events),
        "trades_count": len(result.trades),
        "trace_events_count": len(trace_events),
    }
    _atomic_write_json(Path(root) / "meta.json", meta)

