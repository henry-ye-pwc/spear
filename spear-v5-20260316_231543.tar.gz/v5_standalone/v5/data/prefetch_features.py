"""Batch pre-computation of feature tables for all symbols.

Run after prefetch_symbols() to convert raw OHLCV data into feature DataFrames
stored as parquet files.  Subsequent prepare_bundle() calls will read these
cached features instead of recomputing (~3s read vs ~9min compute on 2-core).

Usage:
    prefetch_features(cache_dir, cfg, workers=4, db_path="cache/market.duckdb")

Each worker reads bars from DuckDB (read-only), runs preprocess + feature
pipeline, and writes a parquet file.  Feature-config hash is embedded in the
filename so different FeatureConfig params produce separate cache entries.
"""
from __future__ import annotations

import os
import time
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path

import pandas as pd

from v5.config.defaults import V5Config


def _worker_compute_batch(
    symbols: list[str],
    cache_dir: str,
    feature_cache_dir: str,
    cfg_features: dict,
    db_path: str | None = None,
    refresh_ts: dict[str, float] | None = None,
    worker_id: int = 0,
    total_symbols: int = 0,
) -> dict:
    """Compute features for a batch of symbols inside a worker process."""
    from v4.data.adapter import preprocess_daily
    from v4.features import (
        add_robust_volume_features,
        add_sequence_features,
        add_structure_features,
    )
    from v5.backtest.prepare import _feature_config_hash, _feature_cache_path

    store = None
    if db_path:
        from v5.data.store import MarketStore
        store = MarketStore(db_path, read_only=True)

    class _FakeCfg:
        class features:
            vol_window = cfg_features["vol_window"]
            sequence_window = cfg_features["sequence_window"]
            peak_window = cfg_features["peak_window"]
            drawdown_min = cfg_features["drawdown_min"]
            peak_touch_eps = cfg_features["peak_touch_eps"]
            consolidation_window = cfg_features["consolidation_window"]

    fake_cfg = _FakeCfg()
    if refresh_ts is None:
        refresh_ts = {}

    computed = 0
    skipped = 0
    errors = 0
    error_syms: list[str] = []

    for i, sym in enumerate(symbols):
        feat_path = _feature_cache_path(sym, fake_cfg, feature_cache_dir)

        # Freshness: compare feature file mtime against DuckDB last_fetched_at
        if os.path.exists(feat_path):
            feat_mtime = os.path.getmtime(feat_path)
            src_ts = refresh_ts.get(str(sym).zfill(6), 0.0)
            if src_ts and feat_mtime >= src_ts:
                skipped += 1
                continue
            # Fallback: check PKL if DuckDB ts not available
            pkl_path = os.path.join(cache_dir, f"{sym}_full.pkl")
            if not src_ts and os.path.exists(pkl_path) and feat_mtime >= os.path.getmtime(pkl_path):
                skipped += 1
                continue

        try:
            raw = None
            if store:
                raw = store.read_bars(sym)
            if raw is None or raw.empty:
                pkl_path = os.path.join(cache_dir, f"{sym}_full.pkl")
                if os.path.exists(pkl_path):
                    raw = pd.read_pickle(pkl_path)
            if raw is None or raw.empty or len(raw) < 120:
                skipped += 1
                continue
            raw.index = pd.to_datetime(raw.index)
            raw = raw.sort_index()
            if "amount" not in raw.columns and "close" in raw.columns and "volume" in raw.columns:
                raw["amount"] = raw["close"].astype(float) * raw["volume"].astype(float)
            raw["symbol"] = sym

            out = preprocess_daily(raw, sym)
            out = add_robust_volume_features(out, window=cfg_features["vol_window"])
            out = add_sequence_features(out, window=cfg_features["sequence_window"])
            out = add_structure_features(
                out,
                peak_window=cfg_features["peak_window"],
                drawdown_min=cfg_features["drawdown_min"],
                peak_touch_eps=cfg_features["peak_touch_eps"],
                consolidation_window=cfg_features["consolidation_window"],
            )

            os.makedirs(feature_cache_dir, exist_ok=True)
            tmp = feat_path + ".tmp"
            out_write = out.reset_index() if isinstance(out.index, pd.DatetimeIndex) else out
            out_write.to_feather(tmp)
            os.replace(tmp, feat_path)
            computed += 1
        except Exception as exc:
            errors += 1
            error_syms.append(sym)
            print(f"[prefetch-feat] W{worker_id} ERROR {sym}: {exc}", flush=True)
            try:
                os.remove(feat_path + ".tmp")
            except OSError:
                pass

        done = i + 1
        if done % 200 == 0 or done == len(symbols):
            print(f"[feat]  w{worker_id}: {done}/{len(symbols)} ({computed} computed)", flush=True)

    if store:
        store.close()
    return {"computed": computed, "skipped": skipped, "errors": errors, "error_syms": error_syms}


def prefetch_features(
    cache_dir: str,
    cfg: V5Config,
    workers: int = 4,
    db_path: str | None = None,
    store=None,
) -> dict:
    """Pre-compute feature parquets for all symbols in the data store.

    Parameters
    ----------
    cache_dir : str
        Base cache directory (features stored under ``{cache_dir}/features/``).
    cfg : V5Config
        Configuration (only ``cfg.features`` is used).
    workers : int
        Number of parallel worker processes.
    db_path : str | None
        Path to DuckDB database.  Workers open read-only connections and read
        bars from DuckDB instead of PKL files.
    store : MarketStore | None
        If provided, reuse this open store for symbol list and refresh_ts
        instead of opening a second connection (avoids DuckDB "different
        configuration" error when the same file is already open read-write).

    Returns
    -------
    dict with keys: total, computed, skipped, errors, elapsed_s.
    """
    feature_cache_dir = os.path.join(cache_dir, "features")
    Path(feature_cache_dir).mkdir(parents=True, exist_ok=True)

    # Discover symbols from DuckDB first, fall back to PKL glob.
    # Reuse caller's store when given to avoid opening same DB with read_only
    # while it is already open read-write (DuckDB forbids mixed config).
    symbols: list[str] = []
    refresh_ts: dict[str, float] = {}
    if store is not None:
        refresh_ts = store.get_refresh_timestamps()
        rows = store._conn.execute(
            "SELECT DISTINCT symbol FROM daily_bars"
        ).fetchall()
        symbols = sorted(str(r[0]) for r in rows)
    elif db_path and os.path.exists(db_path):
        from v5.data.store import MarketStore
        with MarketStore(db_path, read_only=True) as _store:
            refresh_ts = _store.get_refresh_timestamps()
            rows = _store._conn.execute(
                "SELECT DISTINCT symbol FROM daily_bars"
            ).fetchall()
            symbols = sorted(str(r[0]) for r in rows)

    if not symbols:
        symbols = sorted(
            p.stem.replace("_full", "")
            for p in Path(cache_dir).glob("*_full.pkl")
        )
    if not symbols:
        print("[prefetch-feat] No symbols found — nothing to do.", flush=True)
        return {"total": 0, "computed": 0, "skipped": 0, "errors": 0, "elapsed_s": 0}

    cfg_features = {
        "vol_window": cfg.features.vol_window,
        "sequence_window": cfg.features.sequence_window,
        "peak_window": cfg.features.peak_window,
        "drawdown_min": cfg.features.drawdown_min,
        "peak_touch_eps": cfg.features.peak_touch_eps,
        "consolidation_window": cfg.features.consolidation_window,
    }

    n = min(workers, len(symbols))
    batches: list[list[str]] = [[] for _ in range(n)]
    for i, sym in enumerate(symbols):
        batches[i % n].append(sym)

    print(f"[feat]  computing {len(symbols)} symbols ({n}w) ...", flush=True)
    t0 = time.monotonic()

    totals = {"computed": 0, "skipped": 0, "errors": 0}
    all_error_syms: list[str] = []

    with ProcessPoolExecutor(max_workers=n) as pool:
        futures = {
            pool.submit(
                _worker_compute_batch,
                batch, cache_dir, feature_cache_dir, cfg_features,
                db_path=db_path, refresh_ts=refresh_ts,
                worker_id=i, total_symbols=len(symbols),
            ): i
            for i, batch in enumerate(batches)
        }
        for future in as_completed(futures):
            idx = futures[future]
            try:
                result = future.result(timeout=1800)
                totals["computed"] += result["computed"]
                totals["skipped"] += result["skipped"]
                totals["errors"] += result["errors"]
                all_error_syms.extend(result.get("error_syms", []))
            except Exception as exc:
                print(f"[prefetch-feat] Worker {idx} failed: {exc}", flush=True)
                totals["errors"] += len(batches[idx])

    elapsed = time.monotonic() - t0
    parts = [f"{totals['computed']} computed", f"{totals['skipped']} cached"]
    if totals["errors"]:
        parts.append(f"{totals['errors']} errors")
    print(f"[feat]  {' / '.join(parts)} ({elapsed:.1f}s)", flush=True)
    return {
        "total": len(symbols),
        "computed": totals["computed"],
        "skipped": totals["skipped"],
        "errors": totals["errors"],
        "elapsed_s": round(elapsed, 1),
        "error_syms": sorted(all_error_syms),
    }
