"""CP-2: Migrate PKL cache files into DuckDB.

Usage:
    python -m v5.data.migrate_pkl [--cache-dir ./cache] [--db-path cache/market.duckdb] [--verify]
"""
from __future__ import annotations

import argparse
import os
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd

from v5.data.store import MarketStore


def discover_pkl_files(cache_dir: str) -> list[Path]:
    """Find all *_full.pkl files in cache_dir."""
    root = Path(cache_dir)
    if not root.exists():
        return []
    return sorted(root.glob("*_full.pkl"))


def load_pkl(pkl_path: Path) -> tuple[str, pd.DataFrame | None]:
    """Load a PKL file and extract the symbol code."""
    symbol = pkl_path.stem.replace("_full", "")
    try:
        df = pd.read_pickle(pkl_path)
        if df is None or df.empty:
            return symbol, None
        if not isinstance(df.index, pd.DatetimeIndex):
            return symbol, None
        return symbol, df
    except Exception as e:
        print(f"  [WARN] Failed to load {pkl_path.name}: {e}")
        return symbol, None


def verify_symbol(
    store: MarketStore, symbol: str, original_df: pd.DataFrame
) -> tuple[bool, str]:
    """Row-level verification: compare DuckDB contents with original DataFrame."""
    db_df = store.read_bars(symbol)
    if len(db_df) != len(original_df):
        return False, f"Row count mismatch: pkl={len(original_df)} db={len(db_df)}"

    if not db_df.index.equals(original_df.index):
        missing_in_db = original_df.index.difference(db_df.index)
        extra_in_db = db_df.index.difference(original_df.index)
        return False, (
            f"Index mismatch: "
            f"{len(missing_in_db)} dates missing in DB, "
            f"{len(extra_in_db)} extra in DB"
        )

    for col in ["open", "high", "low", "close", "volume", "amount"]:
        if col not in original_df.columns:
            continue
        orig_vals = original_df[col].values.astype(float)
        db_vals = db_df[col].values.astype(float)
        nan_mask = np.isnan(orig_vals)
        if not np.array_equal(np.isnan(orig_vals), np.isnan(db_vals)):
            return False, f"NaN pattern mismatch in column {col}"
        non_nan = ~nan_mask
        if non_nan.any() and not np.array_equal(orig_vals[non_nan], db_vals[non_nan]):
            max_diff = float(np.max(np.abs(orig_vals[non_nan] - db_vals[non_nan])))
            return False, f"Value mismatch in column {col} (max_diff={max_diff:.2e})"

    return True, "OK"


def migrate(
    cache_dir: str,
    db_path_or_store: str | MarketStore = "",
    verify: bool = True,
    batch_size: int = 50,
    *,
    db_path: str = "",
) -> dict:
    """Run the full PKL → DuckDB migration.

    Parameters
    ----------
    db_path_or_store : str | MarketStore
        Either a path to the DuckDB file or an existing MarketStore instance.

    Returns a summary dict with counts.
    """
    pkl_files = discover_pkl_files(cache_dir)
    if not pkl_files:
        print(f"No *_full.pkl files found in {cache_dir}")
        return {"total": 0, "migrated": 0, "skipped": 0, "failed": 0}

    print(f"Found {len(pkl_files)} PKL files in {cache_dir}")

    _owns_store = False
    if isinstance(db_path_or_store, MarketStore):
        store = db_path_or_store
    else:
        resolved_path = db_path_or_store or db_path
        print(f"Target DB: {resolved_path}")
        store = MarketStore(db_path=resolved_path)
        _owns_store = True
    migrated = 0
    skipped = 0
    failed = 0
    t0 = time.time()

    batch_data: dict[str, pd.DataFrame] = {}
    batch_originals: dict[str, pd.DataFrame] = {}

    for i, pkl_path in enumerate(pkl_files, 1):
        symbol, df = load_pkl(pkl_path)
        if df is None:
            skipped += 1
        else:
            batch_data[symbol] = df
            if verify:
                batch_originals[symbol] = df

        if batch_data and (len(batch_data) >= batch_size or i == len(pkl_files)):
            try:
                written = store.upsert_bars_batch(batch_data)
                for sym in batch_data:
                    mtime = os.path.getmtime(
                        Path(cache_dir) / f"{sym}_full.pkl"
                    )
                    store.mark_refreshed(sym)
                migrated += len(batch_data)
            except Exception as e:
                print(f"  [ERROR] Batch insert failed: {e}")
                failed += len(batch_data)
                batch_data.clear()
                batch_originals.clear()
                continue

            if verify:
                for sym, orig in batch_originals.items():
                    ok, msg = verify_symbol(store, sym, orig)
                    if not ok:
                        print(f"  [VERIFY FAIL] {sym}: {msg}")
                        failed += 1
                        migrated -= 1

            batch_data.clear()
            batch_originals.clear()

            elapsed = time.time() - t0
            print(
                f"  Progress: {i}/{len(pkl_files)} files, "
                f"{migrated} migrated, {skipped} skipped, {failed} failed "
                f"({elapsed:.1f}s)",
                flush=True,
            )

    if _owns_store:
        store.close()
    elapsed = time.time() - t0
    summary = {
        "total": len(pkl_files),
        "migrated": migrated,
        "skipped": skipped,
        "failed": failed,
        "elapsed_seconds": round(elapsed, 1),
    }
    print(f"\nMigration complete: {summary}")
    return summary


def main():
    parser = argparse.ArgumentParser(description="Migrate PKL cache → DuckDB")
    parser.add_argument("--cache-dir", default="./cache", help="PKL cache directory")
    parser.add_argument("--db-path", default="cache/market.duckdb", help="DuckDB file path")
    parser.add_argument("--verify", action="store_true", default=True, help="Row-level verification")
    parser.add_argument("--no-verify", dest="verify", action="store_false")
    parser.add_argument("--batch-size", type=int, default=50)
    args = parser.parse_args()
    migrate(args.cache_dir, args.db_path, verify=args.verify, batch_size=args.batch_size)


if __name__ == "__main__":
    main()
