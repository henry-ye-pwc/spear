"""DuckDB-backed market data store.

Replaces the file-per-symbol PKL cache with a single DuckDB database file.
Provides clean APIs for bar CRUD, trading calendar, and freshness tracking.

When opening read-write, an advisory lock is taken on ``<db_path>.lock`` so
only one process can write at a time (e.g. avoid two daily_signal_job runs
conflicting on the same file).
"""
from __future__ import annotations

import os
import time
from pathlib import Path

import duckdb
import pandas as pd

try:
    import fcntl
except ImportError:
    fcntl = None  # Windows

_BAR_COLUMNS = ["open", "high", "low", "close", "volume", "amount"]


class MarketStore:
    """Central DuckDB store for daily bar data and metadata.

    Parameters
    ----------
    db_path : str
        Path to the DuckDB database file.  Use ":memory:" for tests.
    read_only : bool
        Open in read-only mode (for concurrent reader processes).
    """

    def __init__(self, db_path: str = "cache/market.duckdb", read_only: bool = False):
        self.db_path = db_path
        self.read_only = read_only
        self._lock_fd = None
        if db_path != ":memory:":
            Path(db_path).parent.mkdir(parents=True, exist_ok=True)
            if not read_only and fcntl is not None:
                lock_path = db_path + ".lock"
                self._lock_fd = open(lock_path, "a")
                fcntl.flock(self._lock_fd.fileno(), fcntl.LOCK_EX)
        self._conn = duckdb.connect(db_path, read_only=read_only)
        if not read_only:
            self._init_schema()

    def _init_schema(self) -> None:
        self._conn.execute("""
            CREATE TABLE IF NOT EXISTS daily_bars (
                symbol  VARCHAR(6) NOT NULL,
                date    DATE NOT NULL,
                open    DOUBLE,
                high    DOUBLE,
                low     DOUBLE,
                close   DOUBLE,
                volume  DOUBLE,
                amount  DOUBLE,
                PRIMARY KEY (symbol, date)
            )
        """)
        self._conn.execute("DROP TABLE IF EXISTS feature_cache")
        self._conn.execute("""
            CREATE TABLE IF NOT EXISTS symbols_meta (
                symbol          VARCHAR(6) PRIMARY KEY,
                name            VARCHAR(100),
                last_fetched_at DOUBLE,
                last_bar_date   DATE,
                bar_count       INTEGER
            )
        """)

    # ------------------------------------------------------------------
    # Bar CRUD
    # ------------------------------------------------------------------

    def upsert_bars(self, symbol: str, df: pd.DataFrame) -> int:
        """Insert or update bars for a single symbol.  Returns rows written."""
        if df is None or df.empty:
            return 0
        sym = str(symbol).zfill(6)
        insert_df = self._prepare_insert_df(sym, df)
        self._conn.execute(
            "INSERT OR REPLACE INTO daily_bars SELECT * FROM insert_df"
        )
        return len(insert_df)

    def upsert_bars_batch(self, data: dict[str, pd.DataFrame]) -> int:
        """Bulk insert bars for multiple symbols in one transaction."""
        if not data:
            return 0
        parts = []
        for symbol, df in data.items():
            if df is None or df.empty:
                continue
            parts.append(self._prepare_insert_df(str(symbol).zfill(6), df))
        if not parts:
            return 0
        combined = pd.concat(parts, ignore_index=True)
        self._conn.execute(
            "INSERT OR REPLACE INTO daily_bars SELECT * FROM combined"
        )
        return len(combined)

    def read_bars(
        self, symbol: str, start: str | None = None, end: str | None = None
    ) -> pd.DataFrame:
        """Read bars for a symbol, optionally filtered by date range.

        Returns a DataFrame with DatetimeIndex and float64 columns
        [open, high, low, close, volume, amount].
        """
        sym = str(symbol).zfill(6)
        conditions = ["symbol = ?"]
        params: list = [sym]
        if start:
            conditions.append("date >= ?")
            params.append(start)
        if end:
            conditions.append("date <= ?")
            params.append(end)
        where = " AND ".join(conditions)
        result = self._conn.execute(
            f"SELECT date, open, high, low, close, volume, amount "
            f"FROM daily_bars WHERE {where} ORDER BY date",
            params,
        ).df()
        if result.empty:
            return pd.DataFrame(columns=_BAR_COLUMNS)
        result["date"] = pd.to_datetime(result["date"])
        result = result.set_index("date")
        return result

    def read_bars_multi(
        self, symbols: list[str], start: str | None = None, end: str | None = None
    ) -> dict[str, pd.DataFrame]:
        """Bulk-read bars for multiple symbols in a single query.

        Returns {symbol: DataFrame} with float64 columns for all symbols that have data.
        """
        if not symbols:
            return {}
        syms = [str(s).zfill(6) for s in symbols]
        placeholders = ", ".join(["?"] * len(syms))
        conditions = [f"symbol IN ({placeholders})"]
        params: list = list(syms)
        if start:
            conditions.append("date >= ?")
            params.append(start)
        if end:
            conditions.append("date <= ?")
            params.append(end)
        where = " AND ".join(conditions)
        result = self._conn.execute(
            f"SELECT symbol, date, open, high, low, close, volume, amount "
            f"FROM daily_bars WHERE {where} ORDER BY symbol, date",
            params,
        ).df()
        if result.empty:
            return {}
        result["date"] = pd.to_datetime(result["date"])
        out: dict[str, pd.DataFrame] = {}
        for sym, grp in result.groupby("symbol"):
            df = grp.drop(columns=["symbol"]).set_index("date")
            out[str(sym)] = df
        return out

    # ------------------------------------------------------------------
    # Trading calendar
    # ------------------------------------------------------------------

    def trading_dates(self, up_to: str, n: int, min_coverage: int = 20) -> list[str]:
        """Return the last *n* distinct trading dates up to *up_to* (inclusive).

        Dates with fewer than *min_coverage* symbols are excluded to avoid
        ghost dates caused by stray placeholder rows in the store.
        """
        result = self._conn.execute(
            "SELECT date, COUNT(DISTINCT symbol) AS cnt FROM daily_bars "
            "WHERE date <= ? GROUP BY date HAVING cnt >= ? "
            "ORDER BY date DESC LIMIT ?",
            [up_to, min_coverage, n],
        ).fetchall()
        return sorted(str(row[0]) for row in result)

    def latest_bar_date(self, symbol: str | None = None, min_coverage: int = 20) -> str | None:
        """Latest bar date for a specific symbol, or across all symbols.

        When *symbol* is None, requires at least *min_coverage* symbols on
        that date (consistent with ``trading_dates``).
        """
        if symbol:
            row = self._conn.execute(
                "SELECT MAX(date) FROM daily_bars WHERE symbol = ?",
                [str(symbol).zfill(6)],
            ).fetchone()
        else:
            row = self._conn.execute(
                "SELECT date FROM daily_bars "
                "GROUP BY date HAVING COUNT(DISTINCT symbol) >= ? "
                "ORDER BY date DESC LIMIT 1",
                [min_coverage],
            ).fetchone()
        if row and row[0] is not None:
            return str(row[0])
        return None

    # ------------------------------------------------------------------
    # Freshness tracking
    # ------------------------------------------------------------------

    def needs_refresh(
        self,
        symbol: str,
        target_date: str,
        cooldown_seconds: int = 1800,
        latest_available: str | None = None,
    ) -> bool:
        """Determine whether a symbol needs fresh data from mootdx.

        Returns False (fresh) if:
        - The symbol's latest bar is on or after target_date, OR
        - This is a historical backtest (target_date <= latest_available) and
          the symbol was already fetched (data for past dates won't change), OR
        - The symbol's latest bar matches latest_available AND target_date is
          also at latest_available (pure catch-up case).
        Returns True (stale) when target_date is ahead of latest_available
        (new trading day — store must fetch new bars for all symbols).
        """
        sym = str(symbol).zfill(6)
        row = self._conn.execute(
            "SELECT last_bar_date, last_fetched_at FROM symbols_meta WHERE symbol = ?",
            [sym],
        ).fetchone()
        if row is None:
            return True
        last_bar, last_fetched = row
        if last_bar is None:
            return True

        if not target_date:
            return True

        target_ts = pd.Timestamp(target_date).normalize()
        bar_ts = pd.Timestamp(str(last_bar)).normalize()

        if bar_ts >= target_ts:
            return False

        if latest_available:
            latest_ts = pd.Timestamp(str(latest_available)).normalize()
            if target_ts > latest_ts:
                # New trading day: store hasn't caught up yet — need to fetch.
                # Respect cooldown to avoid hammering the API on repeated runs.
                if last_fetched is not None:
                    elapsed = time.time() - float(last_fetched)
                    if elapsed < cooldown_seconds:
                        return False
                return True
            # Historical backtest: target is in the past, data won't change.
            if target_ts <= latest_ts and last_fetched is not None:
                return False
            # Symbol lags behind other symbols in the store.
            return True

        if last_fetched is not None:
            elapsed = time.time() - float(last_fetched)
            gap_days = (target_ts - bar_ts).days
            if elapsed < cooldown_seconds and gap_days <= 3:
                return False

        return True

    def mark_refreshed(self, symbol: str, name: str | None = None) -> None:
        """Update symbols_meta after a successful fetch for *symbol*."""
        sym = str(symbol).zfill(6)
        stats = self._conn.execute(
            "SELECT MAX(date), COUNT(*) FROM daily_bars WHERE symbol = ?",
            [sym],
        ).fetchone()
        last_bar = stats[0] if stats else None
        bar_count = stats[1] if stats else 0
        now_epoch = time.time()

        existing = self._conn.execute(
            "SELECT name FROM symbols_meta WHERE symbol = ?", [sym]
        ).fetchone()
        resolved_name = name if name is not None else (existing[0] if existing else None)

        self._conn.execute(
            "DELETE FROM symbols_meta WHERE symbol = ?", [sym]
        )
        self._conn.execute(
            "INSERT INTO symbols_meta (symbol, name, last_fetched_at, last_bar_date, bar_count) "
            "VALUES (?, ?, ?, ?, ?)",
            [sym, resolved_name, now_epoch, last_bar, bar_count],
        )

    # ------------------------------------------------------------------
    # Metadata queries
    # ------------------------------------------------------------------

    def get_refresh_timestamps(self) -> dict[str, float]:
        """Return {symbol: last_fetched_at_epoch} for all tracked symbols."""
        rows = self._conn.execute(
            "SELECT symbol, last_fetched_at FROM symbols_meta "
            "WHERE last_fetched_at IS NOT NULL"
        ).fetchall()
        return {str(row[0]): float(row[1]) for row in rows}

    def symbol_count(self) -> int:
        row = self._conn.execute(
            "SELECT COUNT(DISTINCT symbol) FROM daily_bars"
        ).fetchone()
        return row[0] if row else 0

    def total_bar_count(self) -> int:
        row = self._conn.execute("SELECT COUNT(*) FROM daily_bars").fetchone()
        return row[0] if row else 0

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def close(self) -> None:
        if self._conn:
            self._conn.close()
            self._conn = None  # type: ignore[assignment]
        if self._lock_fd is not None:
            try:
                if fcntl is not None:
                    fcntl.flock(self._lock_fd.fileno(), fcntl.LOCK_UN)
            finally:
                self._lock_fd.close()
                self._lock_fd = None

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _prepare_insert_df(symbol: str, df: pd.DataFrame) -> pd.DataFrame:
        """Normalize a bars DataFrame into the flat schema for INSERT."""
        out = df.copy()
        if isinstance(out.index, pd.DatetimeIndex):
            out = out.reset_index()
            date_col = out.columns[0]
            out = out.rename(columns={date_col: "date"})
        out["date"] = pd.to_datetime(out["date"]).dt.date
        out["symbol"] = symbol
        for col in _BAR_COLUMNS:
            if col not in out.columns:
                out[col] = None
        return out[["symbol", "date"] + _BAR_COLUMNS]
