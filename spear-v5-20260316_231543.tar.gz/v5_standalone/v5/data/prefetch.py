"""Parallel data prefetch using ProcessPoolExecutor.

The mootdx/tdxpy data-fetching stack does heavy Python-level byte parsing
that holds the GIL, making ThreadPoolExecutor *slower* than serial for
network I/O.  ProcessPoolExecutor bypasses the GIL entirely, giving 4-5x
speedup in practice (verified via POC).

Usage:
    prefetch_symbols(symbols, cache_dir, end_date, workers=4)

Each worker process creates its own mootdx connection and fetches data
into the PKL cache.  When a MarketStore is provided, the main process
syncs updated PKL files into DuckDB after all workers finish.
"""
from __future__ import annotations

import os
import time
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path


def _worker_fetch_batch(
    symbols: list[str],
    cache_dir: str,
    end_date: str | None,
    count: int,
    cache_only: bool,
    force_refresh: bool = False,
    worker_id: int = 0,
    total_symbols: int = 0,
) -> dict:
    """Run inside a worker process.  Creates its own DataFeed + connection.
    Writes to PKL cache on disk."""
    from cq_backtest.data.feed import DataFeed

    feed = DataFeed(cache_dir=cache_dir)
    fetched = 0
    cached = 0
    errors = 0
    error_syms: list[str] = []
    for i, sym in enumerate(symbols):
        try:
            feed.get_kline(sym, end_date=end_date, count=count,
                           cache_only=cache_only, force_refresh=force_refresh)
            pkl = os.path.join(cache_dir, f"{sym}_full.pkl")
            if os.path.exists(pkl):
                fetched += 1
            else:
                error_syms.append(sym)
                cached += 1
        except Exception as exc:
            errors += 1
            error_syms.append(sym)
        done = i + 1
        if done % 100 == 0 or done == len(symbols):
            print(f"[fetch] w{worker_id}: {done}/{len(symbols)}", flush=True)
    try:
        if feed.client is not None:
            feed.client.close()
    except Exception:
        pass
    return {"fetched": fetched, "cached": cached, "errors": errors, "error_syms": error_syms}


def _sync_pkl_to_duckdb(store, symbols: list[str], cache_dir: str, cleanup: bool = False) -> int:
    """Incrementally sync PKL files into DuckDB.

    Only reads PKL files whose mtime is newer than the last sync timestamp
    stored in DuckDB's symbols_meta.last_fetched_at.  This reduces the sync
    cost from O(all_symbols) to O(changed_symbols).

    If *cleanup* is True, successfully synced PKL files are deleted.
    """
    import pandas as pd

    BATCH_SIZE = 100
    synced = 0
    batch: dict[str, pd.DataFrame] = {}
    synced_paths: list[str] = []

    last_fetched = store.get_refresh_timestamps()

    for sym in symbols:
        sym_padded = str(sym).zfill(6)
        pkl_path = os.path.join(cache_dir, f"{sym_padded}_full.pkl")
        if not os.path.exists(pkl_path):
            continue
        pkl_mtime = os.path.getmtime(pkl_path)
        if sym_padded in last_fetched and pkl_mtime <= last_fetched[sym_padded]:
            if cleanup:
                synced_paths.append(pkl_path)
            continue
        try:
            df = pd.read_pickle(pkl_path)
            if df is not None and not df.empty:
                batch[sym] = df
                synced_paths.append(pkl_path)
        except Exception:
            continue
        if len(batch) >= BATCH_SIZE:
            store.upsert_bars_batch(batch)
            for s in batch:
                store.mark_refreshed(str(s).zfill(6))
            synced += len(batch)
            batch = {}

    if batch:
        store.upsert_bars_batch(batch)
        for s in batch:
            store.mark_refreshed(str(s).zfill(6))
        synced += len(batch)

    if cleanup and synced_paths:
        removed = 0
        for p in synced_paths:
            try:
                os.remove(p)
                removed += 1
            except OSError:
                pass
        if removed:
            print(f"[sync]  cleaned up {removed} PKL files", flush=True)

    return synced


def prefetch_symbols(
    symbols: list[str],
    cache_dir: str,
    end_date: str | None = None,
    count: int = 900,
    workers: int = 4,
    cache_only: bool = False,
    force_refresh: bool = False,
    store=None,
) -> dict:
    """Warm cache for *symbols* using parallel processes.

    Parameters
    ----------
    symbols : list[str]
        Stock codes (6-digit strings).
    cache_dir : str
        Path to the mootdx PKL cache directory.
    end_date : str | None
        Target end date (YYYY-MM-DD).  Passed to DataFeed.get_kline().
    count : int
        Number of bars to request per symbol.
    workers : int
        Number of parallel worker processes.
    cache_only : bool
        If True, skip network fetches and only use local cache.
    force_refresh : bool
        If True, bypass cache and do a full history re-fetch for every symbol.
    store : MarketStore | None
        If provided, PKL data is synced into DuckDB after workers finish and
        the DuckDB freshness filter skips already-fresh symbols.

    Returns
    -------
    dict with keys: total, elapsed_s, fetched, errors, workers_used.
    """
    if not symbols:
        return {"total": 0, "elapsed_s": 0, "fetched": 0, "errors": 0, "workers_used": 0}

    use_duckdb = store is not None
    all_symbols: list[str] = list(symbols)

    # In DuckDB mode, sync existing PKL data into DuckDB first (catches
    # migration gaps where DuckDB has stale data), then skip symbols whose
    # data is already fresh.
    skipped_fresh = 0
    if use_duckdb and end_date and not force_refresh and not cache_only:
        t_pre = time.monotonic()
        pre_synced = _sync_pkl_to_duckdb(store, all_symbols, cache_dir)
        sync_elapsed = time.monotonic() - t_pre
        if pre_synced:
            print(f"[sync]  PKL → DuckDB: {pre_synced} symbols ({sync_elapsed:.1f}s)", flush=True)
        elif sync_elapsed > 0.5:
            print(f"[sync]  PKL → DuckDB: up-to-date ({sync_elapsed:.1f}s)", flush=True)

        latest_available = store.latest_bar_date()
        stale = []
        for sym in symbols:
            if store.needs_refresh(str(sym).zfill(6), end_date, latest_available=latest_available):
                stale.append(sym)
        skipped_fresh = len(symbols) - len(stale)
        if skipped_fresh > 0:
            print(f"[fetch] {skipped_fresh} fresh, {len(stale)} stale", flush=True)
        symbols = stale
        if not symbols:
            return {"total": skipped_fresh, "elapsed_s": 0, "fetched": 0, "errors": 0, "workers_used": 0, "skipped_fresh": skipped_fresh}

    if cache_only or workers <= 1:
        t0 = time.monotonic()
        result = _worker_fetch_batch(symbols, cache_dir, end_date, count, cache_only, force_refresh)
        fetched = result["fetched"]
        if use_duckdb:
            synced = _sync_pkl_to_duckdb(store, symbols, cache_dir, cleanup=True)
            if synced:
                print(f"[sync]  post-fetch: {synced} symbols", flush=True)
        elapsed = time.monotonic() - t0
        return {
            "total": len(symbols),
            "elapsed_s": round(elapsed, 1),
            "fetched": fetched,
            "errors": result["errors"],
            "workers_used": 1,
        }

    Path(cache_dir).mkdir(parents=True, exist_ok=True)
    n = min(workers, len(symbols))

    batches: list[list[str]] = [[] for _ in range(n)]
    for i, sym in enumerate(symbols):
        batches[i % n].append(sym)

    print(f"[fetch] fetching {len(symbols)} symbols ({n}w) ...", flush=True)
    t0 = time.monotonic()

    totals = {"fetched": 0, "cached": 0, "errors": 0}
    all_error_syms: list[str] = []

    with ProcessPoolExecutor(max_workers=n) as pool:
        futures = {
            pool.submit(
                _worker_fetch_batch, batch, cache_dir, end_date, count,
                cache_only, force_refresh, worker_id=i, total_symbols=len(symbols),
            ): i
            for i, batch in enumerate(batches)
        }
        for future in as_completed(futures):
            idx = futures[future]
            try:
                result = future.result(timeout=600)
                totals["fetched"] += result["fetched"]
                totals["cached"] += result["cached"]
                totals["errors"] += result["errors"]
                all_error_syms.extend(result.get("error_syms", []))
            except Exception as exc:
                print(f"[prefetch] Worker {idx} failed: {exc}", flush=True)
                totals["errors"] += len(batches[idx])
                all_error_syms.extend(batches[idx])

    elapsed_fetch = time.monotonic() - t0
    parts = [f"{totals['fetched']} updated"]
    if totals["errors"]:
        parts.append(f"{totals['errors']} errors")
    if all_error_syms:
        parts.append(f"{len(all_error_syms)} failed")
    print(f"[fetch] {' / '.join(parts)} ({elapsed_fetch:.1f}s, {n}w)", flush=True)

    if use_duckdb:
        t_sync = time.monotonic()
        synced = _sync_pkl_to_duckdb(store, symbols, cache_dir, cleanup=True)
        if synced:
            print(f"[sync]  post-fetch: {synced} symbols ({time.monotonic() - t_sync:.1f}s)", flush=True)

    elapsed = time.monotonic() - t0
    return {
        "total": len(symbols),
        "elapsed_s": round(elapsed, 1),
        "fetched": totals["fetched"],
        "errors": totals["errors"],
        "workers_used": n,
        "error_syms": sorted(all_error_syms),
    }
