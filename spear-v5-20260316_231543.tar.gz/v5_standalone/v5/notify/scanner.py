from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field
from datetime import datetime, UTC

import pandas as pd

from v5.backtest.prepare import PreparedBundle
from v5.notify.audit import append_audit
from v5.notify.models import ClosedTrade, MarketContext, PendingHuntItem, PositionSummary, SignalSnapshot, TradeSummary, WatchItem
from v5.notify.oracle_constants import get_oracle, path_hint as compute_path_hint, peer_lift_hint as compute_peer_lift, peer_tier as compute_peer_tier
from v5.notify.state import make_watch_key


@dataclass(slots=True)
class NotificationSnapshot:
    as_of_date: str
    new_signals: list[SignalSnapshot]
    watch_updates: list[WatchItem]
    dropped: list[WatchItem]
    today_entries: list[TradeSummary] = field(default_factory=list)
    today_exits: list[TradeSummary] = field(default_factory=list)
    active_positions: list[PositionSummary] = field(default_factory=list)
    closed_trades: list[ClosedTrade] = field(default_factory=list)
    pending_hunts: list[PendingHuntItem] = field(default_factory=list)
    pending_sell_hunts: list[dict] = field(default_factory=list)
    portfolio_equity: float = 0.0
    portfolio_cash: float = 0.0
    portfolio_exposure_pct: float = 0.0
    market_context: MarketContext | None = None
    mode: str = "confirmed"
    hint: str = ""

    def to_dict(self) -> dict:
        return {
            "as_of_date": self.as_of_date,
            "new_signals": [x.to_dict() for x in self.new_signals],
            "watch_updates": [x.to_dict() for x in self.watch_updates],
            "dropped": [x.to_dict() for x in self.dropped],
            "today_entries": [x.to_dict() for x in self.today_entries],
            "today_exits": [x.to_dict() for x in self.today_exits],
            "active_positions": [x.to_dict() for x in self.active_positions],
            "closed_trades": [x.to_dict() for x in self.closed_trades],
            "pending_hunts": [x.to_dict() for x in self.pending_hunts],
            "pending_sell_hunts": self.pending_sell_hunts,
            "portfolio_equity": self.portfolio_equity,
            "portfolio_cash": self.portfolio_cash,
            "portfolio_exposure_pct": self.portfolio_exposure_pct,
            "market_context": self.market_context.to_dict() if self.market_context else None,
            "mode": self.mode,
            "hint": self.hint,
        }


def _safe_int(value: object) -> int:
    if value is None or pd.isna(value):
        return 0
    return int(value)


def _safe_float(value: object) -> float | None:
    if value is None or pd.isna(value):
        return None
    return float(value)


def _build_snapshot(bundle: PreparedBundle, symbol: str, date: str, event) -> SignalSnapshot:
    frame = bundle.feature_data[symbol]
    idx = bundle.idx_by_symbol_date[symbol][date]
    cur = frame.iloc[idx]
    ctx = dict(event.context)
    name = ""
    matched = bundle.universe[bundle.universe["symbol"].astype(str).str.zfill(6) == symbol]
    if not matched.empty:
        name = str(matched.iloc[0].get("name") or "")
    close_val = float(cur["close"])
    gate_val = _safe_float(event.entry_plan.get("gate_price"))
    inv_val = _safe_float(event.invalidation.get("price"))
    et = str(event.event_type)
    peer_val = _safe_int(ctx.get("peer_confirmation"))

    gate_gap = max(0.0, gate_val / close_val - 1.0) if gate_val and close_val > 0 else 0.0
    stop_gap = inv_val / close_val - 1.0 if inv_val and close_val > 0 else 0.0
    oracle = get_oracle(et)
    adj_pot = oracle.get("oracle_gap", 0.15) - gate_gap

    return SignalSnapshot(
        symbol=symbol,
        name=name,
        event_type=et,
        signal_date=date,
        signal_confidence=float(event.confidence),
        entry_style=str(event.entry_plan.get("style", "")),
        gate_price=gate_val,
        invalidation_price=inv_val,
        signal_close=close_val,
        signal_high=float(cur["high"]),
        signal_low=float(cur["low"]),
        theme_label=str(ctx.get("theme_label") or "其他"),
        peer_confirmation=peer_val,
        leader_strength=_safe_int(ctx.get("leader_strength")),
        sector_hot=bool(ctx.get("sector_hot", False)),
        gate_gap_pct=round(gate_gap, 4),
        stop_gap_pct=round(stop_gap, 4),
        adj_potential=round(adj_pot, 4),
        peer_tier=compute_peer_tier(peer_val),
        outcome_dist=dict(oracle.get("outcome_dist", {})),
        peer_lift_hint=compute_peer_lift(et, peer_val),
        spear_role=str(ctx.get("spear_role", "")),
        multi_spear_count=_safe_int(ctx.get("multi_spear_count")),
    )


def collect_new_signals(bundle: PreparedBundle, as_of_date: str) -> list[SignalSnapshot]:
    out: list[SignalSnapshot] = []
    for (symbol, date), events in bundle.events_by_symbol_date.items():
        if date != as_of_date:
            continue
        for event in events:
            if event.side != "long":
                continue
            out.append(_build_snapshot(bundle, symbol, date, event))
    out.sort(
        key=lambda x: (
            x.signal_confidence,
            1 if x.event_type in {"trend_spear", "post_limit", "failed_board"} else 0,
            x.peer_confirmation,
            x.leader_strength,
        ),
        reverse=True,
    )
    return out


def _priority(item: WatchItem) -> str:
    if item.status_label == "Chase Candidate":
        return "A级"
    oracle = get_oracle(item.event_type)
    if oracle.get("peer_lift_stable") and item.peer_tier == "high":
        return "A级"
    if item.event_type in {"attack", "arb"} and item.peer_tier in {"high", "mid"}:
        return "B级"
    if item.event_type in {"trend_spear", "post_limit"}:
        return "B级"
    return "C级"


def _status(item: WatchItem, escape_today: bool) -> tuple[str, bool, str]:
    if escape_today:
        return "失效", False, "出现 escape 风险信号"
    if item.invalidation_price is not None and item.obs_day > 0 and item.latest_low <= item.invalidation_price:
        return "失效", False, "跌破失效位"
    if item.obs_day > 5:
        return "观察结束", False, "超过观察窗口"
    if item.obs_day >= 2 and (not item.hunt_touched) and item.close_ret_since_signal >= 0.03 and item.new_same_side_signal:
        return "Chase Candidate", True, "未回踩但持续强于信号价，且同向信号刷新"
    if item.close_ret_since_signal >= 0.03:
        return "继续强", True, "收盘相对信号日明显走强"
    if item.close_ret_since_signal <= -0.03:
        return "转弱", True, "收盘明显弱于信号日"
    return "继续有效", True, "仍在有效结构内"


def update_watch_state(
    *,
    bundle: PreparedBundle,
    as_of_date: str,
    current_state: dict[str, WatchItem],
    hunt_buffer_pct: float = 0.005,
    watch_window_days: int = 5,
    state_dir: str | None = None,
) -> NotificationSnapshot:
    dates_index = {
        symbol: {date: idx for date, idx in idx_map.items()}
        for symbol, idx_map in bundle.idx_by_symbol_date.items()
    }
    new_signals = collect_new_signals(bundle, as_of_date)
    state = dict(current_state)
    updates: list[WatchItem] = []
    dropped: list[WatchItem] = []

    _watch_fields = {f.name for f in WatchItem.__dataclass_fields__.values()}
    for snap in new_signals:
        key = make_watch_key(snap.symbol, snap.event_type, snap.signal_date)
        if key not in state:
            snap_dict = {k: v for k, v in asdict(snap).items() if k in _watch_fields}
            state[key] = WatchItem(**snap_dict)

    for key, item in list(state.items()):
        idx_map = dates_index.get(item.symbol)
        if not idx_map or item.signal_date not in idx_map or as_of_date not in idx_map:
            continue
        if as_of_date < item.signal_date:
            continue
        frame = bundle.feature_data[item.symbol]
        start_idx = idx_map[item.signal_date]
        end_idx = idx_map[as_of_date]
        if end_idx < start_idx:
            continue
        path = frame.iloc[start_idx : end_idx + 1]
        latest = path.iloc[-1]
        item.obs_day = max(0, len(path) - 1)
        item.latest_date = as_of_date
        item.latest_close = float(latest["close"])
        item.latest_high = float(latest["high"])
        item.latest_low = float(latest["low"])
        item.close_ret_since_signal = float(item.latest_close / item.signal_close - 1.0)
        item.max_ret_since_signal = float(path["high"].max() / item.signal_close - 1.0)
        target = item.gate_price if item.entry_style == "breakout" and item.gate_price is not None else item.signal_close
        lower = target * (1.0 - hunt_buffer_pct)
        upper = target * (1.0 + hunt_buffer_pct)
        future = path.iloc[1:] if len(path) > 1 else path.iloc[0:0]
        item.hunt_touched = bool(not future.empty and (((future["low"] <= upper) & (future["high"] >= lower)).any()))
        item.drawdown_from_peak = round(max(0.0, item.max_ret_since_signal - item.close_ret_since_signal), 4)
        prev_max = max((h.get("max_ret_since_signal", 0.0) for h in item.history), default=0.0)
        if item.max_ret_since_signal > prev_max + 1e-6:
            item.days_since_peak = 0
        elif item.history:
            item.days_since_peak = item.history[-1].get("days_since_peak", 0) + 1 if "days_since_peak" in (item.history[-1] if item.history else {}) else item.obs_day
        if item.gate_price and item.gate_price > 0:
            item.close_vs_gate_pct = round(item.latest_close / item.gate_price - 1.0, 4)
        item.path_hint = compute_path_hint(
            close_ret=item.close_ret_since_signal,
            max_ret=item.max_ret_since_signal,
            drawdown=item.drawdown_from_peak,
        )
        item.new_same_side_signal = any(
            ev.event_type == item.event_type and ev.side == "long"
            for ev in bundle.events_by_symbol_date.get((item.symbol, as_of_date), [])
            if as_of_date > item.signal_date
        )
        escape_today = any(
            ev.event_type == "escape"
            for ev in bundle.events_by_symbol_date.get((item.symbol, as_of_date), [])
        )
        status, active, note = _status(item, escape_today)
        if item.obs_day > watch_window_days and active:
            status, active, note = "观察结束", False, "超过观察窗口"
        item.status_label = status
        item.active = active
        item.note = note
        item.priority_rank = _priority(item)
        item.history.append(
            {
                "date": as_of_date,
                "status": item.status_label,
                "close_ret_since_signal": round(item.close_ret_since_signal, 4),
                "max_ret_since_signal": round(item.max_ret_since_signal, 4),
                "hunt_touched": item.hunt_touched,
                "note": item.note,
                "days_since_peak": item.days_since_peak,
                "drawdown_from_peak": item.drawdown_from_peak,
                "path_hint": item.path_hint,
            }
        )
        if active:
            updates.append(item)
        else:
            dropped.append(item)
            state.pop(key, None)

    updates.sort(key=lambda x: (x.priority_rank, x.signal_confidence, x.max_ret_since_signal), reverse=False)
    dropped.sort(key=lambda x: (x.signal_date, x.symbol))

    if state_dir is not None:
        now = datetime.now(UTC).isoformat()
        audit_records: list[dict] = []
        for snap in new_signals:
            audit_records.append({
                "ts": now, "date": as_of_date, "action": "new",
                "symbol": snap.symbol, "event_type": snap.event_type,
                "confidence": snap.signal_confidence,
            })
        for item in updates:
            audit_records.append({
                "ts": now, "date": as_of_date, "action": "update",
                "symbol": item.symbol, "event_type": item.event_type,
                "status": item.status_label, "obs_day": item.obs_day,
                "close_ret": round(item.close_ret_since_signal, 4),
            })
        for item in dropped:
            audit_records.append({
                "ts": now, "date": as_of_date, "action": "drop",
                "symbol": item.symbol, "event_type": item.event_type,
                "status": item.status_label,
                "final_ret": round(item.close_ret_since_signal, 4),
            })
        append_audit(state_dir, audit_records)

    return NotificationSnapshot(as_of_date=as_of_date, new_signals=new_signals, watch_updates=updates, dropped=dropped), state


def snapshot_to_json(snapshot: NotificationSnapshot) -> str:
    return json.dumps(snapshot.to_dict(), ensure_ascii=False, indent=2)


def _estimate_future_date(base_date: str, trading_days: int) -> str:
    """Estimate a future date by adding N trading days (skip weekends)."""
    from datetime import date as _date, timedelta
    try:
        d = _date.fromisoformat(base_date)
    except Exception:
        return base_date
    added = 0
    while added < trading_days:
        d += timedelta(days=1)
        if d.weekday() < 5:
            added += 1
    return d.isoformat()


def enrich_snapshot_with_trades(
    snapshot: NotificationSnapshot,
    artifacts,
    effective_date: str,
    watch_window_days: int = 5,
) -> None:
    """Populate trade-related fields on snapshot from mini-backtest artifacts.

    Mutates *snapshot* in-place. ``artifacts`` is a ``V5RunArtifacts`` instance.
    """
    result = artifacts.result
    bundle = artifacts.bundle
    universe_names: dict[str, str] = {}
    if bundle.universe is not None and not bundle.universe.empty:
        for _, row in bundle.universe.iterrows():
            universe_names[str(row["symbol"]).zfill(6)] = str(row.get("name") or "")

    equity_curve = artifacts.equity_curve
    final_equity = float(equity_curve.iloc[-1]) if equity_curve is not None and len(equity_curve) else 0.0
    final_cash = float(artifacts.result.summary.get("final_cash", 0.0))

    snapshot.portfolio_equity = round(final_equity, 2)
    snapshot.portfolio_cash = round(final_cash, 2)
    snapshot.portfolio_exposure_pct = round((1.0 - final_cash / final_equity) * 100, 1) if final_equity > 0 else 0.0

    # Build trade index: symbol -> list of trade dicts
    buy_index: dict[str, list[dict]] = {}
    for t in result.trades:
        sym = str(t["symbol"]).zfill(6)
        buy_index.setdefault(sym, []).append(t)

    # Today's entries and exits from trade log
    today_entry_syms: set[str] = set()
    today_exit_syms: set[str] = set()
    for t in result.trades:
        if t["date"] != effective_date:
            continue
        sym = str(t["symbol"]).zfill(6)
        meta = json.loads(t.get("meta", "{}")) if isinstance(t.get("meta"), str) else (t.get("meta") or {})
        ts = TradeSummary(
            symbol=sym,
            name=universe_names.get(sym, ""),
            action=t["action"],
            price=float(t["price"]),
            qty=float(t["qty"]),
            reason=t.get("reason", ""),
            signal_date=meta.get("signal_date", ""),
            signal_type=meta.get("style", ""),
            pnl_pct=None,
            holding_days=None,
            position_pct=round(float(t["price"]) * float(t["qty"]) / final_equity * 100, 1) if final_equity > 0 else 0.0,
        )
        if t["action"] == "buy":
            snapshot.today_entries.append(ts)
            today_entry_syms.add(sym)
        else:
            snapshot.today_exits.append(ts)
            today_exit_syms.add(sym)

    # Supplement: detect today entries from strategy trade_log not captured above
    strategy = getattr(artifacts, "strategy", None)
    trade_log = getattr(strategy, "trade_log", []) if strategy else []
    for t in trade_log:
        if t.get("date") != effective_date or t.get("action") != "buy":
            continue
        sym = str(t["symbol"]).zfill(6)
        if sym in today_entry_syms:
            continue
        meta = json.loads(t.get("meta", "{}")) if isinstance(t.get("meta"), str) else (t.get("meta") or {})
        fill_qty = float(t["qty"])
        fill_price = float(t["price"])
        reason = t.get("reason", "")
        snapshot.today_entries.append(TradeSummary(
            symbol=sym,
            name=universe_names.get(sym, ""),
            action="buy",
            price=fill_price,
            qty=fill_qty,
            reason=reason,
            signal_date="",
            signal_type=meta.get("style", reason.replace("entry:", "")),
            pnl_pct=None,
            holding_days=None,
            position_pct=round(fill_price * fill_qty / final_equity * 100, 1) if final_equity > 0 else 0.0,
        ))
        today_entry_syms.add(sym)

    # Active positions
    for pos in result.open_positions:
        sym = str(pos["symbol"]).zfill(6)
        entry_price = float(pos.get("entry_price", 0))
        current_price = float(pos.get("last_close", 0))
        pnl = float(pos.get("unrealized_pnl", 0))
        pnl_pct = round((current_price / entry_price - 1.0) * 100, 2) if entry_price > 0 else 0.0
        entry_date = str(pos.get("entry_date", ""))
        days_held = 0
        if entry_date and effective_date:
            idx_map = bundle.idx_by_symbol_date.get(sym)
            if idx_map and entry_date in idx_map and effective_date in idx_map:
                days_held = idx_map[effective_date] - idx_map[entry_date]
            else:
                try:
                    days_held = (pd.Timestamp(effective_date) - pd.Timestamp(entry_date)).days
                except Exception:
                    pass
        entry_lu = pos.get("entry_limit_up")
        snapshot.active_positions.append(PositionSummary(
            symbol=sym,
            name=universe_names.get(sym, ""),
            entry_date=entry_date,
            entry_price=round(entry_price, 4),
            current_price=round(current_price, 4),
            qty=float(pos.get("qty", 0)),
            unrealized_pnl=round(pnl, 2),
            unrealized_pnl_pct=pnl_pct,
            days_held=days_held,
            source_event=str(pos.get("source_event", "")),
            entry_limit_up=round(float(entry_lu), 4) if entry_lu is not None else None,
        ))

    # Build closed (round-trip) trades by FIFO matching buy→sell
    open_buys: dict[str, list[dict]] = {}
    for t in result.trades:
        sym = str(t["symbol"]).zfill(6)
        if t["action"] == "buy":
            open_buys.setdefault(sym, []).append(t)
        elif t["action"] == "sell" and sym in open_buys and open_buys[sym]:
            buy = open_buys[sym].pop(0)
            buy_price = float(buy["price"])
            sell_price = float(t["price"])
            qty = float(buy["qty"])
            pnl_pct = round((sell_price / buy_price - 1.0) * 100, 2) if buy_price > 0 else 0.0
            days = 0
            idx_map = bundle.idx_by_symbol_date.get(sym)
            if idx_map and buy["date"] in idx_map and t["date"] in idx_map:
                days = idx_map[t["date"]] - idx_map[buy["date"]]
            else:
                try:
                    days = (pd.Timestamp(t["date"]) - pd.Timestamp(buy["date"])).days
                except Exception:
                    pass
            buy_meta = json.loads(buy.get("meta", "{}")) if isinstance(buy.get("meta"), str) else (buy.get("meta") or {})
            snapshot.closed_trades.append(ClosedTrade(
                symbol=sym,
                name=universe_names.get(sym, ""),
                buy_date=buy["date"],
                buy_price=round(buy_price, 4),
                sell_date=t["date"],
                sell_price=round(sell_price, 4),
                qty=qty,
                pnl_pct=pnl_pct,
                holding_days=days,
                reason=t.get("reason", ""),
                source_event=buy_meta.get("style", ""),
                buy_limit_up=round(float(buy["limit_up"]), 4) if buy.get("limit_up") is not None else None,
                sell_limit_down=round(float(t["limit_down"]), 4) if t.get("limit_down") is not None else None,
            ))
    snapshot.closed_trades.sort(key=lambda x: x.sell_date, reverse=True)

    # Cross-reference trades with signals/watch items
    # For new signals: only match trades on or after the signal date
    # For watch/dropped: match trades on or after the signal date
    traded_by_sym: dict[str, list[dict]] = {}
    for t in result.trades:
        if t["action"] == "buy":
            sym = str(t["symbol"]).zfill(6)
            traded_by_sym.setdefault(sym, []).append(t)

    for sig in snapshot.new_signals:
        sym = sig.symbol
        for t in traded_by_sym.get(sym, []):
            if t["date"] >= sig.signal_date:
                sig.traded = True
                sig.trade_price = float(t["price"])
                sig.trade_date = t["date"]
                break
        if sig.gate_price is not None and sig.signal_close > 0:
            distance = abs(sig.signal_close - sig.gate_price) / sig.signal_close
            sig.near_gate = distance <= 0.01

    for w in snapshot.watch_updates:
        sym = w.symbol
        for t in traded_by_sym.get(sym, []):
            if t["date"] >= w.signal_date:
                w.traded = True
                w.trade_price = float(t["price"])
                w.trade_date = t["date"]
                break
        w.days_to_expiry = max(0, watch_window_days - w.obs_day)

    for d in snapshot.dropped:
        sym = d.symbol
        for t in traded_by_sym.get(sym, []):
            if t["date"] >= d.signal_date:
                d.traded = True
                d.trade_price = float(t["price"])
                d.trade_date = t["date"]
                break

    # Extract pending hunts from the state machine
    sm = getattr(artifacts, "state_machine", None)
    if sm is not None:
        dates_list = sorted(bundle.dates_by_symbol.get(list(bundle.dates_by_symbol.keys())[0], []) if bundle.dates_by_symbol else [])
        def _idx_to_date(idx: int) -> str:
            if 0 <= idx < len(dates_list):
                return dates_list[idx]
            return effective_date

        for sym, hunt in getattr(sm, "pending_hunts", {}).items():
            name = universe_names.get(sym, "")
            expired = False
            status = "等待触发"
            try:
                if hasattr(hunt, "valid_until_idx"):
                    last_date_idx = len(dates_list) - 1
                    if last_date_idx > hunt.valid_until_idx:
                        expired = True
                        status = "已过期"
            except Exception:
                pass
            blocked_date = str(getattr(hunt, "last_blocked_date", ""))
            pos_blocked = bool(blocked_date)
            if pos_blocked and not expired:
                status = f"仓位已满，{blocked_date} 曾触发"
            snapshot.pending_hunts.append(PendingHuntItem(
                symbol=sym,
                name=name,
                source_event=str(getattr(hunt, "source_event", "")),
                target_price=round(float(getattr(hunt, "target_price", 0)), 4),
                buffer_pct=float(getattr(hunt, "buffer_pct", 0)),
                invalidate_price=round(float(getattr(hunt, "invalidate_price", 0)), 4),
                take_profit_pct=float(getattr(hunt, "take_profit_pct", 0)),
                entry_style=str(getattr(hunt, "entry_style", "")),
                position_mult=float(getattr(hunt, "position_mult", 1.0)),
                created_date=_idx_to_date(getattr(hunt, "created_idx", 0)),
                valid_from_date=_idx_to_date(getattr(hunt, "valid_from_idx", 0)),
                valid_until_date=f"还剩 {max(0, getattr(hunt, 'valid_until_idx', 0) - (len(dates_list) - 1))} 天",
                expired=expired,
                status=status,
                confidence=float(getattr(hunt, "confidence", 0)),
                position_blocked=pos_blocked,
                blocked_date=blocked_date,
            ))

        for sym, sh in getattr(sm, "pending_sell_hunts", {}).items():
            name = universe_names.get(sym, "")
            snapshot.pending_sell_hunts.append({
                "symbol": sym,
                "name": name,
                "target_price": round(float(getattr(sh, "target_price", 0)), 4),
                "reason": str(getattr(sh, "reason", "")),
                "valid_until_date": _idx_to_date(getattr(sh, "valid_until_idx", 0)),
                "source_event": str(getattr(sh, "source_event", "")),
            })

    # Market context
    sector_counts: dict[str, int] = {}
    for sig in snapshot.new_signals:
        label = sig.theme_label or "其他"
        sector_counts[label] = sector_counts.get(label, 0) + 1

    pos_sectors: dict[str, int] = {}
    if bundle.env:
        for pos in snapshot.active_positions:
            meta = bundle.env.get_symbol_meta(pos.symbol)
            label = str(meta.get("industry") or "其他")
            pos_sectors[label] = pos_sectors.get(label, 0) + 1

    total_watched = len(snapshot.watch_updates) + len(snapshot.dropped)
    total_traded = sum(1 for w in snapshot.watch_updates if w.traded) + sum(1 for d in snapshot.dropped if d.traded)
    conversion = total_traded / total_watched if total_watched > 0 else 0.0

    # Health monitor: check expired signals against oracle expectations
    expired_max_rets = [
        d.max_ret_since_signal for d in snapshot.dropped
        if d.status_label in {"观察结束", "失效"} and d.obs_day >= 3
    ]
    recent_expired_count = len(expired_max_rets)
    recent_actual_dud = sum(1 for r in expired_max_rets if r < 0.03) / max(1, recent_expired_count)
    recent_actual_hit10 = sum(1 for r in expired_max_rets if r >= 0.10) / max(1, recent_expired_count)
    signal_health = "normal"
    if recent_expired_count >= 5:
        avg_oracle_dud = 0.18
        avg_oracle_hit10 = 0.55
        if recent_actual_dud > avg_oracle_dud * 1.5 or recent_actual_hit10 < avg_oracle_hit10 * 0.7:
            signal_health = "degraded"

    snapshot.market_context = MarketContext(
        sector_signal_counts=sector_counts,
        signal_density=len(snapshot.new_signals),
        trailing_5d_avg_density=0.0,
        conversion_rate=round(conversion, 3),
        portfolio_concentration=pos_sectors,
        signal_health=signal_health,
        recent_expired_count=recent_expired_count,
        recent_actual_dud_rate=round(recent_actual_dud, 3),
        recent_actual_hit10_rate=round(recent_actual_hit10, 3),
    )

