from __future__ import annotations

from typing import Any

from v5.notify.models import SignalSnapshot, WatchItem
from v5.notify.scanner import NotificationSnapshot


def _fmt_pct(value: float) -> str:
    return f"{value * 100:.1f}%"


def _fmt_price(value: float | None) -> str:
    return "-" if value is None else f"{value:.2f}"


def _clean(name: str | None) -> str:
    """Strip null chars and whitespace from stock names."""
    if not name:
        return ""
    return name.replace("\x00", "").strip()


EXIT_REASON_DISPLAY: dict[str, str] = {
    "time_exit": "观察期满",
    "stop_loss": "触发止损",
    "take_profit": "触发止盈",
    "vol_exhaustion": "放量异常退出",
    "trend_drawdown_exit": "回撤过深退出",
    "trend_stale_exit": "横盘过久退出",
    "invalidation": "破位退出",
}


def _human_reason(reason: str) -> str:
    return EXIT_REASON_DISPLAY.get(reason, reason)



def render_markdown_summary(
    *,
    snapshot: NotificationSnapshot,
    watch_window_days: int,
    execution_profile: str,
    push_top_new: int = 3,
    push_top_watch: int = 5,
    push_top_drops: int = 5,
    min_confidence: float = 0.0,
) -> str:
    all_new = [s for s in snapshot.new_signals if s.signal_confidence >= min_confidence] if min_confidence > 0 else snapshot.new_signals
    new_count = len(all_new)
    watch_count = len(snapshot.watch_updates)
    chase_count = sum(1 for x in snapshot.watch_updates if x.status_label == "Chase Candidate")
    drop_count = len(snapshot.dropped)

    from v5.notify.oracle_constants import get_oracle

    top_new = all_new[:push_top_new]
    top_watch = snapshot.watch_updates[:push_top_watch]
    top_drops = snapshot.dropped[:push_top_drops]
    pos_count = len(snapshot.active_positions)
    has_trades = bool(snapshot.today_entries or snapshot.today_exits)
    new_hunts = [h for h in snapshot.pending_hunts if h.created_date == snapshot.as_of_date]

    lines: list[str] = []
    if snapshot.mode == "preview" and snapshot.hint:
        lines.append(f"[{snapshot.hint}]")
        lines.append("")

    summary = [f"{new_count} 个新信号"]
    if pos_count:
        summary.append(f"持仓 {pos_count} 只")
    summary.append(f"观察中 {watch_count} 只")
    lines.append(f"{snapshot.as_of_date}　{' | '.join(summary)}")
    lines.append("")

    if has_trades:
        lines.append("▎今日操作")
        for item in snapshot.today_entries[:5]:
            et = EVENT_DISPLAY.get(item.signal_type, item.signal_type)
            lines.append(f"  📈 买入 {item.symbol} {item.name or ''} ¥{_fmt_price(item.price)} × {item.qty:.0f} 股（{et}，仓位 {item.position_pct:.1f}%）")
            if item.signal_date:
                lines.append(f"     {item.signal_date} 出的信号，今天触到城门价后买入")
        for item in snapshot.today_exits[:5]:
            pnl = f"{'盈利' if (item.pnl_pct or 0) >= 0 else '亏损'} {'+' if (item.pnl_pct or 0) >= 0 else ''}{(item.pnl_pct or 0):.1f}%" if item.pnl_pct is not None else ""
            hold = f"持仓 {item.holding_days} 天" if item.holding_days else ""
            reason = _human_reason(item.reason)
            parts = [p for p in [reason, hold, pnl] if p]
            lines.append(f"  📉 卖出 {item.symbol} {item.name or ''} ¥{_fmt_price(item.price)}（{'，'.join(parts)}）")
        for h in new_hunts[:3]:
            lines.append(f"  📋 新挂单 {h.symbol} {h.name or ''} — 城门 ¥{h.target_price:.2f}（有效至 {h.valid_until_date}）")
        lines.append("")

    lines.append(f"▎新信号（{new_count}）")
    if top_new:
        for i, item in enumerate(top_new, 1):
            lines.append("")
            lines.append(_signal_card_text(item, i))
        if new_count > push_top_new:
            lines.append(f"\n  +{new_count - push_top_new} 未列出")
    else:
        lines.append("  今日无新信号")
    lines.append("")

    if top_watch:
        healthy, caution, fresh = _classify_watch(top_watch)
        lines.append(f"▎跟踪中（{watch_count}）")
        if healthy:
            lines.append("")
            lines.append("🟢 运行良好")
            for w in healthy:
                lines.append(_watch_text(w))
        if caution:
            lines.append("")
            lines.append("🟡 走势承压")
            for w in caution:
                lines.append(_watch_text(w))
        if fresh:
            lines.append("")
            lines.append("⚪ 刚入池")
            for w in fresh:
                lines.append(_watch_text(w))
        if watch_count > push_top_watch:
            lines.append(f"\n  +{watch_count - push_top_watch} 未列出")
        lines.append("")

    if top_drops:
        lines.append(f"▎今日移出（{drop_count}）")
        for item in top_drops:
            et = EVENT_DISPLAY.get(item.event_type, item.event_type)
            badge = "（曾入场）" if item.traded else ""
            lines.append(f"  ✕ {item.symbol} {item.name or ''} — {et}。{item.note}{badge}")
        lines.append("")

    return "\n".join(lines).strip()


def _signal_card_text(item: SignalSnapshot, idx: int) -> str:
    """Plain text version of signal card for summary.md preview."""
    from v5.notify.oracle_constants import get_oracle
    et_label = EVENT_DISPLAY.get(item.event_type, item.event_type)
    oracle = get_oracle(item.event_type)
    sector_name = item.theme_label if item.theme_label and item.theme_label != "其他" else ""

    badge = ""
    if item.traded:
        badge = "（已买入 ✓）"
    elif item.near_gate:
        badge = "（接近城门）"

    ni = NUM_ICONS[idx - 1] if idx <= len(NUM_ICONS) else f"{idx}."
    lines = [f"  {ni} {item.symbol} {item.name or ''} — {et_label}{badge}"]

    if item.peer_tier == "high" and item.event_type in ("attack", "arb"):
        sector_desc = f"{sector_name}板块" if sector_name else "同板块"
        lines.append(f"     · {sector_desc}今天有 {item.peer_confirmation} 只以上个股同时放量异动")
        h_hit = oracle.get("peer_high_hit10", 0)
        h_dud = oracle.get("peer_high_dud", 0)
        if h_hit > 0:
            lines.append(f"     · 历史上出现这种板块集体异动时，{et_label} {h_hit:.0%} 在 20 天内涨超 10%，废票率仅 {h_dud:.0%}")
    elif item.peer_tier == "low" and item.event_type in ("attack", "arb"):
        sector_desc = f"{sector_name}板块" if sector_name else "所属板块"
        lines.append(f"     · {sector_desc}仅此一只触发，缺乏联动 ⚠️")
        l_dud = oracle.get("peer_low_dud", 0)
        if l_dud > 0.15:
            lines.append(f"     · 历史上{et_label}在板块联动弱时废票率升至 {l_dud:.0%}，谨慎对待")
    elif sector_name:
        lines.append(f"     · {sector_name}板块")

    if item.gate_price:
        if item.gate_gap_pct > 0.005:
            lines.append(f"     · 今天收盘 ¥{item.signal_close:.2f}，城门价 ¥{item.gate_price:.2f}（需再涨 {item.gate_gap_pct*100:.1f}% 才触发买入）")
        else:
            lines.append(f"     · 今天收盘 ¥{item.signal_close:.2f}，城门价 ¥{item.gate_price:.2f}（开盘即可成交）")

    if item.stop_gap_pct < -0.001 and item.invalidation_price:
        lines.append(f"     · 止损 ¥{item.invalidation_price:.2f}（{item.stop_gap_pct*100:.1f}%）")

    pq = oracle.get("path_quality_3d", {})
    bull = pq.get("gt2", {})
    if bull.get("hit10", 0) > 0:
        lines.append(f"     · 同类信号中，前 3 天涨幅超过跌幅 2 倍以上的，{bull['hit10']:.0%} 在 20 天内涨过 10%")

    return "\n".join(lines)


def _watch_text(item: WatchItem) -> str:
    """Plain text version of watch item for summary.md preview."""
    ret = item.close_ret_since_signal
    peak = item.max_ret_since_signal
    dd = item.drawdown_from_peak
    ret_str = f"{'+'if ret >= 0 else ''}{ret*100:.1f}%"

    header = f"  {item.symbol} {item.name or ''} — 信号后第 {item.obs_day} 天"
    bullets: list[str] = []

    if dd > 0.03 and ret < peak - 0.02:
        bullets.append(f"     · 最高到过 +{peak*100:.1f}%，但今天收盘已回到 {ret_str}，从高点回撤了 {dd*100:.1f} 个百分点")
    elif ret >= 0.01:
        bullets.append(f"     · 累计涨 {ret_str}，最高到过 +{peak*100:.1f}%")
    elif ret < -0.01:
        bullets.append(f"     · 今天收盘 {ret_str}，最高仅到过 +{peak*100:.1f}%")
    else:
        bullets.append(f"     · 小幅波动，收益 {ret_str}")

    if item.hunt_touched:
        bullets.append("     · 已回踩过城门价（买入会被执行）")

    hint = item.path_hint or item.note
    if hint:
        bullets.append(f"     · {hint}")

    return header + "\n" + "\n".join(bullets)


def build_feishu_post_payload(title: str, markdown_text: str) -> dict[str, Any]:
    """Legacy plain-text post format (kept as fallback)."""
    lines = markdown_text.splitlines()
    content: list[list[dict[str, str]]] = []
    for line in lines:
        content.append([{"tag": "text", "text": line}])
    return {
        "msg_type": "post",
        "content": {
            "post": {
                "zh_cn": {
                    "title": title,
                    "content": content,
                }
            }
        },
    }


EVENT_DISPLAY: dict[str, str] = {
    "trend_spear": "趋势长枪", "post_limit": "板后长枪", "failed_board": "烂板长枪",
    "youzi": "游资长枪", "sector_spear": "板块长枪", "attack": "进攻长枪",
    "arb": "套利长枪", "escape": "逃命长枪", "tail_close": "尾盘入场",
    "breakout": "突破入场",
}


def _md(content: str, **kwargs: Any) -> dict[str, Any]:
    """v2 native markdown element with optional text_size / text_align."""
    el: dict[str, Any] = {"tag": "markdown", "content": content}
    for k in ("text_size", "text_align", "icon"):
        if k in kwargs:
            el[k] = kwargs[k]
    return el


def _markdown(content: str) -> dict[str, Any]:
    return _md(content)


def _hr() -> dict[str, str]:
    return {"tag": "hr"}


def _kpi_column(big: str, label: str) -> dict[str, Any]:
    return {
        "tag": "column",
        "width": "weighted",
        "weight": 1,
        "vertical_align": "center",
        "elements": [
            _md(f"**{big}**", text_size="heading", text_align="center"),
            _md(label, text_size="notation", text_align="center"),
        ],
    }


def _kpi_row(*kpis: tuple[str, str]) -> dict[str, Any]:
    return {
        "tag": "column_set",
        "flex_mode": "none",
        "background_style": "grey",
        "columns": [_kpi_column(big, label) for big, label in kpis],
    }


def _stock_url(symbol: str) -> str:
    s = str(symbol).zfill(6)
    return f"https://stockpage.10jqka.com.cn/{s}/"


def _collapsible(
    title: str,
    elements: list[dict[str, Any]],
    expanded: bool = False,
) -> dict[str, Any]:
    """v2 collapsible panel — folds secondary content."""
    return {
        "tag": "collapsible_panel",
        "expanded": expanded,
        "header": {"title": {"tag": "plain_text", "content": title}},
        "elements": elements,
    }


NUM_ICONS = ["①", "②", "③", "④", "⑤", "⑥", "⑦", "⑧", "⑨", "⑩"]


def _num(idx: int) -> str:
    return NUM_ICONS[idx - 1] if 1 <= idx <= len(NUM_ICONS) else f"{idx}."


def _oracle_type_summary(items: list[SignalSnapshot]) -> str | None:
    """Build a compact oracle reference note grouped by signal type."""
    from v5.notify.oracle_constants import get_oracle
    from collections import Counter
    type_counts = Counter(s.event_type for s in items)
    parts: list[str] = []
    for et, cnt in type_counts.most_common():
        oracle = get_oracle(et)
        et_label = EVENT_DISPLAY.get(et, et)
        hit10 = oracle.get("hit10_20d", 0)
        dud = oracle.get("dud_rate", 0)
        if hit10 > 0:
            parts.append(f"{et_label}（×{cnt}）：20天内{hit10:.0%}涨超10%，废票率{dud:.0%}")
    if not parts:
        return None
    return "**信号类型参考**\n" + "\n".join(parts)


def _signal_card_lines(item: SignalSnapshot, idx: int) -> list[str]:
    """Render one signal card as a list of lines — first is identity, rest are detail."""
    et_label = EVENT_DISPLAY.get(item.event_type, item.event_type)
    name = _clean(item.name)
    sector_name = item.theme_label if item.theme_label and item.theme_label != "其他" else ""

    badge = ""
    if item.traded:
        badge = " `已买入`"
    elif item.near_gate:
        badge = " `接近城门`"

    sector_tag = f" `{sector_name}`" if sector_name else ""
    lines = [f"**{item.symbol} {name}** `{et_label}`{sector_tag}{badge}"]

    if item.gate_price:
        gate_desc = f"距收盘 +{item.gate_gap_pct*100:.1f}%" if item.gate_gap_pct > 0.005 else "开盘即可成交"
        stop_part = f" → 止损 ¥{item.invalidation_price:.2f}（{item.stop_gap_pct*100:.1f}%）" if item.invalidation_price else ""
        lines.append(f"城门 ¥{item.gate_price:.2f}（{gate_desc}）{stop_part}")

    if item.peer_tier == "high" and item.event_type in ("attack", "arb"):
        lines.append(f"板块 **{item.peer_confirmation}** 只共振，集体异动")
    elif item.peer_tier == "low" and item.event_type in ("attack", "arb"):
        lines.append("板块无联动，独自异动 ⚠️")

    return lines


def _table(
    columns: list[dict[str, Any]],
    rows: list[dict[str, Any]],
    page_size: int = 5,
) -> dict[str, Any]:
    """v2 native table component."""
    return {
        "tag": "table",
        "page_size": page_size,
        "row_height": "low",
        "header_style": {
            "text_align": "center",
            "text_size": "normal",
            "background_style": "grey",
            "bold": True,
            "lines": 1,
        },
        "columns": columns,
        "rows": rows,
    }


def _signal_table(items: list[SignalSnapshot]) -> dict[str, Any]:
    """Simplified v2 table for new signals (mobile-friendly: 6 cols)."""
    columns = [
        {"name": "idx", "display_name": "#", "data_type": "text", "width": "auto"},
        {"name": "symbol", "display_name": "代码", "data_type": "text", "width": "auto"},
        {"name": "name", "display_name": "名称", "data_type": "text", "width": "auto"},
        {"name": "type", "display_name": "类型", "data_type": "text", "width": "auto"},
        {"name": "gate", "display_name": "城门", "data_type": "text", "width": "auto"},
        {"name": "gap", "display_name": "距离", "data_type": "text", "width": "auto"},
    ]
    rows = []
    for i, item in enumerate(items, 1):
        et = EVENT_DISPLAY.get(item.event_type, item.event_type)
        gate = f"¥{item.gate_price:.2f}" if item.gate_price else "-"
        gap = f"+{item.gate_gap_pct*100:.1f}%" if item.gate_gap_pct > 0.005 else "≈0" if item.gate_price else "-"
        badge = " ✓" if item.traded else " ⚡" if item.near_gate else ""
        rows.append({
            "idx": _num(i),
            "symbol": item.symbol,
            "name": f"{item.name or ''}{badge}",
            "type": et,
            "gate": gate,
            "gap": gap,
        })
    return _table(columns, rows, page_size=10)


def _watch_table(items: list[WatchItem], page_size: int = 5) -> dict[str, Any]:
    """Compact v2 table for watch list (6 cols, mobile-friendly)."""
    columns = [
        {"name": "status", "display_name": "", "data_type": "text", "width": "auto"},
        {"name": "symbol", "display_name": "代码", "data_type": "text", "width": "auto"},
        {"name": "name", "display_name": "名称", "data_type": "text", "width": "auto"},
        {"name": "days", "display_name": "天", "data_type": "number", "width": "auto"},
        {"name": "ret", "display_name": "涨跌", "data_type": "text", "width": "auto"},
        {"name": "dd", "display_name": "回撤", "data_type": "text", "width": "auto"},
    ]
    rows = []
    for w in items:
        if w.obs_day <= 1:
            dot = "⚪"
        elif w.close_ret_since_signal < -0.01 or w.drawdown_from_peak > 0.04:
            dot = "🟡"
        else:
            dot = "🟢"
        ret = f"{'+'if w.close_ret_since_signal >= 0 else ''}{w.close_ret_since_signal*100:.1f}%"
        dd = f"-{w.drawdown_from_peak*100:.1f}%" if w.drawdown_from_peak > 0.005 else "-"
        traded = " ✓" if w.traded else ""
        rows.append({
            "status": dot,
            "symbol": w.symbol,
            "name": f"{w.name or ''}{traded}",
            "days": w.obs_day,
            "ret": ret,
            "dd": dd,
        })
    return _table(columns, rows, page_size=page_size)


def _dedup_watch(items: list[WatchItem]) -> list[WatchItem]:
    """Keep only the highest obs_day entry per symbol (most mature tracking)."""
    best: dict[str, WatchItem] = {}
    for w in items:
        existing = best.get(w.symbol)
        if existing is None or w.obs_day > existing.obs_day:
            best[w.symbol] = w
    seen: set[str] = set()
    result: list[WatchItem] = []
    for w in items:
        if w.symbol not in seen and best.get(w.symbol) is w:
            seen.add(w.symbol)
            result.append(w)
    return result


def _nice_ticks(min_val: float, max_val: float) -> tuple[float, float, float]:
    """Compute clean axis min/max/step so tick labels are always round numbers."""
    import math
    span = max_val - min_val
    if span <= 2:
        step = 0.5
    elif span <= 5:
        step = 1
    elif span <= 15:
        step = 2
    elif span <= 40:
        step = 5
    else:
        step = 10
    axis_min = math.floor(min_val / step) * step
    axis_max = math.ceil(max_val / step) * step
    if axis_min == axis_max:
        axis_min -= step
        axis_max += step
    return axis_min, axis_max, step


def _equity_chart(equity_data: list[dict] | None) -> dict[str, Any] | None:
    """Build a polished VChart line+area chart for the equity curve."""
    if not equity_data or len(equity_data) < 5:
        return None
    initial_cash = equity_data[0].get("equity", 1_000_000) or 1_000_000
    start_idx = 0
    for i, d in enumerate(equity_data):
        if abs(d.get("equity", initial_cash) - initial_cash) > 1.0:
            start_idx = i
            break
    trimmed = equity_data[start_idx:]
    recent = trimmed[-60:] if len(trimmed) > 60 else trimmed
    if len(recent) < 3:
        return None
    initial = recent[0].get("equity", 1_000_000) or 1_000_000
    values = [
        {"date": d["date"][5:], "ret": round((d["equity"] / initial - 1) * 100, 1)}
        for d in recent
    ]

    all_rets = [v["ret"] for v in values]
    axis_min, axis_max, tick_step = _nice_ticks(min(all_rets), max(all_rets))

    last_ret = values[-1]["ret"]
    line_color = "#DC2626" if last_ret >= 0 else "#16A34A"
    area_color_start = "rgba(220,38,38,0.25)" if last_ret >= 0 else "rgba(22,163,74,0.25)"
    area_color_end = "rgba(220,38,38,0.02)" if last_ret >= 0 else "rgba(22,163,74,0.02)"

    return {
        "tag": "chart",
        "aspect_ratio": "16:9",
        "chart_spec": {
            "type": "line",
            "data": [{"values": values}],
            "xField": "date",
            "yField": "ret",
            "line": {"style": {"stroke": line_color, "lineWidth": 2, "curveType": "monotone"}},
            "area": {
                "visible": True,
                "style": {
                    "fill": {"gradient": "linear", "x0": 0, "y0": 0, "x1": 0, "y1": 1,
                             "stops": [
                                 {"offset": 0, "color": area_color_start},
                                 {"offset": 1, "color": area_color_end},
                             ]},
                    "curveType": "monotone",
                },
            },
            "point": {"visible": False},
            "label": {"visible": False},
            "axes": [
                {
                    "orient": "bottom",
                    "sampling": True,
                    "label": {"visible": True, "style": {"fontSize": 10}},
                },
            ],
            "tooltip": {
                "mark": {
                    "content": [
                        {"key": "日期", "value": "{date}"},
                        {"key": "收益", "value": "{ret}%"},
                    ]
                }
            },
            "title": {"visible": False},
        },
    }


def _signal_detail_card(item: SignalSnapshot, idx: int) -> dict[str, Any]:
    """Each signal as a clickable interactive_container linking to 10jqka."""
    lines = _signal_card_lines(item, idx)
    els: list[dict[str, Any]] = [_md(lines[0])]
    for detail in lines[1:]:
        els.append(_md(detail, text_size="notation"))
    return {
        "tag": "interactive_container",
        "width": "fill",
        "background_style": "grey",
        "margin": "4px 0px",
        "behaviors": [
            {"type": "open_url", "default_url": _stock_url(item.symbol)},
        ],
        "elements": els,
    }


def _classify_watch(items: list[WatchItem]) -> tuple[list[WatchItem], list[WatchItem], list[WatchItem]]:
    """Split watch items into (healthy, caution, fresh) groups.

    Day 0 = today's new signal → fresh.  Day 1+ = already being tracked.
    """
    healthy, caution, fresh = [], [], []
    for w in items:
        if w.obs_day == 0:
            fresh.append(w)
        elif w.close_ret_since_signal < -0.01 or w.drawdown_from_peak > 0.04:
            caution.append(w)
        else:
            healthy.append(w)
    return healthy, caution, fresh


def _path_fate_narrative(event_type: str, drawdown: float, close_ret: float) -> str:
    """Oracle path_fate narrative — natural morning-brief style per drawdown bucket."""
    from v5.notify.oracle_constants import get_oracle
    oracle = get_oracle(event_type)
    path_fate = oracle.get("path_fate", {})
    if not path_fate:
        return ""
    et_label = EVENT_DISPLAY.get(event_type, event_type)
    dd_pct = drawdown * 100

    if dd_pct < 3:
        bucket = path_fate.get("lt3", {})
    elif dd_pct < 5:
        bucket = path_fate.get("3to5", {})
    elif dd_pct < 8:
        bucket = path_fate.get("5to8", {})
    elif dd_pct < 12:
        bucket = path_fate.get("8to12", {})
    else:
        bucket = path_fate.get("gt12", {})

    hit10 = bucket.get("hit10", 0)
    pct = bucket.get("pct", 0)
    h = f"{hit10:.0%}"

    if dd_pct < 3:
        if hit10 >= 0.80:
            return f"走势克制，几乎无回撤——同类{et_label} {h} 在20天内涨超10% ✅"
        return f"目前回撤极小，同类{et_label} {h} 在20天内涨超10% ✅"
    if dd_pct < 5:
        if hit10 >= 0.60:
            return f"小幅回撤，同类{et_label} {h} 仍能在20天内涨过10%，走势正常 ✅"
        return f"小幅回撤，同类{et_label}在这个区间（占{pct:.0%}样本）有 {h} 在20天内涨过10%"
    if dd_pct < 8:
        if hit10 >= 0.50:
            return f"从高点回落了{dd_pct:.0f}%左右，同类{et_label}中约半数仍能在20天内涨过10%"
        return f"从高点回落了{dd_pct:.0f}%左右（占{pct:.0%}样本），{h} 在20天内涨过10%，胜负接近"
    if dd_pct < 12:
        return f"回撤接近{dd_pct:.0f}%，同类{et_label}只有 {h} 在20天内涨过10%，赔率在下降 ⚠"
    return f"回撤已超12%，仅 {h} 能在20天内翻盘涨过10%，大多数走到这步已经走坏 ⚠"


def _watch_item_card(w: WatchItem) -> dict[str, Any]:
    """Oracle-enriched watch card — trader morning brief style."""
    name = _clean(w.name)
    ret = w.close_ret_since_signal
    dd = w.drawdown_from_peak
    ret_str = _pnl_font(ret, f"{'+'if ret >= 0 else ''}{ret*100:.1f}%")
    traded = " `持仓`" if w.traded else ""

    et_label = EVENT_DISPLAY.get(w.event_type, w.event_type)
    line1 = f"**{w.symbol}** {name} `{et_label}`{traded} · 第{w.obs_day}天 · {ret_str}　最大回撤 {dd*100:.1f}%"
    line2 = _path_fate_narrative(w.event_type, dd, ret)

    els: list[dict[str, Any]] = [_md(line1)]
    if line2:
        els.append(_md(line2, text_size="notation"))

    return {
        "tag": "interactive_container",
        "width": "fill",
        "background_style": "grey",
        "margin": "4px 0px",
        "behaviors": [{"type": "open_url", "default_url": _stock_url(w.symbol)}],
        "elements": els,
    }


def _fresh_watch_card(w: WatchItem) -> dict[str, Any]:
    """Day 0 — oracle stats for new entries, same visual weight as regular cards."""
    from v5.notify.oracle_constants import get_oracle
    name = _clean(w.name)
    et_label = EVENT_DISPLAY.get(w.event_type, w.event_type)
    traded = " `持仓`" if w.traded else ""

    line1 = f"**{w.symbol}** {name} `{et_label}`{traded}"
    parts: list[str] = []
    if w.gate_price:
        gap = w.gate_gap_pct
        gap_str = f"距收盘 +{gap*100:.1f}%" if gap > 0.005 else "开盘即可成交"
        parts.append(f"城门 ¥{w.gate_price:.2f}（{gap_str}）")
    oracle = get_oracle(w.event_type)
    hit10 = oracle.get("hit10_20d", 0)
    dud = oracle.get("dud_rate", 0)
    big = oracle.get("outcome_dist", {}).get("big", 0)
    if hit10 > 0:
        oracle_text = f"{et_label}历史上 {hit10:.0%} 在20天内涨超10%，废票率{dud:.0%}"
        if big >= 0.25:
            oracle_text += f"。其中近{_cn_fraction(big)}成为涨超20%的大牛票"
        parts.append(oracle_text)
    line2 = "　".join(parts)

    els: list[dict[str, Any]] = [_md(line1)]
    if line2:
        els.append(_md(line2, text_size="notation"))

    return {
        "tag": "interactive_container",
        "width": "fill",
        "background_style": "grey",
        "margin": "4px 0px",
        "behaviors": [{"type": "open_url", "default_url": _stock_url(w.symbol)}],
        "elements": els,
    }


def _cn_fraction(ratio: float) -> str:
    """Convert a ratio like 0.30 to a Chinese approximation like '三成'."""
    tenths = round(ratio * 10)
    cn = {1: "一", 2: "两", 3: "三", 4: "四", 5: "五", 6: "六", 7: "七", 8: "八", 9: "九"}
    return f"{cn.get(tenths, str(tenths))}成"


def _watch_group_elements(
    items: list[WatchItem],
    label: str,
    remaining_count: int,
    *,
    is_fresh: bool = False,
) -> list[dict[str, Any]]:
    """Render a grouped watch section: emoji header + interactive cards."""
    if not items:
        return []
    els: list[dict[str, Any]] = [_md(f"**{label}**", text_size="notation")]
    for w in items:
        els.append(_fresh_watch_card(w) if is_fresh else _watch_item_card(w))
    return els


def _pnl_font(val: float, text: str) -> str:
    """Wrap text in A-share color: red=positive, green=negative."""
    color = "up" if val >= 0 else "down"
    return f"<font color='{color}'>{text}</font>"


def build_feishu_card_payload(
    *,
    snapshot: "NotificationSnapshot",
    push_top_new: int = 3,
    push_top_watch: int = 8,
    push_top_drops: int = 5,
    min_confidence: float = 0.0,
    data_stale: bool = False,
    equity_data: list[dict] | None = None,
) -> dict[str, Any]:
    """Build a Feishu interactive card v2 payload (new design)."""
    all_new = [s for s in snapshot.new_signals if s.signal_confidence >= min_confidence] if min_confidence > 0 else snapshot.new_signals
    new_count = len(all_new)
    watch_count = len(snapshot.watch_updates)
    drop_count = len(snapshot.dropped)
    pos_count = len(snapshot.active_positions)

    top_new = all_new[:push_top_new]
    top_watch = snapshot.watch_updates[:push_top_watch]
    top_drops = snapshot.dropped[:push_top_drops]

    has_trades = bool(snapshot.today_entries or snapshot.today_exits)
    all_hunts = snapshot.pending_hunts
    new_hunts = [h for h in all_hunts if h.created_date == snapshot.as_of_date]

    weekdays = ["周一", "周二", "周三", "周四", "周五", "周六", "周日"]
    try:
        from datetime import date as _dt
        d = _dt.fromisoformat(snapshot.as_of_date)
        wd = weekdays[d.weekday()]
    except Exception:
        wd = ""

    header_color = "orange" if data_stale else ("green" if snapshot.today_entries else "blue")
    title = f"长枪日报 {snapshot.as_of_date[5:]} {wd}"
    subtitle = ""
    if snapshot.mode == "preview" and snapshot.hint:
        title = f"长枪信号 · {snapshot.hint}"
        subtitle = "盘中预测，收盘后会更新"
        header_color = "purple"
    elif data_stale:
        subtitle = "⚠️ 数据延迟，请检查通达信连接"

    # ── Header tags (contrasting colors) ──
    tags: list[dict[str, Any]] = []
    if new_count > 0:
        tags.append({"tag": "text_tag", "text": {"tag": "plain_text", "content": f"{new_count} 信号"}, "color": "orange"})
    if snapshot.today_entries:
        tags.append({"tag": "text_tag", "text": {"tag": "plain_text", "content": "有买入"}, "color": "red"})
    if snapshot.today_exits:
        tags.append({"tag": "text_tag", "text": {"tag": "plain_text", "content": "有卖出"}, "color": "carmine"})
    if not data_stale and len(tags) < 3:
        tags.append({"tag": "text_tag", "text": {"tag": "plain_text", "content": "数据正常"}, "color": "turquoise"})

    elements: list[dict[str, Any]] = []

    # ── KPI dashboard ──
    kpis: list[tuple[str, str]] = [(str(new_count), "新信号")]
    if pos_count:
        kpis.append((str(pos_count), "持仓中"))
    kpis.append((str(watch_count), "观察中"))
    if snapshot.portfolio_equity > 0:
        eq = snapshot.portfolio_equity
        eq_str = f"¥{eq/10000:.1f}万" if eq >= 10000 else f"¥{eq:,.0f}"
        exp = snapshot.portfolio_exposure_pct
        kpis.append((eq_str, f"总资产({exp:.0f}%仓)"))
    elements.append(_kpi_row(*kpis))

    # ══════════════════════════════════════════════════════════════
    # SECTION 1: 持仓与操作 (always visible)
    # ══════════════════════════════════════════════════════════════
    elements.append(_hr())
    elements.append(_md("**▎今日操盘**", icon={"tag": "standard_icon", "token": "calendar_outlined", "color": "orange"}))

    if has_trades:
        for item in snapshot.today_entries[:5]:
            et_label = EVENT_DISPLAY.get(item.signal_type, item.signal_type)
            name = _clean(item.name)
            line1 = f"🟥 **{item.symbol}** {name} `{et_label}`　{item.position_pct:.1f}%仓"
            detail = f"买入 ¥{_fmt_price(item.price)} × {item.qty:.0f}股"
            if item.signal_date:
                detail += f"　{item.signal_date} 信号，今日触价成交"
            elements.append({
                "tag": "interactive_container", "width": "fill", "margin": "2px 0px",
                "background_style": "grey",
                "behaviors": [{"type": "open_url", "default_url": _stock_url(item.symbol)}],
                "elements": [_md(line1), _md(detail, text_size="notation")],
            })
        for item in snapshot.today_exits[:5]:
            name = _clean(item.name)
            pnl_val = item.pnl_pct or 0
            pnl_str = _pnl_font(pnl_val, f"{'+'if pnl_val >= 0 else ''}{pnl_val:.1f}%") if item.pnl_pct is not None else ""
            hold_str = f"{item.holding_days}天" if item.holding_days else ""
            reason = _human_reason(item.reason)
            line1 = f"🟩 **{item.symbol}** {name}　{pnl_str}"
            detail_parts = [p for p in [f"卖出 ¥{_fmt_price(item.price)}", hold_str, reason] if p]
            elements.append({
                "tag": "interactive_container", "width": "fill", "margin": "2px 0px",
                "background_style": "grey",
                "behaviors": [{"type": "open_url", "default_url": _stock_url(item.symbol)}],
                "elements": [_md(line1), _md("　".join(detail_parts), text_size="notation")],
            })
    else:
        elements.append(_md("今日未触发交易", text_size="notation"))

    # Pending hunts pool — always visible, even when empty
    if all_hunts:
        hunt_els: list[dict[str, Any]] = []
        for h in all_hunts:
            name = _clean(h.name)
            et_label = EVENT_DISPLAY.get(h.source_event, h.source_event)
            status = "已成交" if h.expired and h.status == "已执行" else h.status
            new_tag = " `新`" if h.created_date == snapshot.as_of_date else ""
            line1 = f"**{h.symbol}** {name} `{et_label}`{new_tag}　{status}"
            line2 = f"城门 ¥{h.target_price:.2f}　止损 ¥{h.invalidate_price:.2f}　有效至 {h.valid_until_date}"
            hunt_els.append({
                "tag": "interactive_container", "width": "fill", "margin": "2px 0px",
                "background_style": "grey",
                "behaviors": [{"type": "open_url", "default_url": _stock_url(h.symbol)}],
                "elements": [_md(line1), _md(line2, text_size="notation")],
            })
        elements.append(_collapsible(f"挂单池 ({len(all_hunts)})", hunt_els, expanded=True))
    else:
        elements.append(_collapsible("挂单池 (0)", [_md("暂无挂单")], expanded=False))

    # Full positions (collapsible)
    if snapshot.active_positions:
        total_eq = snapshot.portfolio_equity or 1
        pos_els: list[dict[str, Any]] = []
        for p in snapshot.active_positions:
            name = _clean(p.name)
            pnl_pct = p.unrealized_pnl_pct
            pnl_str = _pnl_font(pnl_pct, f"{'+'if pnl_pct >= 0 else ''}{pnl_pct:.1f}%")
            et_label = EVENT_DISPLAY.get(p.source_event, p.source_event)
            weight = p.qty * p.current_price / total_eq * 100
            line1 = f"**{p.symbol}** {name}　{pnl_str}　`{et_label}`"
            line2 = f"成本 ¥{p.entry_price:.2f} → 现价 ¥{p.current_price:.2f}　{p.days_held}天　占仓 {weight:.1f}%"
            pos_els.append({
                "tag": "interactive_container", "width": "fill", "margin": "2px 0px",
                "background_style": "grey",
                "behaviors": [{"type": "open_url", "default_url": _stock_url(p.symbol)}],
                "elements": [_md(line1), _md(line2, text_size="notation")],
            })
        elements.append(_collapsible(f"当前仓位 ({len(snapshot.active_positions)})", pos_els, expanded=False))

    # Trade history (collapsible)
    if snapshot.closed_trades:
        sorted_trades = sorted(snapshot.closed_trades, key=lambda t: t.sell_date, reverse=True)
        recent_closed = sorted_trades[:10]
        trade_els: list[dict[str, Any]] = []
        for t in recent_closed:
            name = _clean(t.name)
            pnl_str = _pnl_font(t.pnl_pct, f"{'+'if t.pnl_pct >= 0 else ''}{t.pnl_pct:.1f}%")
            reason = _human_reason(t.reason)
            et_label = EVENT_DISPLAY.get(t.source_event, t.source_event)
            line1 = f"**{t.symbol}** {name}　{pnl_str}　`{et_label}`"
            line2 = f"{t.buy_date[5:]} → {t.sell_date[5:]}　{t.holding_days}天　{reason}"
            trade_els.append({
                "tag": "interactive_container", "width": "fill", "margin": "2px 0px",
                "background_style": "grey",
                "behaviors": [{"type": "open_url", "default_url": _stock_url(t.symbol)}],
                "elements": [_md(line1), _md(line2, text_size="notation")],
            })
        elements.append(_collapsible(f"最近成交 ({len(recent_closed)}笔)", trade_els, expanded=False))

    # ══════════════════════════════════════════════════════════════
    # SECTION 2: 新信号
    # ══════════════════════════════════════════════════════════════
    elements.append(_hr())
    elements.append(_md(
        f"**▎今日发现** ({new_count})" if new_count else "**▎今日发现**",
        icon={"tag": "standard_icon", "token": "search_outlined", "color": "blue"},
    ))
    if top_new:
        for i, item in enumerate(top_new, 1):
            elements.append(_signal_detail_card(item, i))
        if new_count > push_top_new:
            extra_els: list[dict[str, Any]] = []
            for i, item in enumerate(all_new[push_top_new:push_top_new + 7], push_top_new + 1):
                extra_els.append(_signal_detail_card(item, i))
            if new_count > push_top_new + 7:
                extra_els.append(_md(f"*+{new_count - push_top_new - 7} 未列出*", text_size="notation"))
            elements.append(_collapsible(
                f"更多信号（+{new_count - push_top_new}）",
                extra_els,
                expanded=False,
            ))
    else:
        elements.append(_md("今日无新信号"))

    # ══════════════════════════════════════════════════════════════
    # SECTION 3: 跟踪中
    # ══════════════════════════════════════════════════════════════
    deduped_watch = _dedup_watch(snapshot.watch_updates)
    dedup_count = len(deduped_watch)
    top_watch_d = deduped_watch[:push_top_watch]
    if top_watch_d:
        elements.append(_hr())
        elements.append(_md(
            f"**▎观察池** ({dedup_count})",
            icon={"tag": "standard_icon", "token": "todo_outlined", "color": "green"},
        ))
        healthy, caution, fresh = _classify_watch(top_watch_d)
        if healthy:
            elements.extend(_watch_group_elements(healthy, "🟢 运行良好", 0))
        if caution:
            elements.extend(_watch_group_elements(caution, "🟡 走势承压", 0))
        if fresh:
            elements.extend(_watch_group_elements(fresh, "⚪ 刚入池", 0, is_fresh=True))
        if dedup_count > push_top_watch:
            remaining = dedup_count - push_top_watch
            extra_watch = deduped_watch[push_top_watch:push_top_watch + 10]
            if extra_watch:
                extra_w_els: list[dict[str, Any]] = [_watch_item_card(w) for w in extra_watch]
                if remaining > len(extra_watch):
                    extra_w_els.append(_md(f"*+{remaining - len(extra_watch)} 未列出*", text_size="notation"))
                elements.append(_collapsible(f"更多跟踪（+{remaining}）", extra_w_els, expanded=False))

    # ── Dropped (collapsible) ──
    if top_drops:
        elements.append(_hr())
        drop_lines: list[str] = []
        for item in top_drops:
            name = _clean(item.name)
            et_label = EVENT_DISPLAY.get(item.event_type, item.event_type)
            badge = " `已入场`" if item.traded else ""
            note_str = f"：{item.note}" if item.note else ""
            drop_lines.append(f"✕ **{item.symbol}** {name} — {et_label}{badge}{note_str}")
        if drop_count > push_top_drops:
            drop_lines.append(f"+{drop_count - push_top_drops} 未列出")
        elements.append(_collapsible(
            f"今日移出 ({drop_count})",
            [_md("\n".join(drop_lines))],
            expanded=False,
        ))

    # ══════════════════════════════════════════════════════════════
    # SECTION 4: 总资产曲线
    # ══════════════════════════════════════════════════════════════
    chart_el = _equity_chart(equity_data)
    if chart_el is not None:
        elements.append(_hr())
        elements.append(_md("**▎净值走势**"))
        elements.append(chart_el)

    # ── Footer ──
    elements.append(_hr())
    mode_label = "盘中预测" if snapshot.mode == "preview" else "收盘确认"
    elements.append(_md(f"*长枪策略 · {snapshot.as_of_date} · {mode_label}*", text_align="center", text_size="notation"))

    # ── Build card ──
    header: dict[str, Any] = {
        "title": {"tag": "plain_text", "content": title},
        "template": header_color,
    }
    if subtitle:
        header["subtitle"] = {"tag": "plain_text", "content": subtitle}
    if tags:
        header["text_tag_list"] = tags[:3]

    return {
        "msg_type": "interactive",
        "card": {
            "schema": "2.0",
            "config": {
                "width_mode": "fill",
                "enable_forward": True,
                "style": {
                    "color": {
                        "up": {"light_mode": "rgba(220,38,38,1)", "dark_mode": "rgba(248,113,113,1)"},
                        "down": {"light_mode": "rgba(22,163,74,1)", "dark_mode": "rgba(74,222,128,1)"},
                    }
                },
            },
            "header": header,
            "body": {"elements": elements},
        },
    }
