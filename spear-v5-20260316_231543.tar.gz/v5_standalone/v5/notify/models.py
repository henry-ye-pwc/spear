from __future__ import annotations

from dataclasses import asdict, dataclass, field


@dataclass(slots=True)
class SignalSnapshot:
    symbol: str
    name: str
    event_type: str
    signal_date: str
    signal_confidence: float
    entry_style: str
    gate_price: float | None
    invalidation_price: float | None
    signal_close: float
    signal_high: float
    signal_low: float
    theme_label: str
    peer_confirmation: int
    leader_strength: int
    sector_hot: bool
    # Oracle enrichment
    gate_gap_pct: float = 0.0
    stop_gap_pct: float = 0.0
    adj_potential: float = 0.0
    peer_tier: str = ""
    outcome_dist: dict = field(default_factory=dict)
    peer_lift_hint: str = ""
    spear_role: str = ""
    multi_spear_count: int = 0
    # Trade enrichment (populated by enrich_snapshot_with_trades)
    traded: bool = False
    trade_price: float | None = None
    trade_date: str = ""
    near_gate: bool = False
    blocked_reason: str = ""

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass(slots=True)
class WatchItem:
    symbol: str
    name: str
    event_type: str
    signal_date: str
    signal_confidence: float
    entry_style: str
    gate_price: float | None
    invalidation_price: float | None
    signal_close: float
    signal_high: float
    signal_low: float
    theme_label: str
    peer_confirmation: int
    leader_strength: int
    sector_hot: bool
    obs_day: int = 0
    latest_date: str = ""
    latest_close: float = 0.0
    latest_high: float = 0.0
    latest_low: float = 0.0
    close_ret_since_signal: float = 0.0
    max_ret_since_signal: float = 0.0
    hunt_touched: bool = False
    still_valid: bool = True
    new_same_side_signal: bool = False
    status_label: str = "新信号"
    priority_rank: str = "C级"
    note: str = ""
    active: bool = True
    history: list[dict] = field(default_factory=list)
    # Oracle enrichment
    gate_gap_pct: float = 0.0
    stop_gap_pct: float = 0.0
    adj_potential: float = 0.0
    peer_tier: str = ""
    outcome_dist: dict = field(default_factory=dict)
    peer_lift_hint: str = ""
    drawdown_from_peak: float = 0.0
    days_since_peak: int = 0
    path_hint: str = ""
    close_vs_gate_pct: float = 0.0
    spear_role: str = ""
    multi_spear_count: int = 0
    # Trade enrichment
    traded: bool = False
    trade_price: float | None = None
    trade_date: str = ""
    days_to_expiry: int = 0

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass(slots=True)
class TradeSummary:
    symbol: str
    name: str
    action: str
    price: float
    qty: float
    reason: str
    signal_date: str
    signal_type: str
    pnl_pct: float | None = None
    holding_days: int | None = None
    position_pct: float = 0.0

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass(slots=True)
class PositionSummary:
    symbol: str
    name: str
    entry_date: str
    entry_price: float
    current_price: float
    qty: float
    unrealized_pnl: float
    unrealized_pnl_pct: float
    days_held: int
    source_event: str
    entry_limit_up: float | None = None

    def to_dict(self) -> dict:
        d = asdict(self)
        if d.get("entry_limit_up") is None:
            d.pop("entry_limit_up", None)
        return d


@dataclass(slots=True)
class ClosedTrade:
    symbol: str
    name: str
    buy_date: str
    buy_price: float
    sell_date: str
    sell_price: float
    qty: float
    pnl_pct: float
    holding_days: int
    reason: str
    source_event: str
    buy_limit_up: float | None = None
    sell_limit_down: float | None = None

    def to_dict(self) -> dict:
        d = asdict(self)
        if d.get("buy_limit_up") is None:
            d.pop("buy_limit_up", None)
        if d.get("sell_limit_down") is None:
            d.pop("sell_limit_down", None)
        return d


@dataclass(slots=True)
class PendingHuntItem:
    symbol: str
    name: str
    source_event: str
    target_price: float
    buffer_pct: float
    invalidate_price: float
    take_profit_pct: float
    entry_style: str
    position_mult: float
    created_date: str
    valid_from_date: str
    valid_until_date: str
    expired: bool = False
    status: str = "等待触发"
    confidence: float = 0.0
    position_blocked: bool = False
    blocked_date: str = ""

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass(slots=True)
class MarketContext:
    sector_signal_counts: dict[str, int] = field(default_factory=dict)
    signal_density: int = 0
    trailing_5d_avg_density: float = 0.0
    conversion_rate: float = 0.0
    portfolio_concentration: dict[str, int] = field(default_factory=dict)
    signal_health: str = ""
    recent_expired_count: int = 0
    recent_actual_dud_rate: float = 0.0
    recent_actual_hit10_rate: float = 0.0

    def to_dict(self) -> dict:
        return asdict(self)
