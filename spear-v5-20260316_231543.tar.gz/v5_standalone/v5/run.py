#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from v5.backtest.runner import run_backtest
from v5.config.pools import list_named_pools, resolve_named_pool
from v5.config.defaults import apply_execution_profile, load_default_config
from v5.data.prefetch import prefetch_symbols
from v5.reports.writer import write_reports


def build_parser() -> argparse.ArgumentParser:
    cfg = load_default_config()
    p = argparse.ArgumentParser(prog="v5/run.py", description="V5 AKQuant + AKShare spear strategy runner")
    p.add_argument("--start", default=cfg.backtest.start)
    p.add_argument("--end", default=cfg.backtest.end)
    p.add_argument("--pool", type=int, default=cfg.backtest.pool_size)
    p.add_argument("--output-dir", default=cfg.backtest.output_dir)
    p.add_argument("--cache-dir", default=cfg.data.cache_dir)
    p.add_argument("--pool-sampling", default=cfg.data.pool_sampling, choices=["random", "head"])
    p.add_argument("--pool-seed", type=int, default=cfg.data.pool_seed)
    p.add_argument("--execution-profile", default=cfg.execution.execution_profile, choices=["day_level_ideal", "next_open_realistic", "delayed_limit_hunt"])
    p.add_argument("--hunt-price-buffer-pct", type=float, default=cfg.execution.hunt_price_buffer_pct)
    p.add_argument("--hunt-window-days", type=int, default=cfg.execution.hunt_window_days)
    p.add_argument("--init-cash", type=float, default=cfg.backtest.initial_cash)
    p.add_argument("--symbols", default="")
    p.add_argument("--pool-name", default="")
    p.add_argument("--enable-events", default="all")
    p.add_argument("--max-positions", type=int, default=cfg.execution.max_positions)
    p.add_argument("--base-pos-pct", type=float, default=cfg.execution.base_pos_pct)
    p.add_argument("--position-sizing-base", default=cfg.execution.position_sizing_base, choices=["cash", "equity"])
    p.add_argument("--cooldown-days", type=int, default=cfg.execution.cooldown_days)
    p.add_argument("--take-profit-pct", type=float, default=cfg.execution.default_take_profit_pct)
    p.add_argument("--trend-spear-pos-mult", type=float, default=cfg.execution.trend_spear_pos_mult)
    p.add_argument("--post-limit-pos-mult", type=float, default=cfg.execution.post_limit_pos_mult)
    p.add_argument("--failed-board-pos-mult", type=float, default=cfg.execution.failed_board_pos_mult)
    p.add_argument("--youzi-pos-mult", type=float, default=cfg.execution.youzi_pos_mult)
    p.add_argument("--sector-spear-pos-mult", type=float, default=cfg.execution.sector_spear_pos_mult)
    p.add_argument("--attack-pos-mult", type=float, default=cfg.execution.attack_pos_mult)
    p.add_argument("--arb-pos-mult", type=float, default=cfg.execution.arb_pos_mult)
    p.add_argument("--warmup-bars", type=int, default=cfg.data.warmup_bars)
    p.add_argument("--disable-env-mapping", action="store_true")
    p.add_argument("--exit-mode", default=cfg.execution.exit_mode, choices=["ideal", "next_open", "hunt_exit"])
    p.add_argument("--exit-hunt-buffer-pct", type=float, default=cfg.execution.exit_hunt_buffer_pct)
    p.add_argument("--exit-hunt-window-days", type=int, default=cfg.execution.exit_hunt_window_days)
    p.add_argument("--trend-spear-stop-mode", default=cfg.execution.trend_spear_stop_mode, choices=["intraday", "close_confirm", "grace_close"])
    p.add_argument("--trend-spear-stop-grace-days", type=int, default=cfg.execution.trend_spear_stop_grace_days)
    p.add_argument("--trend-spear-trend-management", action="store_true", default=cfg.execution.trend_spear_trend_management_enabled)
    p.add_argument("--trend-spear-trend-activation-ret", type=float, default=cfg.execution.trend_spear_trend_activation_ret)
    p.add_argument("--trend-spear-trend-drawdown-exit", type=float, default=cfg.execution.trend_spear_trend_drawdown_exit)
    p.add_argument("--trend-spear-trend-stale-days", type=int, default=cfg.execution.trend_spear_trend_stale_days)
    p.add_argument("--trend-spear-trend-max-extension-days", type=int, default=cfg.execution.trend_spear_trend_max_extension_days)
    p.add_argument("--trend-spear-reentry-watch", action="store_true", default=cfg.execution.trend_spear_reentry_watch_enabled)
    p.add_argument("--trend-spear-reentry-watch-days", type=int, default=cfg.execution.trend_spear_reentry_watch_days)
    p.add_argument("--trend-spear-reentry-min-near-pressure-days", type=int, default=cfg.execution.trend_spear_reentry_min_near_pressure_days)
    p.add_argument("--trend-spear-reentry-min-near-support-days", type=int, default=cfg.execution.trend_spear_reentry_min_near_support_days)
    p.add_argument("--trend-spear-reentry-shrink-threshold", type=float, default=cfg.execution.trend_spear_reentry_shrink_threshold)
    p.add_argument("--trend-spear-reentry-expand-threshold", type=float, default=cfg.execution.trend_spear_reentry_expand_threshold)
    p.add_argument("--trend-spear-dynamic-hold", action="store_true", default=cfg.execution.trend_spear_dynamic_hold_enabled)
    p.add_argument("--trend-spear-limitup-extend-days", type=int, default=cfg.execution.trend_spear_limitup_extend_days)
    p.add_argument("--trend-spear-limitup-wide-atr-mult", type=float, default=cfg.execution.trend_spear_limitup_wide_atr_mult)
    p.add_argument("--trend-spear-limitup-stop-floor-pct", type=float, default=cfg.execution.trend_spear_limitup_stop_floor_pct)
    p.add_argument("--trend-spear-noboard-tighten-days", type=int, default=cfg.execution.trend_spear_noboard_tighten_days)
    p.add_argument("--trend-spear-noboard-tight-atr-mult", type=float, default=cfg.execution.trend_spear_noboard_tight_atr_mult)
    p.add_argument("--trend-spear-noboard-max-hold", type=int, default=cfg.execution.trend_spear_noboard_max_hold)
    p.add_argument("--trend-spear-vol-exhaustion-exit", action="store_true", default=cfg.execution.trend_spear_vol_exhaustion_exit)
    p.add_argument("--no-ts-atr-stop", action="store_true", help="Disable ATR-based initial stop for trend_spear")
    p.add_argument("--no-ts-iqr-filter", action="store_true", help="Disable IQR volume filter for trend_spear")
    p.add_argument("--ts-iqr-threshold", type=float, default=cfg.models.ts_iqr_threshold)
    p.add_argument("--no-ts-elev-filter", action="store_true", help="Disable elevation filter for trend_spear")
    p.add_argument("--ts-elev-threshold", type=float, default=cfg.models.ts_elev_threshold)
    
    p.add_argument("--mootdx-cache-only", action="store_true")
    p.add_argument("--show-progress", action="store_true")
    p.add_argument("--list-pools", action="store_true")
    p.add_argument("--show-config", action="store_true")
    p.add_argument("--db-path", default="", help="DuckDB market store path (enables DuckDB mode)")
    return p


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()
    cfg = load_default_config()
    if args.list_pools:
        print(json.dumps(list_named_pools(), ensure_ascii=False, indent=2))
        return
    if args.show_config:
        print(json.dumps(cfg, default=lambda o: o.__dict__, ensure_ascii=False, indent=2))
        return
    cfg.data.cache_dir = args.cache_dir
    cfg.data.warmup_bars = args.warmup_bars
    cfg.data.pool_sampling = args.pool_sampling
    cfg.data.pool_seed = args.pool_seed
    cfg.data.disable_env_mapping = args.disable_env_mapping
    cfg.data.mootdx_cache_only = args.mootdx_cache_only
    cfg = apply_execution_profile(cfg, args.execution_profile)
    cfg.execution.hunt_price_buffer_pct = args.hunt_price_buffer_pct
    cfg.execution.hunt_window_days = args.hunt_window_days
    cfg.execution.exit_mode = args.exit_mode
    cfg.execution.exit_hunt_buffer_pct = args.exit_hunt_buffer_pct
    cfg.execution.exit_hunt_window_days = args.exit_hunt_window_days
    cfg.execution.trend_spear_stop_mode = args.trend_spear_stop_mode
    cfg.execution.trend_spear_stop_grace_days = args.trend_spear_stop_grace_days
    cfg.execution.trend_spear_trend_management_enabled = args.trend_spear_trend_management
    cfg.execution.trend_spear_trend_activation_ret = args.trend_spear_trend_activation_ret
    cfg.execution.trend_spear_trend_drawdown_exit = args.trend_spear_trend_drawdown_exit
    cfg.execution.trend_spear_trend_stale_days = args.trend_spear_trend_stale_days
    cfg.execution.trend_spear_trend_max_extension_days = args.trend_spear_trend_max_extension_days
    cfg.execution.trend_spear_reentry_watch_enabled = args.trend_spear_reentry_watch
    cfg.execution.trend_spear_reentry_watch_days = args.trend_spear_reentry_watch_days
    cfg.execution.trend_spear_reentry_min_near_pressure_days = args.trend_spear_reentry_min_near_pressure_days
    cfg.execution.trend_spear_reentry_min_near_support_days = args.trend_spear_reentry_min_near_support_days
    cfg.execution.trend_spear_reentry_shrink_threshold = args.trend_spear_reentry_shrink_threshold
    cfg.execution.trend_spear_reentry_expand_threshold = args.trend_spear_reentry_expand_threshold
    cfg.execution.trend_spear_dynamic_hold_enabled = args.trend_spear_dynamic_hold
    cfg.execution.trend_spear_limitup_extend_days = args.trend_spear_limitup_extend_days
    cfg.execution.trend_spear_limitup_wide_atr_mult = args.trend_spear_limitup_wide_atr_mult
    cfg.execution.trend_spear_limitup_stop_floor_pct = args.trend_spear_limitup_stop_floor_pct
    cfg.execution.trend_spear_noboard_tighten_days = args.trend_spear_noboard_tighten_days
    cfg.execution.trend_spear_noboard_tight_atr_mult = args.trend_spear_noboard_tight_atr_mult
    cfg.execution.trend_spear_noboard_max_hold = args.trend_spear_noboard_max_hold
    cfg.execution.trend_spear_vol_exhaustion_exit = args.trend_spear_vol_exhaustion_exit
    cfg.models.ts_atr_stop = not args.no_ts_atr_stop
    cfg.models.ts_iqr_filter = not args.no_ts_iqr_filter
    cfg.models.ts_iqr_threshold = args.ts_iqr_threshold
    cfg.models.ts_elev_filter = not args.no_ts_elev_filter
    cfg.models.ts_elev_threshold = args.ts_elev_threshold
    cfg.execution.max_positions = args.max_positions
    cfg.execution.base_pos_pct = args.base_pos_pct
    cfg.execution.position_sizing_base = args.position_sizing_base
    cfg.execution.cooldown_days = args.cooldown_days
    cfg.execution.default_take_profit_pct = args.take_profit_pct
    cfg.execution.trend_spear_pos_mult = args.trend_spear_pos_mult
    cfg.execution.post_limit_pos_mult = args.post_limit_pos_mult
    cfg.execution.failed_board_pos_mult = args.failed_board_pos_mult
    cfg.execution.youzi_pos_mult = args.youzi_pos_mult
    cfg.execution.sector_spear_pos_mult = args.sector_spear_pos_mult
    cfg.execution.attack_pos_mult = args.attack_pos_mult
    cfg.execution.arb_pos_mult = args.arb_pos_mult
    cfg.backtest.show_progress = args.show_progress
    active_event_types = None
    if args.enable_events.strip().lower() != "all":
        active_event_types = {x.strip() for x in args.enable_events.split(",") if x.strip()}
    if args.pool_name:
        symbols = resolve_named_pool(args.pool_name)
    else:
        symbols = [x.strip() for x in args.symbols.split(",") if x.strip()] or None
    output_dir = Path(args.output_dir)
    if not output_dir.is_absolute():
        output_dir = ROOT / "v5" / "results" / output_dir

    # ── Optional DuckDB store ──
    store = None
    if args.db_path:
        import os
        from v5.data.store import MarketStore
        db_path = args.db_path if os.path.isabs(args.db_path) else str(ROOT / args.db_path)
        store = MarketStore(db_path=db_path)
        print(f"[store] DuckDB mode enabled: {db_path}", flush=True)
        if store.symbol_count() == 0:
            from v5.data.migrate_pkl import migrate
            pkl_dir = str(ROOT / cfg.data.mootdx_cache_dir)
            if Path(pkl_dir).exists() and list(Path(pkl_dir).glob("*_full.pkl")):
                print(f"[store] Empty DuckDB — auto-migrating PKL data from {pkl_dir} ...", flush=True)
                migrate(pkl_dir, store, verify=False)
                print(f"[store] Migration done: {store.symbol_count()} symbols, {store.total_bar_count()} bars", flush=True)

    # Parallel prefetch when mootdx is the bar provider.
    if cfg.data.bar_provider.lower() == "mootdx" and not cfg.data.mootdx_cache_only:
        from v5.data.providers.mootdx_provider import MootdxProvider
        _prov = MootdxProvider(
            cache_dir=cfg.data.mootdx_cache_dir,
            pool_sampling=cfg.data.pool_sampling,
            pool_seed=cfg.data.pool_seed,
            cache_only=True,
        )
        if symbols:
            _pf_syms = [str(s).zfill(6) for s in symbols]
        else:
            _uni = _prov.load_universe(args.pool)
            _pf_syms = _uni["symbol"].tolist() if not _uni.empty else []
        if _pf_syms:
            prefetch_symbols(
                _pf_syms,
                cache_dir=cfg.data.mootdx_cache_dir,
                end_date=args.end,
                workers=4,
                store=store,
            )
            from v5.data.prefetch_features import prefetch_features
            from v5.data.store import MarketStore
            _db_path = str(store.db_path) if store else None
            if store is not None:
                store.close()
            try:
                prefetch_features(
                    cache_dir=cfg.data.mootdx_cache_dir,
                    cfg=cfg,
                    workers=4,
                    db_path=_db_path,
                    store=None,
                )
            finally:
                if _db_path:
                    store = MarketStore(db_path=_db_path)

    artifacts = run_backtest(
        cfg=cfg,
        start=args.start,
        end=args.end,
        pool_size=args.pool,
        initial_cash=args.init_cash,
        symbols=symbols,
        active_event_types=active_event_types,
        store=store,
    )
    cfg.backtest.pool_size = args.pool
    write_reports(str(output_dir), artifacts.result, artifacts.bundle, cfg, args.start, args.end, equity_curve=artifacts.equity_curve, pool_name=args.pool_name, active_event_types=active_event_types)
    print(json.dumps(artifacts.result.summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
