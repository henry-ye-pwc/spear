"""CP-10: Phase C parallelization + IPC elimination.

Tests the thread-based Phase C batch worker and the parallel orchestrator.
"""
from __future__ import annotations

from unittest.mock import MagicMock, patch
from dataclasses import dataclass, field

import pandas as pd
import pytest

from v5.backtest.prepare import (
    PreparedBundle,
    _phase_c_symbol_batch,
    _run_phase_c_parallel,
)
from v5.tests.fixtures import make_bars


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _minimal_bundle(symbols: list[str], n_dates: int = 5) -> tuple:
    """Create a minimal bundle + Phase B context for testing Phase C."""
    bundle = PreparedBundle(universe=pd.DataFrame({"symbol": symbols}))

    n_rows = 200
    idx = pd.bdate_range("2025-01-02", periods=n_rows, freq="B")
    all_dates_str = [str(d)[:10] for d in idx]
    dates = all_dates_str[-(n_dates):]

    for sym in symbols:
        frame = pd.DataFrame(
            {"close": 10.0, "pct": 0.0, "volume": 1000000.0},
            index=idx,
        )
        bundle.feature_data[sym] = frame
        bundle.dates_by_symbol[sym] = all_dates_str
        bundle.idx_by_symbol_date[sym] = {d: i for i, d in enumerate(all_dates_str)}

    raw_events: dict = {}
    day_theme_counts: dict = {}
    day_theme_leaders: dict = {}
    active_date_themes: set = set()
    lhb_cache: dict = {(sym, d): False for sym in symbols for d in dates}

    return (
        bundle, raw_events, day_theme_counts, day_theme_leaders,
        active_date_themes, lhb_cache, dates,
    )


class FakeEnv:
    def get_symbol_meta(self, sym):
        return {"industry": "科技"}

    def recent_lhb_net_sell(self, sym, date):
        return False


class FakeCfg:
    class data:
        disable_env_mapping = True
    class models:
        pass


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

class TestPhaseCBatch:
    def test_all_skipped_when_no_signals(self):
        """With no Phase B signals and no active themes, all pairs are skipped."""
        symbols = ["000001", "000002"]
        (bundle, raw_events, dtc, dtl,
         adt, lhb, dates) = _minimal_bundle(symbols)

        # Patch detect_signals to ensure it's never called
        with patch("v5.backtest.prepare.detect_signals") as mock_detect:
            result = _phase_c_symbol_batch(
                symbols, dates, bundle, raw_events,
                dtc, dtl, adt, lhb,
                {}, None, FakeEnv(), FakeCfg(),
            )

        assert result["skipped_pairs"] > 0
        assert result["processed_pairs"] == 0
        mock_detect.assert_not_called()

    def test_processes_pair_with_signals(self):
        """When Phase B signals exist, Phase C calls detect_signals."""
        symbols = ["000001"]
        (bundle, raw_events, dtc, dtl,
         adt, lhb, dates) = _minimal_bundle(symbols, n_dates=1)

        # Inject a Phase B signal for 000001 on the first valid date
        valid_dates = [d for d in bundle.dates_by_symbol["000001"]
                       if bundle.idx_by_symbol_date["000001"].get(d, 0) >= 120]
        if not valid_dates:
            pytest.skip("No valid dates with idx >= 120")
        target_date = valid_dates[0]
        fake_signal = MagicMock()
        fake_signal.event_type = "trend_spear"
        fake_signal.confidence = 0.8
        raw_events[("000001", target_date)] = [fake_signal]

        with patch("v5.backtest.prepare.detect_signals", return_value=[]) as mock_detect:
            result = _phase_c_symbol_batch(
                symbols, [target_date], bundle, raw_events,
                dtc, dtl, adt, lhb,
                {}, None, FakeEnv(), FakeCfg(),
            )

        assert result["processed_pairs"] >= 1
        mock_detect.assert_called()

    def test_result_structure(self):
        symbols = ["000001"]
        (bundle, raw_events, dtc, dtl,
         adt, lhb, dates) = _minimal_bundle(symbols)

        with patch("v5.backtest.prepare.detect_signals", return_value=[]):
            result = _phase_c_symbol_batch(
                symbols, dates, bundle, raw_events,
                dtc, dtl, adt, lhb,
                {}, None, FakeEnv(), FakeCfg(),
            )

        assert "events_by_sd" in result
        assert "env_by_sd" in result
        assert "flat_events" in result
        assert "total_pairs" in result
        assert "processed_pairs" in result
        assert "skipped_pairs" in result
        assert isinstance(result["flat_events"], list)


class TestPhaseCParallel:
    def test_single_thread_fallback(self):
        """With n_threads=1, runs directly without ThreadPoolExecutor."""
        symbols = ["000001", "000002"]
        (bundle, raw_events, dtc, dtl,
         adt, lhb, dates) = _minimal_bundle(symbols)

        with patch("v5.backtest.prepare.detect_signals", return_value=[]):
            result = _run_phase_c_parallel(
                symbols, dates, bundle, raw_events,
                dtc, dtl, adt, lhb,
                {}, None, FakeEnv(), FakeCfg(),
                n_threads=1,
            )

        assert result["total_pairs"] >= 0

    def test_multi_thread(self):
        """Multiple threads produce merged results."""
        symbols = [f"00000{i}" for i in range(1, 6)]
        (bundle, raw_events, dtc, dtl,
         adt, lhb, dates) = _minimal_bundle(symbols, n_dates=3)

        with patch("v5.backtest.prepare.detect_signals", return_value=[]):
            result = _run_phase_c_parallel(
                symbols, dates, bundle, raw_events,
                dtc, dtl, adt, lhb,
                {}, None, FakeEnv(), FakeCfg(),
                n_threads=3,
            )

        assert result["total_pairs"] > 0

    def test_deterministic_across_thread_counts(self):
        """Results are the same whether using 1 or 4 threads."""
        symbols = [f"00000{i}" for i in range(1, 4)]
        (bundle, raw_events, dtc, dtl,
         adt, lhb, dates) = _minimal_bundle(symbols, n_dates=2)

        with patch("v5.backtest.prepare.detect_signals", return_value=[]):
            r1 = _run_phase_c_parallel(
                symbols, dates, bundle, raw_events,
                dtc, dtl, adt, lhb,
                {}, None, FakeEnv(), FakeCfg(),
                n_threads=1,
            )

        with patch("v5.backtest.prepare.detect_signals", return_value=[]):
            r4 = _run_phase_c_parallel(
                symbols, dates, bundle, raw_events,
                dtc, dtl, adt, lhb,
                {}, None, FakeEnv(), FakeCfg(),
                n_threads=4,
            )

        assert r1["total_pairs"] == r4["total_pairs"]
        assert r1["processed_pairs"] == r4["processed_pairs"]
        assert r1["skipped_pairs"] == r4["skipped_pairs"]
        assert len(r1["flat_events"]) == len(r4["flat_events"])

    def test_small_symbol_list_uses_single_thread(self):
        """With fewer than 10 symbols, falls back to single-thread."""
        symbols = ["000001"]
        (bundle, raw_events, dtc, dtl,
         adt, lhb, dates) = _minimal_bundle(symbols)

        with patch("v5.backtest.prepare.detect_signals", return_value=[]):
            result = _run_phase_c_parallel(
                symbols, dates, bundle, raw_events,
                dtc, dtl, adt, lhb,
                {}, None, FakeEnv(), FakeCfg(),
                n_threads=4,
            )

        assert result["total_pairs"] >= 0
