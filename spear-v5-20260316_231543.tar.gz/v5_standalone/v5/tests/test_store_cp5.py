"""CP-5: Prefetch — workers write PKL, main process syncs to DuckDB."""
from __future__ import annotations

import os
from unittest.mock import patch

import pandas as pd
import pytest

from v5.data.prefetch import (
    _sync_pkl_to_duckdb,
    prefetch_symbols,
)
from v5.data.store import MarketStore
from v5.tests.fixtures import make_bars, make_bars_batch


# ---------------------------------------------------------------------------
# _sync_pkl_to_duckdb
# ---------------------------------------------------------------------------

class TestSyncPklToDuckdb:
    def test_basic(self, tmp_path):
        """Reads PKL files and inserts into DuckDB."""
        store = MarketStore(db_path=str(tmp_path / "sync.duckdb"))
        cache_dir = str(tmp_path / "cache")
        os.makedirs(cache_dir)

        batch = make_bars_batch(["000001", "000002"], n_days=100)
        for sym, df in batch.items():
            df.to_pickle(os.path.join(cache_dir, f"{sym}_full.pkl"))

        synced = _sync_pkl_to_duckdb(store, ["000001", "000002"], cache_dir)
        assert synced == 2
        assert len(store.read_bars("000001")) == 100
        assert len(store.read_bars("000002")) == 100
        store.close()

    def test_marks_refreshed(self, tmp_path):
        """Verify symbols_meta is updated after sync."""
        store = MarketStore(db_path=str(tmp_path / "meta.duckdb"))
        cache_dir = str(tmp_path / "cache")
        os.makedirs(cache_dir)

        df = make_bars("000001", n_days=50)
        df.to_pickle(os.path.join(cache_dir, "000001_full.pkl"))

        _sync_pkl_to_duckdb(store, ["000001"], cache_dir)
        row = store._conn.execute(
            "SELECT last_fetched_at, bar_count FROM symbols_meta WHERE symbol = '000001'"
        ).fetchone()
        assert row is not None
        assert row[0] > 0
        assert row[1] == 50
        store.close()

    def test_skips_missing_pkl(self, tmp_path):
        """Symbols without PKL files are silently skipped."""
        store = MarketStore(db_path=str(tmp_path / "skip.duckdb"))
        cache_dir = str(tmp_path / "cache")
        os.makedirs(cache_dir)

        synced = _sync_pkl_to_duckdb(store, ["999999"], cache_dir)
        assert synced == 0
        store.close()

    def test_batching(self, tmp_path):
        """More than BATCH_SIZE symbols are processed in chunks."""
        store = MarketStore(db_path=str(tmp_path / "batch.duckdb"))
        cache_dir = str(tmp_path / "cache")
        os.makedirs(cache_dir)

        syms = [str(i).zfill(6) for i in range(150)]
        for sym in syms:
            make_bars(sym, n_days=10).to_pickle(
                os.path.join(cache_dir, f"{sym}_full.pkl")
            )

        synced = _sync_pkl_to_duckdb(store, syms, cache_dir)
        assert synced == 150
        assert store.symbol_count() == 150
        store.close()

    def test_needs_refresh_false_after_sync(self, tmp_path):
        """After sync, needs_refresh returns False (freshness updated)."""
        store = MarketStore(db_path=str(tmp_path / "fresh.duckdb"))
        cache_dir = str(tmp_path / "cache")
        os.makedirs(cache_dir)

        df = make_bars("000001", n_days=200)
        df.to_pickle(os.path.join(cache_dir, "000001_full.pkl"))

        last_date = str(df.index.max())[:10]
        assert store.needs_refresh("000001", last_date) is True

        _sync_pkl_to_duckdb(store, ["000001"], cache_dir)
        assert store.needs_refresh("000001", last_date) is False
        store.close()

    def test_idempotent_sync(self, tmp_path):
        """Syncing twice produces the same result (INSERT OR REPLACE)."""
        store = MarketStore(db_path=str(tmp_path / "idem.duckdb"))
        cache_dir = str(tmp_path / "cache")
        os.makedirs(cache_dir)

        df = make_bars("000001", n_days=100)
        df.to_pickle(os.path.join(cache_dir, "000001_full.pkl"))

        synced1 = _sync_pkl_to_duckdb(store, ["000001"], cache_dir)
        assert synced1 == 1
        assert len(store.read_bars("000001")) == 100

        synced2 = _sync_pkl_to_duckdb(store, ["000001"], cache_dir)
        assert synced2 == 1
        assert len(store.read_bars("000001")) == 100
        store.close()


# ---------------------------------------------------------------------------
# prefetch_symbols with DuckDB store
# ---------------------------------------------------------------------------

class TestPrefetchWithStore:
    def test_single_worker_syncs_duckdb(self, tmp_path):
        """Single-worker mode: workers write PKL, then main syncs to DuckDB."""
        bars = make_bars("000001", n_days=100)
        store = MarketStore(db_path=str(tmp_path / "pf.duckdb"))
        cache_dir = str(tmp_path / "cache")
        os.makedirs(cache_dir)

        bars.to_pickle(os.path.join(cache_dir, "000001_full.pkl"))

        with patch("cq_backtest.data.feed.DataFeed") as MockFeed:
            instance = MockFeed.return_value
            instance.get_kline.return_value = bars
            instance.client = None

            result = prefetch_symbols(
                ["000001"], cache_dir,
                workers=1, cache_only=True, store=store,
            )

        assert result["errors"] == 0
        assert len(store.read_bars("000001")) == 100
        row = store._conn.execute(
            "SELECT last_fetched_at FROM symbols_meta WHERE symbol = '000001'"
        ).fetchone()
        assert row is not None and row[0] > 0
        store.close()

    def test_legacy_pkl_mode(self, tmp_path):
        """Without store, prefetch_symbols uses PKL path only."""
        bars = make_bars("000001", n_days=100)
        cache_dir = str(tmp_path / "cache")

        with patch("cq_backtest.data.feed.DataFeed") as MockFeed:
            instance = MockFeed.return_value
            instance.get_kline.return_value = bars
            instance.client = None

            result = prefetch_symbols(
                ["000001"], cache_dir,
                workers=1, cache_only=True, store=None,
            )

        assert result["workers_used"] == 1


class TestPrefetchEmpty:
    def test_empty_symbols(self, tmp_path):
        store = MarketStore(db_path=str(tmp_path / "empty.duckdb"))
        result = prefetch_symbols([], str(tmp_path / "cache"), store=store)
        assert result["total"] == 0
        store.close()
