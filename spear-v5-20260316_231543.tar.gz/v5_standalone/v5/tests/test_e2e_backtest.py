"""E2E tests: prepare_bundle + run_backtest with mocked data (Numba/optimizations enabled)."""
from __future__ import annotations

import pandas as pd

from v5.backtest.prepare import prepare_bundle
from v5.backtest.runner import run_backtest
from v5.config.defaults import load_default_config
from v5.data.router import V5DataRouter


def test_prepare_and_backtest_run_produces_consistent_result(monkeypatch) -> None:
    """Full pipeline: prepare_bundle -> run_backtest; result has expected structure and types."""
    cfg = load_default_config()
    universe = pd.DataFrame(
        {"symbol": ["000001", "600036"], "name": ["平安银行", "招商银行"]},
    )
    raw_idx = pd.date_range("2024-01-01", periods=200, freq="B")
    raw = pd.DataFrame(
        {
            "open": [10.0] * len(raw_idx),
            "high": [10.2] * len(raw_idx),
            "low": [9.8] * len(raw_idx),
            "close": [10.1] * len(raw_idx),
            "volume": [1000.0] * len(raw_idx),
            "amount": [10100.0] * len(raw_idx),
            "symbol": ["000001"] * len(raw_idx),
        },
        index=raw_idx,
    )

    monkeypatch.setattr(V5DataRouter, "load_universe", lambda self, pool_size: universe.copy())
    monkeypatch.setattr(
        V5DataRouter, "load_symbol", lambda self, symbol, start, end: raw.assign(symbol=symbol).copy()
    )

    bundle = prepare_bundle(
        cfg, start="2024-01-02", end="2024-06-30", pool_size=2, symbols=["000001", "600036"]
    )
    assert bundle.universe is not None
    assert len(bundle.feature_data) >= 1

    arts = run_backtest(
        cfg=cfg,
        start="2024-01-02",
        end="2024-06-30",
        pool_size=2,
        initial_cash=1_000_000.0,
        symbols=["000001", "600036"],
        bundle=bundle,
    )
    assert arts.result is not None
    assert arts.result.summary is not None
    s = arts.result.summary
    assert "equity_return_pct" in s
    assert "trade_count" in s
    assert "equity_final" in s
    assert isinstance(arts.result.trades, list)
    assert arts.equity_curve is not None
    assert len(arts.equity_curve) >= 1
