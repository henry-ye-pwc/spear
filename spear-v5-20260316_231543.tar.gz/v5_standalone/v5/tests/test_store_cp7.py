"""CP-7: End-to-end equivalence — PKL vs DuckDB produce identical output.

Tests that both DataFeed paths return bit-identical data for the same
synthetic inputs, and that the calendar/effective-date logic produces
the same results.
"""
from __future__ import annotations

import os

import numpy as np
import pandas as pd
import pytest

from cq_backtest.data.feed import DataFeed
from v5.data.store import MarketStore
from v5.tests.fixtures import make_bars, make_bars_batch


def _setup_pkl_feed(tmp_path, bars_dict):
    """Create a PKL-backed DataFeed with pre-cached data."""
    cache_dir = str(tmp_path / "pkl_cache")
    os.makedirs(cache_dir, exist_ok=True)
    for sym, df in bars_dict.items():
        df.to_pickle(os.path.join(cache_dir, f"{sym}_full.pkl"))
    return DataFeed(cache_dir=cache_dir)


def _setup_duckdb_feed(tmp_path, bars_dict):
    """Create a DuckDB-backed DataFeed with pre-loaded data."""
    db_path = str(tmp_path / "equiv.duckdb")
    store = MarketStore(db_path=db_path)
    for sym, df in bars_dict.items():
        store.upsert_bars(sym, df)
        store.mark_refreshed(sym)
    cache_dir = str(tmp_path / "duck_cache")
    os.makedirs(cache_dir, exist_ok=True)
    feed = DataFeed(cache_dir=cache_dir, store=store)
    return feed, store


class TestGetKlineEquivalence:
    """Verify PKL and DuckDB paths return identical DataFrames."""

    @pytest.fixture
    def bars_dict(self):
        return make_bars_batch(["000001", "000002", "600000"], n_days=250)

    def test_full_read_equivalence(self, tmp_path, bars_dict):
        pkl_feed = _setup_pkl_feed(tmp_path, bars_dict)
        duck_feed, store = _setup_duckdb_feed(tmp_path, bars_dict)

        for sym in bars_dict:
            pkl_result = pkl_feed.get_kline(sym, cache_only=True, count=9999)
            duck_result = duck_feed.get_kline(sym, cache_only=True, count=9999)

            assert len(pkl_result) == len(duck_result), f"{sym}: row count mismatch"
            pd.testing.assert_index_equal(pkl_result.index, duck_result.index)
            for col in ["open", "high", "low", "close", "volume", "amount"]:
                np.testing.assert_array_equal(
                    pkl_result[col].values, duck_result[col].values,
                    err_msg=f"{sym}.{col} differs between PKL and DuckDB",
                )
        store.close()

    def test_end_date_filter_equivalence(self, tmp_path, bars_dict):
        pkl_feed = _setup_pkl_feed(tmp_path, bars_dict)
        duck_feed, store = _setup_duckdb_feed(tmp_path, bars_dict)

        for sym in bars_dict:
            end = str(bars_dict[sym].index[150].date())
            pkl_result = pkl_feed.get_kline(sym, end_date=end, cache_only=True, count=9999)
            duck_result = duck_feed.get_kline(sym, end_date=end, cache_only=True, count=9999)

            assert len(pkl_result) == len(duck_result), f"{sym}: row count for end_date={end}"
            for col in ["close", "volume"]:
                np.testing.assert_array_equal(
                    pkl_result[col].values, duck_result[col].values,
                    err_msg=f"{sym}.{col} end_date filter",
                )
        store.close()

    def test_count_filter_equivalence(self, tmp_path, bars_dict):
        pkl_feed = _setup_pkl_feed(tmp_path, bars_dict)
        duck_feed, store = _setup_duckdb_feed(tmp_path, bars_dict)

        for sym in bars_dict:
            pkl_result = pkl_feed.get_kline(sym, count=100, cache_only=True)
            duck_result = duck_feed.get_kline(sym, count=100, cache_only=True)

            assert len(pkl_result) == len(duck_result) == 100
            np.testing.assert_array_equal(
                pkl_result["close"].values, duck_result["close"].values,
            )
        store.close()

    def test_empty_symbol_equivalence(self, tmp_path, bars_dict):
        pkl_feed = _setup_pkl_feed(tmp_path, bars_dict)
        duck_feed, store = _setup_duckdb_feed(tmp_path, bars_dict)

        pkl_result = pkl_feed.get_kline("999999", cache_only=True)
        duck_result = duck_feed.get_kline("999999", cache_only=True)
        assert pkl_result.empty
        assert duck_result.empty
        store.close()


class TestCalendarEquivalence:
    """Verify DuckDB calendar matches PKL-inferred calendar."""

    def test_calendar_from_store_vs_pkl(self, tmp_path):
        syms = ["000001", "000002"]
        bars = make_bars_batch(syms, n_days=200)

        # PKL calendar: peek from PKL files
        cache_dir = str(tmp_path / "pkl")
        os.makedirs(cache_dir, exist_ok=True)
        for sym, df in bars.items():
            df.to_pickle(os.path.join(cache_dir, f"{sym}_full.pkl"))

        from v5.daily_signal_job import _peek_recent_trading_dates
        pkl_cal = _peek_recent_trading_dates(cache_dir, n=200, up_to="2026-12-31", symbols=syms)

        # DuckDB calendar
        store = MarketStore(db_path=str(tmp_path / "cal.duckdb"))
        for sym, df in bars.items():
            store.upsert_bars(sym, df)
        duck_cal = store.trading_dates(up_to="2026-12-31", n=200)
        store.close()

        assert pkl_cal == duck_cal, (
            f"Calendar mismatch: PKL has {len(pkl_cal)} dates, "
            f"DuckDB has {len(duck_cal)} dates"
        )


class TestMigrationThenRead:
    """Simulate: migrate PKL → DuckDB, then read via DuckDB feed."""

    def test_migrate_then_read_identical(self, tmp_path):
        from v5.data.migrate_pkl import migrate

        bars = make_bars_batch(["000001", "000002"], n_days=200)
        cache_dir = tmp_path / "cache"
        cache_dir.mkdir()
        for sym, df in bars.items():
            df.to_pickle(cache_dir / f"{sym}_full.pkl")

        db_path = str(tmp_path / "migrated.duckdb")
        migrate(str(cache_dir), db_path, verify=True)

        store = MarketStore(db_path=db_path, read_only=True)
        feed = DataFeed(cache_dir=str(cache_dir), store=store)

        for sym, orig in bars.items():
            result = feed.get_kline(sym, cache_only=True, count=9999)
            assert len(result) == len(orig)
            for col in ["open", "high", "low", "close", "volume", "amount"]:
                np.testing.assert_array_equal(
                    orig[col].values, result[col].values,
                    err_msg=f"Post-migration {sym}.{col} mismatch",
                )
        store.close()
