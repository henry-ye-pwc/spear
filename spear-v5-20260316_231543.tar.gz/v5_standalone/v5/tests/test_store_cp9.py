"""CP-9: DuckDB bulk read + pre-load for Phase A workers.

Tests read_bars_multi() and the pre-load architecture where the main process
reads all data from DuckDB and passes it to workers via IPC.
"""
from __future__ import annotations

import numpy as np
import pandas as pd
import pytest

from v5.data.store import MarketStore
from v5.tests.fixtures import make_bars


@pytest.fixture
def store(tmp_path):
    s = MarketStore(db_path=str(tmp_path / "multi.duckdb"))
    yield s
    s.close()


class TestReadBarsMulti:
    def test_basic(self, store):
        for sym in ["000001", "000002", "600000"]:
            bars = make_bars(sym, n_days=200)
            store.upsert_bars(sym, bars)
        result = store.read_bars_multi(["000001", "000002", "600000"])
        assert len(result) == 3
        assert all(isinstance(df, pd.DataFrame) for df in result.values())
        assert all(len(df) == 200 for df in result.values())

    def test_partial_symbols(self, store):
        bars = make_bars("000001", n_days=100)
        store.upsert_bars("000001", bars)
        result = store.read_bars_multi(["000001", "999999"])
        assert len(result) == 1
        assert "000001" in result
        assert "999999" not in result

    def test_empty_symbols(self, store):
        assert store.read_bars_multi([]) == {}

    def test_date_filter(self, store):
        bars = make_bars("000001", n_days=300)
        store.upsert_bars("000001", bars)
        mid = str(bars.index[150])[:10]
        result = store.read_bars_multi(["000001"], start=mid)
        assert len(result["000001"]) < 300
        assert str(result["000001"].index[0])[:10] >= mid

    def test_correct_columns(self, store):
        bars = make_bars("000001", n_days=50)
        store.upsert_bars("000001", bars)
        result = store.read_bars_multi(["000001"])
        df = result["000001"]
        for col in ["open", "high", "low", "close", "volume", "amount"]:
            assert col in df.columns
        assert "symbol" not in df.columns

    def test_index_is_datetime(self, store):
        bars = make_bars("000001", n_days=50)
        store.upsert_bars("000001", bars)
        result = store.read_bars_multi(["000001"])
        assert isinstance(result["000001"].index, pd.DatetimeIndex)


class TestFeatureCacheTableDropped:
    def test_no_feature_cache_table(self, store):
        tables = store._conn.execute(
            "SELECT table_name FROM information_schema.tables WHERE table_name = 'feature_cache'"
        ).fetchall()
        assert len(tables) == 0
