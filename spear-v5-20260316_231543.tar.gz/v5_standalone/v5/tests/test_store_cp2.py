"""CP-2: Migration script — PKL → DuckDB, row-level verification."""
from __future__ import annotations

import numpy as np
import pandas as pd
import pytest

from v5.data.migrate_pkl import (
    discover_pkl_files,
    load_pkl,
    migrate,
    verify_symbol,
)
from v5.data.store import MarketStore
from v5.tests.fixtures import make_bars, make_bars_batch


def _create_pkl_file(cache_dir, symbol, df):
    path = cache_dir / f"{symbol}_full.pkl"
    df.to_pickle(path)
    return path


@pytest.fixture
def cache_with_pkls(tmp_path):
    """Create a tmp cache dir with several PKL files."""
    cache_dir = tmp_path / "cache"
    cache_dir.mkdir()
    syms = ["000001", "000002", "600000", "300001", "688001"]
    batch = make_bars_batch(syms, n_days=200)
    for sym, df in batch.items():
        _create_pkl_file(cache_dir, sym, df)
    return cache_dir, batch


# =====================================================================
# discover_pkl_files
# =====================================================================

class TestDiscoverPkl:
    def test_finds_all(self, cache_with_pkls):
        cache_dir, _ = cache_with_pkls
        files = discover_pkl_files(str(cache_dir))
        assert len(files) == 5
        assert all(f.name.endswith("_full.pkl") for f in files)

    def test_ignores_non_full(self, cache_with_pkls):
        cache_dir, _ = cache_with_pkls
        (cache_dir / "stock_list.pkl").write_bytes(b"dummy")
        files = discover_pkl_files(str(cache_dir))
        assert len(files) == 5

    def test_empty_dir(self, tmp_path):
        files = discover_pkl_files(str(tmp_path / "nonexistent"))
        assert files == []


# =====================================================================
# load_pkl
# =====================================================================

class TestLoadPkl:
    def test_valid(self, cache_with_pkls):
        cache_dir, _ = cache_with_pkls
        pkl = cache_dir / "000001_full.pkl"
        sym, df = load_pkl(pkl)
        assert sym == "000001"
        assert df is not None
        assert len(df) == 200

    def test_corrupt(self, tmp_path):
        bad_pkl = tmp_path / "BAD_full.pkl"
        bad_pkl.write_bytes(b"not a pickle")
        sym, df = load_pkl(bad_pkl)
        assert sym == "BAD"
        assert df is None

    def test_empty_df(self, tmp_path):
        pkl = tmp_path / "EMPTY_full.pkl"
        pd.DataFrame().to_pickle(pkl)
        sym, df = load_pkl(pkl)
        assert sym == "EMPTY"
        assert df is None


# =====================================================================
# Full migration
# =====================================================================

class TestMigrate:
    def test_basic(self, cache_with_pkls, tmp_path):
        cache_dir, original = cache_with_pkls
        db_path = str(tmp_path / "migrated.duckdb")
        result = migrate(str(cache_dir), db_path, verify=True, batch_size=3)
        assert result["total"] == 5
        assert result["migrated"] == 5
        assert result["skipped"] == 0
        assert result["failed"] == 0

        store = MarketStore(db_path=db_path, read_only=True)
        assert store.symbol_count() == 5
        for sym, orig_df in original.items():
            db_df = store.read_bars(sym)
            assert len(db_df) == len(orig_df)
        store.close()

    def test_float64_exact(self, cache_with_pkls, tmp_path):
        """Migration preserves float64 values bit-exactly."""
        cache_dir, original = cache_with_pkls
        db_path = str(tmp_path / "exact.duckdb")
        migrate(str(cache_dir), db_path, verify=False)

        store = MarketStore(db_path=db_path, read_only=True)
        for sym, orig_df in original.items():
            db_df = store.read_bars(sym)
            for col in ["open", "high", "low", "close", "volume", "amount"]:
                np.testing.assert_array_equal(
                    orig_df[col].values, db_df[col].values,
                    err_msg=f"{sym}.{col} not bit-exact after migration",
                )
        store.close()

    def test_with_nan(self, tmp_path):
        cache_dir = tmp_path / "cache"
        cache_dir.mkdir()
        df = make_bars("000001", include_nan_amount=True)
        _create_pkl_file(cache_dir, "000001", df)
        db_path = str(tmp_path / "nan.duckdb")
        result = migrate(str(cache_dir), db_path, verify=True)
        assert result["migrated"] == 1
        assert result["failed"] == 0

    def test_with_placeholder(self, tmp_path):
        cache_dir = tmp_path / "cache"
        cache_dir.mkdir()
        df = make_bars("000001", placeholder_tail=5)
        _create_pkl_file(cache_dir, "000001", df)
        db_path = str(tmp_path / "ph.duckdb")
        result = migrate(str(cache_dir), db_path, verify=True)
        assert result["migrated"] == 1
        assert result["failed"] == 0

        store = MarketStore(db_path=db_path, read_only=True)
        out = store.read_bars("000001")
        assert (out["volume"].iloc[-5:] == 0.0).all()
        store.close()

    def test_idempotent(self, cache_with_pkls, tmp_path):
        """Running migration twice doesn't duplicate data."""
        cache_dir, _ = cache_with_pkls
        db_path = str(tmp_path / "idem.duckdb")
        migrate(str(cache_dir), db_path, verify=False)
        migrate(str(cache_dir), db_path, verify=False)

        store = MarketStore(db_path=db_path, read_only=True)
        assert store.symbol_count() == 5
        for sym in ["000001", "000002", "600000", "300001", "688001"]:
            assert len(store.read_bars(sym)) == 200
        store.close()

    def test_skips_corrupt(self, cache_with_pkls, tmp_path):
        cache_dir, _ = cache_with_pkls
        (cache_dir / "CORRUPT_full.pkl").write_bytes(b"garbage")
        db_path = str(tmp_path / "skip.duckdb")
        result = migrate(str(cache_dir), db_path, verify=False)
        assert result["total"] == 6
        assert result["migrated"] == 5
        assert result["skipped"] == 1


# =====================================================================
# verify_symbol (standalone)
# =====================================================================

class TestVerifySymbol:
    def test_pass(self, tmp_path):
        store = MarketStore(db_path=str(tmp_path / "v.duckdb"))
        df = make_bars("000001", n_days=100)
        store.upsert_bars("000001", df)
        ok, msg = verify_symbol(store, "000001", df)
        assert ok is True
        assert msg == "OK"
        store.close()

    def test_row_count_mismatch(self, tmp_path):
        store = MarketStore(db_path=str(tmp_path / "v2.duckdb"))
        df = make_bars("000001", n_days=100)
        store.upsert_bars("000001", df.iloc[:90])
        ok, msg = verify_symbol(store, "000001", df)
        assert ok is False
        assert "Row count" in msg
        store.close()

    def test_value_mismatch(self, tmp_path):
        store = MarketStore(db_path=str(tmp_path / "v3.duckdb"))
        df = make_bars("000001", n_days=100)
        store.upsert_bars("000001", df)
        tampered = df.copy()
        tampered.iloc[50, tampered.columns.get_loc("close")] = 999999.0
        ok, msg = verify_symbol(store, "000001", tampered)
        assert ok is False
        assert "close" in msg
        store.close()
