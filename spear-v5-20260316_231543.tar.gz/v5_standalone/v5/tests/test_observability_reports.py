from __future__ import annotations

import json

import pandas as pd

from v4.reports.analytics import build_closed_trades
from v5.reports.writer import _flatten_json_columns


def test_build_closed_trades_preserves_trade_meta():
    trades = pd.DataFrame(
        [
            {
                "date": "2025-01-02",
                "symbol": "000001",
                "action": "buy",
                "price": 10.0,
                "qty": 100.0,
                "reason": "entry:trend_spear",
                "meta": json.dumps(
                    {
                        "net_cash_delta": -1005.0,
                        "signal_date": "2025-01-01",
                        "signal_confidence": 0.81,
                        "entry_style": "hunt",
                    },
                    ensure_ascii=False,
                ),
            },
            {
                "date": "2025-01-05",
                "symbol": "000001",
                "action": "sell",
                "price": 11.0,
                "qty": 100.0,
                "reason": "time_exit",
                "meta": json.dumps(
                    {
                        "net_cash_delta": 1094.0,
                        "decision_date": "2025-01-04",
                        "reason": "time_exit",
                        "drawdown_from_peak": 0.123,
                    },
                    ensure_ascii=False,
                ),
            },
        ]
    )

    closed = build_closed_trades(trades)

    assert len(closed) == 1
    row = closed.iloc[0]
    assert row["signal_date"] == "2025-01-01"
    assert json.loads(row["entry_meta"])["signal_confidence"] == 0.81
    assert json.loads(row["exit_meta"])["decision_date"] == "2025-01-04"


def test_flatten_json_columns_expands_nested_meta():
    df = pd.DataFrame(
        [
            {
                "symbol": "000001",
                "entry_meta": json.dumps(
                    {
                        "signal_peer_confirmation": 9,
                        "entry_plan": {"gate_price": 10.5},
                    },
                    ensure_ascii=False,
                ),
                "exit_meta": json.dumps(
                    {
                        "day_amount_vs_hsm": 0.82,
                        "signal_theme_label": "其他",
                    },
                    ensure_ascii=False,
                ),
            }
        ]
    )

    flat = _flatten_json_columns(df, ["entry_meta", "exit_meta"])

    assert flat.loc[0, "entry_meta.signal_peer_confirmation"] == 9
    assert flat.loc[0, "entry_meta.entry_plan.gate_price"] == 10.5
    assert flat.loc[0, "exit_meta.day_amount_vs_hsm"] == 0.82
    assert flat.loc[0, "exit_meta.signal_theme_label"] == "其他"
