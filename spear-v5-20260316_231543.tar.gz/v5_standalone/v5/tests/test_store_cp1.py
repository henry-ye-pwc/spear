"""CP-1: MarketStore core — schema, bar CRUD, calendar, freshness API."""
from __future__ import annotations

import multiprocessing
import time
from datetime import datetime, timezone

import numpy as np
import pandas as pd
import pytest

from v5.data.store import MarketStore
from v5.tests.fixtures import make_bars, make_bars_batch


@pytest.fixture
def store(tmp_path):
    db_path = str(tmp_path / "test.duckdb")
    s = MarketStore(db_path=db_path)
    yield s
    s.close()


# =====================================================================
# Bar CRUD
# =====================================================================

class TestUpsertBars:
    def test_basic(self, store):
        df = make_bars("000001", n_days=200)
        written = store.upsert_bars("000001", df)
        assert written == 200
        out = store.read_bars("000001")
        assert len(out) == 200
        assert list(out.columns) == ["open", "high", "low", "close", "volume", "amount"]

    def test_float64_roundtrip(self, store):
        """Every float64 value survives DuckDB DOUBLE roundtrip bit-exactly."""
        df = make_bars("000001", n_days=200, base_price=123.456)
        store.upsert_bars("000001", df)
        out = store.read_bars("000001")
        for col in ["open", "high", "low", "close", "volume", "amount"]:
            np.testing.assert_array_equal(
                df[col].values, out[col].values,
                err_msg=f"Column {col} not bit-exact after roundtrip",
            )

    def test_nan_handling(self, store):
        df = make_bars("000001", include_nan_amount=True)
        nan_count = df["amount"].isna().sum()
        assert nan_count > 0
        store.upsert_bars("000001", df)
        out = store.read_bars("000001")
        assert out["amount"].isna().sum() == nan_count
        non_nan_mask = df["amount"].notna()
        np.testing.assert_array_equal(
            df.loc[non_nan_mask, "amount"].values,
            out.loc[non_nan_mask, "amount"].values,
        )

    def test_zero_volume(self, store):
        """Placeholder bars with volume=0 stored as 0.0, not NULL."""
        df = make_bars("000001", placeholder_tail=3)
        store.upsert_bars("000001", df)
        out = store.read_bars("000001")
        assert (out["volume"].iloc[-3:] == 0.0).all()
        assert out["volume"].iloc[-3:].notna().all()

    def test_duplicate_date_upsert(self, store):
        """Second write for same (symbol, date) overwrites."""
        df = make_bars("000001", n_days=5)
        store.upsert_bars("000001", df)

        updated = df.copy()
        updated["close"] = 999.99
        store.upsert_bars("000001", updated)

        out = store.read_bars("000001")
        assert len(out) == 5
        assert (out["close"] == 999.99).all()

    def test_batch(self, store):
        batch = make_bars_batch(["000001", "000002", "600000", "300001", "688001"])
        written = store.upsert_bars_batch(batch)
        assert written == 5 * 200
        for sym in batch:
            out = store.read_bars(sym)
            assert len(out) == 200

    def test_incremental_append(self, store):
        df1 = make_bars("000001", start="2025-01-02", n_days=200, seed=1)
        store.upsert_bars("000001", df1)

        new_start = str(df1.index[-5].date())
        df2 = make_bars("000001", start=new_start, n_days=10, seed=2)
        store.upsert_bars("000001", df2)

        out = store.read_bars("000001")
        assert len(out) == 200 - 5 + 10  # 5 overlapping replaced, 5 new added

    def test_empty_dataframe(self, store):
        written = store.upsert_bars("000001", pd.DataFrame())
        assert written == 0

    def test_none_input(self, store):
        written = store.upsert_bars("000001", None)
        assert written == 0


class TestReadBars:
    def test_date_filter(self, store):
        df = make_bars("000001", start="2025-01-02", n_days=300)
        store.upsert_bars("000001", df)
        out = store.read_bars("000001", start="2025-06-01", end="2025-06-30")
        assert len(out) > 0
        assert out.index.min() >= pd.Timestamp("2025-06-01")
        assert out.index.max() <= pd.Timestamp("2025-06-30")

    def test_empty_symbol(self, store):
        out = store.read_bars("999999")
        assert out.empty
        assert list(out.columns) == ["open", "high", "low", "close", "volume", "amount"]

    def test_returns_datetimeindex(self, store):
        store.upsert_bars("000001", make_bars("000001", n_days=10))
        out = store.read_bars("000001")
        assert isinstance(out.index, pd.DatetimeIndex)

    def test_sorted_by_date(self, store):
        df = make_bars("000001", n_days=100)
        shuffled = df.sample(frac=1, random_state=0)
        store.upsert_bars("000001", shuffled)
        out = store.read_bars("000001")
        assert out.index.is_monotonic_increasing

    def test_column_order(self, store):
        store.upsert_bars("000001", make_bars("000001", n_days=5))
        out = store.read_bars("000001")
        assert list(out.columns) == ["open", "high", "low", "close", "volume", "amount"]


# =====================================================================
# Trading calendar
# =====================================================================

class TestTradingCalendar:
    def test_basic(self, store):
        batch = make_bars_batch(["000001", "000002", "600000"], n_days=200)
        store.upsert_bars_batch(batch)
        cal = store.trading_dates(up_to="2026-12-31", n=300)
        assert len(cal) == 200
        assert cal == sorted(cal)

    def test_up_to_non_trading_day(self, store):
        """Saturday end date — returns through Friday."""
        idx = pd.bdate_range("2026-03-02", periods=10, freq="B")
        df = pd.DataFrame({
            "open": 10.0, "high": 10.5, "low": 9.5,
            "close": 10.2, "volume": 1000.0, "amount": 10200.0,
        }, index=idx)
        store.upsert_bars("000001", df)
        cal = store.trading_dates(up_to="2026-03-14", n=20)
        assert "2026-03-13" in cal
        assert "2026-03-14" not in cal

    def test_limit(self, store):
        store.upsert_bars("000001", make_bars("000001", n_days=200))
        cal = store.trading_dates(up_to="2026-12-31", n=5)
        assert len(cal) == 5

    def test_empty_db(self, store):
        cal = store.trading_dates(up_to="2026-12-31", n=10)
        assert cal == []

    def test_multi_symbol_union(self, store):
        """Calendar is union of all symbols' dates."""
        idx_a = pd.bdate_range("2026-03-02", periods=3, freq="B")
        idx_b = pd.bdate_range("2026-03-04", periods=3, freq="B")
        df_a = pd.DataFrame({
            "open": 10.0, "high": 10.5, "low": 9.5,
            "close": 10.2, "volume": 1000.0, "amount": 10200.0,
        }, index=idx_a)
        df_b = pd.DataFrame({
            "open": 20.0, "high": 20.5, "low": 19.5,
            "close": 20.2, "volume": 2000.0, "amount": 40400.0,
        }, index=idx_b)
        store.upsert_bars("000001", df_a)
        store.upsert_bars("000002", df_b)
        cal = store.trading_dates(up_to="2026-12-31", n=20)
        all_dates = sorted(set(str(d.date()) for d in idx_a) | set(str(d.date()) for d in idx_b))
        assert cal == all_dates

    def test_latest_bar_date_basic(self, store):
        df = make_bars("000001", start="2026-01-02", n_days=50)
        store.upsert_bars("000001", df)
        latest = store.latest_bar_date("000001")
        assert latest == str(df.index[-1].date())

    def test_latest_bar_date_unknown_symbol(self, store):
        assert store.latest_bar_date("999999") is None

    def test_latest_bar_date_global(self, store):
        store.upsert_bars("000001", make_bars("000001", start="2026-01-02", n_days=50))
        store.upsert_bars("000002", make_bars("000002", start="2026-01-02", n_days=80))
        latest = store.latest_bar_date()
        expected = str(make_bars("000002", start="2026-01-02", n_days=80).index[-1].date())
        assert latest == expected


# =====================================================================
# Freshness tracking
# =====================================================================

class TestFreshness:
    def test_needs_refresh_no_data(self, store):
        assert store.needs_refresh("000001", "2026-03-13") is True

    def test_needs_refresh_stale(self, store):
        df = make_bars("000001", start="2026-01-02", n_days=50)
        store.upsert_bars("000001", df)
        store.mark_refreshed("000001")
        last = str(df.index[-1].date())
        far_future = "2026-06-01"
        assert store.needs_refresh("000001", far_future) is True

    def test_needs_refresh_fresh(self, store):
        idx = pd.bdate_range("2026-03-09", periods=5, freq="B")
        df = pd.DataFrame({
            "open": 10.0, "high": 10.5, "low": 9.5,
            "close": 10.2, "volume": 1000.0, "amount": 10200.0,
        }, index=idx)
        store.upsert_bars("000001", df)
        store.mark_refreshed("000001")
        assert store.needs_refresh("000001", "2026-03-13") is False

    def test_needs_refresh_weekend_tolerance(self, store):
        """Last bar = Friday, target = Saturday → no refresh needed if recently fetched."""
        idx = pd.bdate_range("2026-03-09", periods=5, freq="B")
        df = pd.DataFrame({
            "open": 10.0, "high": 10.5, "low": 9.5,
            "close": 10.2, "volume": 1000.0, "amount": 10200.0,
        }, index=idx)
        store.upsert_bars("000001", df)
        store.mark_refreshed("000001")
        assert store.needs_refresh("000001", "2026-03-14", cooldown_seconds=3600) is False

    def test_needs_refresh_cooldown_expired(self, store):
        """After cooldown expires, should refresh even for small gap."""
        idx = pd.bdate_range("2026-03-09", periods=4, freq="B")
        df = pd.DataFrame({
            "open": 10.0, "high": 10.5, "low": 9.5,
            "close": 10.2, "volume": 1000.0, "amount": 10200.0,
        }, index=idx)
        store.upsert_bars("000001", df)
        store.mark_refreshed("000001")
        assert store.needs_refresh("000001", "2026-03-13", cooldown_seconds=0) is True

    def test_mark_refreshed_updates_meta(self, store):
        df = make_bars("000001", start="2026-01-02", n_days=50)
        store.upsert_bars("000001", df)
        store.mark_refreshed("000001", name="平安银行")
        row = store._conn.execute(
            "SELECT symbol, name, last_fetched_at, last_bar_date, bar_count "
            "FROM symbols_meta WHERE symbol = '000001'"
        ).fetchone()
        assert row is not None
        assert row[1] == "平安银行"
        assert row[2] > 0  # last_fetched_at is epoch seconds
        assert row[3] is not None  # last_bar_date
        assert row[4] == 50  # bar_count


# =====================================================================
# Concurrency
# =====================================================================

def _reader_process(db_path: str, symbol: str, expected_count: int, result_queue):
    """Helper for multiprocessing test — opens DB in read-only mode."""
    try:
        s = MarketStore(db_path=db_path, read_only=True)
        out = s.read_bars(symbol)
        s.close()
        result_queue.put(("ok", len(out)))
    except Exception as e:
        result_queue.put(("error", str(e)))


class TestConcurrency:
    def test_concurrent_reads(self, tmp_path):
        db_path = str(tmp_path / "concurrent.duckdb")
        store = MarketStore(db_path=db_path)
        df = make_bars("000001", n_days=100)
        store.upsert_bars("000001", df)
        store.close()

        ctx = multiprocessing.get_context("spawn")
        q = ctx.Queue()
        procs = []
        for _ in range(4):
            p = ctx.Process(
                target=_reader_process,
                args=(db_path, "000001", 100, q),
            )
            procs.append(p)
            p.start()
        for p in procs:
            p.join(timeout=15)

        results = []
        while not q.empty():
            results.append(q.get_nowait())
        assert len(results) == 4
        for status, val in results:
            assert status == "ok", f"Reader failed: {val}"
            assert val == 100

    def test_read_only_rejects_write(self, tmp_path):
        db_path = str(tmp_path / "ro.duckdb")
        MarketStore(db_path=db_path).close()

        ro = MarketStore(db_path=db_path, read_only=True)
        with pytest.raises(Exception):
            ro.upsert_bars("000001", make_bars("000001", n_days=5))
        ro.close()


# =====================================================================
# Metadata helpers
# =====================================================================

class TestMetadata:
    def test_symbol_count(self, store):
        batch = make_bars_batch(["000001", "000002", "600000"])
        store.upsert_bars_batch(batch)
        assert store.symbol_count() == 3

    def test_total_bar_count(self, store):
        batch = make_bars_batch(["000001", "000002"], n_days=100)
        store.upsert_bars_batch(batch)
        assert store.total_bar_count() == 200
