"""CP-8: Studio backend endpoints use DuckDB metadata."""
from __future__ import annotations

import pytest

from studio_backend.models import SignalScanRequest


class TestSignalScanRequestDbPath:
    def test_default_duckdb(self):
        req = SignalScanRequest(date="2026-03-14", output_dir="test")
        assert req.db_path == "cache/market.duckdb"

    def test_custom_path(self):
        req = SignalScanRequest(date="2026-03-14", output_dir="test", db_path="/tmp/custom.duckdb")
        assert req.db_path == "/tmp/custom.duckdb"


class TestSignalCommandBuilder:
    def test_db_path_in_command(self):
        from studio_backend.services.tasks import _build_signal_command
        req = SignalScanRequest(
            date="2026-03-14",
            output_dir="test_output",
            db_path="cache/market.duckdb",
        )
        cmd, _ = _build_signal_command(req)
        assert "--db-path" in cmd
        idx = cmd.index("--db-path")
        assert cmd[idx + 1] == "cache/market.duckdb"

    def test_no_db_path_when_empty(self):
        from studio_backend.services.tasks import _build_signal_command
        req = SignalScanRequest(
            date="2026-03-14",
            output_dir="test_output",
            db_path="",
        )
        cmd, _ = _build_signal_command(req)
        assert "--db-path" not in cmd

    def test_all_required_args_present(self):
        from studio_backend.services.tasks import _build_signal_command
        req = SignalScanRequest(
            date="2026-03-14",
            output_dir="test_output",
            db_path="cache/market.duckdb",
        )
        cmd, _ = _build_signal_command(req)
        assert "--date" in cmd
        assert "2026-03-14" in cmd
        assert "--db-path" in cmd
