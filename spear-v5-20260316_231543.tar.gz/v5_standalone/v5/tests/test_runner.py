from __future__ import annotations

from v5.backtest.runner import _apply_trade_costs, _apply_cash
from v4.execution.state_machine import Decision
from v5.config.defaults import load_default_config


def test_apply_trade_costs_buy():
    cfg = load_default_config()
    dec = Decision("buy", "000001", 20.0, 100, "entry:trend_spear", {})
    applied = _apply_trade_costs(cfg, dec)
    assert applied.price >= 20.0
    assert applied.meta["gross_notional"] > 0
    assert applied.meta["commission"] >= cfg.execution.min_commission
    assert applied.meta["stamp_duty"] == 0
    assert applied.meta["net_cash_delta"] < 0


def test_apply_trade_costs_sell():
    cfg = load_default_config()
    dec = Decision("sell", "000001", 22.0, 100, "time_exit", {})
    applied = _apply_trade_costs(cfg, dec)
    assert applied.price <= 22.0
    assert applied.meta["stamp_duty"] > 0
    assert applied.meta["net_cash_delta"] > 0


def test_apply_cash_buy_sell_roundtrip():
    cfg = load_default_config()
    cash = 1_000_000.0
    buy_dec = _apply_trade_costs(cfg, Decision("buy", "000001", 20.0, 100, "entry:test", {}))
    cash = _apply_cash(cash, buy_dec)
    assert cash < 1_000_000.0
    sell_dec = _apply_trade_costs(cfg, Decision("sell", "000001", 22.0, 100, "time_exit", {}))
    cash = _apply_cash(cash, sell_dec)
    assert cash > 0
