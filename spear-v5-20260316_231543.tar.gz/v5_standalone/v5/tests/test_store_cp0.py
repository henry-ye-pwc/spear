"""CP-0: Test infrastructure — verify duckdb dependency and synthetic data generators."""
from __future__ import annotations

import numpy as np
import pandas as pd
import pytest

from v5.tests.fixtures import make_bars, make_bars_batch


# ---------------------------------------------------------------------------
# DuckDB import
# ---------------------------------------------------------------------------

def test_duckdb_import():
    import duckdb
    conn = duckdb.connect(":memory:")
    result = conn.execute("SELECT 42 AS answer").fetchone()
    assert result == (42,)
    conn.close()


def test_duckdb_dataframe_roundtrip():
    """float64 survives DuckDB DOUBLE roundtrip bit-exactly."""
    import duckdb
    conn = duckdb.connect(":memory:")
    df = pd.DataFrame({
        "val": [0.1, 0.2, 1e-15, 1e15, np.pi, -np.e, 0.0],
    })
    conn.execute("CREATE TABLE t AS SELECT * FROM df")
    out = conn.execute("SELECT * FROM t").df()
    np.testing.assert_array_equal(df["val"].values, out["val"].values)
    conn.close()


def test_duckdb_nan_roundtrip():
    """NaN → NULL → NaN roundtrip."""
    import duckdb
    conn = duckdb.connect(":memory:")
    df = pd.DataFrame({"val": [1.0, np.nan, 3.0]})
    conn.execute("CREATE TABLE t AS SELECT * FROM df")
    out = conn.execute("SELECT * FROM t").df()
    assert pd.isna(out["val"].iloc[1])
    assert out["val"].iloc[0] == 1.0
    assert out["val"].iloc[2] == 3.0
    conn.close()


# ---------------------------------------------------------------------------
# Synthetic data generators
# ---------------------------------------------------------------------------

def test_make_bars_realistic():
    df = make_bars("000001", n_days=200)
    assert len(df) == 200
    assert list(df.columns) == ["open", "high", "low", "close", "volume", "amount"]
    assert isinstance(df.index, pd.DatetimeIndex)
    assert (df["low"] <= df["open"]).all()
    assert (df["low"] <= df["close"]).all()
    assert (df["high"] >= df["open"]).all()
    assert (df["high"] >= df["close"]).all()
    assert (df["volume"] > 0).all()
    assert df["amount"].notna().all()


def test_make_bars_deterministic():
    a = make_bars("000001", seed=99)
    b = make_bars("000001", seed=99)
    pd.testing.assert_frame_equal(a, b)


def test_make_bars_different_seeds():
    a = make_bars("000001", seed=1)
    b = make_bars("000001", seed=2)
    assert not a["close"].equals(b["close"])


def test_make_bars_with_nan():
    df = make_bars("000001", include_nan_amount=True)
    assert df["amount"].isna().sum() > 0
    assert df["close"].notna().all()


def test_make_bars_with_placeholder():
    df = make_bars("000001", placeholder_tail=3)
    assert (df["volume"].iloc[-3:] == 0).all()
    assert (df["volume"].iloc[:-3] > 0).all()


def test_make_bars_batch():
    syms = ["000001", "000002", "600000"]
    batch = make_bars_batch(syms, n_days=100)
    assert set(batch.keys()) == set(syms)
    for sym, df in batch.items():
        assert len(df) == 100
        assert (df["volume"] > 0).all()
    assert not batch["000001"]["close"].equals(batch["000002"]["close"])


def test_make_bars_index_is_business_days():
    df = make_bars("000001", start="2025-06-02", n_days=5)
    weekdays = df.index.weekday
    assert (weekdays < 5).all(), "All bars should be on weekdays"
