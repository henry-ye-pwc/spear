"""Shared synthetic data generators for DuckDB migration tests."""
from __future__ import annotations

import numpy as np
import pandas as pd


def make_bars(
    symbol: str = "000001",
    start: str = "2025-01-02",
    n_days: int = 200,
    seed: int = 42,
    base_price: float = 10.0,
    include_nan_amount: bool = False,
    placeholder_tail: int = 0,
) -> pd.DataFrame:
    """Generate realistic synthetic OHLCV bars for one symbol.

    Parameters
    ----------
    placeholder_tail : int
        If > 0, the last N bars will have volume=0 (mootdx placeholder).
    include_nan_amount : bool
        If True, a few amount values will be NaN.
    """
    rng = np.random.default_rng(seed)
    dates = pd.bdate_range(start, periods=n_days, freq="B")

    returns = rng.normal(0.001, 0.02, n_days)
    close = base_price * np.cumprod(1 + returns)

    noise_h = rng.uniform(0.002, 0.03, n_days)
    noise_l = rng.uniform(0.002, 0.03, n_days)
    high = close * (1 + noise_h)
    low = close * (1 - noise_l)

    open_ = low + rng.uniform(0.2, 0.8, n_days) * (high - low)

    volume = rng.uniform(500_000, 5_000_000, n_days).round(0)
    amount = close * volume

    if placeholder_tail > 0:
        volume[-placeholder_tail:] = 0.0
        amount[-placeholder_tail:] = 0.0

    df = pd.DataFrame(
        {
            "open": open_,
            "high": high,
            "low": low,
            "close": close,
            "volume": volume,
            "amount": amount,
        },
        index=dates,
    )
    df.index.name = "date"

    if include_nan_amount:
        nan_idx = rng.choice(len(df), size=min(3, len(df)), replace=False)
        df.iloc[nan_idx, df.columns.get_loc("amount")] = np.nan

    return df


def make_bars_batch(
    symbols: list[str],
    start: str = "2025-01-02",
    n_days: int = 200,
    base_seed: int = 42,
) -> dict[str, pd.DataFrame]:
    """Generate bars for multiple symbols with different seeds."""
    return {
        sym: make_bars(symbol=sym, start=start, n_days=n_days, seed=base_seed + i)
        for i, sym in enumerate(symbols)
    }
