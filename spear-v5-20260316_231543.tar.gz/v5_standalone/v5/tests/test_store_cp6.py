"""CP-6: Calendar + freshness in daily_signal_job.py.

Tests the DuckDB-backed calendar integration in the signal job.
"""
from __future__ import annotations

import pandas as pd
import pytest

from v5.data.store import MarketStore
from v5.tests.fixtures import make_bars, make_bars_batch


class TestStoreCalendarForSignalJob:
    """Verify MarketStore.trading_dates() provides correct calendar
    for the signal job scenarios that caused the 3-13 bug."""

    @pytest.fixture
    def populated_store(self, tmp_path):
        store = MarketStore(db_path=str(tmp_path / "cal.duckdb"))
        idx = pd.bdate_range("2026-01-02", "2026-03-13", freq="B")
        df = pd.DataFrame({
            "open": 10.0, "high": 10.5, "low": 9.5,
            "close": 10.2, "volume": 1000000.0, "amount": 10200000.0,
        }, index=idx)
        store.upsert_bars("000001", df)
        store.mark_refreshed("000001")
        yield store
        store.close()

    def test_friday_included_when_run_on_saturday(self, populated_store):
        """The original bug: running on Saturday 3-14, calendar should include Friday 3-13."""
        cal = populated_store.trading_dates(up_to="2026-03-14", n=7)
        assert "2026-03-13" in cal, "Friday 3-13 should be in the calendar"
        assert "2026-03-14" not in cal, "Saturday 3-14 should NOT be in calendar"

    def test_calendar_includes_recent_trading_days(self, populated_store):
        cal = populated_store.trading_dates(up_to="2026-03-14", n=5)
        assert len(cal) == 5
        assert cal[-1] == "2026-03-13"  # last trading day is Friday

    def test_calendar_with_watch_window(self, populated_store):
        """Simulate watch_window + 2 = 7 lookback."""
        cal = populated_store.trading_dates(up_to="2026-03-14", n=7)
        assert len(cal) == 7
        assert cal == sorted(cal)

    def test_calendar_exact_date(self, populated_store):
        """When run on a trading day, that day is included."""
        cal = populated_store.trading_dates(up_to="2026-03-13", n=5)
        assert "2026-03-13" in cal

    def test_calendar_ytd(self, populated_store):
        """YTD mode needs all dates from Jan 1."""
        cal = populated_store.trading_dates(up_to="2026-03-13", n=300)
        ytd = [d for d in cal if d >= "2026-01-01"]
        assert len(ytd) > 40
        assert ytd[0] == "2026-01-02"
        assert ytd[-1] == "2026-03-13"

    def test_multi_symbol_calendar(self, tmp_path):
        """Calendar is the union of all symbols' trading dates."""
        store = MarketStore(db_path=str(tmp_path / "multi.duckdb"))
        batch = make_bars_batch(["000001", "000002", "600000"], n_days=200)
        store.upsert_bars_batch(batch)
        cal = store.trading_dates(up_to="2026-12-31", n=300)
        assert len(cal) == 200
        store.close()


class TestStoreEffectiveDate:
    """The 'effective_date' logic in the signal job."""

    def test_latest_bar_as_effective(self, tmp_path):
        store = MarketStore(db_path=str(tmp_path / "eff.duckdb"))
        idx = pd.bdate_range("2026-03-02", "2026-03-13", freq="B")
        df = pd.DataFrame({
            "open": 10.0, "high": 10.5, "low": 9.5,
            "close": 10.2, "volume": 1000000.0, "amount": 10200000.0,
        }, index=idx)
        store.upsert_bars("000001", df)
        cal = store.trading_dates(up_to="2026-03-14", n=10)
        effective = cal[-1] if cal else "2026-03-14"
        assert effective == "2026-03-13"
        store.close()

    def test_stale_data_detection(self, tmp_path):
        """If data only goes to 3-12, effective should be 3-12, not 3-14."""
        store = MarketStore(db_path=str(tmp_path / "stale.duckdb"))
        idx = pd.bdate_range("2026-03-02", "2026-03-12", freq="B")
        df = pd.DataFrame({
            "open": 10.0, "high": 10.5, "low": 9.5,
            "close": 10.2, "volume": 1000000.0, "amount": 10200000.0,
        }, index=idx)
        store.upsert_bars("000001", df)
        cal = store.trading_dates(up_to="2026-03-14", n=10)
        effective = cal[-1] if cal else "2026-03-14"
        assert effective == "2026-03-12", "Should detect stale data ending at 3-12"
        store.close()


class TestStorePlaceholderDetection:
    """Placeholder bars (volume < 100) are stored correctly for detection."""

    def test_detect_placeholder_from_store(self, tmp_path):
        store = MarketStore(db_path=str(tmp_path / "ph.duckdb"))
        df = make_bars("000001", n_days=200, placeholder_tail=1)
        store.upsert_bars("000001", df)
        bars = store.read_bars("000001")
        last = bars.iloc[-1]
        assert float(last["volume"]) < 100
        store.close()

    def test_real_bars_not_flagged(self, tmp_path):
        store = MarketStore(db_path=str(tmp_path / "real.duckdb"))
        df = make_bars("000001", n_days=200, placeholder_tail=0)
        store.upsert_bars("000001", df)
        bars = store.read_bars("000001")
        last = bars.iloc[-1]
        assert float(last["volume"]) >= 100
        store.close()


class TestBuildParserDbPath:
    def test_db_path_arg_exists(self):
        from v5.daily_signal_job import build_parser
        parser = build_parser()
        args = parser.parse_args(["--date", "2026-03-14", "--db-path", "cache/market.duckdb"])
        assert args.db_path == "cache/market.duckdb"

    def test_db_path_default_empty(self):
        from v5.daily_signal_job import build_parser
        parser = build_parser()
        args = parser.parse_args(["--date", "2026-03-14"])
        assert args.db_path == ""
