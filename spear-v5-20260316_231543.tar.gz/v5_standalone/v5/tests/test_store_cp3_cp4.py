"""CP-3 & CP-4: DataFeed reads from / writes to DuckDB.

Tests use a mock mootdx client to avoid network calls.
"""
from __future__ import annotations

from unittest.mock import MagicMock, patch

import numpy as np
import pandas as pd
import pytest

from cq_backtest.data.feed import DataFeed
from v5.data.store import MarketStore
from v5.tests.fixtures import make_bars


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

class FakeMootdxClient:
    """Simulates mootdx Quotes client for testing."""

    def __init__(self, bars_data: dict[str, pd.DataFrame] | None = None):
        self._bars_data = bars_data or {}

    def bars(self, symbol, frequency=9, start=0, offset=800, market=0):
        df = self._bars_data.get(symbol)
        if df is None:
            return pd.DataFrame()
        chunk = df.iloc[start:start + offset].copy()
        if chunk.empty:
            return pd.DataFrame()
        chunk = chunk.reset_index()
        if "date" in chunk.columns:
            chunk = chunk.rename(columns={"date": "datetime"})
        chunk = chunk.set_index("datetime")
        return chunk

    def xdxr(self, symbol):
        return pd.DataFrame()


def _make_feed_with_store(tmp_path, pre_loaded=None, fake_client_data=None):
    """Create a DataFeed wired to a DuckDB store."""
    db_path = str(tmp_path / "feed_test.duckdb")
    store = MarketStore(db_path=db_path)
    if pre_loaded:
        for sym, df in pre_loaded.items():
            store.upsert_bars(sym, df)
            store.mark_refreshed(sym)
    cache_dir = str(tmp_path / "cache")
    feed = DataFeed(cache_dir=cache_dir, store=store)
    if fake_client_data is not None:
        feed.client = FakeMootdxClient(fake_client_data)
    return feed, store


# =====================================================================
# CP-3: Read path
# =====================================================================

class TestDuckDBRead:
    def test_read_existing_data(self, tmp_path):
        """get_kline returns data from DuckDB when symbol is pre-loaded."""
        df = make_bars("000001", n_days=200)
        feed, store = _make_feed_with_store(tmp_path, pre_loaded={"000001": df})
        result = feed.get_kline("000001", end_date=str(df.index[-1].date()))
        assert len(result) > 0
        assert isinstance(result.index, pd.DatetimeIndex)
        store.close()

    def test_read_with_count_filter(self, tmp_path):
        df = make_bars("000001", n_days=200)
        feed, store = _make_feed_with_store(tmp_path, pre_loaded={"000001": df})
        result = feed.get_kline("000001", count=50)
        assert len(result) == 50
        store.close()

    def test_read_with_end_date_filter(self, tmp_path):
        df = make_bars("000001", start="2025-01-02", n_days=300)
        feed, store = _make_feed_with_store(tmp_path, pre_loaded={"000001": df})
        result = feed.get_kline("000001", end_date="2025-06-01", count=999)
        assert result.index.max() <= pd.Timestamp("2025-06-01")
        store.close()

    def test_read_empty_symbol(self, tmp_path):
        """Unknown symbol with cache_only returns empty DataFrame."""
        feed, store = _make_feed_with_store(tmp_path)
        result = feed.get_kline("999999", cache_only=True)
        assert result.empty
        store.close()

    def test_float64_preservation(self, tmp_path):
        """Values survive the DuckDB roundtrip bit-exactly."""
        df = make_bars("000001", n_days=200, base_price=99.876)
        feed, store = _make_feed_with_store(tmp_path, pre_loaded={"000001": df})
        result = feed.get_kline("000001", count=9999)
        for col in ["open", "high", "low", "close", "volume", "amount"]:
            np.testing.assert_array_equal(
                df[col].values, result[col].values,
                err_msg=f"Column {col} not bit-exact",
            )
        store.close()

    def test_returns_sorted_datetimeindex(self, tmp_path):
        df = make_bars("000001", n_days=100)
        feed, store = _make_feed_with_store(tmp_path, pre_loaded={"000001": df})
        result = feed.get_kline("000001", count=9999)
        assert isinstance(result.index, pd.DatetimeIndex)
        assert result.index.is_monotonic_increasing
        store.close()

    def test_cache_only_mode(self, tmp_path):
        """cache_only=True reads from store without connecting to mootdx."""
        df = make_bars("000001", n_days=200)
        feed, store = _make_feed_with_store(tmp_path, pre_loaded={"000001": df})
        result = feed.get_kline("000001", cache_only=True)
        assert len(result) > 0
        assert feed.client is None  # never connected
        store.close()


# =====================================================================
# CP-4: Write path
# =====================================================================

class TestDuckDBWrite:
    def test_force_refresh_writes_to_store(self, tmp_path):
        """force_refresh fetches from mootdx and persists to DuckDB."""
        bars = make_bars("000001", n_days=200)
        feed, store = _make_feed_with_store(
            tmp_path, fake_client_data={"000001": bars}
        )
        result = feed.get_kline("000001", force_refresh=True)
        assert len(result) > 0
        db_bars = store.read_bars("000001")
        assert len(db_bars) == 200
        store.close()

    def test_fetch_when_not_in_store(self, tmp_path):
        """When symbol is not in store, fetches from mootdx and writes."""
        bars = make_bars("000001", n_days=200)
        feed, store = _make_feed_with_store(
            tmp_path, fake_client_data={"000001": bars}
        )
        result = feed.get_kline("000001", end_date=str(bars.index[-1].date()))
        assert len(result) > 0
        db_bars = store.read_bars("000001")
        assert len(db_bars) == 200
        store.close()

    def test_incremental_upsert(self, tmp_path):
        """Existing data in store + new bars from mootdx → upsert merges."""
        old_bars = make_bars("000001", start="2025-01-02", n_days=200, seed=1)
        new_bars = make_bars("000001", start="2025-01-02", n_days=210, seed=1)
        feed, store = _make_feed_with_store(
            tmp_path,
            pre_loaded={"000001": old_bars},
            fake_client_data={"000001": new_bars},
        )
        feed.store.mark_refreshed("000001")
        # Force refresh to trigger full fetch
        result = feed.get_kline("000001", force_refresh=True)
        db_bars = store.read_bars("000001")
        assert len(db_bars) == 210
        store.close()

    def test_no_pkl_created(self, tmp_path):
        """DuckDB mode should not create PKL files."""
        bars = make_bars("000001", n_days=200)
        feed, store = _make_feed_with_store(
            tmp_path, fake_client_data={"000001": bars}
        )
        feed.get_kline("000001", force_refresh=True)
        import os
        cache_dir = str(tmp_path / "cache")
        pkl_files = [f for f in os.listdir(cache_dir) if f.endswith(".pkl")] if os.path.exists(cache_dir) else []
        assert len(pkl_files) == 0
        store.close()

    def test_mark_refreshed_after_write(self, tmp_path):
        bars = make_bars("000001", n_days=200)
        feed, store = _make_feed_with_store(
            tmp_path, fake_client_data={"000001": bars}
        )
        feed.get_kline("000001", force_refresh=True)
        row = store._conn.execute(
            "SELECT last_fetched_at FROM symbols_meta WHERE symbol = '000001'"
        ).fetchone()
        assert row is not None
        assert row[0] > 0  # epoch timestamp
        store.close()


# =====================================================================
# Legacy PKL path still works
# =====================================================================

class TestPklFallback:
    def test_no_store_uses_pkl(self, tmp_path):
        """When store=None, DataFeed uses the original PKL path."""
        cache_dir = str(tmp_path / "pkl_cache")
        feed = DataFeed(cache_dir=cache_dir)
        assert feed.store is None
        bars = make_bars("000001", n_days=200)
        feed._remember_kline("000001", bars)
        result = feed.get_kline("000001", end_date=str(bars.index[-1].date()))
        assert len(result) > 0
