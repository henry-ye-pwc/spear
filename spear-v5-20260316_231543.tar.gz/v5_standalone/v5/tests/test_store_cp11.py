"""CP-11: Fix all data fetch paths — PKL root fix + DuckDB defaults.

Tests:
- PKL TTL gate tightening (no more stale data on weekends)
- PKL incremental save (always persists merged data)
- Default db_path in SignalScanRequest and BacktestRequest
- _build_backtest_command includes --db-path
- Auto-migration trigger
- MootdxProvider reads from PKL (no DuckDB in workers)
"""
from __future__ import annotations

import os
import time
from pathlib import Path
from unittest.mock import MagicMock, patch

import numpy as np
import pandas as pd
import pytest

from v5.data.store import MarketStore
from v5.tests.fixtures import make_bars


# ---------------------------------------------------------------------------
# PKL root fix tests
# ---------------------------------------------------------------------------

class TestPklTtlGateFix:
    """The TTL gate should NOT return stale data when there's a gap of >= 2 days."""

    def test_stale_pkl_not_returned_on_saturday(self, tmp_path):
        """Scenario: PKL has data to 03-12 (Thu), end_date is 03-14 (Sat).
        With cache_age < TTL, should NOT return stale data."""
        from cq_backtest.data.feed import DataFeed
        feed = DataFeed(cache_dir=str(tmp_path))
        cache_file = tmp_path / "000001_full.pkl"

        dates = pd.bdate_range("2025-01-02", periods=200)
        df = pd.DataFrame({"open": 10, "high": 11, "low": 9, "close": 10, "volume": 1e6, "amount": 1e7}, index=dates)
        df.to_pickle(str(cache_file))
        os.utime(str(cache_file), (time.time(), time.time()))

        last_date = str(dates[-1])[:10]
        two_days_later = str((dates[-1] + pd.Timedelta(days=2)))[:10]

        assert feed._cache_exactly_covers_end_date(df, two_days_later) is False

    def test_exact_cover_still_returns_from_cache(self, tmp_path):
        """When cache exactly covers end_date, TTL gate should work normally."""
        from cq_backtest.data.feed import DataFeed
        feed = DataFeed(cache_dir=str(tmp_path))

        dates = pd.bdate_range("2025-01-02", periods=200)
        df = pd.DataFrame({"open": 10, "high": 11, "low": 9, "close": 10, "volume": 1e6, "amount": 1e7}, index=dates)
        last_date = str(dates[-1])[:10]

        assert feed._cache_exactly_covers_end_date(df, last_date) is True


class TestPklIncrementalSaveFix:
    """Incremental fetch should always persist merged data, not gate on _cache_exactly_covers."""

    def test_incremental_saves_even_without_exact_cover(self, tmp_path):
        """After an incremental fetch, merged data should be saved to PKL
        even when end_date is beyond the fetched data."""
        from cq_backtest.data.feed import DataFeed

        dates = pd.bdate_range("2025-01-02", periods=200)
        old_df = pd.DataFrame(
            {"open": 10, "high": 11, "low": 9, "close": 10, "volume": 1e6, "amount": 1e7},
            index=dates[:-5],
        )
        cache_file = tmp_path / "000001_full.pkl"
        old_df.to_pickle(str(cache_file))

        new_bars = pd.DataFrame(
            {"open": 10, "high": 11, "low": 9, "close": 10, "volume": 1e6, "amount": 1e7},
            index=dates[-7:],
        )

        feed = DataFeed(cache_dir=str(tmp_path))
        feed._ensure_connected = lambda: None
        feed.client = MagicMock()
        feed._fetch_latest_bars = MagicMock(return_value=new_bars)
        feed._fetch_full_history = MagicMock(return_value=pd.DataFrame())

        end_beyond = str((dates[-1] + pd.Timedelta(days=3)))[:10]
        result = feed._get_kline_pkl("000001", end_date=end_beyond, count=250)

        saved = pd.read_pickle(str(cache_file))
        assert len(saved) >= len(old_df)
        assert saved.index.max() >= dates[-1]


# ---------------------------------------------------------------------------
# Studio default db_path tests
# ---------------------------------------------------------------------------

class TestDefaultDbPath:
    def test_signal_scan_request_default(self):
        from studio_backend.models import SignalScanRequest
        req = SignalScanRequest(date="2026-03-14", output_dir="test")
        assert req.db_path == "cache/market.duckdb"

    def test_backtest_request_default(self):
        from studio_backend.models import BacktestRequest
        req = BacktestRequest(start="2025-01-01", end="2025-12-31", output_dir="test")
        assert req.db_path == "cache/market.duckdb"

    def test_signal_scan_custom_db_path(self):
        from studio_backend.models import SignalScanRequest
        req = SignalScanRequest(date="2026-03-14", output_dir="test", db_path="/tmp/custom.duckdb")
        assert req.db_path == "/tmp/custom.duckdb"

    def test_backtest_custom_db_path(self):
        from studio_backend.models import BacktestRequest
        req = BacktestRequest(start="2025-01-01", end="2025-12-31", output_dir="test", db_path="/tmp/custom.duckdb")
        assert req.db_path == "/tmp/custom.duckdb"


class TestBuildBacktestCommand:
    def test_includes_db_path(self):
        from studio_backend.models import BacktestRequest
        from studio_backend.services.tasks import command_preview
        preview = command_preview(
            "backtest",
            BacktestRequest(start="2025-01-01", end="2025-12-31", output_dir="x").model_dump(),
        )
        assert "--db-path" in preview
        assert "cache/market.duckdb" in preview

    def test_custom_db_path_in_command(self):
        from studio_backend.models import BacktestRequest
        from studio_backend.services.tasks import command_preview
        preview = command_preview(
            "backtest",
            BacktestRequest(
                start="2025-01-01", end="2025-12-31",
                output_dir="x", db_path="/data/my.duckdb",
            ).model_dump(),
        )
        assert "/data/my.duckdb" in preview

    def test_signal_command_includes_db_path(self):
        from studio_backend.models import SignalScanRequest
        from studio_backend.services.tasks import command_preview
        preview = command_preview(
            "signal_scan",
            SignalScanRequest(date="2026-03-14", output_dir="y").model_dump(),
        )
        assert "--db-path" in preview
        assert "cache/market.duckdb" in preview


class TestAutoMigration:
    def test_auto_migrate_when_store_empty(self, tmp_path):
        """When DuckDB is empty and PKL files exist, migration runs."""
        from v5.data.migrate_pkl import migrate

        pkl_dir = tmp_path / "cache"
        pkl_dir.mkdir()
        bars = make_bars("000001", n_days=200)
        bars.to_pickle(str(pkl_dir / "000001_full.pkl"))

        db_path = str(tmp_path / "market.duckdb")
        store = MarketStore(db_path=db_path)
        assert store.symbol_count() == 0

        migrate(str(pkl_dir), store, verify=False)  # type: ignore[arg-type]
        assert store.symbol_count() == 1
        assert store.total_bar_count() == 200
        store.close()

    def test_no_migrate_when_store_has_data(self, tmp_path):
        """When DuckDB already has data, no migration needed."""
        db_path = str(tmp_path / "market.duckdb")
        store = MarketStore(db_path=db_path)
        bars = make_bars("000001", n_days=200)
        store.upsert_bars("000001", bars)
        store.mark_refreshed("000001")
        assert store.symbol_count() == 1
        store.close()


class TestMootdxProviderPkl:
    def test_provider_uses_pkl(self, tmp_path):
        """MootdxProvider reads from PKL cache (no DuckDB in workers)."""
        from v5.data.providers.mootdx_provider import MootdxProvider
        pkl_dir = tmp_path / "cache"
        pkl_dir.mkdir()
        bars = make_bars("000001", n_days=300)
        bars.to_pickle(str(pkl_dir / "000001_full.pkl"))

        prov = MootdxProvider(
            cache_dir=str(pkl_dir),
            warmup_bars=200,
            cache_only=True,
        )
        end = str(bars.index[-1])[:10]
        start = str(bars.index[0])[:10]
        df = prov.load_symbol("000001", start=start, end=end)
        assert not df.empty


class TestRunPyParser:
    def test_db_path_arg_exists(self):
        from v5.run import build_parser
        parser = build_parser()
        args = parser.parse_args(["--start", "2025-01-01", "--end", "2025-12-31",
                                   "--db-path", "cache/market.duckdb"])
        assert args.db_path == "cache/market.duckdb"

    def test_db_path_default_empty(self):
        from v5.run import build_parser
        parser = build_parser()
        args = parser.parse_args(["--start", "2025-01-01", "--end", "2025-12-31"])
        assert args.db_path == ""
