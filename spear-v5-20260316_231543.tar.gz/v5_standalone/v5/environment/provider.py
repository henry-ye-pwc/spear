from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

import pandas as pd

from v4.environment.provider import infer_name_theme


@dataclass(slots=True)
class V5EnvironmentProvider:
    universe: pd.DataFrame
    sector_cache_path: str = "./v5/data/static/stock_sectors_cache.csv"
    lhb_cache_path: str = "./output/lhb_cache.csv"
    stock_meta: dict[str, dict] = field(default_factory=dict)
    lhb: pd.DataFrame = field(default_factory=pd.DataFrame)

    def load(self) -> None:
        self.stock_meta = {}
        if not self.universe.empty:
            for _, row in self.universe.iterrows():
                symbol = str(row["symbol"]).zfill(6)
                name = str(row.get("name", "") or "")
                self.stock_meta[symbol] = {
                    "name": name,
                    "name_theme": infer_name_theme(name),
                    "industry": "",
                }

        sector_path = Path(self.sector_cache_path)
        if sector_path.exists():
            sectors = pd.read_csv(sector_path)
            sectors["code"] = sectors["code"].astype(str).str.zfill(6)
            for _, row in sectors.iterrows():
                meta = self.stock_meta.setdefault(str(row["code"]).zfill(6), {"name": "", "name_theme": "其他", "industry": ""})
                meta["industry"] = str(row.get("industry", "") or "")

        lhb_path = Path(self.lhb_cache_path)
        if lhb_path.exists():
            df = pd.read_csv(lhb_path)
            if "代码" in df.columns and "上榜日" in df.columns and "龙虎榜净买额" in df.columns:
                df["代码"] = df["代码"].astype(str).str.zfill(6)
                df["上榜日"] = pd.to_datetime(df["上榜日"])
                self.lhb = df[["代码", "上榜日", "龙虎榜净买额"]].copy()
            else:
                self.lhb = pd.DataFrame()
        else:
            self.lhb = pd.DataFrame()

    def get_symbol_meta(self, symbol: str) -> dict:
        return dict(self.stock_meta.get(symbol, {"name": "", "name_theme": "其他", "industry": ""}))

    def _ensure_lhb_index(self) -> None:
        """Build per-symbol index for fast LHB lookups (lazy, once)."""
        if hasattr(self, '_lhb_by_symbol'):
            return
        self._lhb_by_symbol: dict[str, pd.DataFrame] = {}
        if not self.lhb.empty:
            for sym, grp in self.lhb.groupby("代码"):
                self._lhb_by_symbol[str(sym)] = grp.sort_values("上榜日")

    def recent_lhb_net_sell(self, symbol: str, date: str, lookback_days: int = 5) -> bool:
        if self.lhb.empty:
            return False
        self._ensure_lhb_index()
        sub = self._lhb_by_symbol.get(symbol)
        if sub is None:
            return False
        ts = pd.Timestamp(date)
        window_start = ts - pd.Timedelta(days=lookback_days)
        mask = (sub["上榜日"] >= window_start) & (sub["上榜日"] <= ts)
        filtered = sub[mask]
        if filtered.empty:
            return False
        return float(filtered["龙虎榜净买额"].sum()) < 0

