from __future__ import annotations

import hashlib
import json
import os
import time
from concurrent.futures import ProcessPoolExecutor, ThreadPoolExecutor
from dataclasses import dataclass, field

import pandas as pd

from v4.data.adapter import preprocess_daily
from v4.features import add_robust_volume_features, add_sequence_features, add_structure_features
from v4.models.registry import count_signals, detect_signals
from v5.config.defaults import V5Config
from v5.data.router import V5DataRouter
from v5.environment.provider import V5EnvironmentProvider

FEATURE_PIPELINE_VERSION = "doc_metrics_v2_arrow"

_STOCK_PREFIXES = ("000", "001", "002", "003", "300", "301", "600", "601", "603", "605", "688", "689")


def _is_stock_symbol(sym: str) -> bool:
    """Return True if *sym* looks like an A-share individual stock (not ETF/index/bond)."""
    s = str(sym).zfill(6)
    return s.startswith(_STOCK_PREFIXES)


def _log(msg: str) -> None:
    print(msg, flush=True)


# ---------------------------------------------------------------------------
# Feature cache helpers.
#
# Caches the output of _prepare_frame() (preprocess + volume + sequence +
# structure features) as Feather (Arrow IPC) files for zero-copy mmap reads.
# Cache key is symbol + feature-config hash.  Freshness is determined by
# comparing feather mtime vs DuckDB last_fetched_at (or PKL mtime fallback).
# ---------------------------------------------------------------------------

def _feature_config_hash(cfg: V5Config) -> str:
    fc = cfg.features
    key = (f"{FEATURE_PIPELINE_VERSION}:{fc.vol_window}:{fc.sequence_window}:{fc.peak_window}:"
           f"{fc.drawdown_min}:{fc.peak_touch_eps}:{fc.consolidation_window}")
    return hashlib.md5(key.encode()).hexdigest()[:8]


def _feature_cache_path(symbol: str, cfg: V5Config, cache_dir: str) -> str:
    return os.path.join(cache_dir, f"{symbol}_{_feature_config_hash(cfg)}.arrow")


def _load_cached_features(
    symbol: str, cfg: V5Config, cache_dir: str, pkl_dir: str,
) -> pd.DataFrame | None:
    feat_path = _feature_cache_path(symbol, cfg, cache_dir)
    if not os.path.exists(feat_path):
        return None
    pkl_path = os.path.join(pkl_dir, f"{symbol}_full.pkl")
    if os.path.exists(pkl_path) and os.path.getmtime(feat_path) < os.path.getmtime(pkl_path):
        return None
    try:
        cached = pd.read_feather(feat_path)
        if "date" in cached.columns:
            cached = cached.set_index("date")
        cached.index = pd.to_datetime(cached.index)
        return cached
    except Exception:
        return None


def _save_features_cache(
    symbol: str, frame: pd.DataFrame, cfg: V5Config, cache_dir: str,
) -> None:
    path = _feature_cache_path(symbol, cfg, cache_dir)
    try:
        os.makedirs(cache_dir, exist_ok=True)
        tmp = path + ".tmp"
        out = frame.reset_index() if isinstance(frame.index, pd.DatetimeIndex) else frame
        out.to_feather(tmp)
        os.replace(tmp, path)
    except Exception:
        try:
            os.remove(tmp)
        except OSError:
            pass


@dataclass(slots=True)
class PreparedBundle:
    universe: pd.DataFrame
    raw_data: dict[str, pd.DataFrame] = field(default_factory=dict)
    feature_data: dict[str, pd.DataFrame] = field(default_factory=dict)
    dates_by_symbol: dict[str, list[str]] = field(default_factory=dict)
    idx_by_symbol_date: dict[str, dict[str, int]] = field(default_factory=dict)
    events_by_symbol_date: dict[tuple[str, str], list] = field(default_factory=dict)
    env_by_symbol_date: dict[tuple[str, str], dict] = field(default_factory=dict)
    flat_events: list[dict] = field(default_factory=list)
    env: V5EnvironmentProvider | None = None


def _prepare_frame(raw: pd.DataFrame, symbol: str, cfg: V5Config) -> pd.DataFrame:
    out = preprocess_daily(raw, symbol)
    out = add_robust_volume_features(out, window=cfg.features.vol_window)
    out = add_sequence_features(out, window=cfg.features.sequence_window)
    out = add_structure_features(
        out,
        peak_window=cfg.features.peak_window,
        drawdown_min=cfg.features.drawdown_min,
        peak_touch_eps=cfg.features.peak_touch_eps,
        consolidation_window=cfg.features.consolidation_window,
    )
    return out


def _theme_label(meta: dict, cfg: V5Config) -> str:
    if cfg.data.disable_env_mapping:
        return "其他"
    return str(meta.get("industry") or meta.get("name_theme") or "其他")


# ---------------------------------------------------------------------------
# Phase A+B worker — runs in a subprocess via ProcessPoolExecutor.
# Must be a top-level function (not a closure/lambda) for pickling.
# Reuses a module-level adapter per worker process to avoid repeated mootdx
# TCP connections (reduces ~67 connections to ~10).
# Also performs Phase B signal counting in-parallel to eliminate the
# sequential Phase B pass entirely.
# ---------------------------------------------------------------------------

_worker_adapter: V5DataRouter | None = None


def _phase_a_worker(args: tuple) -> tuple | None:
    global _worker_adapter
    (symbol, start, end, cfg, intraday_bar,
     theme_label, detect_cfg, target_set, active_event_types, *extra) = args
    preloaded_raw = extra[0] if extra else None
    preloaded_feat = extra[1] if len(extra) > 1 else None

    if preloaded_raw is not None and not preloaded_raw.empty:
        raw = preloaded_raw
    else:
        if _worker_adapter is None:
            _worker_adapter = V5DataRouter(cfg)
        raw = _worker_adapter.load_symbol(symbol, start=start, end=end)

    if raw is None or raw.empty or len(raw) < 120:
        return None

    has_intraday = intraday_bar is not None and not intraday_bar.empty
    if has_intraday:
        syn = intraday_bar.copy()
        syn["symbol"] = symbol
        keep = [c for c in raw.columns if c in syn.columns]
        raw.index = raw.index.normalize()
        syn.index = syn.index.normalize()
        raw = pd.concat([raw, syn[keep]]).sort_index()
        raw = raw[~raw.index.duplicated(keep="last")]

    raw = raw.sort_index()

    feat_cache_dir = os.path.join(cfg.data.mootdx_cache_dir, "features")
    pkl_dir = cfg.data.mootdx_cache_dir
    frame = None
    cache_hit = False
    if not has_intraday:
        cached = preloaded_feat if preloaded_feat is not None else _load_cached_features(symbol, cfg, feat_cache_dir, pkl_dir)
        if cached is not None:
            raw_first_d = raw.index.min().normalize()
            raw_last_d = raw.index.max().normalize()
            if cached.index.max().normalize() >= raw_last_d:
                frame = cached[
                    (cached.index.normalize() >= raw_first_d)
                    & (cached.index.normalize() <= raw_last_d)
                ].copy()
                if len(frame) < 120:
                    frame = None
                else:
                    cache_hit = True
    if frame is None:
        frame = _prepare_frame(raw, symbol, cfg)
        if not has_intraday:
            _save_features_cache(symbol, frame, cfg, feat_cache_dir)

    dates = [str(x)[:10] for x in frame.index]
    idx_map = {d: i for i, d in enumerate(dates)}

    # Phase B: lightweight signal counting (runs in parallel with data loading)
    if target_set is not None:
        indices = [(d, idx_map[d]) for d in target_set if d in idx_map and idx_map[d] >= 120]
    else:
        indices = [(dates[i], i) for i in range(120, len(dates)) if dates[i] >= start]

    env_b = {"theme_label": theme_label, "lhb_net_sell": False}
    signal_results: list[tuple] = []
    for date, i in indices:
        if date < start:
            continue
        counts = count_signals(
            frame, symbol, max_idx=i, env=env_b, **detect_cfg,
        )
        if active_event_types is not None:
            counts = [c for c in counts if c.event_type in active_event_types]
        long_counts = [c for c in counts if c.side == "long"]
        has_long = len(long_counts) > 0
        leader_hit = (
            1 if any(
                c.event_type in {"post_limit", "trend_spear", "failed_board"}
                and c.confidence >= 0.7
                for c in long_counts
            ) else 0
        ) if has_long else 0
        signal_results.append((date, counts, has_long, leader_hit))

    return (symbol, raw, frame, dates, idx_map, theme_label, signal_results, cache_hit)


def prepare_bundle(
    cfg: V5Config,
    start: str,
    end: str,
    pool_size: int,
    symbols: list[str] | None = None,
    active_event_types: set[str] | None = None,
    target_dates: list[str] | None = None,
    intraday_bars: dict[str, pd.DataFrame] | None = None,
    store=None,
) -> PreparedBundle:
    adapter = V5DataRouter(cfg)
    if symbols:
        requested = [str(x).zfill(6) for x in symbols]
        filtered = [s for s in requested if _is_stock_symbol(s)]
        dropped_prefix = set(requested) - set(filtered)
        if dropped_prefix:
            _log(f"[prepare] filtered {len(dropped_prefix)} non-stock prefixes")
        requested = filtered
        catalog = adapter.load_universe(1000000)
        if not catalog.empty:
            catalog = catalog.copy()
            catalog["symbol"] = catalog["symbol"].astype(str).str.zfill(6)
            catalog = catalog.drop_duplicates(subset=["symbol"], keep="first")
            meta = catalog.set_index("symbol")["name"].to_dict()
            known_stocks = set(catalog["symbol"].tolist())
            not_in_catalog = [s for s in requested if s not in known_stocks]
            if not_in_catalog:
                _log(f"[prepare] filtered {len(not_in_catalog)} delisted/index symbols")
                requested = [s for s in requested if s in known_stocks]
        else:
            meta = {}
        universe = pd.DataFrame(
            {
                "symbol": requested,
                "name": [str(meta.get(sym, "") or "") for sym in requested],
            }
        )
    else:
        universe = adapter.load_universe(pool_size)
    env = V5EnvironmentProvider(
        universe=universe,
        sector_cache_path=cfg.data.sector_cache_path,
        lhb_cache_path=cfg.data.lhb_cache_path,
    )
    env.load()
    bundle = PreparedBundle(universe=universe, env=env)

    target_set = set(target_dates) if target_dates is not None else None
    symbols_list = universe["symbol"].tolist()
    n_dates = len(target_dates) if target_dates else 0
    date_range = f"{target_dates[0]} ~ {target_dates[-1]}" if target_dates else f"{start} ~ {end}"
    _log(f"[prepare] {len(symbols_list)} symbols × {n_dates} dates ({date_range})")

    t0 = time.monotonic()

    # Pre-compute per-symbol theme labels (cheap dict lookups)
    theme_labels: dict[str, str] = {}
    for sym in symbols_list:
        sym_meta = env.get_symbol_meta(sym)
        theme_labels[sym] = _theme_label(sym_meta, cfg)

    detect_cfg = {
        "post_limit_lookback": cfg.models.post_limit_lookback,
        "trend_multi_days": cfg.models.trend_multi_spear_days,
        "attack_limit_lookback": cfg.models.attack_limit_lookback,
        "arb_limit_lookback": cfg.models.arb_limit_lookback,
        "ts_atr_stop": cfg.models.ts_atr_stop,
        "ts_iqr_filter": cfg.models.ts_iqr_filter,
        "ts_iqr_threshold": cfg.models.ts_iqr_threshold,
        "ts_elev_filter": cfg.models.ts_elev_filter,
        "ts_elev_threshold": cfg.models.ts_elev_threshold,
    }

    # ── Pre-load raw data from DuckDB (single bulk read, no worker contention) ──
    raw_cache: dict[str, pd.DataFrame] = {}
    if store is not None:
        warmup_bars = cfg.data.warmup_bars
        warmup_start = pd.Timestamp(start) - pd.offsets.BDay(warmup_bars)
        end_ts = pd.Timestamp(end).normalize()
        count = max(warmup_bars + 260, 900)
        t_load = time.monotonic()
        all_bars = store.read_bars_multi(symbols_list)
        for sym, df in all_bars.items():
            df = df[(df.index >= warmup_start) & (df.index.normalize() <= end_ts)]
            if len(df) > count:
                df = df.iloc[-count:]
            if "amount" not in df.columns and "close" in df.columns and "volume" in df.columns:
                df["amount"] = df["close"].astype(float) * df["volume"].astype(float)
            df["symbol"] = sym
            keep = [c for c in ["open", "high", "low", "close", "volume", "amount", "symbol"] if c in df.columns]
            raw_cache[sym] = df[keep].sort_index()
        _log(f"[prepare] DuckDB bulk-read: {len(raw_cache)} symbols ({time.monotonic() - t_load:.1f}s)")

    # ── Pre-load feature cache via thread pool (I/O-bound, zero-copy reads) ──
    feat_cache_dir = os.path.join(cfg.data.mootdx_cache_dir, "features")
    pkl_dir = cfg.data.mootdx_cache_dir

    def _load_one_feature(sym: str) -> tuple[str, pd.DataFrame | None]:
        try:
            return sym, _load_cached_features(sym, cfg, feat_cache_dir, pkl_dir)
        except Exception:
            return sym, None

    preloaded_features: dict[str, pd.DataFrame] = {}
    t_pre = time.monotonic()
    with ThreadPoolExecutor(max_workers=8) as tpool:
        for sym, df in tpool.map(_load_one_feature, symbols_list):
            if df is not None:
                preloaded_features[sym] = df
    if preloaded_features:
        _log(f"[prepare] pre-loaded {len(preloaded_features)} feature caches ({time.monotonic() - t_pre:.1f}s)")

    # ── Phase A+B: parallel data loading + features + signal counting ──
    n_workers = min(max(1, os.cpu_count() or 4), 10)
    work_items = [
        (sym, start, end, cfg,
         intraday_bars.get(sym) if intraday_bars else None,
         theme_labels.get(sym, "其他"),
         detect_cfg, target_set, active_event_types,
         raw_cache.get(sym),
         preloaded_features.get(sym))
        for sym in symbols_list
    ]

    loaded = 0
    skipped = 0
    cache_hits = 0
    skipped_syms: list[str] = []
    raw_events: dict[tuple[str, str], list] = {}
    day_theme_counts: dict[tuple[str, str], int] = {}
    day_theme_leaders: dict[tuple[str, str], int] = {}
    all_dates: set[str] = set()

    with ProcessPoolExecutor(max_workers=n_workers) as pool:
        for sym, result in zip(symbols_list, pool.map(_phase_a_worker, work_items, chunksize=4)):
            if result is None:
                skipped += 1
                skipped_syms.append(sym)
                continue
            symbol, raw, frame, dates, idx_map, theme_label, signal_results, hit = result
            bundle.raw_data[symbol] = raw
            bundle.feature_data[symbol] = frame
            bundle.dates_by_symbol[symbol] = dates
            bundle.idx_by_symbol_date[symbol] = idx_map
            loaded += 1
            if hit:
                cache_hits += 1

            for date, counts, has_long, leader_hit in signal_results:
                all_dates.add(date)
                raw_events[(symbol, date)] = counts
                if has_long:
                    key = (date, theme_label)
                    day_theme_counts[key] = day_theme_counts.get(key, 0) + 1
                    day_theme_leaders[key] = day_theme_leaders.get(key, 0) + leader_hit

            pass

    ab_elapsed = time.monotonic() - t0
    feat_pct = f"{cache_hits*100//loaded}%" if loaded else "0%"
    _log(f"[prepare] Phase A+B: {loaded} loaded, {skipped} skipped | features: {feat_pct} cached ({ab_elapsed:.1f}s)")
    _log(f"[prepare] signals: {len(all_dates)} dates, {len(raw_events)} pairs")

    # ── Phase C: second pass with enriched environment context ──
    # Uses ThreadPoolExecutor for parallelism — threads share memory so no IPC
    # serialization of large DataFrames.
    #
    # SKIP OPTIMIZATION: most (symbol, date) pairs have zero Phase B signals
    # AND zero enriched-env activity.  For those, Phase C is guaranteed to
    # produce zero signals too.  We pre-compute which (date, theme) combos
    # have any env activity and only run detect_signals for pairs that (a)
    # had Phase B signals or (b) belong to an active (date, theme).
    t2 = time.monotonic()
    sorted_dates = sorted(all_dates)
    feature_symbols = list(bundle.feature_data.keys())

    active_date_themes: set[tuple[str, str]] = set()
    for (dt, th), cnt in day_theme_counts.items():
        if cnt >= 1:
            active_date_themes.add((dt, th))
    for (dt, th), ldr in day_theme_leaders.items():
        if ldr >= 1:
            active_date_themes.add((dt, th))

    pairs_with_signals: set[tuple[str, str]] = {k for k, v in raw_events.items() if v}

    # Pre-index LHB symbols for fast membership check
    lhb_symbols: set[str] = set()
    if hasattr(env, 'lhb') and not env.lhb.empty:
        lhb_symbols = set(env.lhb["代码"].unique())

    # Only pre-compute LHB for pairs that Phase C will actually process
    # (have Phase B signals OR belong to an active theme).
    lhb_cache: dict[tuple[str, str], bool] = {}
    for symbol in feature_symbols:
        if symbol not in lhb_symbols:
            continue
        sym_meta = env.get_symbol_meta(symbol)
        theme_label = _theme_label(sym_meta, cfg)
        idx_map = bundle.idx_by_symbol_date.get(symbol, {})
        for date in sorted_dates:
            if date not in idx_map:
                continue
            has_signal = bool(raw_events.get((symbol, date)))
            theme_active = (date, theme_label) in active_date_themes
            if has_signal or theme_active:
                lhb_cache[(symbol, date)] = env.recent_lhb_net_sell(symbol, date)

    phase_c_results = _run_phase_c_parallel(
        feature_symbols=feature_symbols,
        sorted_dates=sorted_dates,
        bundle=bundle,
        raw_events=raw_events,
        day_theme_counts=day_theme_counts,
        day_theme_leaders=day_theme_leaders,
        active_date_themes=active_date_themes,
        lhb_cache=lhb_cache,
        detect_cfg=detect_cfg,
        active_event_types=active_event_types,
        env=env,
        cfg=cfg,
        n_threads=min(4, max(1, os.cpu_count() or 1)),
    )

    total_pairs = phase_c_results["total_pairs"]
    processed_pairs = phase_c_results["processed_pairs"]
    skipped_pairs = phase_c_results["skipped_pairs"]
    for key, val in phase_c_results["events_by_sd"].items():
        bundle.events_by_symbol_date[key] = val
    for key, val in phase_c_results["env_by_sd"].items():
        bundle.env_by_symbol_date[key] = val
    bundle.flat_events = phase_c_results["flat_events"]
    bundle.flat_events.sort(key=lambda e: (str(e.get("date", "")), str(e.get("symbol", ""))))

    total = time.monotonic() - t0
    _log(f"[prepare] Phase C: {time.monotonic() - t2:.1f}s ({processed_pairs} processed, {skipped_pairs} skipped) | total: {total:.1f}s")
    return bundle


def _phase_c_symbol_batch(
    symbols: list[str],
    sorted_dates: list[str],
    bundle: PreparedBundle,
    raw_events: dict,
    day_theme_counts: dict,
    day_theme_leaders: dict,
    active_date_themes: set,
    lhb_cache: dict,
    detect_cfg: dict,
    active_event_types: set[str] | None,
    env: V5EnvironmentProvider,
    cfg: V5Config,
) -> dict:
    """Process a batch of symbols for Phase C. Runs in a thread."""
    events_by_sd: dict[tuple[str, str], list] = {}
    env_by_sd: dict[tuple[str, str], dict] = {}
    flat_events: list[dict] = []
    total_pairs = 0
    processed_pairs = 0
    skipped_pairs = 0

    for symbol in symbols:
        sym_meta = env.get_symbol_meta(symbol)
        theme_label = _theme_label(sym_meta, cfg)
        idx_map = bundle.idx_by_symbol_date.get(symbol, {})
        sym_frame = bundle.feature_data.get(symbol)
        if sym_frame is None:
            continue

        for date in sorted_dates:
            if date not in idx_map:
                continue
            total_pairs += 1

            raw_today = raw_events.get((symbol, date), [])
            has_phase_b_signals = bool(raw_today)
            theme_is_active = (date, theme_label) in active_date_themes

            if not has_phase_b_signals and not theme_is_active:
                skipped_pairs += 1
                continue

            peer_confirmation = day_theme_counts.get((date, theme_label), 0) - (1 if has_phase_b_signals else 0)
            leader_strength = max(
                0,
                day_theme_leaders.get((date, theme_label), 0)
                - (
                    1
                    if any(e.event_type in {"post_limit", "trend_spear", "failed_board"} and e.confidence >= 0.7 for e in raw_today)
                    else 0
                ),
            )
            env_ctx = {
                "theme_label": theme_label,
                "peer_confirmation": peer_confirmation,
                "leader_strength": leader_strength,
                "lhb_net_sell": lhb_cache.get((symbol, date), False),
                "sector_hot": bool(peer_confirmation >= 2 and leader_strength >= 1),
                "_enforce_env": True,
            }
            idx = idx_map[date]
            events = detect_signals(
                sym_frame,
                symbol,
                max_idx=idx,
                **detect_cfg,
                env=env_ctx,
            )
            if active_event_types is not None:
                events = [e for e in events if e.event_type in active_event_types]
            enriched = []
            for ev in events:
                ctx = dict(ev.context)
                ctx.update({k: v for k, v in env_ctx.items() if not str(k).startswith("_")})
                ev.context = ctx
                if ev.side == "long" and ctx["lhb_net_sell"]:
                    continue
                enriched.append(ev)
                flat_events.append(
                    {
                        "date": ev.ts,
                        "symbol": ev.symbol,
                        "event_type": ev.event_type,
                        "confidence": ev.confidence,
                        "side": ev.side,
                        "entry_plan": json.dumps(ev.entry_plan, ensure_ascii=False, sort_keys=True),
                        "invalidation": json.dumps(ev.invalidation, ensure_ascii=False, sort_keys=True),
                        "exit_plan": json.dumps(ev.exit_plan, ensure_ascii=False, sort_keys=True),
                        "context": json.dumps(ev.context, ensure_ascii=False, sort_keys=True),
                    }
                )
            events_by_sd[(symbol, date)] = enriched
            env_by_sd[(symbol, date)] = {k: v for k, v in env_ctx.items() if not str(k).startswith("_")}
            processed_pairs += 1

    return {
        "events_by_sd": events_by_sd,
        "env_by_sd": env_by_sd,
        "flat_events": flat_events,
        "total_pairs": total_pairs,
        "processed_pairs": processed_pairs,
        "skipped_pairs": skipped_pairs,
    }


def _run_phase_c_parallel(
    feature_symbols: list[str],
    sorted_dates: list[str],
    bundle: PreparedBundle,
    raw_events: dict,
    day_theme_counts: dict,
    day_theme_leaders: dict,
    active_date_themes: set,
    lhb_cache: dict,
    detect_cfg: dict,
    active_event_types: set[str] | None,
    env: V5EnvironmentProvider,
    cfg: V5Config,
    n_threads: int = 4,
) -> dict:
    """Run Phase C using ThreadPoolExecutor for shared-memory parallelism."""
    if n_threads <= 1 or len(feature_symbols) < 10:
        return _phase_c_symbol_batch(
            feature_symbols, sorted_dates, bundle, raw_events,
            day_theme_counts, day_theme_leaders, active_date_themes,
            lhb_cache, detect_cfg, active_event_types, env, cfg,
        )

    n = min(n_threads, len(feature_symbols))
    batches: list[list[str]] = [[] for _ in range(n)]
    for i, sym in enumerate(feature_symbols):
        batches[i % n].append(sym)

    merged: dict = {
        "events_by_sd": {},
        "env_by_sd": {},
        "flat_events": [],
        "total_pairs": 0,
        "processed_pairs": 0,
        "skipped_pairs": 0,
    }

    with ThreadPoolExecutor(max_workers=n) as pool:
        futures = [
            pool.submit(
                _phase_c_symbol_batch,
                batch, sorted_dates, bundle, raw_events,
                day_theme_counts, day_theme_leaders, active_date_themes,
                lhb_cache, detect_cfg, active_event_types, env, cfg,
            )
            for batch in batches
        ]
        for future in futures:
            result = future.result()
            merged["events_by_sd"].update(result["events_by_sd"])
            merged["env_by_sd"].update(result["env_by_sd"])
            merged["flat_events"].extend(result["flat_events"])
            merged["total_pairs"] += result["total_pairs"]
            merged["processed_pairs"] += result["processed_pairs"]
            merged["skipped_pairs"] += result["skipped_pairs"]

    return merged
