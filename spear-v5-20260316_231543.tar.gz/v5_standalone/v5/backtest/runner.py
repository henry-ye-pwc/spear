from __future__ import annotations

import json
import math
import time
from collections import defaultdict
from dataclasses import dataclass
from typing import Any

import numpy as np
import pandas as pd

from cq_backtest.shared.market_rules import round_to_tick
from v4.backtest.engine import BacktestResult
from v4.execution.state_machine import Decision, V4ExecutionStateMachine
from v5.backtest.prepare import PreparedBundle, prepare_bundle
from v5.config.defaults import V5Config

DAY_CONTEXT_FLOAT_COLUMNS: dict[str, float] = {
    "amount": 0.0,
    "volume": 0.0,
    "amount_rank": 0.0,
    "amount_z": 0.0,
    "amount_base_hsm": 0.0,
    "amount_q95": 0.0,
    "amp_pct": 0.0,
    "close_pos": 0.0,
    "upper_shadow_pct": 0.0,
    "range_position_120": 0.0,
    "pressure_price": 0.0,
    "release_price": 0.0,
    "anchored_vwap": 0.0,
    "ma20": 0.0,
    "ma60": 0.0,
    "event_dense_mid": 0.0,
    "atr_20d_pct": 0.0,
    "vol60_iqr_norm": 0.0,
    "vol_elevation": 0.0,
    "zhang_ratio_10": 0.0,
    "xu_ratio_10": 0.0,
    "han_ratio_10": 0.0,
    "zhangyang_recent_vol_ratio_10": 0.0,
    "zhangyang_recent_price_gain_10": 0.0,
    "chengshangqixia_pressure_touch_pct": 0.0,
    "chengshangqixia_release_touch_pct": 0.0,
}

DAY_CONTEXT_BOOL_COLUMNS: dict[str, bool] = {
    "is_amount_confirm": False,
    "is_amount_explosive": False,
    "is_amount_outlier": False,
    "is_failed_board": False,
    "touch_limit_up": False,
    "near_peak_pressure": False,
    "near_release_support": False,
    "two_side_active": False,
    "consolidation_ok": False,
    "trend_up": False,
    "zhangyang_zhang_ok": False,
    "zhangyang_xu_ok": False,
    "zhangyang_han_ok": False,
    "zhangyang_explosive_recent": False,
    "zhangyang_vol_price_divergence": False,
    "zhangyang_hanshu_score": False,
    "chengshangqixia_chip_loosen": False,
    "chengshangqixia_position_ok": False,
    "chengshangqixia_score": False,
}

DAY_CONTEXT_TEXT_COLUMNS: dict[str, str] = {
    "three_gun_pattern": "",
    "current_spear_role": "",
}


@dataclass(slots=True)
class V5RunArtifacts:
    result: BacktestResult
    bundle: PreparedBundle
    equity_curve: pd.Series
    state_machine: Any = None


def _build_schedule(
    bundle: PreparedBundle, start: str, end: str,
) -> dict[str, list[str]]:
    """Pre-build date -> sorted symbol list for the backtest window."""
    date_syms: dict[str, list[str]] = defaultdict(list)
    for symbol, idx_map in bundle.idx_by_symbol_date.items():
        for date in idx_map:
            if date < start or date > end:
                continue
            date_syms[date].append(symbol)
    for syms in date_syms.values():
        syms.sort()
    return dict(sorted(date_syms.items()))


def _preextract_ohlc(
    bundle: PreparedBundle,
) -> dict[str, dict[str, np.ndarray]]:
    """Pre-extract OHLC + limit columns as numpy arrays for fast indexed access."""
    ohlc: dict[str, dict[str, np.ndarray]] = {}
    for symbol, df in bundle.feature_data.items():
        cols: dict[str, np.ndarray] = {
            "open": df["open"].values,
            "high": df["high"].values,
            "low": df["low"].values,
            "close": df["close"].values,
        }
        if "limit_up" in df.columns:
            cols["limit_up"] = df["limit_up"].values
        else:
            cols["limit_up"] = np.full(len(df), np.nan)
        if "limit_pct" in df.columns:
            cols["limit_pct"] = df["limit_pct"].values
        else:
            cols["limit_pct"] = np.full(len(df), 0.10)
        for name, default in DAY_CONTEXT_FLOAT_COLUMNS.items():
            if name in df.columns:
                cols[name] = df[name].values
            else:
                cols[name] = np.full(len(df), default)
        for name, default in DAY_CONTEXT_BOOL_COLUMNS.items():
            if name in df.columns:
                cols[name] = df[name].values
            else:
                cols[name] = np.full(len(df), default, dtype=bool)
        for name, default in DAY_CONTEXT_TEXT_COLUMNS.items():
            if name in df.columns:
                cols[name] = df[name].astype(object).values
            else:
                cols[name] = np.full(len(df), default, dtype=object)
        ohlc[symbol] = cols
    return ohlc


def _as_float(value: Any, default: float = 0.0) -> float:
    try:
        out = float(value)
    except Exception:
        return default
    return default if math.isnan(out) else out


def _as_bool(value: Any) -> bool:
    if isinstance(value, (float, np.floating)) and math.isnan(float(value)):
        return False
    return bool(value)


def _as_text(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, (float, np.floating)) and math.isnan(float(value)):
        return ""
    return str(value)


def _ratio_vs_prev_median(arr: dict[str, np.ndarray], column: str, idx: int, window: int) -> float:
    values = arr.get(column)
    if values is None or idx <= 0:
        return 0.0
    start = max(0, idx - window)
    prev = np.asarray(values[start:idx], dtype=float)
    if prev.size == 0:
        return 0.0
    prev = prev[np.isfinite(prev) & (prev > 0)]
    if prev.size == 0:
        return 0.0
    cur = _as_float(values[idx], 0.0)
    med = float(np.median(prev))
    if med <= 0:
        return 0.0
    return cur / med


def _build_day_context(arr: dict[str, np.ndarray], idx: int, env_ctx: dict[str, Any], *, close: float, limit_up: float | None) -> dict[str, Any]:
    ctx = dict(env_ctx)
    for name in DAY_CONTEXT_FLOAT_COLUMNS:
        ctx[name] = _as_float(arr[name][idx], 0.0)
    for name in DAY_CONTEXT_BOOL_COLUMNS:
        ctx[name] = _as_bool(arr[name][idx])
    for name in DAY_CONTEXT_TEXT_COLUMNS:
        ctx[name] = _as_text(arr[name][idx])
    ctx["is_limit_up_close"] = bool(limit_up is not None and limit_up > 0 and abs(close - limit_up) / limit_up < 0.005)
    amount_base_hsm = float(ctx.get("amount_base_hsm", 0.0) or 0.0)
    amount_q95 = float(ctx.get("amount_q95", 0.0) or 0.0)
    amount = float(ctx.get("amount", 0.0) or 0.0)
    ctx["amount_vs_hsm"] = amount / amount_base_hsm if amount_base_hsm > 0 else 0.0
    ctx["amount_vs_q95"] = amount / amount_q95 if amount_q95 > 0 else 0.0
    for window in (5, 10, 20):
        ctx[f"amount_vs_prev{window}_med"] = _ratio_vs_prev_median(arr, "amount", idx, window)
        ctx[f"volume_vs_prev{window}_med"] = _ratio_vs_prev_median(arr, "volume", idx, window)
    return ctx


def _apply_trade_costs(cfg: V5Config, dec: Decision) -> Decision:
    """Apply slippage, commission, and stamp duty. Returns enriched Decision."""
    if dec.price is None:
        return dec
    slip_bps = cfg.execution.buy_slippage_bps if dec.action == "buy" else cfg.execution.sell_slippage_bps
    sign = 1.0 if dec.action == "buy" else -1.0
    price = round_to_tick(dec.price * (1.0 + sign * slip_bps / 10000.0))
    notion = price * dec.qty
    commission = max(cfg.execution.min_commission, notion * cfg.execution.commission_bps / 10000.0) if dec.qty > 0 else 0.0
    stamp = notion * cfg.execution.stamp_duty_bps / 10000.0 if dec.action == "sell" else 0.0
    fee_total = commission + stamp
    net_cash_delta = -(notion + fee_total) if dec.action == "buy" else (notion - fee_total)
    meta = dict(dec.meta)
    meta.update({
        "gross_notional": round(notion, 4),
        "commission": round(commission, 4),
        "stamp_duty": round(stamp, 4),
        "fee_total": round(fee_total, 4),
        "slippage_bps": float(slip_bps),
        "net_cash_delta": round(net_cash_delta, 4),
    })
    return Decision(dec.action, dec.symbol, price, dec.qty, dec.reason, meta)


def _apply_cash(cash: float, dec: Decision) -> float:
    delta = float(dec.meta.get("net_cash_delta", 0.0))
    if delta != 0.0:
        return cash + delta
    if dec.price is None:
        return cash
    notion = dec.price * dec.qty
    if dec.action == "buy":
        return cash - notion
    if dec.action == "sell":
        return cash + notion
    return cash


def _collect_open_positions(
    sm: V4ExecutionStateMachine,
    bundle: PreparedBundle,
    last_close: dict[str, float],
) -> list[dict]:
    rows: list[dict] = []
    for symbol, pos in sm.positions.items():
        close = last_close.get(symbol, pos.entry_price)
        market_value = close * float(pos.qty)
        cost = float(pos.entry_price) * float(pos.qty)
        entry_limit_up = None
        idx_map = bundle.idx_by_symbol_date.get(symbol)
        if idx_map:
            bars = bundle.feature_data.get(symbol)
            entry_idx = idx_map.get(pos.entry_date)
            if bars is not None and entry_idx is not None:
                lu = bars.iloc[entry_idx].get("limit_up")
                if pd.notna(lu):
                    entry_limit_up = round(float(lu), 4)
        row_dict: dict = {
            "symbol": symbol,
            "signal_date": pos.signal_date,
            "entry_date": pos.entry_date,
            "entry_price": round(float(pos.entry_price), 4),
            "qty": float(pos.qty),
            "source_event": pos.source_event,
            "entry_style": pos.entry_style,
            "signal_confidence": round(float(pos.signal_confidence), 4),
            "last_close": round(close, 4),
            "market_value": round(market_value, 4),
            "cost_basis": round(cost, 4),
            "unrealized_pnl": round(market_value - cost, 4),
            "peak_price": round(float(pos.peak_price), 4),
            "peak_ret": round(float(pos.peak_ret), 6),
            "peak_date": pos.peak_date,
            "trough_price": round(float(pos.trough_price), 4),
            "trough_ret": round(float(pos.trough_ret), 6),
            "trough_date": pos.trough_date,
            "drawdown_from_peak": round(float(pos.drawdown_from_peak), 6),
            "had_limit_up_close": bool(pos.had_limit_up_close),
            "limit_up_close_days": int(pos.limit_up_close_days),
        }
        if entry_limit_up is not None:
            row_dict["entry_limit_up"] = entry_limit_up
        rows.append(row_dict)
    return rows


def _enrich_limit_prices(trades: list[dict], bundle: PreparedBundle) -> None:
    """Attach limit_up / limit_down to each trade for frontend display."""
    for t in trades:
        sym = str(t["symbol"]).zfill(6)
        frame = bundle.feature_data.get(sym)
        if frame is None:
            continue
        idx_map = bundle.idx_by_symbol_date.get(sym)
        if idx_map is None:
            continue
        idx = idx_map.get(t["date"])
        if idx is None:
            continue
        row = frame.iloc[idx]
        lp = float(row.get("limit_pct", 0.10))
        lu = row.get("limit_up")
        if pd.notna(lu):
            lu_f = float(lu)
            t["limit_up"] = round(lu_f, 4)
            prev_close = lu_f / (1 + lp)
            t["limit_down"] = round(prev_close * (1 - lp), 4)


def _build_summary(
    trades: list[dict],
    events: list[dict],
    final_cash: float,
    init_cash: float,
    open_positions: list[dict],
) -> dict:
    buys = [x for x in trades if x["action"] == "buy"]
    sells = [x for x in trades if x["action"] == "sell"]
    total_fees = 0.0
    for row in trades:
        try:
            meta = json.loads(row.get("meta", "{}")) if isinstance(row.get("meta"), str) else row.get("meta", {})
            total_fees += float(meta.get("fee_total", 0.0) or 0.0)
        except Exception:
            pass
    open_market_value = sum(float(x.get("market_value", 0.0) or 0.0) for x in open_positions)
    open_unrealized = sum(float(x.get("unrealized_pnl", 0.0) or 0.0) for x in open_positions)
    equity_final = final_cash + open_market_value
    return {
        "init_cash": init_cash,
        "final_cash": round(final_cash, 2),
        "cash_return_pct": round((final_cash / init_cash - 1.0) * 100, 2),
        "open_count": len(open_positions),
        "open_market_value": round(open_market_value, 2),
        "open_unrealized_pnl": round(open_unrealized, 2),
        "equity_final": round(equity_final, 2),
        "equity_return_pct": round((equity_final / init_cash - 1.0) * 100, 2),
        "trade_count": len(trades),
        "buy_count": len(buys),
        "sell_count": len(sells),
        "event_count": len(events),
        "total_fees": round(total_fees, 2),
    }


def _make_sm(cfg: V5Config, trace_hook: Any | None = None) -> V4ExecutionStateMachine:
    return V4ExecutionStateMachine(
        max_positions=cfg.execution.max_positions,
        base_pos_pct=cfg.execution.base_pos_pct,
        position_sizing_base=cfg.execution.position_sizing_base,
        position_multipliers={
            "trend_spear": cfg.execution.trend_spear_pos_mult,
            "post_limit": cfg.execution.post_limit_pos_mult,
            "failed_board": cfg.execution.failed_board_pos_mult,
            "youzi": cfg.execution.youzi_pos_mult,
            "sector_spear": cfg.execution.sector_spear_pos_mult,
            "attack": cfg.execution.attack_pos_mult,
            "arb": cfg.execution.arb_pos_mult,
        },
        cooldown_days=cfg.execution.cooldown_days,
        default_take_profit_pct=cfg.execution.default_take_profit_pct,
        execution_profile=cfg.execution.execution_profile,
        hunt_price_buffer_pct=cfg.execution.hunt_price_buffer_pct,
        hunt_window_days=cfg.execution.hunt_window_days,
        exit_hunt_buffer_pct=cfg.execution.exit_hunt_buffer_pct,
        exit_hunt_window_days=cfg.execution.exit_hunt_window_days,
        exit_mode=cfg.execution.exit_mode,
        trend_spear_stop_mode=cfg.execution.trend_spear_stop_mode,
        trend_spear_stop_grace_days=cfg.execution.trend_spear_stop_grace_days,
        trend_spear_trend_management_enabled=cfg.execution.trend_spear_trend_management_enabled,
        trend_spear_trend_activation_ret=cfg.execution.trend_spear_trend_activation_ret,
        trend_spear_trend_drawdown_exit=cfg.execution.trend_spear_trend_drawdown_exit,
        trend_spear_trend_stale_days=cfg.execution.trend_spear_trend_stale_days,
        trend_spear_trend_max_extension_days=cfg.execution.trend_spear_trend_max_extension_days,
        trend_spear_reentry_watch_enabled=cfg.execution.trend_spear_reentry_watch_enabled,
        trend_spear_reentry_watch_days=cfg.execution.trend_spear_reentry_watch_days,
        trend_spear_reentry_min_near_pressure_days=cfg.execution.trend_spear_reentry_min_near_pressure_days,
        trend_spear_reentry_min_near_support_days=cfg.execution.trend_spear_reentry_min_near_support_days,
        trend_spear_reentry_shrink_threshold=cfg.execution.trend_spear_reentry_shrink_threshold,
        trend_spear_reentry_expand_threshold=cfg.execution.trend_spear_reentry_expand_threshold,
        trend_spear_dynamic_hold_enabled=cfg.execution.trend_spear_dynamic_hold_enabled,
        trend_spear_limitup_extend_days=cfg.execution.trend_spear_limitup_extend_days,
        trend_spear_limitup_wide_atr_mult=cfg.execution.trend_spear_limitup_wide_atr_mult,
        trend_spear_limitup_stop_floor_pct=cfg.execution.trend_spear_limitup_stop_floor_pct,
        trend_spear_noboard_tighten_days=cfg.execution.trend_spear_noboard_tighten_days,
        trend_spear_noboard_tight_atr_mult=cfg.execution.trend_spear_noboard_tight_atr_mult,
        trend_spear_noboard_max_hold=cfg.execution.trend_spear_noboard_max_hold,
        trend_spear_vol_exhaustion_exit=cfg.execution.trend_spear_vol_exhaustion_exit,
        trace_hook=trace_hook,
    )


def run_backtest(
    cfg: V5Config,
    start: str,
    end: str,
    pool_size: int,
    initial_cash: float,
    symbols: list[str] | None = None,
    active_event_types: set[str] | None = None,
    bundle: PreparedBundle | None = None,
    store=None,
) -> V5RunArtifacts:
    if bundle is None:
        bundle = prepare_bundle(
            cfg,
            start=start,
            end=end,
            pool_size=pool_size,
            symbols=symbols,
            active_event_types=active_event_types,
            store=store,
        )

    t0 = time.monotonic()
    schedule = _build_schedule(bundle, start, end)
    ohlc = _preextract_ohlc(bundle)
    trace_events: list[dict] = []

    def _collect_trace(payload: dict[str, Any]) -> None:
        payload = dict(payload)
        payload["trace_seq"] = len(trace_events)
        trace_events.append(payload)

    sm = _make_sm(cfg, trace_hook=_collect_trace)
    print(f"[backtest] schedule built: {len(schedule)} dates, {len(ohlc)} symbols in {time.monotonic() - t0:.2f}s", flush=True)

    cash = float(initial_cash)
    trades: list[dict] = []
    equity_by_date: dict[str, float] = {}
    last_close: dict[str, float] = {}
    prev_equity: float = float(initial_cash)

    for date, symbols_today in schedule.items():
        for symbol in symbols_today:
            idx = bundle.idx_by_symbol_date[symbol][date]
            arr = ohlc[symbol]
            o = float(arr["open"][idx])
            h = float(arr["high"][idx])
            l = float(arr["low"][idx])
            c = float(arr["close"][idx])
            last_close[symbol] = c

            lu_raw = float(arr["limit_up"][idx])
            lp_raw = float(arr["limit_pct"][idx])
            lu = lu_raw if not math.isnan(lu_raw) else None
            ld = c * (1 - lp_raw) if not math.isnan(lp_raw) else None

            events = list(bundle.events_by_symbol_date.get((symbol, date), []))
            env_ctx = dict(bundle.env_by_symbol_date.get((symbol, date), {}))
            env_ctx = _build_day_context(arr, idx, env_ctx, close=c, limit_up=lu)

            decisions = sm.on_day(
                date=date,
                d_idx=idx,
                symbol=symbol,
                open_price=o,
                close=c,
                high=h,
                low=l,
                limit_up=lu,
                limit_down=ld,
                events=events,
                cash=cash,
                equity=prev_equity,
                day_context=env_ctx,
            )

            for dec in decisions:
                if dec.price is None:
                    continue
                applied = _apply_trade_costs(cfg, dec)
                if applied.action == "buy":
                    needed = abs(applied.meta.get("net_cash_delta", 0.0))
                    if cash < needed:
                        sm.positions.pop(applied.symbol, None)
                        sm.cooldowns.pop(applied.symbol, None)
                        sm.pending_fills.pop(applied.symbol, None)
                        continue
                cash = _apply_cash(cash, applied)
                assert cash >= -0.01, f"Negative cash after {applied.action} {applied.symbol}: {cash:.2f}"
                trades.append({
                    "trade_seq": len(trades),
                    "date": date,
                    "symbol": applied.symbol,
                    "action": applied.action,
                    "price": applied.price,
                    "qty": applied.qty,
                    "reason": applied.reason,
                    "meta": json.dumps(applied.meta, ensure_ascii=False, sort_keys=True),
                    "cash_after": round(cash, 2),
                })

        equity = cash
        for sym, pos in sm.positions.items():
            equity += pos.qty * last_close.get(sym, pos.entry_price)
        equity_by_date[date] = round(equity, 2)
        prev_equity = equity

    open_positions = _collect_open_positions(sm, bundle, last_close)
    _enrich_limit_prices(trades, bundle)
    equity_curve = pd.Series(equity_by_date, dtype=float)
    summary = _build_summary(trades, bundle.flat_events, cash, initial_cash, open_positions)

    result = BacktestResult(
        trades=trades,
        events=bundle.flat_events,
        open_positions=open_positions,
        trace_events=trace_events,
        summary=summary,
    )
    return V5RunArtifacts(result=result, bundle=bundle, equity_curve=equity_curve, state_machine=sm)
